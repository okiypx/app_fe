<div class="odometer-container" ng-click="setActiveCategory('slot')" ng-init="loadCounter()">
  <h1 class="odometer__heading">Progressive Jackpot</h1>
  <div class="container-jackpot">
    <div class="currency-sign">
      <img src="/mobile/common/images/odometer/won-sign.png">
    </div>
    <div class="jackpot-odometer"></div>
  </div>
</div>
