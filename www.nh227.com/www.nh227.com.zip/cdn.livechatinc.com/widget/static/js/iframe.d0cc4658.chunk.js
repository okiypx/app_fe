(this["webpackJsonp@livechat/chat-widget"] = this["webpackJsonp@livechat/chat-widget"] || []).push([
    [10],
    [, , function(e, t, n) {
        "use strict";

        function r(e, t) {
            return e + t
        }
        n.d(t, "a", (function() {
            return a
        })), n.d(t, "c", (function() {
            return c
        })), n.d(t, "d", (function() {
            return s
        })), n.d(t, "e", (function() {
            return p
        })), n.d(t, "b", (function() {
            return m
        })), n.d(t, "f", (function() {
            return v
        })), n.d(t, "g", (function() {
            return b
        })), n.d(t, "h", (function() {
            return h
        })), n.d(t, "i", (function() {
            return g
        })), n.d(t, "j", (function() {
            return y
        })), n.d(t, "k", (function() {
            return O
        })), n.d(t, "l", (function() {
            return j
        })), n.d(t, "m", (function() {
            return _
        })), n.d(t, "o", (function() {
            return w
        })), n.d(t, "p", (function() {
            return x
        })), n.d(t, "q", (function() {
            return E
        })), n.d(t, "r", (function() {
            return I
        })), n.d(t, "n", (function() {
            return S
        })), n.d(t, "s", (function() {
            return u
        })), n.d(t, "t", (function() {
            return k
        })), n.d(t, "u", (function() {
            return A
        })), n.d(t, "v", (function() {
            return z
        })), n.d(t, "w", (function() {
            return M
        })), n.d(t, "x", (function() {
            return L
        })), n.d(t, "y", (function() {
            return P
        })), n.d(t, "z", (function() {
            return R
        })), n.d(t, "A", (function() {
            return D
        })), n.d(t, "B", (function() {
            return o
        })), n.d(t, "C", (function() {
            return T
        })), n.d(t, "D", (function() {
            return B
        })), n.d(t, "E", (function() {
            return d
        })), n.d(t, "F", (function() {
            return q
        })), n.d(t, "G", (function() {
            return N
        })), n.d(t, "H", (function() {
            return l
        })), n.d(t, "J", (function() {
            return V
        })), n.d(t, "I", (function() {
            return F
        })), n.d(t, "K", (function() {
            return U
        })), n.d(t, "L", (function() {
            return H
        })), n.d(t, "M", (function() {
            return G
        })), n.d(t, "O", (function() {
            return W
        })), n.d(t, "P", (function() {
            return f
        })), n.d(t, "Q", (function() {
            return Y
        })), n.d(t, "T", (function() {
            return K
        })), n.d(t, "U", (function() {
            return Z
        })), n.d(t, "R", (function() {
            return J
        })), n.d(t, "S", (function() {
            return X
        })), n.d(t, "V", (function() {
            return Q
        })), n.d(t, "W", (function() {
            return ee
        })), n.d(t, "X", (function() {
            return ne
        })), n.d(t, "Y", (function() {
            return re
        })), n.d(t, "Z", (function() {
            return te
        })), n.d(t, "ab", (function() {
            return ie
        })), n.d(t, "bb", (function() {
            return ae
        })), n.d(t, "cb", (function() {
            return ce
        })), n.d(t, "db", (function() {
            return ue
        })), n.d(t, "eb", (function() {
            return se
        })), n.d(t, "fb", (function() {
            return de
        })), n.d(t, "gb", (function() {
            return le
        })), n.d(t, "hb", (function() {
            return fe
        })), n.d(t, "ib", (function() {
            return pe
        })), n.d(t, "jb", (function() {
            return ve
        })), n.d(t, "kb", (function() {
            return he
        })), n.d(t, "lb", (function() {
            return Oe
        })), n.d(t, "mb", (function() {
            return je
        })), n.d(t, "nb", (function() {
            return _e
        })), n.d(t, "ob", (function() {
            return we
        })), n.d(t, "qb", (function() {
            return xe
        })), n.d(t, "rb", (function() {
            return Ce
        })), n.d(t, "sb", (function() {
            return Ee
        })), n.d(t, "tb", (function() {
            return Ie
        })), n.d(t, "ub", (function() {
            return Se
        })), n.d(t, "vb", (function() {
            return Te
        })), n.d(t, "wb", (function() {
            return ke
        })), n.d(t, "xb", (function() {
            return Ae
        })), n.d(t, "N", (function() {
            return ze
        })), n.d(t, "pb", (function() {
            return Me
        })), n.d(t, "yb", (function() {
            return Pe
        })), n.d(t, "zb", (function() {
            return Re
        })), n.d(t, "Ab", (function() {
            return De
        })), n.d(t, "Bb", (function() {
            return $
        })), n.d(t, "Cb", (function() {
            return Be
        }));
        var i = {}.hasOwnProperty;

        function o(e, t) {
            return i.call(t, e)
        }

        function a() {
            return (a = Object.assign || function(e) {
                for (var t = arguments.length, n = new Array(t > 1 ? t - 1 : 0), r = 1; r < t; r++) n[r - 1] = arguments[r];
                return n.forEach((function(t) {
                    for (var n in t) o(n, t) && (e[n] = t[n])
                })), e
            }).apply(void 0, arguments)
        }
        var c = function(e) {
            return e.charAt(0).toUpperCase() + e.slice(1)
        };

        function u(e, t) {
            var n;
            return (n = []).concat.apply(n, t.map(e))
        }

        function s(e, t) {
            for (var n = [], r = 0; r < e.length; r += t) n.push(e.slice(r, r + t));
            return n
        }
        var d = Array.isArray;

        function l(e) {
            return "object" === typeof e && null !== e && !d(e)
        }

        function f(e, t) {
            return Object.keys(t).reduce((function(n, r) {
                return n[r] = e(t[r]), n
            }), {})
        }

        function p(e) {
            return d(e) ? e.map(p) : l(e) ? f(p, e) : e
        }

        function m(e) {
            var t = e.trim();
            return 0 === t.length ? "" : 1 === t.length ? t.toLowerCase() : /^[a-z\d]+$/.test(t) ? t : (t !== t.toLowerCase() && (t = function(e) {
                for (var t = e, n = !1, r = !1, i = !1, o = 0; o < t.length; o++) {
                    var a = t[o];
                    n && /[a-zA-Z]/.test(a) && a.toUpperCase() === a ? (t = t.slice(0, o) + "-" + t.slice(o), n = !1, i = r, r = !0, o++) : r && i && /[a-zA-Z]/.test(a) && a.toLowerCase() === a ? (t = t.slice(0, o - 1) + "-" + t.slice(o - 1), i = r, r = !1, n = !0) : (n = a.toLowerCase() === a, i = r, r = a.toUpperCase() === a)
                }
                return t
            }(t)), t = t.replace(/^[_.\- ]+/, "").toLowerCase().replace(/[_.\- ]+(\w|$)/g, (function(e, t) {
                return t.toUpperCase()
            })))
        }

        function v(e) {
            return d(e) ? e.filter((function(e) {
                return null !== e && void 0 !== e
            })) : Object.keys(e).reduce((function(t, n) {
                var r = e[n];
                return null !== r && void 0 !== r && (t[n] = r), t
            }), {})
        }

        function b() {
            for (var e = arguments.length, t = new Array(e), n = 0; n < e; n++) t[n] = arguments[n];
            return t.reduce((function(e, t) {
                return function() {
                    return e(t.apply(void 0, arguments))
                }
            }))
        }

        function h(e, t) {
            var n;
            return function() {
                clearTimeout(n);
                for (var r = arguments.length, i = new Array(r), o = 0; o < r; o++) i[o] = arguments[o];
                n = setTimeout.apply(void 0, [t, e].concat(i))
            }
        }

        function g(e, t) {
            return Object.keys(t).reduce((function(n, r) {
                return t[r] && "object" === typeof t[r] ? Array.isArray(t[r]) ? (n[e(r)] = t[r].map((function(t) {
                    return g(e, t)
                })), n) : (n[e(r)] = g(e, t[r]), n) : (n[e(r)] = t[r], n)
            }), {})
        }

        function y(e) {
            return function(t) {
                return function(e) {
                    return null === e || void 0 === e
                }(t) ? e : t
            }
        }

        function O(e, t) {
            return t.slice(0, -e)
        }

        function j(e) {
            return d(e) ? e : [e]
        }

        function _(e) {
            return Object.keys(e).map((function(t) {
                return [t, e[t]]
            }))
        }

        function w(e, t) {
            for (var n = 0; n < t.length; n++) {
                var r = t[n];
                if (e(r)) return r
            }
        }

        function x(e, t) {
            for (var n = 0; n < t.length; n++)
                if (e(t[n])) return n;
            return -1
        }

        function E(e, t) {
            for (var n = t.length - 1; n >= 0; n--)
                if (e(t[n])) return t[n]
        }

        function C(e, t, n) {
            for (var r = t; r >= 0; r--)
                if (e(n[r])) return r;
            return -1
        }

        function I(e, t) {
            return C(e, t.length - 1, t)
        }

        function S(e, t) {
            for (var n = []; e--;) n.push(t);
            return n
        }

        function T(e) {
            return e
        }

        function k(e, t) {
            return Object.keys(t).forEach((function(n) {
                e(t[n], n)
            }))
        }
        var A = function(e) {
            return e.reduce((function(e, t) {
                var n = t[0],
                    r = t[1];
                return e[n] = r, e
            }), {})
        };

        function z() {
            return Math.random().toString(36).substring(2)
        }

        function M(e) {
            var t = z();
            return o(t, e) ? M(e) : t
        }

        function L(e, t) {
            for (var n = "string" === typeof e ? e.split(".") : e, r = 0, i = t; i && r < n.length;) i = i[n[r++]];
            return i
        }

        function P(e, t, n) {
            var r = L(t, n);
            return void 0 !== r && null !== r ? r : e
        }

        function R(e, t) {
            return Object.keys(t).reduce((function(n, r) {
                var i = t[r],
                    o = e(i);
                return n[o] = n[o] || [], n[o].push(i), n
            }), {})
        }

        function D(e, t) {
            return Object.keys(t).reduce((function(n, r) {
                var i = e(r);
                return n[i] = n[i] || {}, n[i][r] = t[r], n
            }), {})
        }

        function B(e, t) {
            return -1 !== t.indexOf(e)
        }

        function q(e) {
            return 0 === (d(e) ? e : Object.keys(e)).length
        }
        var N = function(e) {
                return !e
            },
            V = function(e) {
                return !!e
            },
            F = function(e) {
                return !!e && "function" === typeof e.then
            };

        function U(e, t) {
            return t.reduce((function(t, n) {
                return t[n[e]] = n, t
            }), {})
        }

        function H(e) {
            var t = [];
            for (var n in e) Object.prototype.hasOwnProperty.call(e, n) && t.push(n);
            return t
        }

        function G(e) {
            return e.length > 0 ? e[e.length - 1] : null
        }

        function W(e, t) {
            return Object.keys(t).reduce((function(n, r) {
                return n[e(r)] = t[r], n
            }), {})
        }

        function Y(e, t) {
            return Object.keys(t).reduce((function(n, r) {
                return n[r] = e(t[r], r), n
            }), {})
        }

        function K(e, t) {
            if (q(t)) return e;
            var n = {};
            return k((function(r, i) {
                if (o(i, t))
                    if (l(e[i]) && l(t[i])) n[i] = K(e[i], t[i]);
                    else if (d(e[i]) && d(t[i])) {
                    var a = Math.max(e[i].length, t[i].length);
                    n[i] = new Array(a);
                    for (var c = 0; c < a; c++) c in t[i] ? n[i][c] = t[i][c] : c in e[i] && (n[i][c] = e[i][c])
                } else n[i] = t[i];
                else n[i] = e[i]
            }), e), k((function(e, r) {
                o(r, n) || (n[r] = t[r])
            }), t), n
        }

        function Z(e) {
            if (0 === e.length) return {};
            var t = e[0];
            return e.slice(1).reduce((function(e, t) {
                return K(e, t)
            }), t)
        }

        function J(e) {
            return function(e, t) {
                var n = {};
                return function() {
                    var r = e.apply(void 0, arguments);
                    if (o(r, n)) return n[r];
                    var i = t.apply(void 0, arguments);
                    return n[r] = i, i
                }
            }(T, e)
        }

        function X(e) {
            var t, n, r = !1;
            return function() {
                return r && (arguments.length <= 0 ? void 0 : arguments[0]) === n ? t : (r = !0, n = arguments.length <= 0 ? void 0 : arguments[0], t = e.apply(void 0, arguments))
            }
        }

        function Q() {}

        function $(e) {
            return Object.keys(e).map((function(t) {
                return e[t]
            }))
        }

        function ee(e, t) {
            var n = "function" === typeof e ? e : function(t) {
                return L(e, t)
            };
            return (d(t) ? [].concat(t) : $(t)).sort((function(e, t) {
                return n(e) - n(t)
            }))
        }

        function te(e, t) {
            return Object.keys(t).reduce((function(n, r) {
                return e(t[r], r) || (n[r] = t[r]), n
            }), {})
        }

        function ne(e, t) {
            return te((function(t, n) {
                return -1 !== e.indexOf(n)
            }), t)
        }

        function re(e, t) {
            return Object.keys(t).reduce((function(n, r) {
                return e(t[r]) || (n[r] = t[r]), n
            }), {})
        }

        function ie(e) {
            var t, n = !1;
            return function() {
                return n ? t : (n = !0, t = e.apply(void 0, arguments))
            }
        }

        function oe(e, t) {
            return [e, t]
        }

        function ae(e, t) {
            return Object.keys(t).reduce((function(n, r) {
                return n[e(t[r]) ? 0 : 1][r] = t[r], n
            }), [{}, {}])
        }

        function ce(e, t) {
            return e.reduce((function(e, n) {
                return e[n] = t[n], e
            }), {})
        }

        function ue(e, t) {
            return Object.keys(t).reduce((function(n, r) {
                return e(t[r]) && (n[r] = t[r]), n
            }), {})
        }

        function se(e, t) {
            return Object.keys(t).reduce((function(n, r) {
                return e(t[r], r) && (n[r] = t[r]), n
            }), {})
        }

        function de(e, t) {
            return e.reduce((function(e, n) {
                return o(n, t) && (e[n] = t[n]), e
            }), {})
        }

        function le(e) {
            for (var t = [], n = 0; n <= e;) t.push(n++);
            return t
        }

        function fe(e, t) {
            return t.filter((function(t) {
                return !e(t)
            }))
        }

        function pe(e, t) {
            var n = [].concat(t);
            return n.splice(e, 1), n
        }
        var me = n(1);

        function ve(e, t, n) {
            var r, i = e.split ? e.split(".") : e,
                a = i[0],
                c = t;
            if (i.length > 1) {
                var u = null != n && o(a, n) ? n[a] : {};
                c = ve(i.slice(1), t, u)
            }
            return Object(me.a)({}, n, ((r = {})[a] = c, r))
        }

        function be(e, t) {
            return e === t ? 0 !== e || 0 !== t || 1 / e === 1 / t : e !== e && t !== t
        }

        function he(e, t) {
            if (be(e, t)) return !0;
            if ("object" !== typeof e || null === e || "object" !== typeof t || null === t) return !1;
            var n = Object.keys(e),
                r = Object.keys(t);
            if (n.length !== r.length) return !1;
            for (var i = 0; i < n.length; i++)
                if (!o(n[i], t) || !be(e[n[i]], t[n[i]])) return !1;
            return !0
        }

        function ge(e, t) {
            var n;
            if ("undefined" === typeof Symbol || null == e[Symbol.iterator]) {
                if (Array.isArray(e) || (n = function(e, t) {
                        if (!e) return;
                        if ("string" === typeof e) return ye(e, t);
                        var n = Object.prototype.toString.call(e).slice(8, -1);
                        "Object" === n && e.constructor && (n = e.constructor.name);
                        if ("Map" === n || "Set" === n) return Array.from(e);
                        if ("Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return ye(e, t)
                    }(e)) || t && e && "number" === typeof e.length) {
                    n && (e = n);
                    var r = 0;
                    return function() {
                        return r >= e.length ? {
                            done: !0
                        } : {
                            done: !1,
                            value: e[r++]
                        }
                    }
                }
                throw new TypeError("Invalid attempt to iterate non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
            }
            return (n = e[Symbol.iterator]()).next.bind(n)
        }

        function ye(e, t) {
            (null == t || t > e.length) && (t = e.length);
            for (var n = 0, r = new Array(t); n < t; n++) r[n] = e[n];
            return r
        }
        var Oe = function(e, t) {
            if (t.length <= e) return t;
            for (var n, r = [], i = 0, o = ge(t.split(" ")); !(n = o()).done;) {
                var a = n.value;
                if (i + a.length > e) break;
                i += a.length + 1, r.push(a)
            }
            return r.join(" ") + "..."
        };

        function je(e) {
            return "number" !== typeof e || isNaN(e) ? NaN : 0 === e ? 0 : -0 === e ? -0 : e > 0 ? 1 : -1
        }

        function _e(e) {
            var t = e.replace(/[A-Z]|([-_ ]+)/g, (function(e) {
                var t = e.charCodeAt(0);
                return t > 64 && t < 91 ? "_" + e.toLowerCase() : "_"
            }));
            return "_" === t[0] ? t.substr(1) : t
        }

        function we(e, t) {
            return [t.slice(0, e), t.slice(e, t.length)]
        }

        function xe(e) {
            return e.reduce(r, 0)
        }

        function Ee(e, t, n) {
            var r = C((function(t) {
                return !e(t)
            }), t, n);
            return r === t ? [] : n.slice(r + 1, t + 1)
        }

        function Ce(e, t) {
            return Ee(e, t.length - 1, t)
        }

        function Ie(e, t) {
            var n, r = Date.now() - 2 * e,
                i = function() {
                    r = Date.now(), t.apply(void 0, arguments)
                };
            return function() {
                for (var t = Date.now(), o = arguments.length, a = new Array(o), c = 0; c < o; c++) a[c] = arguments[c];
                t - r >= e ? i.apply(void 0, a) : (clearTimeout(n), n = setTimeout.apply(void 0, [i, r - t + e].concat(a)))
            }
        }

        function Se(e) {
            return Array.prototype.slice.call(e)
        }
        var Te = function(e, t) {
                return Number(e.toFixed(t))
            },
            ke = function(e) {
                return Object.keys(e).map((function(t) {
                    return [t, e[t]]
                }))
            };

        function Ae(e, t) {
            var n, r = Date.now() - 2 * e,
                i = function() {
                    return r = Date.now(), t.apply(void 0, arguments)
                };
            return function() {
                var t = Date.now();
                t - r >= e && (r = Date.now()), clearTimeout(n);
                for (var o = arguments.length, a = new Array(o), c = 0; c < o; c++) a[c] = arguments[c];
                n = setTimeout.apply(void 0, [i, r - t + e].concat(a))
            }
        }

        function ze(e, t) {
            var n = 0;
            return function() {
                var r = Date.now();
                r - n >= e && (n = Date.now(), t.apply(void 0, arguments))
            }
        }
        var Me = function(e, t) {
            return e === t ? 0 : e < t ? -1 : 1
        };
        var Le = /\s+$/;

        function Pe(e) {
            return e.replace(Le, "")
        }

        function Re(e, t) {
            var n = [];
            return t.filter((function(t) {
                var r = e(t);
                return -1 === n.indexOf(r) && (n.push(r), !0)
            }))
        }

        function De(e, t, n) {
            return [].concat(n.slice(0, e), [t], n.slice(e + 1, n.length))
        }

        function Be(e, t) {
            return function(e, t, n) {
                return t.map((function(t, r) {
                    return e(t, n[r])
                }))
            }(oe, e, t)
        }
    }, function(e, t, n) {
        "use strict";
        n.d(t, "d", (function() {
            return r
        })), n.d(t, "b", (function() {
            return i
        })), n.d(t, "g", (function() {
            return o
        })), n.d(t, "i", (function() {
            return a
        })), n.d(t, "f", (function() {
            return c
        })), n.d(t, "e", (function() {
            return u
        })), n.d(t, "c", (function() {
            return s
        })), n.d(t, "h", (function() {
            return d
        })), n.d(t, "a", (function() {
            return l
        }));
        var r = "liveChatChatId",
            i = "email_prompt",
            o = "message_draft",
            a = 100,
            c = 20,
            u = 255,
            s = "Invalid `chat.id`",
            d = "Move chat to mobile",
            l = {
                labs: "https://mobile-chat.labs.livechat.com/chat-widget-moment/",
                staging: "https://mobile-chat.staging.livechat.com/chat-widget-moment/",
                production: "https://mobile-chat.livechat.com/chat-widget-moment/"
            }
    }, , function(e, t, n) {
        "use strict";
        n.d(t, "a", (function() {
            return r.a
        })), n.d(t, "b", (function() {
            return o.a
        })), n.d(t, "c", (function() {
            return a.a
        })), n.d(t, "d", (function() {
            return s.a
        })), n.d(t, "e", (function() {
            return d.a
        })), n.d(t, "f", (function() {
            return l.a
        })), n.d(t, "g", (function() {
            return f.a
        })), n.d(t, "h", (function() {
            return m.a
        })), n.d(t, "i", (function() {
            return b.a
        })), n.d(t, "j", (function() {
            return y.a
        })), n.d(t, "k", (function() {
            return w
        })), n.d(t, "l", (function() {
            return x
        })), n.d(t, "m", (function() {
            return C.a
        })), n.d(t, "n", (function() {
            return P
        })), n.d(t, "o", (function() {
            return I.a
        })), n.d(t, "p", (function() {
            return D
        })), n.d(t, "r", (function() {
            return B.a
        })), n.d(t, "q", (function() {
            return N
        })), n.d(t, "s", (function() {
            return M.a
        })), n.d(t, "t", (function() {
            return _.a
        })), n.d(t, "u", (function() {
            return V.a
        })), n.d(t, "v", (function() {
            return F.a
        })), n.d(t, "w", (function() {
            return U.a
        })), n.d(t, "x", (function() {
            return H.a
        })), n.d(t, "y", (function() {
            return T.a
        })), n.d(t, "z", (function() {
            return G.a
        })), n.d(t, "A", (function() {
            return W.a
        })), n.d(t, "B", (function() {
            return K.a
        })), n.d(t, "C", (function() {
            return A.a
        })), n.d(t, "D", (function() {
            return Z.a
        })), n.d(t, "E", (function() {
            return L
        })), n.d(t, "F", (function() {
            return X.a
        })), n.d(t, "G", (function() {
            return Q.a
        })), n.d(t, "H", (function() {
            return $.a
        })), n.d(t, "I", (function() {
            return ee.a
        }));
        var r = n(167),
            i = n(168),
            o = n.n(i),
            a = n(169),
            c = (n(170), n(72)),
            u = n.n(c),
            s = n(100),
            d = n(66),
            l = n(171),
            f = n(172),
            p = n(102),
            m = n(173),
            v = n(31),
            b = n.n(v),
            h = n(57),
            g = n(50),
            y = n.n(g),
            O = n(30),
            j = n(51),
            _ = n.n(j);

        function w(e, t) {
            return _.a.apply(void 0, t.map((function(t) {
                return Object(O.a)(e, t)
            })))
        }

        function x(e, t) {
            return u()((function(n) {
                return e.on(t, n),
                    function() {
                        e.off(t, n)
                    }
            }))
        }
        var E = n(174),
            C = n.n(E),
            I = n(103),
            S = n(82),
            T = n.n(S),
            k = n(104),
            A = n.n(k),
            z = n(62),
            M = n.n(z);

        function L(e) {
            return function(t) {
                return Object(h.a)(M()(e)(t))
            }
        }

        function P(e) {
            return T()(Object(d.a)((function() {
                return Object(I.a)(Promise.race([e.call("isFocused"), new Promise((function(t) {
                    return r = "focus", i = t, void(n = e).on(r, (function e(t) {
                        n.off(r, e), i(t)
                    }));
                    var n, r, i
                }))]))
            })), L((function(t) {
                return T()(x(e, "focus"), A()(t))
            })))
        }
        var R = n(43);

        function D() {
            var e = Object(R.a)((function() {
                    return !!document.hasFocus && document.hasFocus()
                })),
                t = M()((function() {
                    return !0
                }))(Object(O.a)(window, "focus")),
                n = M()((function() {
                    return !1
                }))(Object(O.a)(window, "blur"));
            return _()(e, t, n)
        }
        var B = n(175);
        var q, N = (q = function() {
                return p.a
            }, function(e) {
                return function(t, n) {
                    if (0 === t) {
                        var r, i = !1,
                            o = function(e, t) {
                                r(e, t)
                            };
                        e(t, (function e(t, a) {
                            if (0 === t) return r = a, i ? void o(1) : void n(t, o);
                            if (2 === t && a && !i) {
                                i = !0;
                                try {
                                    q(a)(0, e)
                                } catch (c) {
                                    n(2, c)
                                }
                            } else n(t, a)
                        }))
                    }
                }
            }),
            V = (n(137), n(176)),
            F = n(177),
            U = n(178),
            H = n(179),
            G = n(180),
            W = n(48),
            Y = n(181),
            K = n.n(Y),
            Z = (n(87), n(138)),
            J = n(40),
            X = n.n(J),
            Q = n(61),
            $ = (n(182), n(183), n(71), n(184)),
            ee = n(42)
    }, function(e, t, n) {
        "use strict";
        n.r(t), n.d(t, "getView", (function() {
            return u
        })), n.d(t, "getDefaultView", (function() {
            return s
        })), n.d(t, "getCurrentView", (function() {
            return d
        })), n.d(t, "getConnectionState", (function() {
            return l
        })), n.d(t, "getEvent", (function() {
            return m
        })), n.d(t, "getEventByServerId", (function() {
            return v
        })), n.d(t, "hasEvent", (function() {
            return b
        })), n.d(t, "hasEventByServerId", (function() {
            return h
        })), n.d(t, "getIndexedEvents", (function() {
            return g
        })), n.d(t, "getEvents", (function() {
            return y
        })), n.d(t, "getChat", (function() {
            return O
        })), n.d(t, "getChatByServerId", (function() {
            return j
        })), n.d(t, "hasChat", (function() {
            return _
        })), n.d(t, "getChats", (function() {
            return w
        })), n.d(t, "getUsers", (function() {
            return x
        })), n.d(t, "getSessionUser", (function() {
            return E
        })), n.d(t, "getUser", (function() {
            return C
        })), n.d(t, "getUserByServerId", (function() {
            return I
        })), n.d(t, "hasUser", (function() {
            return S
        })), n.d(t, "getTimeline", (function() {
            return T
        })), n.d(t, "getChatList", (function() {
            return k
        })), n.d(t, "getSessionUserId", (function() {
            return A
        })), n.d(t, "getLastDeliveredEvent", (function() {
            return z
        })), n.d(t, "getLastSeenEvent", (function() {
            return M
        })), n.d(t, "getLastEvent", (function() {
            return L
        })), n.d(t, "getUnseenCount", (function() {
            return B
        })), n.d(t, "getLastSeenAgentEvent", (function() {
            return q
        })), n.d(t, "getParticipants", (function() {
            return N
        })), n.d(t, "localize", (function() {
            return V
        })), n.d(t, "getApplicationState", (function() {
            return F
        }));
        var r = n(1),
            i = n(73),
            o = n(2),
            a = n(76),
            c = function(e, t) {
                return t
            },
            u = function(e, t) {
                var n = t.replace(/\//gi, ".");
                return Object(o.x)(n, e.views)
            },
            s = function(e) {
                for (var t = arguments.length, n = new Array(t > 1 ? t - 1 : 0), r = 1; r < t; r++) n[r - 1] = arguments[r];
                return Object(o.x)(n + "._default", e.views)
            },
            d = function(e) {
                return e.views.current
            },
            l = function(e) {
                return e.session.connectionState
            },
            f = function(e) {
                return e.entities.chats.byIds
            },
            p = function(e, t) {
                return f(e)[t]
            },
            m = function(e, t, n) {
                return p(e, t).events.byIds[n]
            },
            v = function(e, t, n) {
                return m(e, t, p(e, t).events.serverIdsMapping[n])
            },
            b = function(e, t, n) {
                return !!m(e, t, n)
            },
            h = function(e, t, n) {
                return !!v(e, t, n)
            },
            g = function(e, t) {
                return p(e, t).events.byIds
            },
            y = Object(i.a)([function(e, t) {
                return p(e, t).events.orderedIds
            }, g], (function(e, t) {
                return e.map((function(e) {
                    return t[e]
                }))
            }))(c),
            O = Object(i.a)([p, y], (function(e, t) {
                return Object(r.a)({}, e, {
                    events: t
                })
            }))(c),
            j = function(e, t) {
                return O(e, e.entities.chats.serverIdsMapping[t])
            },
            _ = function(e, t) {
                return !!p(e, t)
            },
            w = function(e) {
                return Object(o.P)((function(t) {
                    var n = t.id;
                    return O(e, n)
                }), f(e))
            },
            x = function(e) {
                return e.entities.users.byIds
            },
            E = function(e) {
                return x(e)[function(e) {
                    return e.session.id
                }(e)]
            },
            C = function(e, t) {
                return x(e)[t]
            },
            I = function(e, t) {
                return C(e, e.entities.users.serverIdsMapping[t])
            },
            S = function(e, t) {
                return !!C(e, t)
            },
            T = function(e, t) {
                var n;
                return null == (n = e.views) ? void 0 : n.Chat[t].timeline
            },
            k = function(e) {
                var t;
                return null == (t = e.views) ? void 0 : t.ChatList
            },
            A = function(e) {
                return E(e).id
            },
            z = Object(i.a)([y, A], (function(e, t) {
                return Object(o.q)((function(e) {
                    var n = e.delivered,
                        r = e.author;
                    return n && r === t
                }), e)
            }))(c),
            M = Object(i.a)([y, A], (function(e, t) {
                return Object(o.q)((function(e) {
                    var n = e.seen,
                        r = e.author;
                    return n && r === t
                }), e)
            }))(c),
            L = function(e, t) {
                return Object(o.M)(y(e, t))
            },
            P = {
                boosters: !0,
                form: !0,
                system_message: !0
            },
            R = Object(a.createSelector)([y, function(e) {
                return E(e).id
            }], (function(e, t) {
                return Object(o.r)((function(e) {
                    var n = e.author === t && "message" === e.type,
                        r = !!e.properties && "file" === e.properties.serverType,
                        i = !0 === e.seen && !P[e.type] && e.serverId;
                    return n && !r || i
                }), e)
            })),
            D = function(e, t) {
                return e.author !== t && !e.seen && !P[e.type]
            },
            B = function(e, t) {
                var n = R(e, t),
                    r = E(e).id;
                return y(e, t).slice(n + 1).filter((function(e) {
                    return D(e, r)
                })).length
            },
            q = function(e, t) {
                var n = R(e, t);
                if (-1 === n) return null;
                var r = E(e).id,
                    i = y(e, t).slice(n + 1);
                return Object(o.o)((function(e) {
                    return D(e, r)
                }), i)
            },
            N = Object(i.a)([function(e, t) {
                return p(e, t).participants
            }, x], (function(e, t) {
                return e.map((function(e) {
                    return t[e]
                }))
            }))(c),
            V = function(e, t, n) {
                var r = e.localization[t];
                return n ? Object.keys(n).reduce((function(e, t) {
                    return e.replace(new RegExp("%" + t + "%", "g"), n[t])
                }), r) : r
            };

        function F(e, t) {
            if (void 0 === t) return e.application;
            var n = t;
            return e.application[n]
        }
    }, function(e, t, n) {
        "use strict";
        n.d(t, "z", (function() {
            return _
        })), n.d(t, "a", (function() {
            return q
        })), n.d(t, "b", (function() {
            return _e
        })), n.d(t, "c", (function() {
            return Ee
        })), n.d(t, "f", (function() {
            return Ce
        })), n.d(t, "g", (function() {
            return Pe
        })), n.d(t, "h", (function() {
            return ge
        })), n.d(t, "i", (function() {
            return Dt
        })), n.d(t, "n", (function() {
            return ft
        })), n.d(t, "m", (function() {
            return pt
        })), n.d(t, "j", (function() {
            return Rt
        })), n.d(t, "k", (function() {
            return Ye
        })), n.d(t, "l", (function() {
            return He
        })), n.d(t, "q", (function() {
            return L
        })), n.d(t, "v", (function() {
            return Vt
        })), n.d(t, "o", (function() {
            return Gt
        })), n.d(t, "p", (function() {
            return Ut
        })), n.d(t, "s", (function() {
            return at
        })), n.d(t, "w", (function() {
            return ut
        })), n.d(t, "x", (function() {
            return Zt
        })), n.d(t, "r", (function() {
            return rn
        })), n.d(t, "t", (function() {
            return nn
        })), n.d(t, "u", (function() {
            return un
        })), n.d(t, "d", (function() {
            return xt
        })), n.d(t, "e", (function() {
            return An
        })), n.d(t, "y", (function() {
            return re
        }));
        var r = {};
        n.r(r), n.d(r, "Root", (function() {
            return M
        })), n.d(r, "Maximized", (function() {
            return I
        })), n.d(r, "Minimized", (function() {
            return k
        }));
        var i = n(1),
            o = n(261),
            a = n(2),
            c = function(e) {
                var t = {};
                if (e.flexFill && (t.flexGrow = 1, t.maxWidth = "100%"), e.flexFit && (t.flexGrow = 0), e.noShrink && (t.flexShrink = 0), e.ellipsis && (t.whiteSpace = "nowrap", t.overflow = "hidden", t.textOverflow = "ellipsis"), e.nowrap && (t.whiteSpace = "nowrap"), "isFocusVisible" in e && (t["&:focus"] = {
                        outlineStyle: e.isFocusVisible ? "auto" : "none"
                    }), e.preserveLines && (t.whiteSpace = "pre-line"), e.textWrap) {
                    var n = "break-word";
                    t.wordWrap = n, t.overflowWrap = n, t.wordBreak = n
                }
                return t
            },
            u = n(0),
            s = n(68),
            d = u.createContext(),
            l = function(e) {
                var t = e.value,
                    n = e.children;
                return u.createElement(s.d, {
                    theme: t
                }, u.createElement(d.Provider, {
                    value: t
                }, n))
            },
            f = n(8),
            p = function(e) {
                return e.charAt(0) !== e.charAt(0).toLowerCase()
            },
            m = function(e, t) {
                return p(t)
            },
            v = (a.Z.bind(null, m), a.eb.bind(null, m)),
            b = {},
            h = function(e) {
                if (!e) return b;
                var t = e.css,
                    n = e.vars,
                    r = Object(f.a)(e, ["css", "vars"]);
                return Object(i.a)({
                    css: t,
                    vars: n
                }, function(e) {
                    return Object(a.A)((function(t) {
                        return p(t) ? "components" : Object(a.H)(e[t]) ? "propsDescriptions" : "themeProps"
                    }), e)
                }(r))
            },
            g = function(e) {
                return function(t) {
                    return function(n) {
                        var r = n[e];
                        if (!r) return n;
                        var o = h(r),
                            c = o.propsDescriptions,
                            u = o.components;
                        if (!c && !u) return n;
                        var s = function(e, t, n) {
                            void 0 === n && (n = {});
                            var r = Object(a.eb)((function(e, n) {
                                return t[n]
                            }), n);
                            return Object.keys(r).map((function(t) {
                                var n, o = r[t],
                                    a = h(o),
                                    c = a.themeProps,
                                    u = a.components;
                                if (!c) return u;
                                var s = ((n = {})[e] = c, n);
                                return u ? Object(i.a)({}, s, u) : s
                            }))
                        }(e, t, c);
                        return Object(a.U)([n, u].concat(s).filter(Boolean))
                    }
                }
            },
            y = function(e) {
                var t = e.__ui_kit_name,
                    n = g(t);
                return u.forwardRef((function(t, r) {
                    return u.createElement(l, {
                        value: n(t)
                    }, u.createElement(e, Object(i.a)({}, t, {
                        ref: r
                    })))
                }))
            },
            O = function e(t, n) {
                var r = Object(a.db)(a.H, n);
                return 0 === Object.keys(r) ? n : Object(a.f)(Object(a.Q)((function(n, r) {
                    return Object(a.H)(n) ? ":" === r[0] ? e(t, n) : n[Object(a.o)((function(e) {
                        return t[e]
                    }), Object.keys(n))] || n.default : n
                }), n))
            },
            j = function(e, t, n) {
                var r = e.theme,
                    o = e.style,
                    a = h(r[t]),
                    u = a.css,
                    s = a.vars,
                    d = a.themeProps;
                return [s ? Object(i.a)({}, r.vars, s) : r.vars, "function" === typeof n && void 0 !== d && n(d), u && O(e, u), c(e), "function" === typeof n && n(Object(i.a)({}, d, e)), o]
            },
            _ = function(e, t) {
                void 0 === t && (t = {});
                var n = t,
                    r = n.displayName,
                    i = n.displayType,
                    a = n.mapPropsToStyles;
                var c = (0, o.a)(e, t);
                return function() {
                    for (var e = arguments.length, n = new Array(e), o = 0; o < e; o++) n[o] = arguments[o];
                    if (n.length > 0 && void 0 !== n[0].raw) {
                        var u = n;
                        n = [u[0][0]];
                        for (var s = 1; s < u.length; s++) n.push(u[s], u[0][s])
                    }
                    var d = r || i || null,
                        l = c.apply(void 0, n.concat([function(e) {
                            return j(e, d, a)
                        }]));
                    return l.__ui_kit_name = d, t.section ? Object.defineProperty(y(l), "toString", {
                        value: l.toString
                    }) : l
                }
            },
            w = n(10),
            x = n(438);
        var E = _("div", {
                displayName: "FixedWrapperMaximized",
                mapPropsToStyles: function(e) {
                    var t = {};
                    return e.theme && (t.right = "right" === e.theme.FixedWrapperRoot.position ? "0" : "auto", t.left = "left" === e.theme.FixedWrapperRoot.position ? "0" : "auto"), e.animationDuration && (t.transition = "all " + e.animationDuration + "ms ease-out"), e.state && (t.transform = "entered" === e.state ? "none" : "scale(0.8) translate(10%, 30%)", t.opacity = "entered" === e.state ? "1" : "0"), e.height && (t.height = e.height), e.width && (t.width = e.width), t
                },
                target: "ep7mz240"
            })({
                name: "1jmpskd",
                styles: "display:flex;flex-direction:column;max-height:100vh;position:absolute;bottom:0;@media (max-width: 490px){width:100%;height:100%;position:fixed;}"
            }),
            C = function(e) {
                var t = Object(s.g)();
                return u.createElement(x.a, { in: e.active,
                    mountOnEnter: !0,
                    timeout: t.FixedWrapperMaximized.animationDuration,
                    unmountOnExit: !0
                }, (function(t) {
                    return u.createElement(E, Object(i.a)({}, e, {
                        state: t
                    }), u.Children.map(e.children, (function(t) {
                        return u.cloneElement(t, {
                            minimize: e.minimize
                        })
                    })))
                }))
            };
        C.propTypes = {
            active: w.bool,
            children: w.node.isRequired,
            minimize: w.func,
            style: w.shape()
        };
        var I = C;
        var S = _("div", {
                displayName: "FixedWrapperMinimized",
                mapPropsToStyles: function(e) {
                    var t = e.state,
                        n = e.theme,
                        r = {};
                    return n && (r.transition = "all " + n.FixedWrapperMaximized.animationDuration + "ms ease-out", r.right = "right" === n.FixedWrapperRoot.position ? "0" : "auto", r.left = "left" === n.FixedWrapperRoot.position ? "0" : "auto"), t && (r.transform = "entered" === t ? "none" : "scale(0.8) translate(10%, 30%)", r.opacity = "entered" === t ? "1" : "0"), r
                },
                target: "eq1nrcm0"
            })({
                name: "m2cnsn",
                styles: "width:60px;height:60px;position:absolute;bottom:1em"
            }),
            T = function(e) {
                var t = Object(s.g)();
                return u.createElement(x.a, { in: e.active,
                    mountOnEnter: !0,
                    timeout: t.FixedWrapperMinimized.animationDuration,
                    unmountOnExit: !0
                }, (function(t) {
                    return u.createElement(S, Object(i.a)({}, e, {
                        state: t
                    }), u.Children.map(e.children, (function(t) {
                        return u.cloneElement(t, {
                            maximize: e.maximize
                        })
                    })))
                }))
            };
        T.propTypes = {
            active: w.bool,
            children: w.node.isRequired,
            maximize: w.func,
            style: w.shape()
        };
        var k = T;
        var A = _("div", {
                displayName: "FixedWrapperRoot",
                mapPropsToStyles: function(e) {
                    var t = {};
                    return "right" === e.position ? (t.right = "1em", t.left = "auto") : "left" === e.position && (t.right = "auto", t.left = "1em"), t
                },
                target: "e7t7c040"
            })({
                name: "1inca8e",
                styles: "position:fixed;bottom:0;z-index:99;font-size:16px"
            }),
            z = function(e) {
                var t = u.useState(e.maximizedOnInit),
                    n = t[0],
                    r = t[1];
                return u.createElement(A, e, u.createElement("div", null, u.Children.map(e.children, (function(e) {
                    return e.type === I ? u.cloneElement(e, {
                        minimize: function() {
                            return r(!1)
                        },
                        active: n
                    }) : e.type === k ? u.cloneElement(e, {
                        maximize: function() {
                            return r(!0)
                        },
                        active: !n
                    }) : e
                }))))
            };
        z.defaultProps = {
            maximizedOnInit: !1
        }, z.propTypes = {
            children: w.node.isRequired,
            maximizedOnInit: w.bool,
            style: w.shape()
        };
        var M = z;
        var L = _("div", {
            mapPropsToStyles: function(e) {
                var t = {};
                return e.verticalAlign && ("top" === e.verticalAlign ? t.alignItems = "flex-start" : "bottom" === e.verticalAlign ? t.alignItems = "flex-end" : t.alignItems = e.verticalAlign), e.justify && (!0 === e.justify ? t.justifyContent = "space-between" : "left" === e.justify ? t.justifyContent = "flex-start" : "right" === e.justify ? t.justifyContent = "flex-end" : t.justifyContent = e.justify), e.reverse && (t.flexDirection = "row-reverse"), t
            },
            target: "e108e6fy0"
        })({
            name: "14u08z3",
            styles: "display:flex;min-width:0"
        });
        var P = _(L, {
                displayName: "ChatListItem",
                mapPropsToStyles: function(e) {
                    return {
                        background: e.active ? "rgba(0, 0, 0, 0.1)" : "rgba(0, 0, 0, 0)"
                    }
                },
                section: !0,
                target: "edumshe0"
            })({
                name: "141f6e2",
                styles: "padding:0.5em;transition:background 0.2s;border-bottom:1px solid rgba(0, 0, 0, 0.1);&:hover{cursor:pointer;}"
            }),
            R = function(e) {
                return u.createElement(P, e)
            };
        R.propTypes = {
            active: w.bool,
            children: w.node.isRequired
        };
        var D = _(L, {
                displayName: "AgentBar",
                section: !0,
                target: "e1j58gbc0"
            })({
                name: "66u5jz",
                styles: "padding:1em"
            }),
            B = function(e) {
                return u.createElement(D, Object(i.a)({
                    verticalAlign: "center"
                }, e))
            };
        B.propTypes = {
            children: w.node
        };
        var q = B,
            N = n(4),
            V = n(116);
        var F = function(e) {
                var t = e.color;
                return t ? {
                    fill: t,
                    "& *": {
                        fill: t
                    }
                } : null
            },
            U = Object(a.R)((function(e) {
                return _(e, {
                    displayType: "Icon",
                    mapPropsToStyles: F,
                    shouldForwardProp: V.a,
                    target: "e5ibypu0"
                })({
                    name: "y0b0au",
                    styles: "&{display:block;}&,& *{fill:currentColor;}"
                })
            })),
            H = function(e) {
                var t = e.children,
                    n = Object(f.a)(e, ["children"]),
                    r = U(t.type);
                return u.createElement(r, n)
            };
        H.propTypes = {
            children: w.node.isRequired
        };
        var G = H,
            W = function(e) {
                return u.createElement("svg", Object(i.a)({
                    width: "8px",
                    height: "13px",
                    viewBox: "0 0 8 13"
                }, e), u.createElement("g", {
                    stroke: "none",
                    strokeWidth: "1",
                    fill: "none",
                    fillRule: "evenodd"
                }, u.createElement("g", {
                    transform: "translate(-840.000000, -560.000000)",
                    fill: "#424D57",
                    fillRule: "nonzero"
                }, u.createElement("g", {
                    transform: "translate(845.000000, 567.000000) scale(-1, 1) translate(-845.000000, -567.000000) translate(831.000000, 553.000000)"
                }, u.createElement("g", {
                    transform: "translate(3.000000, 1.000000)"
                }, u.createElement("polygon", {
                    points: "8.59 17.34 13.17 12.75 8.59 8.16 10 6.75 16 12.75 10 18.75"
                }))))))
            },
            Y = function(e) {
                return u.createElement(G, e, u.createElement(W, null))
            },
            K = function(e) {
                return u.createElement("svg", Object(i.a)({
                    width: "8px",
                    height: "13px",
                    viewBox: "0 0 8 13"
                }, e), u.createElement("g", {
                    stroke: "none",
                    strokeWidth: "1",
                    fill: "none",
                    fillRule: "evenodd"
                }, u.createElement("g", {
                    transform: "translate(-1104.000000, -560.000000)",
                    fill: "#424D57",
                    fillRule: "nonzero"
                }, u.createElement("g", {
                    transform: "translate(1094.000000, 553.000000)"
                }, u.createElement("g", {
                    transform: "translate(2.000000, 1.000000)"
                }, u.createElement("polygon", {
                    points: "8.59 17.34 13.17 12.75 8.59 8.16 10 6.75 16 12.75 10 18.75"
                }))))))
            },
            Z = function(e) {
                return u.createElement(G, e, u.createElement(K, null))
            },
            J = function(e) {
                return u.createElement("svg", Object(i.a)({
                    viewBox: "0 0 58 58",
                    style: {
                        enableBackground: "new 0 0 58 58"
                    }
                }, e), u.createElement("rect", {
                    style: {
                        fillRule: "evenodd",
                        clipRule: "evenodd",
                        fill: "#F2F2F2"
                    },
                    width: "58",
                    height: "58"
                }), u.createElement("path", {
                    style: {
                        fillRule: "evenodd",
                        clipRule: "evenodd",
                        fill: "#424D57"
                    },
                    d: "M40,38c7.3,3.8,11,8.4,11,13.9v6c0,0.2-0.1,0.3-0.2,0.4C47.9,62,6.1,62,6.1,58l0-0.1l0-0.1 v-6c0-5.5,3.7-10.1,11-13.9c1.2-0.7,2-0.2,2-0.2c2.5,2.3,5.8,3.7,9.5,3.7l-0.1,0l0.3,0c3.5-0.1,6.7-1.5,9.1-3.7 C38,37.8,38.8,37.3,40,38z M28.5,17C34.3,17,39,21.7,39,27.5S34.3,38,28.5,38S18,33.3,18,27.5S22.7,17,28.5,17z"
                }))
            },
            X = function(e) {
                return u.createElement(G, e, u.createElement(J, null))
            },
            Q = function(e) {
                return u.createElement("svg", Object(i.a)({
                    height: "18px",
                    viewBox: "0 0 21 18",
                    width: "21px"
                }, e), u.createElement("g", {
                    fill: "none",
                    fillRule: "evenodd",
                    stroke: "none",
                    strokeWidth: "1"
                }, u.createElement("g", {
                    fill: "#000000"
                }, u.createElement("polygon", {
                    points: "0.01 18 21 9 0.01 0 0 7 15 9 0 11"
                }))))
            },
            $ = function(e) {
                return u.createElement(G, e, u.createElement(Q, null))
            },
            ee = n(21);

        function te() {
            var e = Object(ee.a)(["\n\t0% {\n\t\topacity: 1.0;\n\t}\n\n\t50% {\n\t\topacity: 0.4;\n\t}\n\n\t100% {\n\t\topacity: 1.0;\n\t}\n"]);
            return te = function() {
                return e
            }, e
        }
        var ne = Object(N.e)(te()),
            re = Object(N.c)("animation:1.5s ease-in-out 0s infinite;animation-name:", ne, ";");
        var ie = _("div", {
                target: "e11eolwx0"
            })({
                name: "3st5dg",
                styles: "width:100vw;max-width:100%;height:100%;display:flex;align-items:center;justify-content:center;background-color:#e5e5e5"
            }),
            oe = {
                name: "1t9hbt0",
                styles: "width:32px;height:32px;fill:currentColor"
            },
            ae = function(e) {
                return Object(N.d)(ie, e, Object(N.d)("svg", {
                    viewBox: "0 0 32 32",
                    css: [oe, re, ""]
                }, Object(N.d)("path", {
                    d: "M6.1,22.1l5.3-4.8c0.4-0.3,1-0.3,1.3,0l3.2,2.8l6.5-5.8c0.4-0.3,1-0.3,1.3,0l2.3,2.1V9c0-0.6-0.4-1-1-1h-18 c-0.6,0-1,0.4-1,1L6.1,22.1C6.1,22,6.1,22,6.1,22.1z M8,23h8.1l-4.1-3.7L8,23z M19.1,23h5.9c0.6,0,1-0.4,1-1v-3l-3-2.7l-5.7,5.1 L19.1,23z M7.1,6h18c1.7,0,3,1.3,3,3v13c0,1.7-1.3,3-3,3h-18c-1.7,0-3-1.3-3-3V9C4.1,7.3,5.4,6,7.1,6z M15.1,16c-1.7,0-3-1.3-3-3 s1.3-3,3-3s3,1.3,3,3S16.8,16,15.1,16z M15.1,14c0.6,0,1-0.4,1-1s-0.4-1-1-1c-0.6,0-1,0.4-1,1S14.5,14,15.1,14z"
                })))
            },
            ce = function(e) {
                return Object(N.d)(ie, e, Object(N.d)("svg", {
                    viewBox: "0 0 32 32",
                    css: oe
                }, Object(N.d)("path", {
                    d: "M3.6,5.1L3.6,5.1l24.1,21.1c0.4,0.4,0.5,1,0.1,1.4c-0.3,0.4-0.9,0.4-1.3,0.2l-0.1-0.1l-8.1-7.1l-2,1.8  l1.7,1.5h4l2.3,2l-0.1,0L24,26H6c-1.6,0-2.9-1.2-3-2.8L3,23L3,7.3L2.3,6.7c-0.4-0.4-0.5-1-0.1-1.4C2.6,4.9,3.1,4.9,3.6,5.1z   M11,20.3L6.9,24h8.1L11,20.3z M26,5c1.6,0,2.9,1.2,3,2.8L29,8v15.4l0,0l-2-1.7l0-3.7l-3-2.7l-2.2,2L20.3,16l3.1-2.8  c0.3-0.3,0.9-0.3,1.2-0.1l0.1,0.1l2.3,2.1V8c0-0.5-0.4-0.9-0.9-1L26,7H10L7.7,5l0.1,0L8,5H26z M5,9.1l0,14l5.3-4.8  c0.3-0.3,0.9-0.3,1.2-0.1l0.1,0.1l3.2,2.8l1.9-1.7L5,9.1z M20,8c1.7,0,3,1.3,3,3s-1.3,3-3,3s-3-1.3-3-3S18.3,8,20,8z M20,10  c-0.6,0-1,0.4-1,1s0.4,1,1,1s1-0.4,1-1S20.6,10,20,10z"
                })))
            },
            ue = n(725);

        function se() {
            var e = Object(ee.a)(["\n\t&-enter {\n\t\topacity: 0;\n\t\theight: 0;\n\t}\n\n\t&-enter&-enter-active {\n\t\topacity: 1;\n\t\theight: 1.2em;\n\t\ttransition: height 200ms ease-in-out, opacity 100ms ease-in-out 100ms;\n\t}\n\n\t&-exit {\n\t\topacity: 1;\n\t\theight: 1.2em;\n\t}\n\n\t&-exit&-exit-active {\n\t\topacity: 0;\n\t\theight: 0;\n\t\ttransition: height 100ms ease-in-out 100ms, opacity 200ms ease-in-out;\n\t}\n"]);
            return se = function() {
                return e
            }, e
        }
        var de = function(e) {
                return e(se())
            },
            le = function(e) {
                return u.createElement(N.a, null, (function(t) {
                    var n = t.css;
                    return u.createElement(ue.a, Object(i.a)({}, e, {
                        classNames: de(n),
                        timeout: 200
                    }))
                }))
            };
        le.propTypes = {
            children: w.node
        };
        var fe = le;

        function pe() {
            var e = Object(ee.a)(["\n\t&-enter {\n\t\topacity: 0;\n\t\ttransform: scale(1.2);\n\t}\n\n\t&-enter-active {\n\t\topacity: 1;\n\t\ttransform: scale(1);\n\t\ttransition: opacity ", "ms ", ", transform ", "ms ", ";\n\t}\n\n\t&-enter-done {\n\t\topacity: 1;\n\t\ttransform: scale(1);\n\t}\n"]);
            return pe = function() {
                return e
            }, e
        }
        var me = "cubic-bezier(0.14, 0, 0, 1)",
            ve = function(e) {
                return e(pe(), 200, me, 200, me)
            },
            be = function(e) {
                return u.createElement(N.a, null, (function(t) {
                    var n = t.css;
                    return u.createElement(ue.a, Object(i.a)({}, e, {
                        classNames: ve(n),
                        timeout: 500
                    }))
                }))
            },
            he = function(e) {
                var t = e.children,
                    n = e.src,
                    r = e.srcSet,
                    o = (e.scaleImage, e.className),
                    a = e.alt,
                    c = void 0 === a ? "" : a,
                    s = Object(f.a)(e, ["children", "src", "srcSet", "scaleImage", "className", "alt"]),
                    d = u.useState("pending"),
                    l = d[0],
                    p = d[1],
                    m = u.useState(!1),
                    v = m[0],
                    b = m[1],
                    h = u.useRef(0),
                    g = "loaded" === l,
                    y = null;
                if (t) y = t({
                    imageStatus: l,
                    shouldAnimate: v
                });
                else switch (l) {
                    case "pending":
                        y = u.createElement(ae, s);
                        break;
                    case "failed":
                        y = u.createElement(ce, s);
                        break;
                    default:
                        y = null
                }
                return u.useLayoutEffect((function() {
                    return p("pending"), b(!1), h.current = setTimeout((function() {
                            return b(!0)
                        }), 300),
                        function() {
                            return clearTimeout(h.current)
                        }
                }), [n, r]), u.createElement(u.Fragment, null, u.createElement(be, { in: v && g
                }, u.createElement("img", Object(i.a)({
                    alt: c
                }, s, {
                    src: n,
                    srcSet: r,
                    className: o,
                    onLoad: function() {
                        p("loaded"), clearTimeout(h.current)
                    },
                    onError: function() {
                        return p("failed")
                    },
                    style: Object(i.a)({}, !g && {
                        display: "none"
                    })
                }))), y)
            };
        he.propTypes = {
            children: w.func
        };
        var ge = he;
        var ye = {
                name: "1wtwico",
                styles: "display:block;border-radius:inherit;width:100%;height:100%;object-fit:cover"
            },
            Oe = _("div", {
                displayName: "Avatar",
                mapPropsToStyles: function(e) {
                    var t = {},
                        n = {},
                        r = e.size,
                        o = e.radius,
                        a = e.fontSize;
                    return r && (t.width = r, t.height = r, t.lineHeight = r), o && (t.borderRadius = o, n.borderRadius = o), a && (t.fontSize = a), Object(i.a)({}, t, {
                        "& img": n
                    })
                },
                target: "e11ezd0e0"
            })({
                name: "1f2to7",
                styles: "border:1px solid #fff;border-radius:50%;text-align:center;background-color:#fff;text-transform:uppercase;overflow:hidden"
            }),
            je = function(e) {
                var t = e.imgUrl,
                    n = e.letter,
                    r = null;
                return t || n ? t ? r = Object(N.d)(ge, {
                    src: t,
                    css: ye,
                    alt: "avatar"
                }, (function(e) {
                    var t = e.imageStatus,
                        n = e.shouldAnimate;
                    switch (t) {
                        case "pending":
                            return Object(N.d)(X, {
                                css: [ye, n && re, ""]
                            });
                        case "failed":
                            return Object(N.d)(X, {
                                css: ye
                            });
                        default:
                            return null
                    }
                })) : n && (r = Object(N.d)("span", null, n)) : r = Object(N.d)("div", {
                    css: ye
                }, Object(N.d)(X, {
                    css: ye
                })), Object(N.d)(Oe, e, r)
            };
        je.propTypes = {
            imgUrl: w.string,
            letter: w.string,
            size: w.string,
            style: w.shape()
        };
        var _e = je;
        var we = {
                name: "1oep8ze",
                styles: "&>:first-child{border-top-left-radius:inherit;border-top-right-radius:inherit;border-bottom-right-radius:0;border-bottom-left-radius:0;}&>:last-child{border-top-left-radius:0;border-top-right-radius:0;border-bottom-right-radius:inherit;border-bottom-left-radius:inherit;}&>:first-child:last-child{border-top-left-radius:inherit;border-top-right-radius:inherit;border-bottom-right-radius:inherit;border-bottom-left-radius:inherit;}"
            },
            xe = _("div", {
                displayName: "Bubble",
                mapPropsToStyles: function(e) {
                    var t = e.isOwn,
                        n = e.ovalBorderRadius,
                        r = e.sharpBorderRadius,
                        i = e.radiusType,
                        o = {
                            borderTopLeftRadius: "single" === i || "first" === i ? n : r,
                            borderTopRightRadius: n,
                            borderBottomRightRadius: n,
                            borderBottomLeftRadius: "single" === i || "last" === i ? n : r
                        };
                    return t ? function(e) {
                        var t = e.borderTopLeftRadius,
                            n = e.borderTopRightRadius,
                            r = e.borderBottomRightRadius;
                        return {
                            borderTopLeftRadius: n,
                            borderTopRightRadius: t,
                            borderBottomRightRadius: e.borderBottomLeftRadius,
                            borderBottomLeftRadius: r
                        }
                    }(o) : o
                },
                target: "emwkn670"
            })(we, ";border:1px solid rgba(0, 0, 0, 0.05);display:inline-block;max-width:100%;margin-bottom:0.1em;& img{max-width:100%;display:block;}");
        xe.propTypes = {
            children: w.node,
            isOwn: w.bool,
            radiusType: w.oneOf(["single", "first", "last"])
        };
        var Ee = xe;
        var Ce = _("div", {
                target: "ek650k30"
            })({
                name: "1ojnsow",
                styles: "display:flex;flex-direction:column;min-width:0"
            }),
            Ie = _("div", {
                mapPropsToStyles: function(e) {
                    return {
                        flexShrink: e.shrink ? 1 : 0
                    }
                },
                target: "e1jdwequ0"
            })(""),
            Se = function(e) {
                return u.createElement(Ie, Object(i.a)({
                    flexFill: !0
                }, e))
            };
        Se.defaultProps = {
            shrink: !0
        }, Se.propTypes = {
            shrink: w.bool
        };
        var Te = Se,
            ke = _("div", {
                mapPropsToStyles: function(e) {
                    return {
                        flexShrink: e.shrink ? 1 : 0
                    }
                },
                target: "e1yi1p4d0"
            })(""),
            Ae = function(e) {
                return u.createElement(ke, Object(i.a)({
                    flexFit: !0
                }, e))
            };
        Ae.defaultProps = {
            shrink: !0
        }, Ae.propTypes = {
            shrink: w.bool
        };
        var ze = n(17),
            Me = _("button", {
                displayName: "IconButton",
                section: !0,
                target: "e1m5b1js0"
            })("appearance:none;background:transparent;border:0;display:inline-block;margin:0;padding:0.5em;color:inherit;&:hover{cursor:", (function(e) {
                return e.disabled ? "default" : "pointer"
            }), ";}"),
            Le = u.forwardRef((function(e, t) {
                var n = Object(ze.f)();
                return u.createElement(Me, Object(i.a)({
                    ref: t
                }, n, e))
            }));
        Le.propTypes = {
            active: w.bool,
            disabled: w.bool,
            children: w.node.isRequired,
            color: w.string,
            onClick: w.func
        };
        var Pe = Le,
            Re = n(28),
            De = n(726),
            Be = n(38),
            qe = n(14),
            Ne = function(e) {
                return e.getBoundingClientRect().top + window.pageYOffset
            },
            Ve = n(88);
        var Fe = u.createContext({
                registerUnseenListItem: a.V,
                isScrollOnBottom: a.V,
                scrollToBottom: a.V
            }),
            Ue = Fe.Provider,
            He = Fe.Consumer,
            Ge = function(e) {
                void 0 === e && (e = 0);
                var t = e;
                return function() {
                    return t++
                }
            }(),
            We = _("div", {
                displayName: "MessageList",
                target: "e1i3n9g60"
            })({
                name: "1qptc4e",
                styles: "padding:0.5em;overflow-y:auto;height:100%;outline-offset:-5px"
            }),
            Ye = u.forwardRef((function(e, t) {
                var n = e.active,
                    r = void 0 === n || n,
                    o = e.onScroll,
                    c = Object(f.a)(e, ["active", "onScroll"]),
                    s = u.useRef(),
                    d = Object(Ve.a)(s, t),
                    l = function() {
                        var e = u.useRef([]);
                        return {
                            getAll: function() {
                                return e.current
                            },
                            registerItem: u.useCallback((function(t) {
                                var n = Ge(),
                                    r = e.current;
                                return r.push(Object(i.a)({}, t, {
                                        id: n
                                    })),
                                    function() {
                                        var e = Object(a.p)((function(e) {
                                            return e.id === n
                                        }), r); - 1 !== e && r.splice(e, 1)
                                    }
                            }), [])
                        }
                    }(),
                    p = l.getAll,
                    m = l.registerItem,
                    v = Object(Re.l)(r),
                    b = Object(Re.l)(o),
                    h = Object(ze.f)(),
                    g = u.useCallback((function() {
                        p().forEach((function(e) {
                            var t, n;
                            (t = s.current, n = e.ref, Ne(n) - Ne(t) + n.clientHeight <= t.clientHeight) && e.onSeen()
                        }))
                    }), [p]),
                    y = u.useMemo((function() {
                        return Object(a.tb)(300, (function() {
                            v.current && g()
                        }))
                    }), [v, g]),
                    O = u.useCallback((function(e) {
                        y(), b.current && b.current(e)
                    }), [b, y]);
                u.useEffect((function() {
                    r && g()
                }), [r, g]);
                var j = u.useMemo((function() {
                    return {
                        registerUnseenListItem: m,
                        isScrollOnBottom: function() {
                            return e = s.current, void 0 === (t = 20) && (t = 0), e.scrollTop + e.clientHeight - e.scrollHeight >= -t;
                            var e, t
                        },
                        scrollToBottom: function() {
                            var e;
                            (e = s.current).scrollTop = e.scrollHeight
                        }
                    }
                }), [m]);
                return u.createElement(Ue, {
                    value: j
                }, u.createElement(We, Object(i.a)({}, h, c, {
                    ref: d,
                    onScroll: O,
                    role: "grid",
                    "aria-live": "polite",
                    "aria-relevant": "additions"
                })))
            })),
            Ke = function(e) {
                function t() {
                    for (var t, n = arguments.length, r = new Array(n), i = 0; i < n; i++) r[i] = arguments[i];
                    return (t = e.call.apply(e, [this].concat(r)) || this)._unregisterFromMessageList = a.V, t._registerInMessageList = Object(a.S)((function(e) {
                        return function(n) {
                            t._unregisterFromMessageList(), n && (t._unregisterFromMessageList = e({
                                ref: n,
                                onSeen: t.props.onSeen
                            }))
                        }
                    })), t
                }
                Object(Be.a)(t, e);
                var n = t.prototype;
                return n.componentWillUnmount = function() {
                    this._unregisterFromMessageList()
                }, n.render = function() {
                    var e = this;
                    return u.createElement(He, null, (function(t) {
                        var n = t.registerUnseenListItem;
                        return u.createElement("div", {
                            ref: e.props.seen ? null : e._registerInMessageList(n),
                            role: "row"
                        }, u.Children.only(e.props.children))
                    }))
                }, t
            }(u.Component);
        Ke.propTypes = {
            children: w.node.isRequired,
            onSeen: w.func
        }, Ke.defaultProps = {
            onSeen: a.V
        };
        var Ze = Ke;
        var Je = _("div", {
                displayName: "Message",
                mapPropsToStyles: function(e) {
                    var t = e.horizontalAlign;
                    return t ? {
                        flexDirection: "left" === t ? "row" : "row-reverse"
                    } : null
                },
                section: !0,
                target: "e10ccb475"
            })({
                name: "gsl41n",
                styles: "display:flex;align-items:flex-start;font-size:0.9em;margin:0.3em;max-width:100%"
            }),
            Xe = _("span", {
                displayName: "AuthorName",
                target: "e10ccb474"
            })({
                name: "1rawn5e",
                styles: "font-size:0.8em"
            }),
            Qe = _("div", {
                displayName: "MessageMeta",
                target: "e10ccb473"
            })({
                name: "1flj9lk",
                styles: "text-align:left"
            }),
            $e = _("div", {
                displayName: "Content",
                target: "e10ccb472"
            })({
                name: "fabj5c",
                styles: "display:flex;flex-direction:column;overflow:hidden;align-items:flex-start"
            }),
            et = _("span", {
                displayName: "Time",
                target: "e10ccb471"
            })({
                name: "1rawn5e",
                styles: "font-size:0.8em"
            }),
            tt = _("div", {
                displayName: "Status",
                target: "e10ccb470"
            })({
                name: "5m4wg",
                styles: "text-align:right;font-size:0.8em"
            }),
            nt = {
                name: "oldbq4",
                styles: "user-select:none"
            },
            rt = u.forwardRef((function(e, t) {
                var n = e.children,
                    r = e.authorName,
                    o = e.deliveryStatus,
                    c = void 0 === o ? "" : o,
                    u = e.isOwn,
                    s = e.date,
                    d = e.showMetaOnClick,
                    l = e.onSeen,
                    p = (e.radiusType, e.seen),
                    m = e.enforceDeliveryStatusDisplay,
                    v = e.onClick,
                    b = void 0 === v ? a.V : v,
                    h = e.onKeyUp,
                    g = void 0 === h ? a.V : h,
                    y = Object(f.a)(e, ["children", "authorName", "deliveryStatus", "isOwn", "date", "showMetaOnClick", "onSeen", "radiusType", "seen", "enforceDeliveryStatusDisplay", "onClick", "onKeyUp"]),
                    O = Object(ze.f)(),
                    j = Object(Re.x)(!1),
                    _ = j[0],
                    w = j[1];
                return Object(N.d)(Ze, {
                    onSeen: l,
                    seen: p
                }, Object(N.d)(Je, Object(i.a)({
                    ref: t,
                    "aria-expanded": d ? _ : null
                }, y, {
                    onKeyUp: function(e) {
                        g(e), "Enter" !== e.key && " " !== e.key || w()
                    },
                    onClick: function(e) {
                        b(e), w()
                    },
                    own: u,
                    tabIndex: null
                }), Object(N.d)($e, Object(i.a)({
                    role: "gridcell"
                }, O), Object(N.d)(De.a, null, (!d || _) && Object(N.d)(fe, null, Object(N.d)(Qe, null, r && Object(N.d)(Xe, null, r, " "), s && Object(N.d)(et, null, s)))), n, c ? Object(N.d)(tt, null, c) : m ? Object(N.d)(tt, {
                    css: nt
                }, "\xa0") : null)))
            }));
        rt.propTypes = {
            authorName: w.oneOfType([w.string, w.node]),
            authorOpen: w.bool,
            children: w.node,
            date: w.string,
            deliveryStatus: w.string,
            enforceDeliveryStatusDisplay: w.bool,
            isOwn: w.bool,
            onClick: w.func,
            onSeen: w.func,
            showMetaOnClick: w.bool,
            style: w.shape(),
            toggleAuthor: w.func,
            radiusType: w.oneOf(["single", "first", "last"]),
            seen: w.bool
        }, rt.defaultProps = {
            onClick: a.V,
            seen: !1
        };
        var it = rt;
        var ot = _("div", {
            displayName: "SubTitle",
            target: "e1fut3qs0"
        })({
            name: "1ecjc06",
            styles: "font-weight:300;opacity:0.7"
        });
        ot.defaultProps = {
            textWrap: !0
        };
        var at = ot;
        var ct = _("div", {
            displayName: "Title",
            target: "e9xf8br0"
        })({
            name: "mmvz9h",
            styles: "font-weight:400"
        });
        ct.defaultProps = {
            textWrap: !0
        };
        var ut = ct;
        Object(a.ab)(console.warn.bind(console));
        var st = _("div", {
                displayName: "MessageTitle",
                target: "e1ykjxgu0"
            })({
                name: "1kj42yy",
                styles: "font-weight:600;padding:1em"
            }),
            dt = {
                name: "11rcwxl",
                styles: "margin-bottom:4px"
            },
            lt = function(e) {
                var t = e.children,
                    n = e.title,
                    r = e.subtitle,
                    i = Object(f.a)(e, ["children", "title", "subtitle"]);
                var o = t || [n && Object(N.d)(ut, {
                    key: "title",
                    preserveLines: !0,
                    css: dt
                }, n), r && Object(N.d)(at, {
                    key: "subtitle",
                    preserveLines: !0
                }, r)];
                return Object(N.d)(st, i, o)
            };
        lt.propTypes = {
            children: w.oneOfType([w.arrayOf(w.node), w.node]),
            subtitle: w.string,
            title: w.string
        };
        var ft = lt;
        var pt = _("div", {
            displayName: "MessageText",
            target: "eovu8nx0"
        })({
            name: "tzdp72",
            styles: "white-space:pre-line;word-wrap:break-word;overflow-wrap:break-word;max-width:100%;padding:1em"
        });
        var mt = _("div", {
                displayName: "MessageMedia",
                mapPropsToStyles: function(e) {
                    var t = e.style || {};
                    return {
                        img: {
                            borderTopLeftRadius: t.borderTopLeftRadius,
                            borderTopRightRadius: t.borderTopRightRadius,
                            borderBottomRightRadius: t.borderBottomRightRadius,
                            borderBottomLeftRadius: t.borderBottomLeftRadius
                        }
                    }
                },
                target: "evmhqt80"
            })({
                name: "d3v9zr",
                styles: "overflow:hidden"
            }),
            vt = "rgba(0, 0, 0, 0.1)",
            bt = "1px solid " + vt,
            ht = _("div", {
                displayName: "MessageButtons",
                target: "edowbh60"
            })(we, ";&>:first-child{border-top:", bt, ";}&:first-child>:first-child{border-top:0;}&>:last-child{border-bottom:", bt, ";}&:last-child>:last-child{border-bottom:0;}>*{border-color:", vt, "!important;}"),
            gt = n(22),
            yt = n(143),
            Ot = n(20);
        var jt = Object(gt.a)(.2),
            _t = _(u.forwardRef((function(e, t) {
                var n = e.href,
                    r = Object(f.a)(e, ["href"]);
                return n ? u.createElement("a", Object(i.a)({
                    href: n,
                    rel: "nofollow noopener"
                }, r, {
                    ref: t
                })) : u.createElement("button", Object(i.a)({}, r, {
                    ref: t
                }))
            })), {
                displayName: "Button",
                mapPropsToStyles: function(e) {
                    var t = e.primary ? e.theme.vars["--primary-color"] : "black",
                        n = jt(t);
                    return {
                        borderColor: t,
                        color: t,
                        "&:hover": {
                            color: n,
                            borderColor: n
                        }
                    }
                },
                shouldForwardProp: V.a,
                target: "e1972fzd0"
            })({
                name: "1x6954b",
                styles: "border-width:1px;border-style:solid;background-color:#fff;font-size:1em;font-family:inherit;line-height:1.4em;text-align:center;text-decoration:none;appearance:none;padding:0.8em;transition:box-shadow 0.1s,color 0.1s,border-color 0.2s;&:hover{cursor:pointer;}&:active{box-shadow:none;outline:none;}&[disabled]{pointer-events:none;}"
            }),
            wt = function(e) {
                var t = e.label,
                    n = e.onPress,
                    r = e.disabled,
                    o = Object(f.a)(e, ["label", "onPress", "disabled"]),
                    a = Object(ze.f)(),
                    c = u.useRef(),
                    s = Object(yt.a)(Object(i.a)({
                        onPress: n,
                        isDisabled: r
                    }, o), c).buttonProps;
                return u.createElement(_t, Object(Ot.h)(a, s, o, {
                    ref: c
                }), t)
            };
        wt.propTypes = {
            label: w.oneOfType([w.string, w.node])
        };
        var xt = wt,
            Et = _(xt, {
                target: "e121y1dq0"
            })("display:inline-block;width:100%;border-left:0;border-right:0;border-top:0;border-bottom-color:rgba(0, 0, 0, 0.1);box-shadow:none;transition:background-color 0.1s;background:transparent;color:", (function(e) {
                return e.disabled ? "#8D9BA9" : "inherit"
            }), ";margin:0;&:hover{border-bottom-color:rgba(0, 0, 0, 0.15);background:rgba(0, 0, 0, 0.02);color:inherit;}&:active{background:rgba(0, 0, 0, 0.04);color:inherit;}"),
            Ct = function(e) {
                function t() {
                    for (var t, n = arguments.length, r = new Array(n), i = 0; i < n; i++) r[i] = arguments[i];
                    return (t = e.call.apply(e, [this].concat(r)) || this).handleClick = function(e) {
                        e.stopPropagation(), t.props.onClick(e)
                    }, t
                }
                return Object(Be.a)(t, e), t.prototype.render = function() {
                    return u.createElement(Et, Object(i.a)({}, this.props, {
                        onClick: this.handleClick
                    }))
                }, t
            }(u.Component);
        Ct.propTypes = {
            className: w.string,
            label: w.string,
            onClick: w.func,
            primary: w.bool,
            value: w.oneOfType([w.string, w.number])
        }, Ct.defaultProps = {
            onClick: a.V
        };
        var It = function(e) {
            return u.Children.toArray(e).filter(Boolean)
        };
        var St = {
                radiusType: "single"
            },
            Tt = {
                radiusType: "first"
            },
            kt = {
                radiusType: "last"
            },
            At = {
                authorName: null,
                date: null
            },
            zt = _("div", {
                displayName: "MessageGroup",
                mapPropsToStyles: function(e) {
                    return e.isOwn ? {
                        flexDirection: "row-reverse"
                    } : null
                },
                target: "eslhdd61"
            })({
                name: "a5a8k1",
                styles: "display:flex;margin-bottom:1em"
            }),
            Mt = _("div", {
                target: "eslhdd60"
            })("display:flex;flex-direction:column;align-items:center;text-align:center;font-size:0.7em;line-height:1.6em;", (function(e) {
                return {
                    minWidth: e.theme.Avatar.size,
                    margin: e.isOwn ? "0 0 0 .3em" : "0 .3em 0 0"
                }
            }), ";"),
            Lt = {
                name: "d3v9zr",
                styles: "overflow:hidden"
            },
            Pt = function(e) {
                var t = e.avatar,
                    n = e.avatarLetter,
                    r = e.children,
                    o = e.onlyFirstWithMeta,
                    a = Object(f.a)(e, ["avatar", "avatarLetter", "children", "onlyFirstWithMeta"]),
                    c = It(r),
                    s = u.Children.count(c);
                return Object(N.d)(zt, a, (t || n) && Object(N.d)(Mt, {
                    flexFit: !0,
                    isOwn: a.isOwn
                }, Object(N.d)(_e, {
                    imgUrl: t,
                    letter: n
                })), Object(N.d)(Te, {
                    css: Lt
                }, u.Children.map(c, (function(e, t) {
                    if (1 === s) return Object(u.cloneElement)(e, St);
                    if (0 === t) return Object(u.cloneElement)(e, Tt);
                    var n = o && t > 0;
                    return t === s - 1 ? Object(u.cloneElement)(e, n ? Object(i.a)({}, kt, At) : kt) : n ? Object(u.cloneElement)(e, At) : e
                }))))
            };
        Pt.propTypes = {
            avatar: w.string,
            avatarLetter: w.string,
            children: w.node,
            isOwn: w.bool,
            onlyFirstWithMeta: w.bool
        };
        var Rt = Pt,
            Dt = it,
            Bt = "#fff",
            qt = {
                vars: {
                    "primary-color": "#427fe1",
                    "secondary-color": "#fbfbfb",
                    "tertiary-color": Bt
                },
                AgentBar: {
                    Avatar: {
                        size: "42px",
                        css: {
                            marginRight: ".6em"
                        }
                    },
                    css: {
                        backgroundColor: "var(--secondary-color)"
                    }
                },
                Avatar: {
                    size: "30px"
                },
                Bubble: {
                    sharpBorderRadius: "0.3em",
                    ovalBorderRadius: "1.4em",
                    css: {
                        backgroundColor: {
                            default: "var(--secondary-color)",
                            bot: "green"
                        }
                    }
                },
                Button: {},
                ChatListItem: {
                    Avatar: {
                        css: {
                            marginRight: ".5em"
                        }
                    }
                },
                FixedWrapperMaximized: {
                    animationDuration: 100,
                    width: "400px",
                    height: "500px"
                },
                FixedWrapperMinimized: {
                    animationDuration: 100
                },
                FixedWrapperRoot: {
                    position: "right",
                    css: {}
                },
                Message: {
                    secondaryTextColor: "#000",
                    horizontalAlign: "left",
                    own: {
                        horizontalAlign: "right",
                        Bubble: {
                            css: {
                                backgroundColor: "var(--primary-color)",
                                color: Bt
                            }
                        },
                        Content: {
                            css: {
                                alignItems: "flex-end"
                            }
                        },
                        MessageMeta: {
                            css: {
                                textAlign: "right"
                            }
                        },
                        Time: {
                            css: {
                                textAlign: "right"
                            }
                        }
                    },
                    bot: {
                        Bubble: {
                            css: {
                                backgroundColor: "green"
                            }
                        }
                    }
                },
                MessageButtons: {},
                MessageGroup: {},
                MessageList: {
                    css: {
                        backgroundColor: "var(--tertiary-color)"
                    }
                },
                MessageMedia: {},
                MessageText: {},
                MessageTitle: {},
                QuickReply: {
                    css: {
                        borderColor: "var(--primary-color)",
                        backgroundColor: "#fff",
                        color: "var(--primary-color)"
                    }
                },
                TextComposer: {
                    inputColor: "#000",
                    Icon: {
                        color: "#aaa"
                    },
                    IconButton: {
                        active: {
                            Icon: {
                                color: "var(--primary-color)"
                            }
                        }
                    }
                },
                TitleBar: {
                    iconsColor: "#fff",
                    behaviour: "default",
                    css: {
                        backgroundColor: "var(--primary-color)"
                    }
                }
            },
            Nt = function e(t) {
                var n = v(t);
                return 0 === Object.keys(n).length ? Object(i.a)({}, t, {
                    vars: Object(a.O)((function(e) {
                        return "--" + e
                    }), t.vars || {})
                }) : Object(i.a)({}, t, Object(a.P)((function(t) {
                    return Object(i.a)({}, e(t), {
                        css: t.css || {}
                    })
                }), n), {
                    vars: Object(a.O)((function(e) {
                        return "--" + e
                    }), t.vars || {})
                })
            },
            Vt = function(e) {
                var t = e.theme,
                    n = void 0 === t ? {} : t,
                    r = e.children,
                    i = Nt(Object(a.T)(qt, n));
                return u.createElement(l, {
                    value: i
                }, r)
            };
        var Ft = _("button", {
                displayName: "QuickReply",
                target: "e1gt5po80"
            })({
                name: "hta3ic",
                styles: "border-width:1px;border-style:solid;font-size:1em;line-height:1em;appearance:none;transition:box-shadow 0.1s,color 0.1s,border-color 0.2s;margin:0.25em;background-color:#fff;border-radius:1.4em;box-shadow:0 0.1em 0.1em 0 rgba(32, 34, 40, 0.05);font-weight:400;overflow:hidden;padding:0.375em 1em 0.5em;word-break:break-word;&:hover{cursor:pointer;}&:active{outline:none;}"
            }),
            Ut = function(e) {
                var t = e.value,
                    n = e.onSelect,
                    r = void 0 === n ? a.V : n,
                    o = e.onClick,
                    c = void 0 === o ? a.V : o,
                    s = Object(f.a)(e, ["value", "onSelect", "onClick"]),
                    d = Object(ze.f)(),
                    l = u.useCallback((function(e) {
                        r(t), c(e)
                    }), [c, r, t]);
                return u.createElement(Ft, Object(i.a)({
                    value: t
                }, s, d, {
                    onClick: l
                }))
            };
        Object(a.ab)(console.warn.bind(console));
        var Ht = _("div", {
                displayName: "QuickReplies",
                target: "e1dnb9qc0"
            })({
                name: "1q028wg",
                styles: "display:flex;flex-wrap:wrap;text-align:center;justify-content:center;width:100%"
            }),
            Gt = function(e) {
                function t() {
                    for (var t, n = arguments.length, r = new Array(n), i = 0; i < n; i++) r[i] = arguments[i];
                    return (t = e.call.apply(e, [this].concat(r)) || this)._handleSelect = function(e) {
                        return t.props.onSelect(e)
                    }, t
                }
                return Object(Be.a)(t, e), t.prototype.render = function() {
                    var e = this,
                        t = this.props,
                        n = t.children,
                        r = t.replies,
                        o = (t.onSelect, Object(f.a)(t, ["children", "replies", "onSelect"]));
                    var a = n ? It(n) : r.map((function(e, t) {
                        return u.createElement(Ut, {
                            key: t,
                            value: e
                        }, e)
                    }));
                    return u.createElement(Ht, Object(i.a)({}, o, {
                        role: "group"
                    }), u.Children.map(a, (function(t) {
                        return Object(u.cloneElement)(t, {
                            onSelect: e._handleSelect
                        })
                    })))
                }, t
            }(u.Component);
        Gt.defaultProps = {
            onSelect: a.V
        }, Gt.propTypes = {
            children: w.node,
            onSelect: w.func,
            replies: w.arrayOf(w.string)
        };
        var Wt = _("div", {
                displayName: "TitleBar",
                section: !0,
                target: "e1ohfhv1"
            })({
                name: "1rw1ajx",
                styles: "display:flex;justify-content:center;align-items:center;width:100%;border:#000;color:#fff;position:relative;z-index:2;text-align:center;padding:0.4em"
            }),
            Yt = _("div", {
                displayName: "TitleBarTitle",
                target: "e1ohfhv0"
            })({
                name: "1tbgouq",
                styles: "width:100%;margin:0;margin-bottom:4px;padding:0 2px;text-align:center;font-size:0.9em;flex-grow:1"
            }),
            Kt = function(e) {
                var t = e.leftIcons,
                    n = e.rightIcons,
                    r = e.title,
                    i = Object(f.a)(e, ["leftIcons", "rightIcons", "title"]);
                return u.createElement(Wt, i, t, u.createElement(Yt, {
                    ellipsis: !0
                }, r), n)
            };
        Kt.propTypes = {
            leftIcons: w.arrayOf(w.node),
            rightIcons: w.arrayOf(w.node),
            theme: w.shape(),
            title: w.node
        };
        var Zt = Kt,
            Jt = function(e) {
                return 13 === e.which
            },
            Xt = function(e) {
                return Jt(e) && (e.altKey || e.shiftKey)
            },
            Qt = function(e) {
                return Jt(e) && !e.altKey && !e.shiftKey
            };
        var $t = u.createContext(),
            en = function() {
                return u.useContext($t)
            },
            tn = _("div", {
                displayName: "TextComposer",
                section: !0,
                target: "eyij3xx0"
            })({
                name: "1xbhw8e",
                styles: "padding:0;background:#fff;border-top:1px solid rgba(0, 0, 0, 0.1)"
            }),
            nn = function(e) {
                function t() {
                    for (var t, n = arguments.length, r = new Array(n), i = 0; i < n; i++) r[i] = arguments[i];
                    return (t = e.call.apply(e, [this].concat(r)) || this).state = {
                        value: t._getValue({
                            value: t.props.defaultValue
                        })
                    }, t._handleButtonClick = function(e) {
                        t.maybeSend() && t.props.onButtonClick(e)
                    }, t._handleChange = function(e) {
                        var n = e.target.value;
                        t._isControlled() || t.setState({
                            value: n
                        }), t.props.onValueChange(n), t.props.onChange(e)
                    }, t._handleInputRef = function(e) {
                        t._inputRef = e
                    }, t._handleKeyDown = function(e) {
                        var n = t.props.onKeyDown;
                        Qt(e) && e.preventDefault(), Jt(e) && !Xt(e) ? (t.maybeSend(), n(e)) : n(e)
                    }, t.maybeSend = function() {
                        return !!t._canSend() && (t._isControlled() || t.setState({
                            value: ""
                        }), t.props.onValueChange(""), t.props.onSend(Object(a.yb)(t._getValue())), !0)
                    }, t
                }
                Object(Be.a)(t, e);
                var n = t.prototype;
                return n._getValue = function(e, t) {
                    return void 0 === e && (e = this.state), void 0 === t && (t = this.props), this._isControlled() ? t.value : e.value
                }, n._canSend = function() {
                    return this.props.active && "" !== this._getValue().trim()
                }, n._isControlled = function() {
                    return "string" === typeof this.props.value
                }, n._setCursorAtTheEnd = function() {
                    var e = this._inputRef.value.length;
                    this._inputRef.setSelectionRange(e, e)
                }, n.componentDidMount = function() {
                    this.props.defaultValue && this._inputRef && document.activeElement === this._inputRef && this._setCursorAtTheEnd()
                }, n.componentDidUpdate = function(e, t) {
                    var n = this._getValue();
                    n !== this._getValue(t, e) && "" === n && this._inputRef.focus()
                }, n.render = function() {
                    var e = this.props,
                        t = (e.active, e.children),
                        n = (e.defaultValue, e.onButtonClick, e.onChange, e.onKeyDown, e.onSend, e.onValueChange, e.value, Object(f.a)(e, ["active", "children", "defaultValue", "onButtonClick", "onChange", "onKeyDown", "onSend", "onValueChange", "value"])),
                        r = {
                            active: this._canSend(),
                            inputRef: this._handleInputRef,
                            value: this._getValue(),
                            maybeSend: this.maybeSend,
                            onButtonClick: this._handleButtonClick,
                            onChange: this._handleChange,
                            onKeyDown: this._handleKeyDown
                        };
                    return u.createElement($t.Provider, {
                        value: r
                    }, u.createElement(tn, n, t))
                }, t
            }(u.Component);
        nn.propTypes = {
            active: w.bool,
            children: w.node,
            defaultValue: w.string,
            onButtonClick: w.func,
            onChange: w.func,
            onKeyDown: w.func,
            onSend: w.func,
            value: w.string
        }, nn.defaultProps = {
            active: !0,
            defaultValue: "",
            onButtonClick: a.V,
            onChange: a.V,
            onKeyDown: a.V,
            onSend: a.V,
            onValueChange: a.V
        };
        var rn = function(e) {
                var t = e.icon,
                    n = e.onClick,
                    r = void 0 === n ? a.V : n,
                    o = Object(f.a)(e, ["icon", "onClick"]),
                    c = en(),
                    s = c.active,
                    d = c.onButtonClick;
                return u.createElement(Pe, Object(i.a)({}, o, {
                    active: s,
                    disabled: !s,
                    onClick: function(e) {
                        s && (d(e), r(e))
                    }
                }), t ? u.createElement(G, {
                    "aria-hidden": !0
                }, t) : u.createElement($, null))
            },
            on = n(257),
            an = n(75);
        var cn = _(u.forwardRef((function(e, t) {
                e.flexFill;
                var n = Object(f.a)(e, ["flexFill"]);
                return u.createElement(on.a, Object(i.a)({
                    ref: t
                }, n))
            })), {
                displayName: "TextInput",
                target: "e1m92qam0"
            })({
                name: "1c0v4at",
                styles: "appearance:none;border:0;resize:none;background-color:#fff;height:1.5em;line-height:1.5em;min-width:0;width:100%;font-size:1em;&:focus,&:active{outline:none;}"
            }),
            un = u.forwardRef((function(e, t) {
                var n = e.maxRows,
                    r = void 0 === n ? 3 : n,
                    o = e.placeholder,
                    a = void 0 === o ? "Write a message..." : o,
                    c = Object(f.a)(e, ["maxRows", "placeholder"]),
                    s = u.useRef(),
                    d = Object(Ve.a)(s, t),
                    l = en(),
                    p = l.value,
                    m = l.inputRef,
                    v = l.onChange,
                    b = l.onKeyDown,
                    h = Object(an.useFrame)().document;
                return u.createElement(cn, Object(i.a)({}, c, {
                    onChange: function(e) {
                        v(e), c.onChange && c.onChange(e)
                    },
                    onKeyDown: function(e) {
                        b(e), c.onKeyDown && c.onKeyDown(e)
                    },
                    value: p,
                    maxRows: r,
                    placeholder: a,
                    ref: function(e) {
                        d(e), m(e)
                    },
                    document: h
                }))
            })),
            sn = function(e) {
                function t() {
                    for (var t, n = arguments.length, r = new Array(n), i = 0; i < n; i++) r[i] = arguments[i];
                    return (t = e.call.apply(e, [this].concat(r)) || this).handleButtonClick = function(e) {
                        return function(n) {
                            t.props.onButtonClick(n, e)
                        }
                    }, t
                }
                return Object(Be.a)(t, e), t.prototype.render = function() {
                    var e = this,
                        t = null,
                        n = Object(a.p)((function(e) {
                            return e.showMore
                        }), this.props.buttons);
                    if (-1 !== n) {
                        var r = this.props.buttons[n],
                            o = r.text,
                            c = Object(f.a)(r, ["text"]);
                        t = u.createElement(Ct, Object(i.a)({}, c, {
                            label: o,
                            "data-variant": "show-more",
                            onClick: this.handleButtonClick(n)
                        }))
                    }
                    return u.createElement(u.Fragment, null, u.createElement(ht, null, this.props.buttons.map((function(t, r) {
                        var o = t.text,
                            a = t.key,
                            c = (t.showMore, Object(f.a)(t, ["text", "key", "showMore"])),
                            s = void 0 !== a ? a : r;
                        return r !== n ? u.createElement(Ct, Object(i.a)({
                            key: s,
                            label: o.length > 20 ? o.slice(0, 20).trim() + "\u2026" : o,
                            onClick: e.handleButtonClick(s)
                        }, c)) : null
                    }))), t)
                }, t
            }(u.Component);
        sn.defaultProps = {
            onButtonClick: a.V
        };
        var dn = sn,
            ln = function(e) {
                return e.stopPropagation()
            },
            fn = function(e) {
                return Object(N.d)("a", Object(i.a)({}, e, {
                    onClick: ln,
                    rel: "nofollow noopener",
                    target: "_blank"
                }))
            },
            pn = function(e) {
                return Object(N.c)("display:block;width:100%;height:", e ? "100%" : "150px", ";object-fit:cover;")
            },
            mn = _("div", {
                target: "e9ztsyy0"
            })("display:flex;margin:0 auto;overflow:hidden;width:100%;min-width:110px;height:", (function(e) {
                return e.horizontalLayout ? "100%" : "150px"
            }), ";align-items:center;justify-content:center;background:#fff;"),
            vn = function(e) {
                var t = e.link,
                    n = e.url,
                    r = e.srcset,
                    o = e.horizontalLayout,
                    a = Object(f.a)(e, ["link", "url", "srcset", "horizontalLayout"]),
                    c = Object(N.d)(mt, a, Object(N.d)(mn, {
                        horizontalLayout: o
                    }, Object(N.d)(ge, Object(i.a)({
                        alt: "",
                        css: pn(o)
                    }, function(e, t) {
                        var n = {
                            src: e
                        };
                        return void 0 !== t && (n.srcSet = t), n
                    }(n, r)))));
                return t ? Object(N.d)(fn, {
                    href: t,
                    style: a.style
                }, c) : c
            };
        vn.propTypes = {
            link: w.string,
            url: w.string.isRequired,
            srcSet: w.string
        };
        var bn = vn;
        var hn = {
                name: "oipjxo",
                styles: "width:230px"
            },
            gn = {
                name: "ho1qnd",
                styles: "display:flex;flex-direction:row"
            },
            yn = {
                name: "1mb649y",
                styles: "max-width:110px"
            },
            On = _("div", {
                target: "es7wtci0"
            })("width:230px;min-width:0px;max-width:", (function(e) {
                return e.horizontalLayout ? "66%" : "100%"
            }), ";"),
            jn = {
                borderTopLeftRadius: "inherit",
                borderTopRightRadius: "inherit",
                borderBottomRightRadius: 0,
                borderBottomLeftRadius: 0
            },
            _n = {
                borderTopLeftRadius: "inherit",
                borderTopRightRadius: 0,
                borderBottomRightRadius: 0,
                borderBottomLeftRadius: "inherit"
            },
            wn = (u.Component, n(193));
        var xn = _("div", {
                target: "epptpc33"
            })({
                name: "1u909ow",
                styles: "position:relative;width:100%;display:flex"
            }),
            En = {
                name: "fol00x",
                styles: "scrollbar-width:none;-ms-overflow-style:none;&::-webkit-scrollbar{display:none;}"
            },
            Cn = _("div", {
                target: "epptpc32"
            })("display:flex;width:100%;overflow-x:auto;-webkit-overflow-scrolling:touch;align-items:flex-start;", En, " ", (function(e) {
                var t, n = e.padding,
                    r = e.dir;
                return Object(i.a)({}, "undefined" !== typeof n && {
                    padding: n
                }, {
                    "> :not(:last-child)": (t = {}, t["rtl" === r ? "marginLeft" : "marginRight"] = 8, t)
                })
            }), ";"),
            In = _("div", {
                target: "epptpc31"
            })({
                name: "1blnsxj",
                styles: "flex-grow:0;flex-shrink:0"
            }),
            Sn = _("button", {
                target: "epptpc30"
            })("position:absolute;width:30px;height:30px;border-radius:50%;background:#fff;border:0;box-shadow:0 4px 12px rgba(0, 0, 0, 0.3);text-align:center;top:32%;display:flex;align-items:center;justify-content:center;padding:0;z-index:1;outline:0;-webkit-transform:translate3d(0, 0, 0);&:hover{cursor:pointer;}svg{display:inline;}", (function(e) {
                var t;
                return (t = {})[e.variant] = ".5em", t
            }), ";"),
            Tn = function(e) {
                var t = e.itemCount;
                return t * e.itemWidth + (t - 1) * e.spacing
            },
            kn = function(e) {
                var t = e.clientWidth,
                    n = e.scrollableElement,
                    r = e.currentX,
                    i = e.nextX,
                    o = e.scrollDirection,
                    a = e.isRtl,
                    c = n.firstElementChild.getBoundingClientRect().width,
                    u = function(e, t) {
                        if (e.length < 2) return 0;
                        var n = e[0],
                            r = e[1],
                            i = n.getBoundingClientRect(),
                            o = r.getBoundingClientRect();
                        return t ? i.left - o.right : o.left - i.right
                    }(n.children, a),
                    s = (a ? n.lastElementChild : n.firstElementChild).getBoundingClientRect().left - n.getBoundingClientRect().left + r,
                    d = function(e) {
                        var t = e.x,
                            n = e.scrollDirection,
                            r = (t - e.leftElementXOffset) / (e.itemWidth + e.spacing);
                        return 1 === n ? Math.floor(r) : Math.ceil(r)
                    }({
                        x: i,
                        scrollDirection: o,
                        leftElementXOffset: s,
                        itemWidth: c,
                        spacing: u
                    });
                if (c > t) return s + (1 === o ? d + 1 : d - 1) * (c + u);
                var l = s + d * (c + u),
                    f = Math.floor(t / (c + u)),
                    p = Tn({
                        itemCount: f,
                        itemWidth: c,
                        spacing: u
                    });
                return l + (p + c <= t ? Tn({
                    itemCount: f + 1,
                    itemWidth: c,
                    spacing: u
                }) : p) / 2 - t / 2
            },
            An = function(e) {
                var t = e.children,
                    n = e.scrollableElementPadding,
                    r = e.dir,
                    o = u.useRef(0),
                    c = u.useRef(null),
                    s = Object(ze.f)().isFocusVisible,
                    d = u.useState(!0),
                    l = d[0],
                    f = d[1],
                    p = u.useState(!0),
                    m = p[0],
                    v = p[1],
                    b = Object(Re.j)(),
                    h = b[0],
                    g = b[1],
                    y = Object(Re.t)("x", c),
                    O = !(h && s),
                    j = u.useCallback((function() {
                        var e = c.current;
                        e && (f(! function(e) {
                            if ("ltr" === getComputedStyle(e).direction) return e.scrollLeft <= 1;
                            var t = e.scrollWidth - e.clientWidth;
                            switch (Object(qe.g)()) {
                                case "negative":
                                    return e.scrollLeft <= 1 - t;
                                case "positive-ascending":
                                    return e.scrollLeft >= t - 1;
                                case "positive-descending":
                                    return e.scrollLeft <= 1
                            }
                        }(e)), v(! function(e) {
                            var t = getComputedStyle(e).direction,
                                n = e.scrollWidth - e.clientWidth;
                            if ("ltr" === t) return e.scrollLeft >= n - 1;
                            switch (Object(qe.g)()) {
                                case "negative":
                                    return e.scrollLeft >= -1;
                                case "positive-ascending":
                                    return e.scrollLeft <= 1;
                                case "positive-descending":
                                    return e.scrollLeft >= n - 1
                            }
                        }(e)))
                    }), []),
                    _ = u.useMemo((function() {
                        return Object(a.tb)(200, j)
                    }), [j]);
                Object(Re.n)((function() {
                    var e = requestAnimationFrame(j),
                        t = new wn.a(Object(a.h)(200, j));
                    return t.observe(c.current),
                        function() {
                            cancelAnimationFrame(e), t.disconnect()
                        }
                }));
                var w = function(e) {
                    o.current += e, o.current < 0 ? o.current = 0 : o.current >= t.length && (o.current = t.length - 1);
                    var n = c.current,
                        i = n.clientWidth,
                        a = n.scrollWidth,
                        u = "rtl" === r,
                        s = function(e, t) {
                            var n = e.scrollWidth - e.clientWidth;
                            if (t) switch (Object(qe.g)()) {
                                case "negative":
                                    return n + e.scrollLeft;
                                case "positive-ascending":
                                    return n - e.scrollLeft;
                                case "positive-descending":
                                    return e.scrollLeft
                            }
                            return e.scrollLeft
                        }(n, u),
                        d = s + e * i,
                        l = 1 === e ? Math.min(d, a - i) : Math.max(d, 0),
                        f = d === l ? kn({
                            clientWidth: i,
                            scrollableElement: n,
                            currentX: s,
                            nextX: d,
                            scrollDirection: e,
                            isRtl: u
                        }) : l;
                    if (u) switch (Object(qe.g)()) {
                        case "negative":
                            return void y(-a + i + f);
                        case "positive-ascending":
                            return void y(a - i - f);
                        case "positive-descending":
                            return void y(f)
                    } else y(f)
                };
                return u.createElement(xn, null, O && l && u.createElement(Sn, {
                    variant: "left",
                    "aria-label": "Previous item",
                    onClick: function(e) {
                        e.stopPropagation(), w(-1)
                    }
                }, u.createElement(Y, {
                    "aria-hidden": !0
                })), u.createElement(Cn, Object(i.a)({
                    dir: r,
                    tabIndex: -1,
                    ref: c,
                    onScroll: _,
                    padding: n
                }, g), u.Children.map(t, (function(e, t) {
                    return u.createElement(In, {
                        onFocus: function() {
                            return w(Object(a.mb)(t - o.current))
                        }
                    }, e)
                }))), O && m && u.createElement(Sn, {
                    variant: "right",
                    "aria-label": "Next item",
                    onClick: function(e) {
                        e.stopPropagation(), w(1)
                    }
                }, u.createElement(Z, {
                    "aria-hidden": !0
                })))
            }
    }, , function(e, t, n) {
        "use strict";
        n.d(t, "c", (function() {
            return l
        })), n.d(t, "g", (function() {
            return f
        })), n.d(t, "H", (function() {
            return p
        })), n.d(t, "E", (function() {
            return m
        })), n.d(t, "U", (function() {
            return v
        })), n.d(t, "D", (function() {
            return b
        })), n.d(t, "n", (function() {
            return g
        })), n.d(t, "r", (function() {
            return y
        })), n.d(t, "e", (function() {
            return O
        })), n.d(t, "l", (function() {
            return j
        })), n.d(t, "q", (function() {
            return _
        })), n.d(t, "x", (function() {
            return w
        })), n.d(t, "f", (function() {
            return x
        })), n.d(t, "z", (function() {
            return E
        })), n.d(t, "lb", (function() {
            return C
        })), n.d(t, "Z", (function() {
            return I
        })), n.d(t, "db", (function() {
            return S
        })), n.d(t, "G", (function() {
            return T
        })), n.d(t, "J", (function() {
            return k
        })), n.d(t, "kb", (function() {
            return A
        })), n.d(t, "p", (function() {
            return M
        })), n.d(t, "k", (function() {
            return L
        })), n.d(t, "h", (function() {
            return P
        })), n.d(t, "F", (function() {
            return R
        })), n.d(t, "s", (function() {
            return D
        })), n.d(t, "eb", (function() {
            return B
        })), n.d(t, "o", (function() {
            return q
        })), n.d(t, "t", (function() {
            return N
        })), n.d(t, "i", (function() {
            return V
        })), n.d(t, "S", (function() {
            return F
        })), n.d(t, "T", (function() {
            return U
        })), n.d(t, "L", (function() {
            return H
        })), n.d(t, "ib", (function() {
            return W
        })), n.d(t, "fb", (function() {
            return Y
        })), n.d(t, "gb", (function() {
            return K
        })), n.d(t, "w", (function() {
            return Z
        })), n.d(t, "R", (function() {
            return J
        })), n.d(t, "hb", (function() {
            return X
        })), n.d(t, "A", (function() {
            return Q
        })), n.d(t, "ab", (function() {
            return $
        })), n.d(t, "jb", (function() {
            return ee
        })), n.d(t, "bb", (function() {
            return ne
        })), n.d(t, "K", (function() {
            return re
        })), n.d(t, "cb", (function() {
            return ie
        })), n.d(t, "j", (function() {
            return ae
        })), n.d(t, "N", (function() {
            return ce
        })), n.d(t, "I", (function() {
            return ue
        })), n.d(t, "d", (function() {
            return se
        })), n.d(t, "O", (function() {
            return de
        })), n.d(t, "mb", (function() {
            return le
        })), n.d(t, "X", (function() {
            return fe
        })), n.d(t, "M", (function() {
            return pe
        })), n.d(t, "C", (function() {
            return me
        })), n.d(t, "Y", (function() {
            return ve
        })), n.d(t, "P", (function() {
            return be
        })), n.d(t, "a", (function() {
            return he
        })), n.d(t, "m", (function() {
            return ye
        })), n.d(t, "b", (function() {
            return Oe
        })), n.d(t, "Q", (function() {
            return je
        })), n.d(t, "W", (function() {
            return _e
        })), n.d(t, "B", (function() {
            return we
        })), n.d(t, "V", (function() {
            return xe
        })), n.d(t, "y", (function() {
            return Ce
        })), n.d(t, "v", (function() {
            return Ie
        })), n.d(t, "u", (function() {
            return Se
        }));
        var r = n(2),
            i = n(3),
            o = n(55),
            a = n(67),
            c = n(76),
            u = n(6),
            s = n(24),
            d = n(19),
            l = function(e, t) {
                var n = t.getChat(e).properties.currentAgent;
                return n ? t.getUser(n) : null
            },
            f = function(e, t) {
                return t.getApplicationState("config").features[e]
            },
            p = function(e) {
                return f("continuousChat", e).enabled
            },
            m = function(e) {
                return f("chatHistory", e).enabled
            },
            v = function(e) {
                return !!e.getView("Chat")[i.d].hasDividers
            },
            b = function(e) {
                return U(e) && !p(e)
            },
            h = function(e, t, n) {
                var i = t.authorPredicate,
                    o = t.lastSeenPredicate,
                    a = n.getEvents(e),
                    c = Object(r.r)(o, a),
                    u = Object(r.sb)((function(e) {
                        return i(e) || !e.seen
                    }), c, a);
                return Object(r.hb)(i, u)
            },
            g = function(e, t, n) {
                var r = n.getSessionUserId();
                return h(e, {
                    authorPredicate: function(e) {
                        return e.author !== r
                    },
                    lastSeenPredicate: function(e) {
                        return (e.serverTimestamp || e.timestamp) <= t
                    }
                }, n)
            },
            y = function(e, t, n) {
                var r = n.getSessionUserId();
                return h(e, {
                    authorPredicate: function(e) {
                        return e.author === r
                    },
                    lastSeenPredicate: function(e) {
                        return e.timestamp <= t
                    }
                }, n)
            },
            O = function(e, t, n) {
                var o = e.getEvent(t, n);
                if (o.type === i.g && null === o.serverId) {
                    var a = Object(r.q)((function(e) {
                        return e.type === i.g
                    }), e.getEvents(t));
                    return o.id === a.id ? e.localize("not_sent_yet") : null
                }
                if (!o.own) return null;
                if (o.failed) return "Message not sent";
                if (o.seen) {
                    var c = e.getLastSeenEvent(t);
                    return c && n === c.id ? e.localize("message_read") : null
                }
                var u = e.getLastDeliveredEvent(t);
                return u && n === u.id ? e.localize("message_delivered") : null
            },
            j = function(e) {
                var t = e.getApplicationState("config");
                return !0 === e.getApplicationState("mobile") ? t.mobileMinimizedType : t.minimizedType
            },
            _ = function(e) {
                var t = e.getApplicationState("config");
                return !0 === e.getApplicationState("mobile") ? t.mobileScreenPosition : t.screenPosition
            },
            w = function(e, t) {
                return m(e) && e.getChat(t).properties.hasMoreHistory
            },
            x = function(e, t) {
                var n = e.getChat(t).properties.fakeAgentMessageId;
                return n ? e.getEvent(t, n) : null
            },
            E = function(e, t) {
                return !!x(e, t)
            },
            C = function(e) {
                var t = e.getApplicationState(),
                    n = t.embedded,
                    r = t.actingAsDirectLink,
                    i = t.isInCustomContainer;
                return !!n && !r && !i
            },
            I = function(e, t) {
                var n = t.getChat(i.d),
                    o = n.active,
                    a = n.properties.queued;
                if (o || a) return !1;
                var c = t.getApplicationState(),
                    u = c.availability,
                    d = c.readyState;
                return "online" === u && (d === s.a.NOT_READY || (!_e(t, "maximized") || Object(r.F)(t.getEvents(e))))
            },
            S = function(e, t) {
                if (m(t)) return !1;
                var n = t.getApplicationState(),
                    r = n.availability,
                    i = n.embedded,
                    o = n.actingAsDirectLink,
                    a = n.isInCustomContainer,
                    c = t.getChat(e);
                return i && !o && !a && !c.active && !c.properties.ended && "offline" === r && !U(t)
            },
            T = function(e) {
                return e.getConnectionState() === o.a
            },
            k = function(e) {
                return e.getConnectionState() === o.b
            },
            A = function(e) {
                return e.getConnectionState() === o.d || k(e)
            },
            z = function e(t, n) {
                if (n < 0) return null;
                var r = t[n];
                return r.own && "message" === r.type ? null : "system_message" === r.type || "rich_message_postback" === r.type ? e(t, n - 1) : r.properties.quickReplies ? r : null
            },
            M = function(e, t) {
                var n = t.getEvents(e),
                    r = z(n, n.length - 1);
                return r && (r.properties.invitation || t.getChat(e).active) ? r : null
            },
            L = function(e, t) {
                var n = t.getApplicationState().availability,
                    r = t.getChat(e),
                    i = r.active,
                    o = r.properties,
                    a = o.queued,
                    c = o.ended;
                if (a) return t.localize("embedded_waiting_for_operator");
                var u = l(e, t);
                return i && u ? t.localize("embedded_chat_with", {
                    operator: u.name
                }) : c ? t.localize("embedded_chat_ended") : "online" === n ? t.localize("embedded_chat_now") : U(t) ? t.localize("embedded_leave_message") : t.localize("agents_not_available")
            },
            P = function(e, t) {
                var n = e.getChat(t),
                    r = p(e);
                return e.getApplicationState().limitReached || ee(e) && !te(e) ? null : n.active ? "text" : be(e, t) || H(e) ? null : !n.properties.ended || r && !F(e) ? r || "offline" !== e.getApplicationState().availability ? E(e, i.d) ? F(e) && f("preChatAfterGreeting", e).enabled ? r && "offline" === e.getApplicationState().availability ? null : "requestPrechat" : l(t, e).properties.isBot || G(e) ? "startChat" : "text" : r ? F(e) ? "offline" === e.getApplicationState().availability ? null : "requestPrechat" : "text" : r && n.properties.ended ? "text" : null : null : "startChatAgain"
            },
            R = function(e, t) {
                return !!t.getChat(e).properties.starting
            },
            D = function(e) {
                return e.getApplicationState("testGroup")
            },
            B = function(e) {
                return 1520 === e.getApplicationState("license")
            },
            q = function(e) {
                var t = e.localize("user_in_queue"),
                    n = e.getView("Chat/prechat").fields;
                if (!n || Object(r.F)(n)) return t;
                var i = n.find((function(e) {
                    var t = e.meta;
                    return t && "groupSelect" === t
                }));
                if (!i || !i.options || Object(r.F)(i.options)) return t;
                var o = i.options.find((function(t) {
                    return t.groupNumber === e.getApplicationState("group")
                }));
                return o && o.queueTemplate ? o.queueTemplate : t
            },
            N = function(e) {
                return e.getApplicationState("config").theme.name
            },
            V = function(e, t) {
                return Object(r.q)((function(e) {
                    return !e.own && Object(r.D)(e.type, ["message", "rich_message", "url_preview", "emoji"])
                }), e.getEvents(t))
            },
            F = function(e) {
                return e.getApplicationState().config.features.preChatForm.enabled
            },
            U = function(e) {
                return e.getApplicationState().config.features.ticketForm.enabled
            },
            H = function(e, t) {
                void 0 === t && (t = void 0);
                var n = e.getLastEvent(i.d);
                if (!n) return !1;
                var r = n.type,
                    o = n.properties;
                return "form" === r && !o.answered && "ask_for_email" !== o.formId && ("string" !== typeof t || o.formType === t)
            },
            G = function(e) {
                return !!e.getChat(i.d).properties.groupHasProbableQueue
            },
            W = function(e) {
                var t = e.getChat(i.d),
                    n = t.active,
                    r = t.properties,
                    o = r.queued,
                    a = r.ended,
                    c = r.startChatAgainPending,
                    u = r.currentAgent,
                    s = e.getApplicationState(),
                    d = s.availability,
                    l = s.limitReached,
                    f = p(e),
                    m = U(e);
                return !(!l || m && !f) || "offline" === d && (!(a && !c) && (f ? !u && !o : !n && !o && !m))
            },
            Y = function(e) {
                return l(i.d, e) && !H(e) && ! function(e, t) {
                    return !!t.getChat(e).properties.queued
                }(i.d, e) && !W(e)
            },
            K = function(e) {
                return !(!ee(e) || e.getView("Chat/queue")) || ("loader" === e.getDefaultView("Chat") || !ve(e) && me(e))
            },
            Z = function(e) {
                var t = e.getLastEvent(i.d);
                return !!t && ("form" === t.type && "ticket" === t.properties.formType && t.properties.answered)
            },
            J = function(e) {
                return e.getApplicationState("config").nonProfitLicense
            },
            X = function(e) {
                var t = e.getApplicationState(),
                    n = t.actingAsDirectLink,
                    r = t.isInCustomContainer,
                    i = t.mobileWrapper,
                    o = t.embedded;
                return !n && !r && (i || o)
            },
            Q = function(e) {
                return Boolean(e.getApplicationState("invitation").current)
            },
            $ = function(e) {
                var t = e.getChat(i.d).properties,
                    n = t.lastThread,
                    o = t.currentAgent,
                    a = t.queued;
                return !(!p(e) || o || a) && !!!Object(r.q)((function(e) {
                    var t = e.type,
                        r = e.thread;
                    return "email_prompt" === t && r === n
                }), e.getEvents(i.d))
            },
            ee = function(e) {
                return e.getChat(i.d).properties.queued
            },
            te = function(e) {
                var t;
                return Boolean(null == (t = f("queue", e)) ? void 0 : t.writingInQueueEnabled)
            },
            ne = function(e) {
                return f("fileSharing", e).enabled
            },
            re = function(e) {
                return e.getChat(i.d).active && !A(e)
            },
            ie = function(e) {
                return !A(e)
            },
            oe = Object(c.createSelector)([function(e) {
                return Object(u.getEvents)(e, i.d)
            }, function(e) {
                return Object(u.getChat)(e, i.d).properties.lastThread
            }], (function(e, t) {
                return Object(r.rb)((function(e) {
                    return e.thread === t
                }), e)
            })),
            ae = function(e) {
                return oe(e.getState())
            },
            ce = function(e, t) {
                return !!e.hasEvent(i.d, t) && e.getEvent(i.d, t).properties.invitation
            },
            ue = function(e) {
                return !e.getApplicationState().mobile && "bar" === j(e)
            },
            se = function(e) {
                var t = x(e, i.d);
                return t && t.properties.invitation ? t : null
            },
            de = function(e, t) {
                void 0 === t && (t = se(e));
                var n = e.getApplicationState(),
                    i = n.availability,
                    o = n.invitation;
                return !("offline" !== i && !ue(e)) || Boolean(t && Object(r.D)(t.properties.uniqueId, o.hiddenIds))
            },
            le = function(e, t) {
                void 0 === t && (t = se(e));
                var n = e.getApplicationState().invitation;
                return Boolean(t && Object(r.D)(t.properties.uniqueId, n.displayedIds))
            },
            fe = function(e) {
                return !ae(e).some((function(e) {
                    var t = e.author;
                    return !e.own && "system" !== t
                }))
            },
            pe = function(e) {
                var t = e.properties,
                    n = t.formType,
                    i = t.fields,
                    o = t.answered,
                    a = i.filter((function(e) {
                        return e.answer && e.label
                    }));
                return "ticket" !== n && o && Object(r.F)(a)
            },
            me = function(e) {
                var t = e.getEvents(i.d);
                return Object(r.F)(t) || t.every((function(e) {
                    return "form" === e.type && pe(e)
                }))
            },
            ve = function(e) {
                return Y(e) || W(e) || ee(e)
            },
            be = function(e, t) {
                return e.getEvents(t).some((function(e) {
                    return e.type === i.g && null === e.serverId
                }))
            },
            he = function(e) {
                var t = e.getApplicationState(),
                    n = t.embedded,
                    r = t.actingAsDirectLink;
                return !n || r ? "direct_link" : "code"
            },
            ge = Object(c.createSelector)([function(e) {
                return oe(e)
            }], (function(e) {
                return e.filter((function(e) {
                    return "file" === e.type && !e.delivered && !e.properties.canceled
                }))
            })),
            ye = function(e) {
                return ge(e.getState())
            },
            Oe = function(e) {
                return e.getChat(i.d).serverId
            },
            je = function(e) {
                var t = e.getApplicationState().mobile;
                return f(t ? "mobileMinimized" : "minimized", e).enabled
            },
            _e = function(e, t) {
                return e.getApplicationState("visibility").state === t
            },
            we = function(e, t) {
                var n = e.getApplicationState("config").properties.license;
                return Object.keys(n).some((function(e) {
                    return n[e][t]
                }))
            },
            xe = function(e) {
                var t = e.getApplicationState().mobile;
                return f("hideTrademark", e).enabled || t
            },
            Ee = function(e, t) {
                return e.getApplicationState("config").properties.license[t]
            },
            Ce = function(e) {
                if ("en" !== e.getApplicationState().language) return !1;
                var t = a.a,
                    n = Ee(e, t);
                return Boolean(null == n ? void 0 : n.transfer_identity_enabled)
            },
            Ie = function(e) {
                var t = a.d,
                    n = Ee(e, t);
                return {
                    url: null == n ? void 0 : n.widget_message_box_moment_url,
                    height: null == n ? void 0 : n.widget_message_box_moment_height
                }
            },
            Se = function(e) {
                var t, n, r = Ie(e).url;
                return {
                    disabled: !e.getChat(i.d).active || !l(i.d, e),
                    visible: Object(d.s)(r) && (null == (t = e.getView("Moment")) || null == (n = t.data) ? void 0 : n.url) !== r
                }
            }
    }, , function(e, t, n) {
        "use strict";
        var r = n(1),
            i = n(4),
            o = n(0),
            a = n(126);
        t.a = function(e, t) {
            return o.memo((function(n) {
                return Object(i.d)(a.a, Object(r.a)({}, t, n), e)
            }))
        }
    }, function(e, t, n) {
        "use strict";
        n.d(t, "c", (function() {
            return a
        })), n.d(t, "e", (function() {
            return c
        })), n.d(t, "a", (function() {
            return u
        })), n.d(t, "d", (function() {
            return s
        })), n.d(t, "b", (function() {
            return d
        })), n.d(t, "f", (function() {
            return l
        }));
        var r = n(1),
            i = n(2),
            o = n(58),
            a = function(e, t) {
                var n = function(n) {
                    var r = Object.create(n);
                    r.action = function(t, r) {
                        var i = {
                            type: e,
                            payload: t
                        };
                        r && (i.meta = r), n.dispatch(i)
                    };
                    for (var i = arguments.length, o = new Array(i > 1 ? i - 1 : 0), a = 1; a < i; a++) o[a - 1] = arguments[a];
                    return t.apply(void 0, [r].concat(o))
                };
                return n.toString = function() {
                    return e
                }, n
            },
            c = function(e, t) {
                var n = "REQUEST_" + e,
                    c = a(e, t),
                    u = function(e) {
                        for (var a = arguments.length, u = new Array(a > 1 ? a - 1 : 0), s = 1; s < a; s++) u[s - 1] = arguments[s];
                        var d, l = Object.create(e);
                        if (l.action = function(t) {
                                var a = Object(o.a)(),
                                    s = a.promise,
                                    l = a.resolve,
                                    f = a.reject;
                                e.dispatch({
                                    type: n,
                                    payload: Object(r.a)({}, t, {
                                        resolve: l,
                                        reject: f
                                    })
                                }), (d = s).then((function() {
                                    c.apply(void 0, [e].concat(u))
                                }), i.V)
                            }, t.apply(void 0, [l].concat(u)), "undefined" === typeof d) throw new Error("You forgot to call `action` handler in " + n + " creator.");
                        return d
                    };
                return u.toString = function() {
                    return n
                }, {
                    actionMethod: c,
                    requestActionMethod: u
                }
            },
            u = function(e, t) {
                if ("object" !== typeof e || null === e || Array.isArray(e)) throw new Error("bindActionMethods expects a plain object with actionMethods as values.");
                return Object(i.P)((function(e) {
                    return function(e, t) {
                        return function() {
                            for (var n = arguments.length, r = new Array(n), i = 0; i < n; i++) r[i] = arguments[i];
                            return e.apply(void 0, [t].concat(r))
                        }
                    }(e, t)
                }), e)
            },
            s = function(e, t) {
                return t[void 0] && console.warn(["Reducer contains an 'undefined' action type.", "Have you misspelled a constant?"].join("\n")),
                    function(n, r) {
                        return void 0 === n && (n = e), Object(i.B)(r.type, t) ? t[r.type](n, r.payload) : n
                    }
            };
        var d = function(e, t) {
                if ("object" !== typeof e || null === e || Array.isArray(e)) throw new Error("bindSelectors expects a plain object with selectors as values.");
                return Object(i.P)((function(e) {
                    return function(e, t) {
                        return function() {
                            for (var n = arguments.length, r = new Array(n), i = 0; i < n; i++) r[i] = arguments[i];
                            return e.apply(void 0, [t()].concat(r))
                        }
                    }(e, t)
                }), e)
            },
            l = function() {
                for (var e = arguments.length, t = new Array(e), n = 0; n < e; n++) t[n] = arguments[n];
                return function(e, n) {
                    return t.reduce((function(e, t) {
                        return t(e, n)
                    }), e)
                }
            }
    }, function(e, t, n) {
        "use strict";
        n.d(t, "a", (function() {
            return i
        })), n.d(t, "b", (function() {
            return o
        })), n.d(t, "d", (function() {
            return c
        })), n.d(t, "e", (function() {
            return s
        })), n.d(t, "h", (function() {
            return m
        })), n.d(t, "i", (function() {
            return p
        })), n.d(t, "f", (function() {
            return b
        })), n.d(t, "j", (function() {
            return l
        })), n.d(t, "k", (function() {
            return y
        })), n.d(t, "l", (function() {
            return j
        })), n.d(t, "m", (function() {
            return f
        })), n.d(t, "g", (function() {
            return w
        })), n.d(t, "c", (function() {
            return E
        }));
        var r = n(2),
            i = function(e) {
                return Object(r.wb)(e).map((function(e) {
                    return e.map(encodeURIComponent).join("=")
                })).join("&")
            },
            o = function(e) {
                var t = e.split("&").map((function(e) {
                    return e.split("=").map((function(e) {
                        return decodeURIComponent(e.replace("+", "%20"))
                    }))
                }));
                return Object(r.u)(t)
            },
            a = /(?:[^:]+:\/\/)?([^/\s]+)/;

        function c(e) {
            var t = e.match(a);
            return t && t[1]
        }
        var u = /[^:]+:\/\/[^(/|?)\s]+/,
            s = function(e) {
                var t = e.match(u);
                return t && t[0]
            },
            d = /.*?\?([^#]+)/,
            l = function(e) {
                var t = e.match(d);
                return t ? "?" + t[1] : ""
            },
            f = function(e) {
                return e.replace(/^\?/, "")
            },
            p = function(e) {
                var t = f(l(e));
                return o(t || e)
            },
            m = function(e, t) {
                return p(t)[e]
            },
            v = /^(?:https?:)?\/\/[^/]+\/([^?#]+)/,
            b = function(e) {
                var t = e.match(v);
                return "/" + (t && t[1] || "")
            },
            h = function(e) {
                return e.replace(/\w/g, "$&[\\r\\n\\t]*")
            },
            g = new RegExp("^[\0-\x1f]*(" + h("javascript") + "|" + h("data") + "):", "i"),
            y = function(e) {
                return g.test(e)
            },
            O = /^((http(s)?:)?\/\/)/,
            j = function(e) {
                return e.replace(O, "")
            },
            _ = /^((http(s)?:)?\/\/)/,
            w = function(e) {
                var t = e.match(_);
                return t ? t[2] : null
            },
            x = n(1),
            E = function(e, t) {
                if (0 === Object.keys(t).length) return e;
                var n = s(e),
                    r = b(e),
                    o = l(e) ? p(e) : {};
                return "" + n + r + "?" + i(Object(x.a)({}, o, t))
            }
    }, function(e, t, n) {
        "use strict";
        n.d(t, "a", (function() {
            return o
        })), n.d(t, "b", (function() {
            return i
        })), n.d(t, "e", (function() {
            return c
        })), n.d(t, "f", (function() {
            return s
        })), n.d(t, "h", (function() {
            return d
        })), n.d(t, "g", (function() {
            return f
        })), n.d(t, "i", (function() {
            return p
        })), n.d(t, "j", (function() {
            return m
        })), n.d(t, "k", (function() {
            return v
        })), n.d(t, "c", (function() {
            return b
        })), n.d(t, "d", (function() {
            return u.a
        }));
        var r = n(2),
            i = function(e, t) {
                Object(r.t)((function(e, n) {
                    t.style[n] = e
                }), e)
            },
            o = function(e, t) {
                Object(r.t)((function(e, n) {
                    "style" !== n ? t.setAttribute(n, e) : i(e, t)
                }), e)
            },
            a = !!document.documentElement.currentStyle,
            c = function(e, t) {
                var n = window.getComputedStyle(t),
                    i = "border-box" === n.boxSizing,
                    o = Object(r.cb)(e, n);
                if (a && i && Object(r.B)("width", o) && null !== o.width) {
                    var c = [o.width, n.paddingLeft, n.paddingRight, n.borderLeftWidth, n.borderRightWidth];
                    o.width = Object(r.qb)(c.map(parseFloat)) + "px"
                }
                if (a && i && Object(r.B)("height", o) && null !== o.height) {
                    var u = [o.height, n.paddingTop, n.paddingBottom, n.borderTopWidth, n.borderBottomWidth];
                    o.height = Object(r.qb)(u.map(parseFloat)) + "px"
                }
                return o
            },
            u = n(101);

        function s(e, t) {
            void 0 === t && (t = document.body);
            var n = Object(u.b)(t),
                i = Object(r.p)((function(t) {
                    return t === e
                }), n);
            return n[i === n.length - 1 ? 0 : i + 1]
        }

        function d() {
            return new Promise((function(e) {
                ! function t() {
                    document.body ? e(document.body) : setTimeout(t, 100)
                }()
            }))
        }
        var l = null,
            f = function() {
                if (l) return l;
                var e = document.createElement("div"),
                    t = e.style;
                t.width = "50px", t.height = "50px", t.overflow = "scroll", t.direction = "rtl";
                var n = document.createElement("div"),
                    r = n.style;
                return r.width = "100px", r.height = "50px", e.appendChild(n), document.body.appendChild(e), e.scrollLeft > 0 ? l = "positive-descending" : (e.scrollLeft = 1, l = 0 === e.scrollLeft ? "negative" : "positive-ascending"), document.body.removeChild(e), l
            };

        function p(e, t) {
            return void 0 === t && (t = 0), Math.abs(e.scrollTop + e.clientHeight - e.scrollHeight) <= t
        }

        function m(e, t) {
            return void 0 === t && (t = 0), e.scrollTop <= t
        }

        function v(e) {
            var t = e.parentNode;
            t && t.removeChild(e)
        }
        var b = function(e, t) {
            var n = document.createElement(e);
            return o(t, n), n
        }
    }, , function(e, t, n) {
        "use strict";
        var r = n(23);
        t.a = {
            spaceBase: 8,
            typography: r.g,
            colors: r.c,
            transitions: r.f,
            borderRadius: r.a,
            boxShadow: r.b,
            spaces: r.e
        }
    }, , function(e, t, n) {
        "use strict";
        n.d(t, "c", (function() {
            return u
        })), n.d(t, "b", (function() {
            return d
        })), n.d(t, "e", (function() {
            return l
        })), n.d(t, "i", (function() {
            return f
        })), n.d(t, "h", (function() {
            return p
        })), n.d(t, "g", (function() {
            return m
        })), n.d(t, "d", (function() {
            return v
        })), n.d(t, "f", (function() {
            return b
        })), n.d(t, "a", (function() {
            return h
        }));
        var r = n(13),
            i = n(22),
            o = n(3),
            a = n(9),
            c = n(67),
            u = function() {
                var e = Object(r.i)(window.location.search);
                return parseInt(function() {
                    var e = String(window.location).match(/licen(?:s|c)e\/g?(\d+)/);
                    return e ? e[1] : null
                }() || e.license_id, 10)
            },
            s = function(e) {
                var t = parseInt(e, 10);
                return t > -1 ? t : null
            },
            d = function(e) {
                return "group" in e ? s(e.group) : "groups" in e ? s(e.groups) : null
            },
            l = function() {
                return "1" === Object(r.h)("unique_groups", window.location.search) || "1" === Object(r.h)("unique_group", window.location.search)
            },
            f = function(e, t, n) {
                void 0 === n && (n = {});
                var r = n,
                    i = r.name,
                    c = void 0 === i ? function(e) {
                        return e.getSessionUser().name || e.localize("client")
                    }(e) : i,
                    u = r.agent,
                    s = void 0 === u ? function(e) {
                        return Object(a.c)(o.d, e).name
                    }(e) : u;
                return t.replace(/%name%/g, c).replace(/%agent%/g, s)
            },
            p = function(e) {
                return Object(i.c)(e) > .7
            },
            m = function(e) {
                return Object(i.c)(e) <= .179
            },
            v = function(e) {
                var t, n, r = c.b,
                    i = Boolean(null == (t = e.properties.group[r]) ? void 0 : t.forwardTicketFormToHelpdesk),
                    o = e.__unsafeProperties.license.inboundForwardingToHelpdeskEnabled,
                    a = null == (n = e.properties.license[r]) ? void 0 : n.hdLicenseID;
                return "number" === typeof a && a > -1 && (i || o) ? "helpdesk" : e.__unsafeProperties.group.offlineMessagesEnabled ? "offline_message" : "livechat"
            },
            b = function(e) {
                var t, n = c.c;
                return Boolean(null == (t = e.properties.license[n]) ? void 0 : t.messaging_in_queue_enabled)
            },
            h = function(e) {
                return "https://" + e + "." + ("api" === e ? "livechatinc" : "livechat") + ".com"
            }
    }, function(e, t, n) {
        "use strict";
        n.d(t, "d", (function() {
            return E
        })), n.d(t, "b", (function() {
            return C
        })), n.d(t, "k", (function() {
            return I
        })), n.d(t, "p", (function() {
            return S
        })), n.d(t, "q", (function() {
            return T
        })), n.d(t, "m", (function() {
            return k
        })), n.d(t, "t", (function() {
            return A
        })), n.d(t, "v", (function() {
            return z
        })), n.d(t, "r", (function() {
            return M
        })), n.d(t, "l", (function() {
            return L
        })), n.d(t, "B", (function() {
            return R
        })), n.d(t, "C", (function() {
            return D
        })), n.d(t, "A", (function() {
            return B
        })), n.d(t, "D", (function() {
            return q
        })), n.d(t, "H", (function() {
            return N
        })), n.d(t, "G", (function() {
            return V
        })), n.d(t, "K", (function() {
            return F
        })), n.d(t, "z", (function() {
            return U
        })), n.d(t, "L", (function() {
            return H
        })), n.d(t, "g", (function() {
            return W
        })), n.d(t, "i", (function() {
            return Y
        })), n.d(t, "h", (function() {
            return K
        })), n.d(t, "M", (function() {
            return Z
        })), n.d(t, "u", (function() {
            return J
        })), n.d(t, "n", (function() {
            return X
        })), n.d(t, "I", (function() {
            return Q
        })), n.d(t, "s", (function() {
            return ee
        })), n.d(t, "F", (function() {
            return te
        })), n.d(t, "a", (function() {
            return ne
        })), n.d(t, "f", (function() {
            return re
        })), n.d(t, "N", (function() {
            return ie
        })), n.d(t, "E", (function() {
            return oe
        })), n.d(t, "x", (function() {
            return ce
        })), n.d(t, "w", (function() {
            return ue
        })), n.d(t, "y", (function() {
            return se
        })), n.d(t, "j", (function() {
            return de
        })), n.d(t, "c", (function() {
            return le
        })), n.d(t, "o", (function() {
            return fe
        })), n.d(t, "J", (function() {
            return pe
        })), n.d(t, "e", (function() {
            return me
        }));
        var r = n(8),
            i = n(1),
            o = n(188),
            a = n(2),
            c = n(13),
            u = n(155),
            s = n.n(u),
            d = n(156),
            l = n.n(d),
            f = n(3),
            p = n(18),
            m = n(9),
            v = n(106),
            b = function(e) {
                var t = 0;
                return e.split("").forEach((function(e) {
                    var n = e.charCodeAt(0);
                    t = (t << 5) - t + n, t &= t
                })), t
            },
            h = function(e, t) {
                return b(e) % (1 / t) === 0
            },
            g = n(93),
            y = [0, 2, 4, 6, 8, 1, 3, 5, 7, 9],
            O = function(e) {
                return e.replace(/\b(?:\d[ -]*?){8,15}((?:\d[ -]*?){4})\b/g, (function(e, t) {
                    var n = e.replace(/(-|\s)/g, "");
                    return function(e) {
                        if (/[^0-9-\s]+/.test(e)) return !1;
                        for (var t, n = e.replace(/\D/g, ""), r = n.length, i = 1, o = 0; r;) t = parseInt(n.charAt(--r), 10), o += (i ^= 1) ? y[t] : t;
                        return o && o % 10 === 0
                    }(n) ? "" + function(e) {
                        var t = e % 4,
                            n = t ? 4 - t : 0,
                            r = Math.floor(e / 4) + (t ? 1 : 0) - n - 1,
                            i = Object(a.n)(n, "XXX"),
                            o = Object(a.n)(r, "XXXX");
                        return i.concat(o).join("-").concat("-")
                    }(n.length) + t : e
                }))
            },
            j = n(39),
            _ = n(24),
            w = n(27);
        (new s.a).tlds(l.a);
        var x = function(e, t, n) {
                var r = Object(a.p)((function(t) {
                    return t.name === e
                }), n);
                return -1 !== r ? Object(a.Ab)(r, Object(i.a)({}, n[r], {
                    defaultValue: t
                }), n) : n
            },
            E = function(e, t, n) {
                e.addEvent(t, Object(i.a)({}, n, {
                    serverId: n.serverId || null
                }))
            },
            C = function(e, t, n) {
                var r = n.systemMessageType,
                    i = n.textVariables,
                    o = n.text;
                E(e, t, {
                    id: Object(a.w)(e.getIndexedEvents(f.d)),
                    serverId: null,
                    type: "system_message",
                    author: "system",
                    seen: !0,
                    properties: Object(a.f)({
                        systemMessageType: r,
                        textVariables: i,
                        defaultText: o
                    })
                })
            },
            I = function(e) {
                e.updateChat(f.d, {
                    active: !1,
                    properties: {
                        ended: !0,
                        queued: !1,
                        agentIsTyping: !1
                    }
                }), e.setApplicationState({
                    greetingsMuted: !1
                })
            },
            S = function(e) {
                e.setApplicationState({
                    eyeCatcher: Object(i.a)({}, e.getApplicationState().eyeCatcher, {
                        hidden: !0
                    })
                })
            },
            T = function(e) {
                var t = m.d(e);
                if (t && t.properties.uniqueId && !m.O(e, t)) {
                    var n = e.getApplicationState().invitation;
                    e.setApplicationState({
                        invitation: Object(i.a)({}, n, {
                            hiddenIds: [].concat(n.hiddenIds, [t.properties.uniqueId])
                        })
                    }), h(e.getSessionUser().serverId, .01) && Object(j.d)({
                        minimizedType: m.l(e),
                        greetingId: t.properties.id,
                        greetingUniqueId: t.properties.uniqueId,
                        greetingType: t.properties.type,
                        greetingSubtype: t.properties.subtype,
                        greetingAddon: t.properties.addon || "none"
                    })
                }
            },
            k = function(e) {
                var t = m.d(e);
                if (t && t.properties.uniqueId && !m.mb(e)) {
                    var n = e.getApplicationState().invitation;
                    e.setApplicationState({
                        invitation: Object(i.a)({}, n, {
                            displayedIds: [].concat(n.displayedIds, [t.properties.uniqueId])
                        })
                    })
                }
            },
            A = function(e) {
                m.W(e, "maximized") || e.setApplicationState({
                    visibility: {
                        state: "maximized"
                    }
                })
            },
            z = function(e, t, n) {
                void 0 === t && (t = !1), void 0 === n && (n = !1);
                var r = e.getApplicationState(),
                    i = r.visibility,
                    o = r.destroyed;
                !t && "hidden" === i.state && i.forced || "minimized" === i.state || (!m.Q(e) || m.db(f.d, e) || o ? e.setApplicationState({
                    visibility: {
                        state: "hidden"
                    }
                }) : n || !e.getView("Moment").show ? e.setApplicationState({
                    visibility: {
                        state: "minimized"
                    }
                }) : e.emit("request_close_moment"))
            },
            M = function(e) {
                m.W(e, "minimized") && e.setApplicationState({
                    visibility: {
                        state: "hidden"
                    }
                })
            },
            L = function(e, t) {
                var n = t.id,
                    r = t.active,
                    i = void 0 === r || r,
                    o = t.thread,
                    c = t.group,
                    u = t.agent,
                    s = t.queued,
                    d = void 0 !== s && s;
                null === e.getChat(f.d).serverId && e.setChatServerId(f.d, n);
                var l = {
                    ended: !1,
                    queued: d,
                    fakeAgentMessageId: null,
                    lastThread: o,
                    currentAgent: u
                };
                "number" === typeof c && (l.group = c), S(e), e.updateChat(f.d, {
                    active: i,
                    properties: l
                }), ce(e);
                var p = m.c(f.d, e);
                Object(a.x)("properties.isBot", p) ? setTimeout((function() {
                    return "loader" === e.getDefaultView("Chat") && e.setDefaultView("Chat", "timeline")
                }), 1500) : e.setDefaultView("Chat", "timeline"), e.setApplicationState({
                    hidden: !1
                });
                var v = e.getApplicationState().readyState;
                e.setCurrentView("Chat"), v === _.a.NOT_READY || m.W(e, "maximized") || A(e)
            },
            P = function(e, t, n) {
                void 0 === n && (n = {});
                var r = m.g("creditCardMasking", e).enabled ? O(t) : t;
                return {
                    type: Object(v.a)(r) ? "emoji" : "message",
                    thread: e.getChat(f.d).active ? e.getChat(f.d).properties.lastThread : null,
                    properties: Object(a.f)(Object(i.a)({
                        text: r
                    }, n))
                }
            },
            R = function(e, t, n, r) {
                e.sendEvent(t, P(e, n, {
                    triggeredBy: r
                }))
            },
            D = function(e, t, n, r) {
                var o = e.getApplicationState("invitation").current,
                    c = e.getEvent(t, o),
                    u = P(e, n, Object(i.a)({
                        triggeredBy: r
                    }, c && {
                        fromGreeting: Object(i.a)({}, Object(a.cb)(["id", "uniqueId"], c.properties))
                    })),
                    s = e.getChat(t).active,
                    d = m.S(e),
                    l = m.g("preChatAfterGreeting", e).enabled;
                if (d && !s && l) {
                    var p = m.L(e, "prechat"),
                        v = m.P(e, t);
                    E(e, t, Object(i.a)({}, u, {
                        seen: !0,
                        type: f.g,
                        author: e.getSessionUserId(),
                        id: Object(a.w)(e.getIndexedEvents(f.d))
                    })), p || v || N(e)
                } else e.sendEvent(t, u)
            },
            B = function(e, t, n) {
                var r = n.text,
                    i = n.recipients,
                    o = void 0 === i ? "all" : i;
                e.sendEvent(t, {
                    type: "custom_system_message",
                    thread: e.getChat(f.d).active ? e.getChat(f.d).properties.lastThread : null,
                    properties: {
                        text: r.trim(),
                        recipients: o
                    }
                })
            },
            q = function(e, t) {
                e.updateChat(f.d, {
                    properties: {
                        currentAgent: t
                    }
                })
            },
            N = function(e) {
                if (!m.L(e, "prechat")) {
                    var t = e.getView("Chat/prechat");
                    $(e, t)
                }
            },
            V = function(e, t) {
                var n = e.getChat(f.d).properties,
                    o = n.rate,
                    a = n.rateComment,
                    c = t.fields,
                    u = Object(r.a)(t, ["fields"]);
                o && (c = x("rating", o, c)), a && (c = x("rateComment", a, c)), $(e, Object(i.a)({}, u, {
                    fields: c
                }))
            },
            F = function(e) {
                e.updateChat(f.d, {
                    properties: {
                        startChatAgainPending: !0
                    }
                })
            },
            U = function(e, t, n) {
                var r = void 0 === n ? {} : n,
                    i = r.chatId,
                    o = r.forced;
                e.updateChat(f.d, {
                    properties: {
                        startChatAgainPending: !1
                    }
                }), re(e);
                var a = e.getChat(f.d),
                    c = a.properties.lastThread,
                    u = a.serverId;
                if (o || !m.E(e) || u && i !== u) e.flushChat(t), i && e.setChatServerId(f.d, i);
                else {
                    ae(e);
                    var s = m.f(e, f.d);
                    s && e.removeEvent(f.d, s.id), e.hasEvent(f.d, "boosters") && e.removeEvent(f.d, "boosters")
                }
                e.updateChat(t, {
                    properties: {
                        agentIsTyping: !1,
                        ended: !1,
                        fakeAgentMessageId: null,
                        lastThread: c,
                        loadingHistory: !1,
                        queued: !1,
                        rate: null,
                        rateComment: null,
                        transcriptSentTo: null
                    }
                }), e.setApplicationState({
                    greetingsMuted: !1
                }), ne(e)
            },
            H = function(e, t) {
                var n = t.getApplicationState("config");
                t.setApplicationState({
                    config: Object(i.a)({}, n, {
                        features: Object(i.a)({}, n.features, {
                            fileSharing: {
                                enabled: e.__unsafeProperties.license.fileSharingEnabled
                            },
                            agentAvatar: {
                                enabled: e.__unsafeProperties.group.hasAgentAvatarsEnabled
                            },
                            continuousChat: {
                                enabled: e.__unsafeProperties.license.continuousChatWidgetEnabled
                            },
                            chatHistory: {
                                enabled: e.__unsafeProperties.license.continuousChatWidgetEnabled || e.__unsafeProperties.license.customerHistoryEnabled
                            },
                            rating: {
                                enabled: e.__unsafeProperties.group.ratingEnabled
                            },
                            emailTranscript: {
                                enabled: e.__unsafeProperties.group.transcriptButtonEnabled
                            },
                            logo: {
                                enabled: e.__unsafeProperties.group.logo.enabled,
                                path: e.__unsafeProperties.group.logo.src
                            },
                            linksPreview: {
                                enabled: e.__unsafeProperties.group.linksUnfurlingEnabled
                            },
                            ticketForm: {
                                enabled: "ticketForm" in e,
                                mode: Object(p.d)(e)
                            },
                            queue: {
                                writingInQueueEnabled: Object(p.f)(e)
                            },
                            preChatForm: {
                                enabled: "prechatForm" in e
                            },
                            preChatAfterGreeting: {
                                enabled: e.__unsafeProperties.group.prechatFormAfterGreetingEnabled
                            },
                            creditCardMasking: {
                                enabled: e.__unsafeProperties.license.creditCardMaskingEnabled
                            },
                            hideTrademark: {
                                enabled: e.__unsafeProperties.group.hasHiddenTrademark
                            },
                            disableSounds: {
                                enabled: !e.__unsafeProperties.group.hasSoundsEnabled
                            },
                            minimized: {
                                enabled: !e.__unsafeProperties.group.disabledMinimized
                            },
                            mobileMinimized: {
                                enabled: e.__unsafeProperties.group.hasCustomMobileSettings ? !e.__unsafeProperties.group.disabledMinimizedOnMobile : !e.__unsafeProperties.group.disabledMinimized
                            }
                        }),
                        minimizedType: e.__unsafeProperties.group.minimizedType,
                        mobileMinimizedType: e.__unsafeProperties.group.minimizedTypeOnMobile,
                        theme: Object(a.T)(n.theme, Object(g.a)(e.__unsafeProperties.group.theme)),
                        screenPosition: e.__unsafeProperties.group.screenPosition,
                        mobileScreenPosition: e.__unsafeProperties.group.screenPositionOnMobile,
                        nonProfitLicense: e.__unsafeProperties.license.nonProfit,
                        properties: e.properties,
                        screenOffset: {
                            x: e.__unsafeProperties.group.offsetX,
                            y: e.__unsafeProperties.group.offsetY
                        }
                    })
                }), t.getApplicationState("config").features.disableSounds.enabled && t.setApplicationState({
                    muted: !0
                })
            },
            G = function(e, t, n) {
                var r, o = e.getApplicationState("config");
                e.setApplicationState({
                    config: Object(i.a)({}, o, {
                        features: Object(a.T)(o.features, (r = {}, r[t] = n, r))
                    })
                })
            },
            W = function(e, t) {
                G(e, t, {
                    enabled: !1
                })
            },
            Y = function(e, t, n) {
                G(e, t, Object(i.a)({
                    enabled: !0
                }, n))
            },
            K = function(e, t) {
                try {
                    var n = JSON.parse(t).filter((function(e) {
                        return "moment" === e.template_id
                    }));
                    if (Object(a.F)(n)) return;
                    Y(e, "boosters", {
                        items: n.map((function(e) {
                            var t = {
                                type: e.action.type,
                                label: e.action.label,
                                url: e.action.url
                            };
                            return e.action.webview_height && (t.webviewHeight = e.action.webview_height), {
                                id: e.id,
                                template: e.template_id,
                                title: e.title,
                                description: e.description,
                                icon: e.icon,
                                action: t
                            }
                        }))
                    })
                } catch (r) {}
            },
            Z = function(e, t, n) {
                var r = {
                    answered: !0
                };
                n && (r.fields = n.properties.fields, n.id && e.setEventServerId(f.d, t, n.id)), e.updateEvent(f.d, t, {
                    properties: r
                })
            },
            J = function(e, t) {
                t.properties.receivedFirstTime && h(e.getSessionUser().serverId, .01) && Object(j.e)({
                    minimizedType: m.l(e),
                    greetingId: t.properties.id,
                    greetingUniqueId: t.properties.uniqueId,
                    greetingType: t.properties.type,
                    greetingSubtype: t.properties.subtype,
                    greetingAddon: t.properties.addon || "none"
                })
            },
            X = function(e, t) {
                var n = e.getApplicationState(),
                    r = n.embedded,
                    o = n.actingAsDirectLink,
                    c = n.availability,
                    u = n.greetingsMuted,
                    s = m.L(e, "prechat");
                q(e, t.author), "bar" !== m.l(e) && S(e), e.setDefaultView("Chat", "timeline"), ce(e), se(e);
                var d, l, v, b, h, g = m.d(e);
                g && (Object(j.f)({
                    minimizedType: m.l(e),
                    greetingId: null == (d = g.properties) ? void 0 : d.id,
                    greetingUniqueId: null == (l = g.properties) ? void 0 : l.uniqueId,
                    greetingType: null == (v = g.properties) ? void 0 : v.type,
                    greetingSubtype: null == (b = g.properties) ? void 0 : b.subtype,
                    greetingAddon: (null == (h = g.properties) ? void 0 : h.addon) || "none"
                }), e.removeEvent(f.d, g.id));
                Object(a.l)(t.properties.cards || t.properties.card).filter(Boolean).forEach((function(t) {
                    t.title && (t.title = Object(p.i)(e, t.title)), t.subtitle && (t.subtitle = Object(p.i)(e, t.subtitle)), t.buttons && (t.buttons.forEach((function(e) {
                        return e.invitation = !0
                    })), r && !o || t.buttons.filter((function(e) {
                        return "url" === e.type && "target" in e
                    })).forEach((function(e) {
                        return e.target = "new"
                    })))
                }));
                var y = Object(a.w)(e.getIndexedEvents(f.d));
                E(e, f.d, Object(i.a)({}, t, {
                    seen: !u,
                    id: y,
                    properties: Object(i.a)({}, t.properties, t.properties.text && {
                        text: Object(p.i)(e, t.properties.text)
                    })
                })), e.updateChat(f.d, {
                    properties: {
                        fakeAgentMessageId: y
                    }
                }), e.setApplicationState({
                    invitation: Object(i.a)({}, e.getApplicationState("invitation"), {
                        current: y
                    })
                }), m.W(e, "maximized") || (e.setCurrentView("Chat"), m.O(e, t) && t.properties.receivedFirstTime && !u ? A(e) : z(e, !0)), m.H(e) && "offline" === c && s && N(e), u || J(e, t)
            },
            Q = function(e) {
                $(e, e.getView("Chat/ticketForm"))
            },
            $ = function(e, t) {
                var n = {
                    formType: t.type,
                    formId: t.id,
                    fields: t.fields
                };
                if (m.L(e)) {
                    var r = e.getLastEvent(f.d).id;
                    return e.updateEvent(f.d, r, {
                        properties: n
                    })
                }
                var i = {
                    id: Object(a.w)(e.getIndexedEvents(f.d)),
                    type: "form",
                    author: "system",
                    properties: n
                };
                return E(e, f.d, i)
            },
            ee = function(e) {
                return !!e && function(e) {
                    var t = Object(c.g)(e);
                    return !t || "https:" === t || !1
                }(Object(o.a)(e))
            },
            te = function(e, t) {
                var n = e.getView("Moment");
                if (n.show && !t.wasTriggeredByGreeting) return n.data.url === t.url ? void e.emit("request_expand_moment") : void e.emit("request_expand_moment", {
                    nextMoment: t
                });
                ee(t.url) ? (e.updateView("Moment", {
                    show: !0,
                    data: t
                }), n.show && e.emit("request_expand_moment")) : C(e, f.d, {
                    text: "Link attached to the button is invalid."
                })
            },
            ne = function(e) {
                var t = m.g("boosters", e);
                t.enabled && (e.hasEvent(f.d, "boosters") || e.addEvent(f.d, {
                    type: "boosters",
                    id: "boosters",
                    author: "system",
                    seen: !0,
                    properties: {
                        boosters: t.items
                    }
                }))
            },
            re = function(e, t) {
                e.updateView("Moment", {
                    show: !1,
                    data: {}
                }), t && z(e)
            },
            ie = function(e, t) {
                e.requestUpdateUser(e.getSessionUser().id, t)
            },
            oe = function(e, t) {
                var n;
                e.setUserServerId(e.getSessionUser().id, t), e.setApplicationState({
                    testGroup: (n = t, b(n) % 2 ? "A" : "B")
                })
            },
            ae = function(e, t) {
                if (void 0 === t && (t = void 0), m.L(e, t)) {
                    var n = e.getLastEvent(f.d).id;
                    e.removeEvent(f.d, n)
                }
            },
            ce = function(e) {
                ae(e, "prechat")
            },
            ue = function(e) {
                ae(e, "postchat")
            },
            se = function(e) {
                ae(e, "ticket")
            },
            de = function(e, t, n) {
                var r = Object(a.x)("error.details.errors", e);
                if (r) {
                    var o = r.reduce((function(e, n) {
                        return "requester.email" === n.field ? Object(i.a)({}, e, {
                            email: t("invalid_email")
                        }) : "requester.name" === n.field ? Object(i.a)({}, e, {
                            name: n.message
                        }) : e
                    }), {});
                    Object(a.F)(o) ? n() : n(o)
                } else n()
            },
            le = function(e) {
                var t = f.b,
                    n = e.getChat(f.d).properties.lastThread;
                e.hasEvent(f.d, t) && e.removeEvent(f.d, t), !!m.j(e).find((function(e) {
                    return "form" === e.type && "ask_for_email" === e.properties.formId
                })) || e.addEvent(f.d, {
                    id: t,
                    serverId: null,
                    seen: !0,
                    type: f.b,
                    author: "system",
                    thread: n
                })
            },
            fe = function(e, t, n, r) {
                switch (Object(a.D)(n.type, ["message", "webview"]) && A(e), n.type) {
                    case "message":
                        D(e, f.d, n.text, {
                            event: t,
                            button: n
                        });
                        break;
                    case "webview":
                        te(e, {
                            url: n.value,
                            height: n.webviewHeight,
                            wasTriggeredByGreeting: r,
                            source: r ? "targeted_message" : "rich_message"
                        });
                        break;
                    case "cancel":
                        ve(e, f.d, t)
                }
                e.emit("rich_greeting_button_clicked", {
                    button: n,
                    event: e.getEvent(f.d, t)
                })
            },
            pe = function(e) {
                e.emit("start_thread")
            },
            me = function(e, t, n) {
                void 0 === n && (n = "button");
                var r = e.getChat(f.d),
                    i = Object(a.D)("image", t.type);
                ("clipboard" === n || Math.random() < .1) && Object(w.d)("file_upload_added", {
                    uploadSource: n
                }), e.sendEvent(f.d, {
                    type: "file",
                    thread: r.properties.lastThread,
                    properties: {
                        name: t.name.substring(0, f.e),
                        progress: 0,
                        finished: !1,
                        failed: !1,
                        failReason: null,
                        fileType: i ? "image" : "other",
                        url: i ? URL.createObjectURL(t) : null,
                        uploadSource: n
                    }
                }, {
                    file: t
                })
            },
            ve = function(e, t, n) {
                var r = e.getChat(t),
                    i = e.getApplicationState().mobile,
                    o = e.getEvent(t, n);
                !r.active && o && (h(e.getSessionUser().serverId, .01) && Object(j.c)({
                    mobile: i,
                    greetingId: o.properties.id,
                    greetingUniqueId: o.properties.uniqueId,
                    greetingType: o.properties.type,
                    greetingSubtype: o.properties.subtype,
                    greetingAddon: o.properties.addon || "none",
                    minimizedType: m.l(e)
                }), e.emit("request_cancel_greeting", o.properties.uniqueId))
            }
    }, , , , function(e, t, n) {
        "use strict";
        n.d(t, "a", (function() {
            return r
        })), n.d(t, "b", (function() {
            return o
        })), n.d(t, "c", (function() {
            return i
        })), n.d(t, "e", (function() {
            return a
        })), n.d(t, "f", (function() {
            return c
        })), n.d(t, "g", (function() {
            return u
        })), n.d(t, "d", (function() {
            return D
        }));
        var r = {};
        n.r(r), n.d(r, "xs", (function() {
            return s
        })), n.d(r, "sm", (function() {
            return d
        })), n.d(r, "md", (function() {
            return l
        })), n.d(r, "lg", (function() {
            return f
        })), n.d(r, "xl", (function() {
            return p
        })), n.d(r, "none", (function() {
            return m
        })), n.d(r, "round", (function() {
            return v
        })), n.d(r, "def", (function() {
            return b
        }));
        var i = {};
        n.r(i), n.d(i, "caution", (function() {
            return h
        })), n.d(i, "divider", (function() {
            return g
        })), n.d(i, "border", (function() {
            return y
        })), n.d(i, "error", (function() {
            return O
        })), n.d(i, "success", (function() {
            return j
        })), n.d(i, "accent", (function() {
            return _
        })), n.d(i, "notification", (function() {
            return w
        })), n.d(i, "webkitOutline", (function() {
            return x
        })), n.d(i, "surface", (function() {
            return E
        })), n.d(i, "text", (function() {
            return C
        })), n.d(i, "grayscale", (function() {
            return I
        })), n.d(i, "brand", (function() {
            return S
        }));
        var o = {};
        n.r(o), n.d(o, "xs", (function() {
            return A
        })), n.d(o, "sm", (function() {
            return z
        })), n.d(o, "md", (function() {
            return M
        })), n.d(o, "lg", (function() {
            return L
        })), n.d(o, "floating", (function() {
            return P
        })), n.d(o, "outline", (function() {
            return R
        }));
        var a = {};
        n.r(a), n.d(a, "space0", (function() {
            return V
        })), n.d(a, "space1", (function() {
            return F
        })), n.d(a, "space2", (function() {
            return U
        })), n.d(a, "space3", (function() {
            return H
        })), n.d(a, "space4", (function() {
            return G
        })), n.d(a, "space5", (function() {
            return W
        })), n.d(a, "space6", (function() {
            return Y
        })), n.d(a, "space7", (function() {
            return K
        }));
        var c = {};
        n.r(c), n.d(c, "easings", (function() {
            return Z
        }));
        var u = {};
        n.r(u), n.d(u, "heading", (function() {
            return J
        })), n.d(u, "subheading", (function() {
            return X
        })), n.d(u, "input", (function() {
            return Q
        })), n.d(u, "placeholder", (function() {
            return $
        })), n.d(u, "caption", (function() {
            return ee
        })), n.d(u, "basic", (function() {
            return te
        })), n.d(u, "basicContrast", (function() {
            return ne
        })), n.d(u, "errorCaption", (function() {
            return re
        }));
        var s = "2px",
            d = "4px",
            l = "6px",
            f = "8px",
            p = "12px",
            m = "0px",
            v = "50%",
            b = l,
            h = "#ffd000",
            g = "#e3e3e3",
            y = "#b3b3b3",
            O = "#d93311",
            j = "#268750",
            _ = "#2000f0",
            w = "#e30d34",
            x = "#3b99fc",
            E = {
                light: "#ffffff",
                lightVariant: "#f0f0f0",
                dark: "#252525",
                darkVariant: "#2e2e2e "
            },
            C = {
                white: "#ffffff",
                black: "#111111",
                muted: "#6E6E6E"
            },
            I = {
                50: "#f8f8f8",
                100: "#e3e3e3",
                200: "#d5d5d5",
                300: "#c0c0c0",
                400: "#b3b3b3",
                500: "#757575",
                600: "#575757",
                700: "#2e2e2e",
                800: "#252525",
                900: "#111111"
            },
            S = {
                black: "#1b1b20",
                orange: "#ff5100"
            },
            T = n(22),
            k = "rgba(0, 0, 0, 0)",
            A = "0px 1px 2px " + Object(T.e)(.1, k),
            z = "0px 0px 8px " + Object(T.e)(.2, k),
            M = "0px 1px 10px " + Object(T.e)(.2, k),
            L = "0px 0px 24px " + Object(T.e)(.2, k),
            P = "0 4px 12px " + Object(T.e)(.3, k),
            R = "0 0 0 1px " + _,
            D = function(e) {
                return e / 16 + "rem"
            },
            B = D(16),
            q = D(14),
            N = D(12),
            V = "0px",
            F = "2px",
            U = "4px",
            H = "8px",
            G = "10px",
            W = "12px",
            Y = "16px",
            K = "24px",
            Z = {
                linear: "cubic-bezier(0, 0, 1, 1)",
                sharp: "cubic-bezier(0.33, 0, 0, 1)",
                smooth: "cubic-bezier(0.33, 0, 0.67, 1)",
                swift: "cubic-bezier(0.14, 0, 0, 1)",
                spring: "cubic-bezier(0.18, 0.89, 0.32, 1.28)"
            },
            J = {
                fontSize: B,
                fontWeight: "bold",
                color: C.black
            },
            X = {
                fontSize: q,
                fontWeight: "bold",
                color: C.black
            },
            Q = {
                fontSize: q,
                fontWeight: "normal",
                color: C.black
            },
            $ = {
                fontSize: q,
                fontWeight: "normal",
                color: C.muted
            },
            ee = {
                fontSize: N,
                fontWeight: "normal",
                color: C.black
            },
            te = {
                fontSize: q,
                fontWeight: "normal",
                color: C.black
            },
            ne = {
                fontSize: q,
                fontWeight: "normal",
                color: C.white
            },
            re = {
                fontSize: N,
                fontWeight: "normal",
                color: O
            }
    }, function(e, t, n) {
        "use strict";
        n.d(t, "a", (function() {
            return r
        }));
        var r = {};
        n.r(r), n.d(r, "NOT_READY", (function() {
            return i
        })), n.d(r, "READY", (function() {
            return o
        })), n.d(r, "BOOTSTRAPPED", (function() {
            return a
        }));
        var i = "not_ready",
            o = "ready",
            a = "bootstrapped"
    }, function(e, t, n) {
        "use strict";
        n.d(t, "e", (function() {
            return Te
        })), n.d(t, "c", (function() {
            return Me
        })), n.d(t, "b", (function() {
            return Be
        })), n.d(t, "a", (function() {
            return De
        })), n.d(t, "d", (function() {
            return r
        }));
        var r = {};
        n.r(r), n.d(r, "CONNECTED", (function() {
            return o
        })), n.d(r, "DISCONNECTED", (function() {
            return a
        })), n.d(r, "NOT_INITIALIZED", (function() {
            return c
        })), n.d(r, "RECONNECTING", (function() {
            return u
        }));
        var i = {};
        n.r(i), n.d(i, "addView", (function() {
            return _
        })), n.d(i, "setCurrentView", (function() {
            return w
        })), n.d(i, "updateView", (function() {
            return x
        })), n.d(i, "setDefaultView", (function() {
            return E
        })), n.d(i, "addChat", (function() {
            return C
        })), n.d(i, "addEvent", (function() {
            return I
        })), n.d(i, "removeEvent", (function() {
            return S
        })), n.d(i, "addHistoryEvents", (function() {
            return T
        })), n.d(i, "addParticipant", (function() {
            return k
        })), n.d(i, "addUser", (function() {
            return A
        })), n.d(i, "flushChat", (function() {
            return z
        })), n.d(i, "recalculateTimeline", (function() {
            return M
        })), n.d(i, "removeParticipant", (function() {
            return L
        })), n.d(i, "sendEvent", (function() {
            return P
        })), n.d(i, "setApplicationState", (function() {
            return R
        })), n.d(i, "updateFeature", (function() {
            return D
        })), n.d(i, "setConnectionState", (function() {
            return B
        })), n.d(i, "setChatServerId", (function() {
            return q
        })), n.d(i, "setEventData", (function() {
            return N
        })), n.d(i, "setEventServerId", (function() {
            return V
        })), n.d(i, "setLocalization", (function() {
            return F
        })), n.d(i, "setUserServerId", (function() {
            return U
        })), n.d(i, "setUserProperties", (function() {
            return G
        })), n.d(i, "requestSetUserProperties", (function() {
            return W
        })), n.d(i, "updateChat", (function() {
            return K
        })), n.d(i, "requestUpdateChat", (function() {
            return Z
        })), n.d(i, "updateEvent", (function() {
            return X
        })), n.d(i, "requestUpdateEvent", (function() {
            return Q
        })), n.d(i, "updateUser", (function() {
            return ee
        })), n.d(i, "requestUpdateUser", (function() {
            return te
        }));
        var o = "connected",
            a = "disconnected",
            c = "not_initialized",
            u = "reconnecting",
            s = n(1),
            d = n(63),
            l = n(29),
            f = n(12),
            p = n(2),
            m = n(105),
            v = n(8),
            b = function(e) {
                var t = e.id,
                    n = e.serverId,
                    r = void 0 === n ? null : n,
                    i = e.active,
                    o = void 0 === i || i,
                    a = e.participants,
                    c = void 0 === a ? [] : a,
                    u = e.properties;
                if ("string" !== typeof t) throw new Error("Chat ID has to be a string.");
                if (null !== r && t !== r) throw new Error('If serverId is given ("' + r + '") it should match id ("' + t + '").');
                return {
                    id: t,
                    serverId: r,
                    active: o,
                    participants: c,
                    properties: u
                }
            },
            h = function(e) {
                var t = e.id,
                    n = e.type,
                    r = e.author,
                    i = e.timestamp,
                    o = e.own,
                    a = e.serverId,
                    c = void 0 === a ? null : a,
                    u = e.thread,
                    s = void 0 === u ? null : u,
                    d = e.serverTimestamp,
                    l = void 0 === d ? null : d,
                    f = e.delivered,
                    p = void 0 === f || f,
                    m = e.seen,
                    v = void 0 !== m && m,
                    b = e.failed,
                    h = void 0 !== b && b,
                    g = e.properties,
                    y = void 0 === g ? {} : g;
                if ("string" !== typeof t) throw new Error("Event ID has to be a string.");
                if ("string" !== typeof n) throw new Error("Event has to have string `type` property.");
                if (null !== c && t !== c) throw new Error('If serverId is given ("' + c + '") it should match id ("' + t + '").');
                return {
                    id: t,
                    serverId: c,
                    type: n,
                    thread: s,
                    author: r,
                    own: o,
                    timestamp: i,
                    serverTimestamp: l,
                    delivered: p,
                    seen: v,
                    failed: h,
                    properties: y
                }
            },
            g = function(e) {
                var t = e.id,
                    n = e.serverId,
                    r = void 0 === n ? t : n,
                    i = e.type,
                    o = void 0 === i ? null : i,
                    a = e.name,
                    c = void 0 === a ? null : a,
                    u = e.email,
                    s = void 0 === u ? null : u,
                    d = e.avatar,
                    l = void 0 === d ? null : d,
                    f = e.properties,
                    p = void 0 === f ? {} : f;
                if ("string" !== typeof t) throw new Error("User ID has to be a string.");
                return {
                    id: t,
                    serverId: r,
                    type: o,
                    name: c,
                    email: s,
                    avatar: l,
                    properties: p
                }
            },
            y = n(6),
            O = ["delivered", "failed", "properties", "seen", "serverTimestamp", "thread"],
            j = function(e, t) {
                return e.forEach((function(e) {
                    if (Object(p.B)(e, t)) throw new Error("Updating `" + e + "` property is not possible.")
                }))
            },
            _ = Object(f.c)("ADD_VIEW", (function(e, t, n) {
                var r = e.action,
                    i = e.getState;
                if (void 0 === n && (n = {}), y.getView(i(), t)) throw new Error('There is already the "' + t + '" view. It has to be unique.');
                return r({
                    name: t,
                    data: n
                }), y.getView(i(), t)
            })),
            w = Object(f.c)("SET_CURRENT_VIEW", (function(e, t) {
                var n = e.action,
                    r = e.getState;
                if (!y.getView(r(), t)) throw new Error('Given view "' + t + "\" doesn't exist.");
                return n({
                    name: t
                }), y.getCurrentView(r())
            })),
            x = Object(f.c)("UPDATE_VIEW", (function(e, t, n) {
                var r = e.action,
                    i = e.getState;
                if (!y.getView(i(), t)) throw new Error('There is no "' + t + '" view. You should add it first.');
                return r({
                    name: t,
                    data: n
                }), y.getView(i(), t)
            })),
            E = Object(f.c)("SET_DEFAULT_VIEW", (function(e, t, n) {
                var r = e.action,
                    i = e.getState;
                return r({
                    name: n,
                    path: t
                }), y.getView(i(), t + "/" + n)
            })),
            C = Object(f.c)("ADD_CHAT", (function(e, t) {
                var n = e.action,
                    r = e.getState,
                    i = t.events,
                    o = void 0 === i ? [] : i,
                    a = Object(v.a)(t, ["events"]);
                if (a.id && y.hasChat(r(), a.id)) throw new Error('There is already a chat with "' + a.id + '" ID. It has to be unique.');
                var c = Object(p.o)((function(e) {
                    return !y.hasUser(r(), e)
                }), o.map((function(e) {
                    return e.author
                })).concat(a.participants || []));
                if (c) throw new Error('Given user ("' + c + "\") doesn't exist. You should add it first.");
                var u = a.id || Object(p.w)(y.getChats(r()));
                return n({
                    id: u,
                    chat: b(Object(s.a)({}, a, {
                        id: u
                    })),
                    events: o.map(h)
                }), y.getChat(r(), u)
            })),
            I = Object(f.c)("ADD_EVENT", (function(e, t, n) {
                var r = e.action,
                    i = e.getState,
                    o = n.id,
                    a = n.serverId,
                    c = i();
                if (o && a && o !== a) throw new Error('Specified ID ("' + o + '") differs from specified serverId ("' + a + '"). You either should use only ID or both should be the same.');
                if (!y.hasChat(c, t)) throw new Error('There is no chat with "' + t + '" ID. You should add it first.');
                if (y.hasEvent(c, t, o)) throw new Error('There is already an event with "' + o + '" ID in this chat ("' + t + '"). It has to be unique.');
                if (!y.hasUser(c, n.author)) throw new Error('Specified author ("' + n.author + "\") doesn't exist. You should add it first.");
                return r({
                    id: o,
                    chat: t,
                    event: h(Object(s.a)({
                        timestamp: Date.now()
                    }, n, {
                        own: n.author === y.getSessionUserId(c)
                    }))
                }), y.getEvent(i(), t, o)
            })),
            S = Object(f.c)("REMOVE_EVENT", (function(e, t, n) {
                var r = e.action,
                    i = (0, e.getState)();
                if (!y.hasChat(i, t)) throw new Error('There is no chat with "' + t + '" ID. You should add it first.');
                if (!y.hasEvent(i, t, n)) throw new Error('There is no event with "' + n + '" ID in this chat ("' + t + '").');
                r({
                    id: n,
                    chat: t
                })
            })),
            T = Object(f.c)("ADD_HISTORY_EVENTS", (function(e, t, n) {
                var r = e.action,
                    i = (0, e.getState)();
                if (!y.hasChat(i, t)) throw new Error('There is no chat with "' + t + '" ID. You should add it first.');
                n.forEach((function(e) {
                    if (y.hasEvent(i, t, e.id)) throw new Error('There is already an event with "' + e.id + '" ID in this chat ("' + t + '"). It has to be unique.');
                    if (!y.hasUser(i, e.author)) throw new Error('Specified author ("' + e.author + "\") doesn't exist. You should add it first.")
                }));
                var o = y.getSessionUserId(i);
                r({
                    chat: t,
                    events: n.map((function(e) {
                        return h(Object(s.a)({}, e, {
                            serverId: e.id,
                            own: e.author === o
                        }))
                    }))
                })
            })),
            k = Object(f.c)("ADD_PARTICIPANT", (function(e, t, n) {
                var r = e.action,
                    i = e.getState;
                if (!y.hasChat(i(), t)) throw new Error('There is no chat with "' + t + '" ID. You should add it first.');
                if (!y.hasUser(i(), n)) throw new Error('Given user ("' + n + "\") doesn't exist. You should add it first.");
                return r({
                    chat: t,
                    user: n
                }), y.getParticipants(i(), t)
            })),
            A = Object(f.c)("ADD_USER", (function(e, t) {
                var n = e.action,
                    r = e.getState,
                    i = t.id;
                if (y.hasUser(r(), i)) throw new Error('There is already a user with "' + i + '" ID. It has to be unique.');
                return n({
                    id: i,
                    user: g(t)
                }), y.getUser(r(), i)
            })),
            z = Object(f.c)("FLUSH_CHAT", (function(e, t) {
                var n = e.action,
                    r = e.getState;
                if (!y.hasChat(r(), t)) throw new Error('There is no chat with "' + t + '" ID. You should add it first.');
                return n({
                    id: t
                }), y.getChat(r(), t)
            })),
            M = Object(f.c)("RECALCULATE_TIMELINE", (function(e, t) {
                var n = e.action,
                    r = e.getState;
                if (!y.hasChat(r(), t)) throw new Error('There is no chat with "' + t + '" ID. You should add it first.');
                return n({
                    id: t
                }), y.getTimeline(r(), t)
            })),
            L = Object(f.c)("REMOVE_PARTICIPANT", (function(e, t, n) {
                var r = e.action,
                    i = e.getState;
                if (!y.hasChat(i(), t)) throw new Error('There is no chat with "' + t + '" ID. You should add it first.');
                if (!y.hasUser(i(), n)) throw new Error('Given user ("' + n + "\") doesn't exist. You should add it first.");
                return r({
                    chat: t,
                    user: n
                }), y.getParticipants(i(), t)
            })),
            P = Object(f.c)("SEND_EVENT", (function(e, t, n, r) {
                var i = e.action,
                    o = e.getState;
                if (!y.hasChat(o(), t)) throw new Error('There is no chat with "' + t + '" ID. You should add it first.');
                if (y.hasEvent(o(), t, n.id)) throw new Error('There is already an event with "' + n.id + '" ID in this chat ("' + t + '"). It has to be unique.');
                var a = n.id || Object(p.w)(y.getIndexedEvents(o(), t));
                return i({
                    id: a,
                    chat: t,
                    event: h(Object(s.a)({}, n, {
                        author: y.getSessionUser(o()).id,
                        own: !0,
                        id: a,
                        timestamp: Date.now(),
                        delivered: !1
                    }))
                }, r), y.getEvent(o(), t, a)
            })),
            R = Object(f.c)("SET_APPLICATION_STATE", (function(e, t) {
                var n = e.action,
                    r = e.getApplicationState;
                if (!t || Object(p.F)(t)) throw new Error("Given data object is empty.");
                return n(t), r()
            })),
            D = Object(f.c)("UPDATE_FEATURE", (function(e, t, n) {
                var r = e.action,
                    i = e.getApplicationState;
                if (!n || !t || Object(p.F)(n)) throw new Error("Given data object is empty.");
                return r({
                    feature: t,
                    data: n
                }), i()
            })),
            B = Object(f.c)("SET_CONNECTION_STATE", (function(e, t) {
                var n = e.action,
                    r = e.getState;
                return n({
                    connectionState: t
                }), y.getConnectionState(r())
            })),
            q = Object(f.c)("SET_CHAT_SERVER_ID", (function(e, t, n) {
                var r = e.action,
                    i = e.getState;
                if (!y.hasChat(i(), t)) throw new Error('There is no chat with "' + t + '" ID. You should add it first.');
                if (null !== y.getChat(i(), t).serverId) throw new Error('Chat with "' + t + '" ID has already serverId.');
                return r({
                    id: t,
                    serverId: n
                }), y.getChat(i(), t)
            })),
            N = Object(f.c)("SET_EVENT_DATA", (function(e, t, n, r) {
                var i = e.action,
                    o = e.getState;
                if (!y.hasChat(o(), t)) throw new Error('There is no chat with "' + t + '" ID. You should add it first.');
                if (!y.hasEvent(o(), t, n)) throw new Error('There is no "' + n + '" event in "' + t + '" chat. You should add it first.');
                return j(["id", "type", "own"], r), i({
                    chat: t,
                    id: n,
                    data: Object(s.a)({}, Object(p.fb)(O.concat("author", "serverId", "timestamp"), r), {
                        own: r.author === y.getSessionUserId(o())
                    })
                }), y.getEvent(o(), t, n)
            })),
            V = Object(f.c)("SET_EVENT_SERVER_ID", (function(e, t, n, r) {
                var i = e.action,
                    o = e.getState;
                if (!y.hasChat(o(), t)) throw new Error('There is no chat with "' + t + '" ID. You should add it first.');
                if (!y.hasEvent(o(), t, n)) throw new Error('There is no "' + n + '" event in "' + t + '" chat. You should add it first.');
                if (null !== y.getEvent(o(), t, n).serverId) throw new Error('Event with "' + n + '" ID has already serverId.');
                return i({
                    chat: t,
                    id: n,
                    serverId: r
                }), y.getEvent(o(), t, n)
            })),
            F = Object(f.c)("SET_LOCALIZATION", (function(e, t) {
                (0, e.action)(t)
            })),
            U = Object(f.c)("SET_USER_SERVER_ID", (function(e, t, n) {
                var r = e.action,
                    i = e.getState;
                if (!y.hasUser(i(), t)) throw new Error('There is no "' + t + '" user. You should add it first.');
                if (null !== y.getUser(i(), t).serverId) throw new Error('User with "' + t + '" ID has already serverId.');
                return r({
                    id: t,
                    serverId: n
                }), y.getUser(i(), t)
            })),
            H = Object(f.e)("SET_USER_PROPERTIES", (function(e, t, n) {
                var r = e.action,
                    i = e.getState;
                if (!y.hasUser(i(), t)) throw new Error('There is no user with "' + t + '" ID. You should add it first.');
                return r({
                    id: t,
                    properties: n
                }), y.getUser(i(), t)
            })),
            G = H.actionMethod,
            W = H.requestActionMethod,
            Y = Object(f.e)("UPDATE_CHAT", (function(e, t, n) {
                var r = e.action,
                    i = e.getState;
                if (!y.hasChat(i(), t)) throw new Error('There is no chat with "' + t + '" ID. You should add it first.');
                return j(["id", "participants", "events"], n), r({
                    id: t,
                    data: Object(p.fb)(["active", "properties"], n)
                }), y.getChat(i(), t)
            })),
            K = Y.actionMethod,
            Z = Y.requestActionMethod,
            J = Object(f.e)("UPDATE_EVENT", (function(e, t, n, r) {
                var i = e.action,
                    o = e.getState;
                if (!y.hasChat(o(), t)) throw new Error('There is no chat with "' + t + '" ID. You should add it first.');
                if (!y.hasEvent(o(), t, n)) throw new Error('There is no "' + n + '" event in "' + t + '" chat. You should add it first.');
                return j(["id", "type", "author", "own", "timestamp"], r), i({
                    chat: t,
                    id: n,
                    data: Object(p.fb)(O, r)
                }), y.getEvent(o(), t, n)
            })),
            X = J.actionMethod,
            Q = J.requestActionMethod,
            $ = Object(f.e)("UPDATE_USER", (function(e, t, n) {
                var r = e.action,
                    i = e.getState;
                if (!y.hasUser(i(), t)) throw new Error('There is no user with "' + t + '" ID. You should add it first.');
                return j(["id", "type"], n), r({
                    id: t,
                    data: Object(p.fb)(["name", "email", "avatar", "properties"], n)
                }), y.getUser(i(), t)
            })),
            ee = $.actionMethod,
            te = $.requestActionMethod,
            ne = function(e) {
                var t;
                return void 0 === e && (e = {}), Object(f.d)(e, ((t = {})[D] = function(e, t) {
                    var n, r = t.feature,
                        i = t.data;
                    return Object(s.a)({}, e, {
                        config: Object(s.a)({}, e.config, {
                            features: Object(s.a)({}, e.config.features, (n = {}, n[r] = Object(s.a)({}, e.config.features[r], i), n))
                        })
                    })
                }, t[R] = function(e, t) {
                    return Object(s.a)({}, e, t)
                }, t))
            },
            re = function(e) {
                return Object(p.Bb)(e).reduce((function(e, t) {
                    var n = t.serverId,
                        r = t.id;
                    return null === n || (e[n] = r), e
                }), {})
            },
            ie = function(e, t) {
                var n;
                return null !== t.serverId ? Object(s.a)({}, e, ((n = {})[t.serverId] = t.id, n)) : e
            },
            oe = function(e, t) {
                var n, r, i = t.id,
                    o = t.chat,
                    a = t.event;
                return Object(s.a)({}, e, {
                    chats: Object(s.a)({}, e.chats, {
                        byIds: Object(s.a)({}, e.chats.byIds, (r = {}, r[o] = Object(s.a)({}, e.chats.byIds[o], {
                            events: {
                                byIds: Object(s.a)({}, e.chats.byIds[o].events.byIds, (n = {}, n[i] = a, n)),
                                orderedIds: e.chats.byIds[o].events.orderedIds.concat(i),
                                serverIdsMapping: ie(e.chats.byIds[o].events.serverIdsMapping, a)
                            }
                        }), r))
                    })
                })
            },
            ae = function(e, t) {
                var n, r = t.id,
                    i = t.chat;
                return Object(s.a)({}, e, {
                    chats: Object(s.a)({}, e.chats, {
                        byIds: Object(s.a)({}, e.chats.byIds, (n = {}, n[i] = Object(s.a)({}, e.chats.byIds[i], {
                            events: {
                                byIds: Object(p.X)([r], e.chats.byIds[i].events.byIds),
                                orderedIds: e.chats.byIds[i].events.orderedIds.filter((function(e) {
                                    return e !== r
                                })),
                                serverIdsMapping: Object(p.Y)((function(e) {
                                    return e === r
                                }), e.chats.byIds[i].events.serverIdsMapping)
                            }
                        }), n))
                    })
                })
            },
            ce = function(e, t) {
                var n, r = t.chat,
                    i = t.events;
                return Object(s.a)({}, e, {
                    chats: Object(s.a)({}, e.chats, {
                        byIds: Object(s.a)({}, e.chats.byIds, (n = {}, n[r] = Object(s.a)({}, e.chats.byIds[r], {
                            events: {
                                byIds: Object(s.a)({}, e.chats.byIds[r].events.byIds, Object(p.K)("id", i)),
                                orderedIds: i.map((function(e) {
                                    return e.id
                                })).concat(e.chats.byIds[r].events.orderedIds),
                                serverIdsMapping: Object(s.a)({}, e.chats.byIds[r].events.serverIdsMapping, Object(p.P)((function(e) {
                                    return e.id
                                }), Object(p.K)("serverId", i)))
                            }
                        }), n))
                    })
                })
            },
            ue = function(e, t) {
                var n, r = t.id,
                    i = t.user;
                return Object(s.a)({}, e, {
                    users: Object(s.a)({}, e.users, {
                        byIds: Object(s.a)({}, e.users.byIds, (n = {}, n[r] = i, n)),
                        serverIdsMapping: ie(e.users.serverIdsMapping, i)
                    })
                })
            },
            se = function(e, t, n) {
                var r, i = n.properties,
                    o = Object(v.a)(n, ["properties"]),
                    a = e.byIds[t];
                return Object(s.a)({}, e, {
                    byIds: Object(s.a)({}, e.byIds, (r = {}, r[t] = Object(s.a)({}, a, o, {
                        properties: i ? Object(s.a)({}, a.properties, i) : a.properties
                    }), r))
                })
            },
            de = function(e, t, n) {
                var r, i, o = e.byIds[t],
                    a = Object(s.a)({
                        byIds: Object(s.a)({}, e.byIds, (r = {}, r[t] = Object(s.a)({}, o, n), r))
                    }, n.serverId && Object(p.B)("serverIdsMapping", e) && Object(s.a)({}, e.serverIdsMapping, ((i = {})[n.serverId] = t, i)));
                return Object(s.a)({}, e, a)
            },
            le = function(e) {
                var t, n = (void 0 === e ? {} : e).users,
                    r = void 0 === n ? [] : n,
                    i = Object(p.K)("id", r.map(g));
                return Object(f.d)({
                    users: {
                        byIds: Object(s.a)({}, i, {
                            system: {
                                id: "system",
                                type: "system"
                            }
                        }),
                        serverIdsMapping: re(i)
                    },
                    chats: {
                        byIds: {},
                        serverIdsMapping: {}
                    }
                }, ((t = {})[C] = function(e, t) {
                    var n, r = t.id,
                        i = t.chat,
                        o = t.events;
                    return Object(s.a)({}, e, {
                        chats: Object(s.a)({}, e.chats, {
                            byIds: Object(s.a)({}, e.chats.byIds, (n = {}, n[r] = Object(s.a)({}, i, {
                                events: {
                                    byIds: Object(p.K)("id", o),
                                    orderedIds: o.map((function(e) {
                                        return e.id
                                    })),
                                    serverIdsMapping: re(o)
                                }
                            }), n)),
                            serverIdsMapping: ie(e.chats.serverIdsMapping, i)
                        })
                    })
                }, t[I] = oe, t[S] = ae, t[T] = ce, t[k] = function(e, t) {
                    var n, r = t.chat,
                        i = t.user,
                        o = e.chats.byIds[r].participants;
                    return Object(p.p)((function(e) {
                        return i === e
                    }), o) > -1 ? e : Object(s.a)({}, e, {
                        chats: Object(s.a)({}, e.chats, {
                            byIds: Object(s.a)({}, e.chats.byIds, (n = {}, n[r] = Object(s.a)({}, e.chats.byIds[r], {
                                participants: [].concat(o, [i])
                            }), n))
                        })
                    })
                }, t[A] = ue, t[z] = function(e, t) {
                    var n, r = t.id;
                    return Object(s.a)({}, e, {
                        chats: Object(s.a)({}, e.chats, {
                            byIds: Object(s.a)({}, e.chats.byIds, (n = {}, n[r] = Object(s.a)({}, e.chats.byIds[r], {
                                serverId: null,
                                events: {
                                    byIds: {},
                                    orderedIds: [],
                                    serverIdsMapping: {}
                                },
                                properties: {}
                            }), n))
                        })
                    })
                }, t[L] = function(e, t) {
                    var n, r = t.chat,
                        i = t.user,
                        o = e.chats.byIds[r].participants,
                        a = Object(p.p)((function(e) {
                            return i === e
                        }), o);
                    return -1 === a ? e : Object(s.a)({}, e, {
                        chats: Object(s.a)({}, e.chats, {
                            byIds: Object(s.a)({}, e.chats.byIds, (n = {}, n[r] = Object(s.a)({}, e.chats.byIds[r], {
                                participants: Object(p.ib)(a, o)
                            }), n))
                        })
                    })
                }, t[P] = oe, t[q] = function(e, t) {
                    var n, r = t.id,
                        i = t.serverId;
                    return Object(s.a)({}, e, {
                        chats: Object(s.a)({}, se(e.chats, r, {
                            serverId: i
                        }), {
                            serverIdsMapping: Object(s.a)({}, e.chats.serverIdsMapping, (n = {}, n[i] = r, n))
                        })
                    })
                }, t[V] = function(e, t) {
                    var n, r, i = t.id,
                        o = t.chat,
                        a = t.serverId;
                    return Object(s.a)({}, e, {
                        chats: Object(s.a)({}, e.chats, {
                            byIds: Object(s.a)({}, e.chats.byIds, (r = {}, r[o] = Object(s.a)({}, e.chats.byIds[o], {
                                events: Object(s.a)({}, se(e.chats.byIds[o].events, i, {
                                    serverId: a
                                }), {
                                    serverIdsMapping: Object(s.a)({}, e.chats.byIds[o].events.serverIdsMapping, (n = {}, n[a] = i, n))
                                })
                            }), r))
                        })
                    })
                }, t[N] = function(e, t) {
                    var n, r = t.id,
                        i = t.chat,
                        o = t.data;
                    return Object(s.a)({}, e, {
                        chats: Object(s.a)({}, e.chats, {
                            byIds: Object(s.a)({}, e.chats.byIds, (n = {}, n[i] = Object(s.a)({}, e.chats.byIds[i], {
                                events: de(e.chats.byIds[i].events, r, o)
                            }), n))
                        })
                    })
                }, t[G] = function(e, t) {
                    var n = t.id,
                        r = t.properties;
                    return Object(s.a)({}, e, {
                        users: de(e.users, n, {
                            properties: r
                        })
                    })
                }, t[U] = function(e, t) {
                    var n, r = t.id,
                        i = t.serverId;
                    return Object(s.a)({}, e, {
                        users: Object(s.a)({}, se(e.users, r, {
                            serverId: i
                        }), {
                            serverIdsMapping: Object(s.a)({}, e.users.serverIdsMapping, (n = {}, n[i] = r, n))
                        })
                    })
                }, t[K] = function(e, t) {
                    var n = t.id,
                        r = t.data;
                    return Object(s.a)({}, e, {
                        chats: se(e.chats, n, r)
                    })
                }, t[X] = function(e, t) {
                    var n, r = t.id,
                        i = t.chat,
                        o = t.data;
                    return Object(s.a)({}, e, {
                        chats: Object(s.a)({}, e.chats, {
                            byIds: Object(s.a)({}, e.chats.byIds, (n = {}, n[i] = Object(s.a)({}, e.chats.byIds[i], {
                                events: se(e.chats.byIds[i].events, r, o)
                            }), n))
                        })
                    })
                }, t[ee] = function(e, t) {
                    var n = t.id,
                        r = t.data;
                    return Object(s.a)({}, e, {
                        users: se(e.users, n, r)
                    })
                }, t))
            },
            fe = function(e) {
                return void 0 === e && (e = {}),
                    function(t, n) {
                        return void 0 === t && (t = e), n.type !== String(F) ? t : Object(s.a)({}, t, n.payload)
                    }
            },
            pe = function(e) {
                var t;
                return Object(f.d)(function(e) {
                    var t = e.id,
                        n = e.connectionState;
                    return {
                        id: t,
                        connectionState: void 0 === n ? c : n
                    }
                }(e), ((t = {})[B] = function(e, t) {
                    var n = t.connectionState;
                    return Object(s.a)({}, e, {
                        connectionState: n
                    })
                }, t))
            },
            me = function(e) {
                return +new Date(e).setHours(0, 0, 0, 0)
            },
            ve = function(e, t) {
                return me(e) === me(t)
            },
            be = function(e) {
                var t = e.sessionUserId,
                    n = e.event,
                    r = e.showDate,
                    i = void 0 !== r && r;
                return {
                    own: n.author === t,
                    author: n.author,
                    events: [{
                        id: n.id,
                        type: n.type
                    }],
                    type: n.type,
                    showDate: i,
                    timestamp: n.timestamp
                }
            },
            he = function(e, t) {
                return be({
                    sessionUserId: y.getSessionUser(e).id,
                    event: t,
                    showDate: !0
                })
            },
            ge = function(e) {
                return Object(p.W)((function(e) {
                    return -1 * Object(p.y)(0, "timestamp", Object(p.M)(e.events))
                }), e).map((function(e) {
                    return {
                        id: e.id
                    }
                }))
            },
            ye = function(e, t) {
                var n, r = t.id;
                return Object(s.a)({}, e, {
                    Chat: Object(s.a)({}, e.Chat, (n = {}, n[r] = Object(s.a)({}, e.Chat[r], {
                        timeline: []
                    }), n))
                })
            },
            Oe = function() {
                return !1
            },
            je = function() {
                return !0
            },
            _e = function() {
                return function(e) {
                    return void 0 === e && (e = {}), e
                }
            },
            we = function(e, t) {
                return Object(f.f)(Object(d.b)(Object(p.Q)((function(t, n) {
                    return t(e[n])
                }), {
                    application: ne,
                    entities: le,
                    localization: fe,
                    session: pe,
                    views: _e
                })), function(e) {
                    var t = e.shouldAddToTimeline,
                        n = void 0 === t ? je : t,
                        r = e.shouldCreateNewGroup,
                        i = void 0 === r ? Oe : r,
                        o = function(e, t) {
                            var n = y.getSessionUser(e).id;
                            return function(r, o) {
                                var a = Object(p.M)(r),
                                    c = y.getEvent(e, t, Object(p.M)(a.events).id);
                                if ("message_draft" === o.type && "form" === a.type) {
                                    var u = Object(p.q)((function(e) {
                                        return "message_draft" === e.type
                                    }), r);
                                    return u ? [].concat(Object(p.k)(2, r), [Object(s.a)({}, u, {
                                        events: [].concat(u.events, [{
                                            id: o.id,
                                            type: o.type
                                        }])
                                    }), a]) : [].concat(Object(p.k)(1, r), [be({
                                        sessionUserId: n,
                                        event: o
                                    }), a])
                                }
                                return ve(c.timestamp, o.timestamp) ? o.timestamp >= a.timestamp + 3e5 || a.author !== o.author || i(o) ? [].concat(r, [be({
                                    sessionUserId: n,
                                    event: o
                                })]) : [].concat(Object(p.k)(1, r), [Object(s.a)({}, a, {
                                    events: [].concat(a.events, [{
                                        id: o.id,
                                        type: o.type
                                    }])
                                })]) : [].concat(r, [be({
                                    sessionUserId: n,
                                    event: o,
                                    showDate: !0
                                })])
                            }
                        },
                        a = function(e, t, r) {
                            var i = r.filter(n);
                            if (0 === i.length) return [];
                            var a = i[0],
                                c = i.slice(1),
                                u = he(e, a);
                            return c.reduce(o(e, t), [u])
                        },
                        c = function(e, t, n) {
                            var r = y.getChats(n);
                            return {
                                Chat: Object(p.P)((function(e) {
                                    var t;
                                    return (t = {})[e.id] = {
                                        timeline: a(n, e.id, e.events)
                                    }, t
                                }), r),
                                ChatList: ge(r),
                                current: null
                            }
                        },
                        u = function(e, t, n) {
                            var r, i = t.id;
                            return Object(s.a)({}, e, {
                                Chat: Object(s.a)({}, e.Chat, (r = {}, r[i] = {
                                    timeline: a(n, i, y.getChat(n, i).events)
                                }, r)),
                                ChatList: ge(y.getChats(n))
                            })
                        },
                        d = function(e, t, r) {
                            var i, a = t.chat,
                                c = t.id,
                                u = e.Chat[a].timeline,
                                d = y.getEvent(r, a, c);
                            return n(d) ? Object(s.a)({}, e, {
                                Chat: Object(s.a)({}, e.Chat, (i = {}, i[a] = Object(s.a)({}, e.Chat[a], {
                                    timeline: u.length > 0 ? o(r, a)(u, d) : [he(r, d)]
                                }), i)),
                                ChatList: ge(y.getChats(r))
                            }) : e
                        },
                        l = function(e, t) {
                            var n, r, i = t.chat,
                                o = t.id,
                                a = e.Chat[i].timeline,
                                c = Object(p.p)((function(e) {
                                    return e.events.some((function(e) {
                                        return e.id === o
                                    }))
                                }), a),
                                u = a[c],
                                d = u.events.filter((function(e) {
                                    return e.id !== o
                                }));
                            return d.length > 0 ? r = Object(p.Ab)(c, Object(s.a)({}, u, {
                                events: d
                            }), a) : (r = c + 1 < a.length ? Object(p.Ab)(c + 1, Object(s.a)({}, a[c + 1], {
                                showDate: a[c + 1].showDate || u.showDate
                            }), a) : a, r = Object(p.ib)(c, r)), Object(s.a)({}, e, {
                                Chat: Object(s.a)({}, e.Chat, (n = {}, n[i] = Object(s.a)({}, e.Chat[i], {
                                    timeline: r
                                }), n))
                            })
                        },
                        f = function(e, t, n) {
                            var r, i = t.chat,
                                o = t.events,
                                c = e.Chat[i].timeline,
                                u = c[0],
                                d = c.slice(1),
                                l = Object(p.M)(o);
                            u && ve(l.timestamp, u.timestamp) && (u = Object(s.a)({}, u, {
                                showDate: ve(Date.now(), u.timestamp)
                            }));
                            var f = a(n, i, o),
                                m = u ? [].concat(f, [u], d) : f,
                                v = o[0],
                                b = !ve(v.timestamp, Date.now());
                            return Object(s.a)({}, e, {
                                Chat: Object(s.a)({}, e.Chat, (r = {}, r[i] = Object(s.a)({}, e.Chat[i], {
                                    hasDividers: b,
                                    timeline: m
                                }), r))
                            })
                        },
                        m = function(e, t, n) {
                            var r, i = t.id;
                            return Object(s.a)({}, e, {
                                Chat: Object(s.a)({}, e.Chat, (r = {}, r[i] = {
                                    timeline: a(n, i, y.getChat(n, i).events)
                                }, r))
                            })
                        };
                    return function(e, t) {
                        var n = t.type,
                            r = t.payload;
                        if (Object(p.F)(e.views)) return Object(s.a)({}, e, {
                            views: c(e.views, 0, e)
                        });
                        switch (n) {
                            case String(C):
                                return Object(s.a)({}, e, {
                                    views: u(e.views, r, e)
                                });
                            case String(I):
                            case String(P):
                                return Object(s.a)({}, e, {
                                    views: d(e.views, r, e)
                                });
                            case String(S):
                                return Object(s.a)({}, e, {
                                    views: l(e.views, r)
                                });
                            case String(T):
                                return Object(s.a)({}, e, {
                                    views: f(e.views, r, e)
                                });
                            case String(_):
                                var i = r.name.replace(/\//gi, ".");
                                return Object(s.a)({}, e, {
                                    views: Object(p.jb)(i, r.data, e.views)
                                });
                            case String(z):
                                return Object(s.a)({}, e, {
                                    views: ye(e.views, r)
                                });
                            case String(E):
                                var o = r.path.replace(/\//gi, ".") + "._default";
                                return Object(s.a)({}, e, {
                                    views: Object(p.jb)(o, r.name, e.views)
                                });
                            case String(M):
                                return Object(s.a)({}, e, {
                                    views: m(e.views, r, e)
                                });
                            case String(w):
                                return Object(s.a)({}, e, {
                                    views: Object(s.a)({}, e.views, {
                                        current: r.name
                                    })
                                });
                            case String(x):
                                var a = r.name.replace(/\//gi, "."),
                                    v = Object(p.x)(a, e.views);
                                return Object(s.a)({}, e, {
                                    views: Object(p.jb)(a, Object(s.a)({}, v, r.data), e.views)
                                });
                            default:
                                return e
                        }
                    }
                }(t))
            },
            xe = function(e, t) {
                var n = e.id,
                    r = t.getState;
                return y.getChat(r(), n)
            },
            Ee = function(e, t) {
                var n = e.id,
                    r = e.chat,
                    i = t.getState;
                return {
                    chat: r,
                    event: y.getEvent(i(), r, n)
                }
            },
            Ce = function(e, t) {
                var n = e.id,
                    r = t.getState;
                return y.getUser(r(), n)
            },
            Ie = function(e) {
                var t = y.getCurrentView(e);
                return {
                    view: t,
                    default: y.getDefaultView(e, t)
                }
            },
            Se = function(e) {
                var t;
                return function(e, t) {
                    return function(n, r) {
                        if (Object(p.B)(n.type, e)) {
                            var i = e[n.type](n.payload, r);
                            n.meta && (i.meta = n.meta), t(n.type.toLowerCase(), i)
                        }
                    }
                }(((t = {})[C] = xe, t[I] = Ee, t[A] = Ce, t[z] = xe, t[Z] = p.C, t[Q] = p.C, t[P] = Ee, t[R] = function(e, t) {
                    var n = t.getState;
                    return y.getApplicationState(n())
                }, t[B] = function(e, t) {
                    var n = t.getState;
                    return y.getConnectionState(n())
                }, t[w] = function(e, t) {
                    var n = e.name,
                        r = t.getState;
                    return {
                        name: n,
                        data: y.getView(r(), n),
                        viewInfo: Ie(r())
                    }
                }, t[E] = function(e, t) {
                    var n = e.name,
                        r = e.path,
                        i = t.getState;
                    return {
                        name: n,
                        path: r,
                        data: y.getView(i(), r + "/" + n),
                        viewInfo: Ie(i())
                    }
                }, t[K] = xe, t[X] = Ee, t[ee] = Ce, t[G] = Ce, t[te] = p.C, t[W] = p.C, t[q] = p.C, t), e)
            };

        function Te(e, t) {
            void 0 === e && (e = {}), void 0 === t && (t = {});
            var n = Object(l.a)(),
                r = p.C,
                o = Object(m.a)(),
                a = Object(d.c)(we(function(e) {
                    var t = e.entities,
                        n = void 0 === t ? {} : t,
                        r = e.session,
                        i = void 0 === r ? {} : r,
                        o = i.id,
                        a = void 0 === o ? "session_" + Object(p.v)() : o,
                        c = n.users,
                        u = void 0 === c ? [] : c,
                        d = Object(p.o)((function(e) {
                            return e.id === a
                        }), u);
                    return Object(s.a)({}, e, {
                        entities: Object(s.a)({}, n, {
                            users: d ? u : [].concat(u, [{
                                id: a,
                                serverId: null
                            }])
                        }),
                        session: Object(s.a)({}, i, {
                            id: a
                        })
                    })
                }(e), t), void 0, r(Object(d.a)(o)));
            o.add(Se(n.emit));
            var c = a.getState(),
                u = c,
                v = c;
            return a.subscribe((function() {
                var e = a.getState();
                if (v !== e) {
                    var t = [v, e];
                    u = t[0], v = t[1]
                }
            })), Object(p.a)(a, Object(f.a)(i, a), Object(f.b)(y, a.getState), {
                getPreviousState: function() {
                    return u
                },
                emit: n.emit,
                on: n.on,
                once: n.once,
                off: function(e, t) {
                    if (!e || !t) throw new Error(".off needs to be called with both type and handler arguments.");
                    if ("*" === e) throw new Error(".off('*', ...) is not supported.");
                    n.off(e, t)
                }
            }), a
        }
        var ke = n(108),
            Ae = {},
            ze = function() {
                return Ae
            };
        var Me = function(e, t) {
                return void 0 === t && (t = {}), Object(ke.b)(e, ze, void 0, Object(s.a)({
                    areStatesEqual: function(e) {
                        return e.getState() === e.getPreviousState()
                    }
                }, t))
            },
            Le = n(0),
            Pe = Le.createContext(void 0),
            Re = Me((function(e) {
                return {
                    localize: e.localize,
                    localization: e.getState().localization
                }
            }))((function(e) {
                var t = e.localize,
                    n = e.children;
                return Le.createElement(Pe.Provider, {
                    value: function(e, n) {
                        return t(e, n)
                    }
                }, n)
            })),
            De = function(e) {
                if ("string" === typeof e.children) {
                    var t = e.children,
                        n = Object(v.a)(e, ["children"]);
                    return Le.createElement(Pe.Consumer, null, (function(e) {
                        return e(t, n)
                    }))
                }
                return Le.createElement(Pe.Consumer, e)
            };

        function Be(e) {
            var t = e.store,
                n = e.children,
                r = Object.create(t);
            return r.getState = function() {
                return t
            }, Le.createElement(ke.a, {
                store: r
            }, Le.createElement(Re, null, n))
        }
    }, , function(e, t, n) {
        "use strict";
        n.d(t, "c", (function() {
            return r.a
        })), n.d(t, "d", (function() {
            return r.b
        })), n.d(t, "e", (function() {
            return r.c
        })), n.d(t, "b", (function() {
            return i.a
        })), n.d(t, "f", (function() {
            return i.g
        })), n.d(t, "a", (function() {
            return v
        }));
        var r = n(32),
            i = n(39),
            o = n(1),
            a = n(5),
            c = n(2),
            u = n(3),
            s = n(9),
            d = n(18),
            l = n(49),
            f = n(92),
            p = n(44),
            m = function(e) {
                return s.j(e).some((function(e) {
                    return "form" === e.type && e.properties.fields.some((function(e) {
                        return "group_chooser" === e.type
                    }))
                }))
            },
            v = function(e) {
                var t = Object(a.y)(Object(l.c)(e, (function(e) {
                    return Object(p.a)(e, "maximized")
                })), Object(a.B)(1), Object(a.i)(Boolean));
                Object(a.y)(t, Object(a.F)(1), Object(a.i)((function() {
                    return !Math.floor(1e3 * Math.random())
                })), Object(a.j)((function() {
                    return function(e) {
                        Object(i.h)({
                            isMessagingModeEnabled: s.H(e),
                            isCustomerInvited: s.A(e, u.d),
                            groupAvailability: e.getApplicationState().availability,
                            minimizedType: s.l(e)
                        })
                    }(e)
                }))), Object(a.y)(Object(l.a)(e), Object(a.j)((function() {
                    return function(e) {
                        var t = e.getApplicationState(),
                            n = t.s,
                            r = t.embedded,
                            a = t.testGroup,
                            l = t.actingAsDirectLink,
                            p = t.config,
                            v = t.language,
                            b = t.integrationName,
                            h = t.clientChatNumber,
                            g = t.clientVisitNumber,
                            y = p && p.theme && p.theme.name,
                            O = Object(f.b)() || "none",
                            j = Object(d.e)(),
                            _ = s.E(e),
                            w = !!s.x(e, u.d),
                            x = !!e.getSessionUser().email,
                            E = s.A(e, u.d) ? "invitation" : "other",
                            C = s.l(e),
                            I = s.j(e),
                            S = I.find((function(e) {
                                return !!e.properties.invitation
                            })),
                            T = Object(c.M)(I.filter((function(e) {
                                return "message" === e.type || "message_draft" === e.type
                            })));
                        Object(i.b)(Object(o.a)({
                            s: n,
                            embedded: r,
                            themeName: y,
                            testGroup: a,
                            uniqueGroups: j,
                            minimizedType: C,
                            language: v || "unknown",
                            integrationName: b || "none",
                            mobileBridgeType: O,
                            chatHistoryEnabled: _,
                            hasPreviousChatThreads: w,
                            hasGroupChooser: String(m(e)),
                            hasBeenImmediatelyQueued: String(e.getChat(u.d).properties.queued),
                            isCustomerEmailSet: x,
                            actingAsDirectLink: l,
                            chatWidgetWidth: window.innerWidth,
                            chatWidgetHeight: window.innerHeight,
                            clientChatNumber: h + 1,
                            clientVisitNumber: g,
                            chatSource: E,
                            fromGreeting: !!Object(c.y)(!1, "properties.fromGreeting", T)
                        }, "invitation" === E && S && {
                            greetingId: S.properties.id,
                            greetingUniqueId: S.properties.uniqueId,
                            greetingType: S.properties.type,
                            greetingSubtype: S.properties.subtype,
                            greetingAddon: S.properties.addon || "none"
                        }))
                    }(e)
                })))
            }
    }, function(e, t, n) {
        "use strict";
        n.d(t, "d", (function() {
            return r.a
        })), n.d(t, "c", (function() {
            return i.a
        })), n.d(t, "l", (function() {
            return o.a
        })), n.d(t, "m", (function() {
            return a.a
        })), n.d(t, "t", (function() {
            return u.a
        })), n.d(t, "a", (function() {
            return m
        })), n.d(t, "b", (function() {
            return b
        })), n.d(t, "g", (function() {
            return g
        })), n.d(t, "h", (function() {
            return w
        })), n.d(t, "k", (function() {
            return x
        })), n.d(t, "n", (function() {
            return l
        })), n.d(t, "o", (function() {
            return E
        })), n.d(t, "p", (function() {
            return C
        })), n.d(t, "q", (function() {
            return I
        })), n.d(t, "s", (function() {
            return L
        })), n.d(t, "u", (function() {
            return P
        })), n.d(t, "v", (function() {
            return R
        })), n.d(t, "w", (function() {
            return D
        })), n.d(t, "x", (function() {
            return B
        })), n.d(t, "i", (function() {
            return V
        })), n.d(t, "r", (function() {
            return W
        })), n.d(t, "e", (function() {
            return Y
        })), n.d(t, "f", (function() {
            return K
        })), n.d(t, "j", (function() {
            return J
        }));
        var r = n(124),
            i = n(88),
            o = n(52),
            a = n(250),
            c = n(125),
            u = n(141),
            s = n(140),
            d = n(0);
        var l = function(e) {
            d.useEffect(e, [])
        };

        function f(e) {
            return e < 0 ? -1 : 1
        }

        function p(e, t) {
            var n, r, i;
            return n = 0, r = 1, i = t + e / 100, Math.min(Math.max(i, n), r)
        }
        var m = function(e, t) {
                var n = Object(o.a)(t);
                l((function() {
                    var t = 0,
                        r = 0,
                        i = 1,
                        o = 1,
                        a = 0,
                        c = 0,
                        u = 0,
                        s = function(e, i) {
                            t = p(e, t), r = p(i, r), n.current({
                                x: t,
                                y: r
                            })
                        },
                        d = function e(n) {
                            var a = ("x" === n || "xy" === n) && t > 0 && t < 1,
                                c = ("y" === n || "xy" === n) && r > 0 && r < 1;
                            (a || c) && (s(a ? 5 * i : 0, c ? 5 * o : 0), u = requestAnimationFrame((function() {
                                return e(n)
                            })))
                        },
                        l = e.subscribe((function(e) {
                            var t = e.deltaX,
                                n = e.deltaY;
                            Math.abs(t) > 8 && (s(t, 0), i = f(t), clearTimeout(a), a = window.setTimeout((function() {
                                return d("x")
                            }), 50)), Math.abs(n) > 8 && (s(0, n), o = f(n), clearTimeout(c), c = window.setTimeout((function() {
                                return d("y")
                            }), 50))
                        }));
                    return function() {
                        l(), clearTimeout(a), clearTimeout(c), cancelAnimationFrame(u)
                    }
                }))
            },
            v = function e(t, n) {
                t.forEach((function(t) {
                    if (t !== n.modalElement) {
                        if (!n.ancestors.has(t)) {
                            var r = t.getAttribute("aria-hidden");
                            return n.originalValues.set(t, r), void t.setAttribute("aria-hidden", "true")
                        }
                        t.children && e([].slice.call(t.children), n)
                    }
                }))
            },
            b = function(e) {
                d.useEffect((function() {
                    if (e) {
                        var t = e.current,
                            n = t.ownerDocument || document,
                            r = function(e, t) {
                                for (var n = new Set, r = e; r = r.parentElement;) {
                                    if (t.body === r) return n;
                                    n.add(r)
                                }
                                return n
                            }(t, n),
                            i = new Map;
                        return v([].slice.call(n.body.children), {
                                ancestors: r,
                                originalValues: i,
                                modalElement: t
                            }),
                            function() {
                                i.forEach((function(e, t) {
                                    null !== e ? t.setAttribute("aria-hidden", e) : t.removeAttribute("aria-hidden")
                                }))
                            }
                    }
                }), [e])
            };

        function h(e, t, n) {
            d.useEffect((function() {
                return document.addEventListener(e, t, n),
                    function() {
                        return document.removeEventListener(e, t, n)
                    }
            }), [e, t, n])
        }
        var g = function(e, t) {
                d.useEffect((function() {
                    var n = t.current;
                    if (n) {
                        var r = function(e) {
                            e.preventDefault()
                        };
                        return n.addEventListener(e, r, {
                                passive: !1
                            }),
                            function() {
                                return n.removeEventListener("touchmove", r)
                            }
                    }
                }), [e, t])
            },
            y = 0,
            O = null,
            j = function() {
                O = "keyboard"
            },
            _ = function() {
                O = "click"
            },
            w = function(e) {
                var t = (null == e ? void 0 : e.document) || document;
                return d.useEffect((function() {
                    return 0 === y && (t.addEventListener("keydown", j, !0), t.addEventListener("mousedown", _, !0), t.addEventListener("touchstart", _, !0)), y++,
                        function() {
                            --y > 0 || (O = null, t.removeEventListener("keydown", j, !0), t.removeEventListener("mousedown", _, !0), t.removeEventListener("touchstart", _, !0))
                        }
                }), [t]), d.useCallback((function() {
                    return O
                }), [])
            };
        var x = function(e) {
            return {
                onKeyPress: d.useCallback((function(t) {
                    var n = t.key;
                    "Enter" !== n && " " !== n || e()
                }), [e])
            }
        };
        var E = function(e) {
                var t = Object(o.a)(e);
                d.useEffect((function() {
                    return function() {
                        return t.current()
                    }
                }), [t])
            },
            C = function(e, t) {
                var n = d.useRef(!1);
                d.useEffect((function() {
                    n.current ? e() : n.current = !0
                }), t)
            },
            I = function(e) {
                var t = d.useRef(!1),
                    n = Object(o.a)(e);
                return d.useEffect((function() {
                    t.current && (t.current = !1, n.current())
                })), d.useCallback((function() {
                    t.current = !0
                }), [])
            },
            S = n(2),
            T = n(14),
            k = n(191),
            A = {
                duration: 0
            },
            z = Object(k.a)(),
            M = ["End", "Home", "Space", "PageUp", "PageDown", "ArrowUp", "ArrowDown"];
        var L = function(e, t) {
                void 0 === t && (t = {});
                var n = t,
                    r = n.firstItemKey,
                    i = n.lastItemKey,
                    o = n.topThreshold,
                    a = void 0 === o ? 20 : o,
                    s = n.bottomThreshold,
                    l = void 0 === s ? 20 : s,
                    f = n.initialScrollTop,
                    p = n.onIsUserScrollingChanged,
                    m = n.onIsScrolledToTopChanged,
                    v = n.onIsScrolledToBottomChanged,
                    b = n.onScrollDeltaChanged,
                    g = n.isScrollingChangedTimeout,
                    y = void 0 === g ? 300 : g,
                    O = d.useRef(0),
                    j = d.useRef(0),
                    _ = d.useRef(!1),
                    w = d.useRef(!1),
                    x = d.useRef(!1),
                    E = d.useRef(!1),
                    C = d.useRef(null),
                    I = d.useRef({
                        timeout: 0,
                        value: !1
                    }),
                    k = d.useRef("none"),
                    L = Object(u.a)("y", e),
                    P = d.useCallback((function() {
                        E.current = !0, L.apply(void 0, arguments)
                    }), [L]),
                    R = Object(c.a)(r),
                    D = Object(c.a)(i),
                    B = d.useCallback((function() {
                        E.current = !1
                    }), []),
                    q = d.useCallback((function() {
                        return w.current
                    }), []),
                    N = d.useCallback((function() {
                        return x.current
                    }), []),
                    V = d.useCallback((function(e) {
                        return P(0, e)
                    }), [L]),
                    F = d.useCallback((function(t) {
                        if (e.current) {
                            var n = e.current,
                                r = n.scrollHeight,
                                i = n.clientHeight;
                            P(r - i, t), k.current = t && 0 === t.duration ? "instant" : "animated"
                        }
                    }), [e, P]),
                    U = d.useCallback((function(e) {
                        return C.current = e
                    }), []),
                    H = d.useCallback((function() {
                        return !!e.current && e.current.scrollHeight > e.current.clientHeight
                    }), [e]),
                    G = d.useCallback((function() {
                        I.current.value || (I.current.value = !0, p && p(I.current.value)), clearTimeout(I.current.timeout), I.current.timeout = window.setTimeout((function() {
                            I.current.value && (I.current.value = !1, p && p(I.current.value))
                        }), y)
                    }), [y]),
                    W = d.useCallback((function() {
                        var t = e.current,
                            n = t.scrollTop,
                            r = t.scrollHeight,
                            i = O.current > n,
                            o = O.current < n,
                            c = O.current === n,
                            u = r < j.current,
                            s = r > j.current,
                            d = O.current - n,
                            f = r > 1.5 * window.innerHeight;
                        if (O.current = n, j.current = r, H() && !E.current && G(), !c || !_.current) {
                            ("instant" === k.current || "animated" === k.current && x.current) && requestAnimationFrame((function() {
                                F({
                                    duration: 0
                                }), k.current = "none"
                            }));
                            var p = w.current && i,
                                h = x.current && (o || u || s),
                                g = p || Object(T.j)(t, a),
                                y = h || Object(T.i)(t, l);
                            m && (!w.current && g ? m(!0) : w.current && !g && m(!1)), v && (!x.current && y ? v(!0) : x.current && !y && v(!1)), w.current = g, x.current = y, !s && !w.current && b && !x.current && _.current && I.current && z && !E.current && f && b({
                                deltaX: 0,
                                deltaY: d / 2
                            })
                        }
                    }), [m, v, G]),
                    Y = d.useCallback((function(e) {
                        Object(S.D)(e.key, M) && B()
                    }), [B]),
                    K = function() {
                        P(C.current.offsetTop, A), C.current = null
                    },
                    Z = function() {
                        C.current ? K() : (R !== r && function() {
                            var t = e.current.scrollHeight,
                                n = j.current - O.current;
                            P(t - n, A)
                        }(), D !== i && x.current && F())
                    };
                return h("keydown", Y), d.useEffect((function() {
                    !1 === _.current ? (C.current ? K() : P("number" === typeof f ? f : e.current.scrollHeight, A), W(), _.current = !0) : Z()
                })), d.useEffect((function() {
                    if (e.current) {
                        var t = e.current;
                        return t.addEventListener("scroll", W, z ? {
                                passive: !0
                            } : void 0),
                            function() {
                                return t.removeEventListener("scroll", W)
                            }
                    }
                }), [e, W]), {
                    scrollTo: P,
                    scrollToTop: V,
                    scrollToBottom: F,
                    getIsOnTop: q,
                    getIsOnBottom: N,
                    getIsScrollable: H,
                    setScrollTargetNode: U,
                    onWheel: B,
                    onTouchStart: B
                }
            },
            P = function(e) {
                return Object(s.useSubscription)({
                    getCurrentValue: e.get,
                    subscribe: e.subscribe
                })
            },
            R = function(e) {
                return Object(r.a)((function() {
                    var t = e,
                        n = [];
                    return {
                        subscribe: function(e) {
                            return n.push(e),
                                function() {
                                    n.splice(n.indexOf(e), 1)
                                }
                        },
                        next: function(e) {
                            t = e, n.forEach((function(t) {
                                return t(e)
                            }))
                        },
                        get: function() {
                            return t
                        }
                    }
                }))
            },
            D = function(e, t) {
                d.useEffect((function() {
                    var n = setTimeout(e, t);
                    return function() {
                        return clearTimeout(n)
                    }
                }), [e, t])
            };

        function B(e) {
            var t = d.useState(e),
                n = t[0],
                r = t[1];
            return [n, d.useCallback((function() {
                r((function(e) {
                    return !e
                }))
            }), [])]
        }
        var q = new Map,
            N = d.createContext(q);
        N.Provider;

        function V(e) {
            var t = d.useContext(N);
            if (t.has(e)) return t.get(e);
            var n = {},
                r = {
                    get: function() {
                        return n.value
                    },
                    set: function(e) {
                        return n.value = e
                    },
                    clear: function() {
                        return delete n.value
                    },
                    destroy: function() {
                        return t.delete(e)
                    }
                };
            return t.set(e, r), r
        }
        var F = '[role="row"]',
            U = '[role="gridcell"]',
            H = function(e) {
                var t, n;
                if (e.target && Object(S.D)(e.key, ["ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight"])) {
                    var r = e.target;
                    switch (!0) {
                        case "TEXTAREA" === r.tagName:
                        case "INPUT" === r.tagName && "text" === (null == (t = r.attributes.type) ? void 0 : t.value):
                        case "INPUT" === r.tagName && "email" === (null == (n = r.attributes.type) ? void 0 : n.value):
                            e.stopPropagation()
                    }
                }
            },
            G = window.MutationObserver || window.WebKitMutationObserver;

        function W(e) {
            var t = e.mainElementRef,
                n = e.itemsCount,
                r = e.tableEdgeReached,
                i = void 0 === r ? S.V : r,
                o = d.useState(n),
                a = o[0],
                c = o[1],
                u = d.useRef(!1),
                s = d.useRef(!1),
                l = d.useRef(null),
                f = d.useRef(null),
                p = d.useRef(null);
            h("keydown", (function(e) {
                "Tab" === e.key && (u.current = !0)
            })), h("keyup", (function(e) {
                "Tab" === e.key && (u.current = !1)
            }));
            var m = function(e) {
                    return e ? Object(S.ub)(e.querySelectorAll("a, button, input, textarea, select")) : []
                },
                v = d.useCallback((function() {
                    var e = new G((function() {
                            if (s.current || p.current.contains(document.activeElement)) {
                                d(p.current);
                                var e = m(p.current);
                                e.forEach((function(e) {
                                    e.tabIndex = 0, e.addEventListener("blur", n), e.addEventListener("keydown", H)
                                })), c(p.current, !1), e.length && !p.current.contains(document.activeElement) && e[0].focus()
                            }
                        })),
                        n = function(e) {
                            var t = e.target === p.current,
                                n = e.relatedTarget === p.current,
                                i = p.current.contains(e.target),
                                o = p.current.contains(e.relatedTarget);
                            if (u.current && e.relatedTarget && !t && (!o || n)) return e.preventDefault(), void requestAnimationFrame((function() {
                                return e.target.focus()
                            }));
                            i && !o && r()
                        },
                        r = function() {
                            m(p.current).forEach((function(e) {
                                e.tabIndex = -1, e.removeEventListener("blur", n), e.removeEventListener("keydown", H)
                            }))
                        },
                        o = function(e) {
                            " " === e.key && e.target === p.current && e.preventDefault()
                        },
                        a = function(e) {
                            switch (e.key) {
                                case " ":
                                case "Enter":
                                    return void(e.target === p.current && (e.preventDefault(), function() {
                                        var e = m(p.current).filter((function(e) {
                                            return !e.disabled
                                        }));
                                        e.forEach((function(e) {
                                            e.tabIndex = 0, e.addEventListener("blur", n), e.addEventListener("keydown", H)
                                        })), e.length && e[0].focus(), s.current = !0
                                    }()));
                                case "Escape":
                                    return e.preventDefault(), r(), void requestAnimationFrame((function() {
                                        return p.current.focus()
                                    }))
                            }
                        },
                        c = function(t, r) {
                            void 0 === r && (r = !0), t.tabIndex = 0, r && t.focus(), t.addEventListener("keyup", a), t.addEventListener("keydown", o), t.addEventListener("blur", n), e.observe(t, {
                                childList: !0,
                                subtree: !0
                            })
                        },
                        d = function(t) {
                            t.tabIndex = -1, t.removeEventListener("keyup", a), t.removeEventListener("keydown", o), t.removeEventListener("blur", n), e.disconnect()
                        },
                        v = function(e) {
                            var t = e + "ElementSibling";
                            if (f.current && l.current && (f.current[t] || l.current[t])) {
                                for (var n = null, r = f.current, o = l.current; !n;)
                                    if (r && r[t]) n = (r = r[t]).querySelector(U);
                                    else {
                                        if (!o || !o[t]) return void i(e);
                                        if ((o = o[t]).attributes.role && "row" === o.attributes.role.value) r = o;
                                        else {
                                            var a = o.querySelectorAll(F);
                                            r = "previous" === e ? Object(S.M)(a) : a[0]
                                        }
                                        n = r ? r.querySelector(U) : null
                                    }
                                o !== l.current && (l.current = o), r !== f.current && (f.current = r), n !== p.current && (d(p.current), c(n), p.current = n)
                            } else i(e)
                        },
                        b = function(e) {
                            switch (e.key) {
                                case "ArrowUp":
                                case "ArrowLeft":
                                    return e.preventDefault(), void v("previous");
                                case "ArrowDown":
                                case "ArrowRight":
                                    return e.preventDefault(), void v("next");
                                default:
                                    return
                            }
                        };
                    p.current && c(p.current, !1);
                    var h = t.current;
                    return h.addEventListener("keydown", b),
                        function() {
                            e.disconnect(), h.removeEventListener("keydown", b)
                        }
                }), [p, t, f, l, i]);
            d.useEffect((function() {
                var e = setTimeout((function() {
                    return c(n)
                }), 100);
                return function() {
                    return clearTimeout(e)
                }
            }), [n]), d.useEffect((function() {
                if (t.current && t.current.children.length) {
                    t.current.tabIndex = -1;
                    var e = t.current.contains(document.activeElement),
                        n = m(t.current);
                    n.forEach((function(e) {
                        e.tabIndex = -1, e.addEventListener("keydown", H)
                    })), Object(S.ub)(t.current.querySelectorAll(U)).forEach((function(t) {
                        e && t === p.current || (t.tabIndex = -1)
                    }));
                    var r = Object(S.M)(Object(S.ub)(t.current.children)),
                        i = r ? r.querySelector(U) : null,
                        o = m(i),
                        a = i && i !== document.activeElement && i.contains(document.activeElement),
                        c = function() {
                            return o.forEach((function(e) {
                                e.tabIndex = 0, e.addEventListener("keydown", H)
                            }))
                        };
                    if (a ? c() : o.forEach((function(e) {
                            e.addEventListener("focus", c)
                        })), !e || a) {
                        if (l.current = Object(S.M)(Object(S.ub)(t.current.children)), !l.current) return;
                        var u = l.current.attributes.role;
                        if (f.current = u && "row" === u.value ? l.current : Object(S.M)(Object(S.ub)(l.current.querySelectorAll(F))), l.current.attributes.role && "row" === l.current.attributes.role.value ? f.current = l.current : f.current = Object(S.M)(Object(S.ub)(l.current.querySelectorAll(F))), !f.current) return;
                        if (p.current = f.current.querySelector(U), !p.current) return
                    }
                    var s = v();
                    return function() {
                        s(), o.forEach((function(e) {
                            e.removeEventListener("keydown", H), e.removeEventListener("focus", c)
                        })), n.filter(Boolean).forEach((function(e) {
                            e.removeEventListener("keydown", H)
                        }))
                    }
                }
            }), [p, f, l, t, v, a])
        }
        var Y = function(e, t) {
            void 0 === e && (e = !1), void 0 === t && (t = 1e3);
            var n = d.useState(!1),
                r = n[0],
                i = n[1];
            return d.useEffect((function() {
                var n, r = function() {
                    e || (i(!0), n = window.setTimeout((function() {
                        i(!1)
                    }), t))
                };
                return window.addEventListener("beforeunload", r),
                    function() {
                        window.removeEventListener("beforeunload", r), n && window.clearTimeout(n)
                    }
            }), [e, t]), r
        };
        var K = function(e, t) {
                var n = d.useState(e),
                    r = n[0],
                    i = n[1],
                    o = d.useRef(null);
                return d.useEffect((function() {
                    o.current = e ? document.activeElement : null, i(e)
                }), [e, o]), [r, function() {
                    t(), o.current instanceof HTMLElement && o.current.focus()
                }]
            },
            Z = n(17),
            J = function(e) {
                void 0 === e && (e = !1);
                var t = d.useState(e),
                    n = t[0],
                    r = t[1];
                return [n, Object(Z.h)({
                    onFocusWithin: function() {
                        r(!0)
                    },
                    onBlurWithin: function() {
                        r(!1)
                    }
                }).focusWithinProps]
            }
    }, function(e, t, n) {
        "use strict";
        var r = n(1),
            i = n(8),
            o = n(189);
        t.a = function() {
            var e = Object(o.a)(),
                t = e.all,
                n = Object(i.a)(e, ["all"]);
            return Object(r.a)({}, n, {
                off: function(e, r) {
                    e ? n.off(e, r) : t.clear()
                },
                once: function(e, t) {
                    n.on(e, (function r(i, o) {
                        n.off(e, r), t(i, o)
                    }))
                }
            })
        }
    }, , , function(e, t, n) {
        "use strict";
        n.d(t, "a", (function() {
            return h
        })), n.d(t, "b", (function() {
            return g
        })), n.d(t, "c", (function() {
            return y
        }));
        var r, i = n(1),
            o = n(8),
            a = n(47),
            c = n(13);
        ! function(e) {
            e[e.Emergency = 0] = "Emergency", e[e.Alert = 1] = "Alert", e[e.Critical = 2] = "Critical", e[e.Error = 3] = "Error", e[e.Warning = 4] = "Warning", e[e.Notice = 5] = "Notice", e[e.Informational = 6] = "Informational", e[e.Debug = 7] = "Debug"
        }(r || (r = {}));
        var u = function(e) {
                var t = e.type,
                    n = e.license,
                    r = Object(o.a)(e, ["type", "license"]),
                    i = {
                        licence_id: n.toString(),
                        event_id: t,
                        message: JSON.stringify(r)
                    },
                    u = "https://queue.livechatinc.com/logs";
                return Object(a.a)(u, {
                    method: "POST",
                    headers: {
                        Accept: "*/*",
                        "Content-Type": "application/x-www-form-urlencoded"
                    },
                    body: Object(c.a)(i)
                }).then((function() {
                    return Promise.resolve()
                }))
            },
            s = n(2),
            d = n(18),
            l = n(77),
            f = "_livechat_has_visited",
            p = n(35),
            m = [/sendURLToGuardwareProxy/i, /safari-extension:\/\//],
            v = !("true" === l.a.getItem(f));
        l.a.setItem(f, "true");
        var b = function(e, t, n) {
                var r = (new Intl.DateTimeFormat).resolvedOptions().timeZone,
                    o = Object(i.a)({
                        type: "chat_widget_" + t,
                        license: Object(d.c)(),
                        userAgent: navigator.userAgent,
                        mobile: Object(p.g)(),
                        timeZone: String(r),
                        logVersion: "2021-03-03",
                        firstTimeVisitor: v,
                        severity: e,
                        lc_env: "production"
                    }, n);
                if (r) {
                    var a = r.split("/")[0];
                    a !== r && (o.timeZoneArea = String(a))
                }
                return u(o)
            },
            h = function(e, t, n) {
                var r, o = {};
                if (t instanceof Error ? (o.errorMessage = t.message, o.stack = t.stack, o.code = t.code) : o.errorMessage = JSON.stringify({
                        error: t
                    }), r = o, !m.some((function(e) {
                        return e.test(r.errorMessage + " " + r.stack)
                    }))) return Object(s.H)(n) || (n = {
                    meta: JSON.stringify({
                        info: n
                    })
                }), b("Error", e, Object(i.a)({}, n, o))
            },
            g = function(e, t) {
                return b("Informational", e, t)
            },
            y = function(e) {
                return b("Notice", e)
            }
    }, , , function(e, t, n) {
        "use strict";
        n.d(t, "h", (function() {
            return i
        })), n.d(t, "e", (function() {
            return o
        })), n.d(t, "f", (function() {
            return a
        })), n.d(t, "g", (function() {
            return c
        })), n.d(t, "i", (function() {
            return u
        })), n.d(t, "b", (function() {
            return s
        })), n.d(t, "a", (function() {
            return d
        })), n.d(t, "c", (function() {
            return l
        })), n.d(t, "d", (function() {
            return f
        }));
        var r = n(2),
            i = function(e) {
                return !!e && /native code/.test(String(e))
            },
            o = function() {
                return !i(window.matchMedia) || !window.matchMedia("(hover: none)").matches
            },
            a = function() {
                return Object(r.D)(navigator.platform, ["iPad Simulator", "iPhone Simulator", "iPod Simulator", "iPad", "iPhone", "iPod"]) && Object(r.D)("Version/15", navigator.userAgent)
            },
            c = function() {
                return /mobile/gi.test(navigator.userAgent) && !("MacIntel" === navigator.platform && Object(r.D)("iPad", navigator.userAgent))
            },
            u = function() {
                return c() || "MacIntel" === navigator.platform && navigator.maxTouchPoints > 0
            },
            s = function() {
                return Object(r.D)("Chrome", navigator.userAgent)
            },
            d = function() {
                var e = navigator.userAgent.match(/Chrom(e|ium)\/([0-9]+)\./);
                return e ? parseInt(e[2], 10) : 0
            },
            l = function() {
                return Object(r.D)("Chrome-Lighthouse", navigator.userAgent)
            },
            f = function() {
                return /Firefox/.test(navigator.userAgent)
            }
    }, , , , function(e, t, n) {
        "use strict";
        n.d(t, "b", (function() {
            return i
        })), n.d(t, "a", (function() {
            return o
        })), n.d(t, "h", (function() {
            return a
        })), n.d(t, "e", (function() {
            return c
        })), n.d(t, "d", (function() {
            return u
        })), n.d(t, "c", (function() {
            return s
        })), n.d(t, "f", (function() {
            return d
        })), n.d(t, "g", (function() {
            return l
        }));
        var r = n(32),
            i = function(e) {
                return Object(r.b)("chat_started", e)
            },
            o = function(e) {
                return Object(r.b)("chat_rated", e)
            },
            a = function(e) {
                return Object(r.b)("widget_opened", e)
            },
            c = function(e) {
                return Object(r.b)("greeting_displayed", e)
            },
            u = function(e) {
                return Object(r.b)("greeting_dismissed", e)
            },
            s = function(e) {
                return Object(r.b)("greeting_canceled", e)
            },
            d = function(e) {
                return Object(r.b)("greeting_not_canceled", e)
            },
            l = function(e, t) {
                return Object(r.b)("potential_connection_problem_" + e, t)
            }
    }, , function(e, t, n) {
        "use strict";
        n.d(t, "a", (function() {
            return u
        })), n.d(t, "g", (function() {
            return s
        })), n.d(t, "c", (function() {
            return l
        })), n.d(t, "b", (function() {
            return f
        })), n.d(t, "i", (function() {
            return p
        })), n.d(t, "h", (function() {
            return m
        })), n.d(t, "d", (function() {
            return b
        })), n.d(t, "e", (function() {
            return h
        })), n.d(t, "k", (function() {
            return g
        })), n.d(t, "l", (function() {
            return y
        })), n.d(t, "j", (function() {
            return O
        })), n.d(t, "f", (function() {
            return E
        }));
        var r = n(7),
            i = n(4),
            o = n(22),
            a = n(197),
            c = function(e) {
                var t = e.color,
                    n = e.backgroundColor,
                    r = e.hoverBackgroundColor;
                return Object(i.c)("color:", t, ";background-color:", n, ";&:hover{color:", t, ";background-color:", r, ";}")
            },
            u = Object(r.z)(r.d, {
                target: "e1osmd0p1"
            })("padding:", (function(e) {
                return e.theme.spaces.space3
            }), ";overflow:hidden;font-weight:400;white-space:nowrap;text-overflow:ellipsis;border:none!important;width:100%;display:block;outline-offset:2px;", (function(e) {
                var t = e.theme,
                    n = e.variant,
                    r = e.disabled;
                return Object(i.c)(t.typography.input, " border-radius:", "modern" === t.name ? 4 : 6, "px!important;", (!n || "default" === n) && c({
                    color: Object(o.f)(.6, t.colors.cta),
                    backgroundColor: Object(o.g)(.95, t.colors.cta),
                    hoverBackgroundColor: Object(o.g)(.85, t.colors.cta)
                }), " ", "primary" === n && c({
                    color: t.colors.ctaText,
                    backgroundColor: t.colors.cta,
                    hoverBackgroundColor: Object(o.f)(.25, t.colors.cta)
                }), " ", "danger" === n && c({
                    color: t.colors.text.white,
                    backgroundColor: t.colors.error,
                    hoverBackgroundColor: Object(o.f)(.25, t.colors.error)
                }), " ", r && Object(a.b)(t), ";")
            }), ";"),
            s = Object(r.z)(r.d, {
                target: "e1osmd0p0"
            })("padding:6px 4px;width:100%;height:32px;overflow:hidden;font-weight:400;white-space:nowrap;text-overflow:ellipsis;border:none;", (function(e) {
                var t = e.theme;
                return c({
                    color: Object(o.f)(.6, t.colors.cta),
                    backgroundColor: Object(o.d)(.02, t.colors.surface.lightVariant),
                    hoverBackgroundColor: Object(o.d)(.01, t.colors.surface.lightVariant)
                })
            }), ";"),
            d = n(114),
            l = Object(r.z)("ul", {
                target: "e52g9ij3"
            })("list-style:none;display:flex;flex-direction:column;margin:0;padding:1em;", (function(e) {
                var t = e.compact,
                    n = e.theme;
                return t && Object(i.c)("padding:", n.spaces.space3, ";flex-wrap:wrap;flex-direction:row;")
            }), ";"),
            f = Object(r.z)("li", {
                target: "e52g9ij2"
            })("margin-bottom:", (function(e) {
                return e.theme.spaces.space3
            }), ";", (function(e) {
                return e.compact && Object(i.c)(d.a, " padding:0;flex-grow:1;")
            }), ";"),
            p = Object(r.z)("div", {
                target: "e52g9ij1"
            })("margin:0;padding:1em;", (function(e) {
                var t = e.compact,
                    n = e.theme;
                return t && Object(i.c)("padding:", n.spaces.space3, ";")
            }), ";"),
            m = Object(r.z)("div", {
                target: "e52g9ij0"
            })("margin-bottom:", (function(e) {
                return e.theme.spaces.space3
            }), ";", (function(e) {
                return e.compact && Object(i.c)(d.a, " padding:0;")
            }), ";"),
            v = n(208),
            b = Object(r.z)(v.a, {
                target: "ezxewqd1"
            })("display:flex;overflow:hidden;flex-direction:", (function(e) {
                return e.horizontalLayout ? "row" : "column"
            }), ";width:", (function(e) {
                return e.horizontalLayout ? "100%" : "230px"
            }), ";max-width:100%;margin-bottom:0.1em;", (function(e) {
                var t = e.theme;
                return "smooth" === t.name ? Object(i.c)("box-shadow:", t.boxShadow.xs, ";") : Object(i.c)("border:1px solid ", t.colors.divider, ";")
            }), ";"),
            h = Object(r.z)("div", {
                target: "ezxewqd0"
            })("display:flex;flex-direction:column;width:230px;min-width:0%;max-width:100%;color:", (function(e) {
                return e.theme.colors.text.black
            }), ";", (function(e) {
                return e.narrow && {
                    flex: 2
                }
            }), ";");
        var g = Object(r.z)("div", {
                target: "eztkvdh2"
            })({
                name: "o30wb6",
                styles: "padding:1em;&:active{outline:none;}"
            }),
            y = Object(r.z)("h2", {
                target: "eztkvdh1"
            })({
                name: "yoe8zv",
                styles: "margin:0;margin-bottom:4px;font-size:1em;font-weight:400"
            }),
            O = Object(r.z)("p", {
                target: "eztkvdh0"
            })("margin:0;color:", (function(e) {
                return e.theme.colors.grayscale[600]
            }), ";"),
            j = n(110);
        var _ = {
                name: "idj2s4",
                styles: "object-fit:cover;width:100%;height:100%"
            },
            w = {
                name: "je8g23",
                styles: "pointer-events:none"
            },
            x = Object(r.z)("div", {
                target: "ex5d4ma0"
            })("overflow:hidden;", (function(e) {
                var t = e.horizontalLayout,
                    n = e.theme;
                return t ? Object(i.c)("flex:1;height:100%;border-top-left-radius:", n.borderRadius.md, ";border-bottom-left-radius:", n.borderRadius.md, ";") : Object(i.c)("width:100%;height:150px;border-top-left-radius:", n.borderRadius.md, ";border-top-right-radius:", n.borderRadius.md, ";")
            }), ";"),
            E = function(e) {
                var t = e.url,
                    n = e.link,
                    o = e.horizontalLayout,
                    a = e.alternativeText,
                    c = void 0 === a ? "" : a,
                    u = Object(i.d)(x, {
                        horizontalLayout: o
                    }, Object(i.d)(r.h, {
                        alt: c,
                        src: t,
                        css: _
                    }));
                return n ? Object(i.d)(j.a, {
                    href: n,
                    css: w
                }, u) : u
            }
    }, , , function(e, t, n) {
        "use strict";
        n.d(t, "a", (function() {
            return i
        }));
        var r = n(6),
            i = function(e, t) {
                return Object(r.getApplicationState)(e, "visibility").state === t
            }
    }, function(e, t, n) {
        "use strict";
        n.d(t, "a", (function() {
            return x
        }));
        var r = n(0),
            i = n(258),
            o = n.n(i),
            a = function() {
                return new RegExp("(" + o()().source + ")")
            },
            c = n(259),
            u = n.n(c),
            s = "msCrypto" in window,
            d = function(e) {
                return !s && u()(e)
            },
            l = n(4),
            f = n(7),
            p = n(260),
            m = n.n(p);
        var v = /\s/g,
            b = function() {
                return null
            },
            h = {
                name: "14c9nf6",
                styles: "width:1.75em;height:1.75em;margin:-1px;vertical-align:middle!important;display:inline!important"
            },
            g = function(e) {
                var t = e.emoji,
                    n = "https://cdn.livechat-static.com/api/file/lc/img/emoji-fallback/" + m()(t).toUpperCase().replace(v, "-") + ".svg";
                return Object(l.d)(f.h, {
                    alt: t,
                    css: h,
                    src: n
                }, b)
            },
            y = r.memo(g),
            O = a(),
            j = function(e) {
                return e.split(O).map((function(e, t) {
                    return !(t % 2 === 1) || d(e) ? e : r.createElement(y, {
                        key: t,
                        emoji: e
                    })
                }))
            },
            _ = function e(t) {
                return r.Children.map(t, (function(t) {
                    var n;
                    return "string" === typeof t ? j(t) : r.Children.count(null == t || null == (n = t.props) ? void 0 : n.children) ? r.cloneElement(t, void 0, e(t.props.children)) : t
                }))
            },
            w = function(e) {
                var t = e.children;
                return "string" === typeof t ? j(t) : t ? _(t) : null
            },
            x = r.memo(w)
    }, , , , function(e, t, n) {
        "use strict";
        n.d(t, "c", (function() {
            return o
        })), n.d(t, "b", (function() {
            return a
        })), n.d(t, "a", (function() {
            return d
        }));
        var r = n(5),
            i = n(2);

        function o(e, t) {
            return Object(r.y)(Object(r.m)(e), Object(r.C)(e.getState()), Object(r.s)(t), Object(r.f)(i.kb))
        }
        var a = function(e, t) {
                return Object(r.y)(o(e, (function(e) {
                    return e.application.readyState
                })), Object(r.i)((function(e) {
                    return e === t
                })), Object(r.F)(1), r.z)
            },
            c = n(6),
            u = n(24),
            s = n(3),
            d = function(e) {
                return Object(r.y)(a(e, u.a.READY), Object(r.E)((function() {
                    return Object(r.y)(o(e, (function(e) {
                        return Object(c.getChat)(e, s.d).active
                    })), Object(r.B)(1), Object(r.i)(Boolean))
                })))
            }
    }, , , , function(e, t, n) {
        "use strict";
        n.d(t, "q", (function() {
            return l
        })), n.d(t, "A", (function() {
            return b
        })), n.d(t, "B", (function() {
            return x
        })), n.d(t, "a", (function() {
            return u.a
        })), n.d(t, "b", (function() {
            return u.b
        })), n.d(t, "c", (function() {
            return u.d
        })), n.d(t, "d", (function() {
            return u.e
        })), n.d(t, "e", (function() {
            return u.f
        })), n.d(t, "f", (function() {
            return u.g
        })), n.d(t, "g", (function() {
            return u.i
        })), n.d(t, "h", (function() {
            return u.j
        })), n.d(t, "i", (function() {
            return u.l
        })), n.d(t, "j", (function() {
            return u.m
        })), n.d(t, "k", (function() {
            return u.o
        })), n.d(t, "l", (function() {
            return u.p
        })), n.d(t, "m", (function() {
            return u.q
        })), n.d(t, "n", (function() {
            return u.r
        })), n.d(t, "o", (function() {
            return u.s
        })), n.d(t, "p", (function() {
            return u.t
        })), n.d(t, "r", (function() {
            return u.u
        })), n.d(t, "s", (function() {
            return u.v
        })), n.d(t, "t", (function() {
            return u.y
        })), n.d(t, "u", (function() {
            return u.z
        })), n.d(t, "v", (function() {
            return u.A
        })), n.d(t, "w", (function() {
            return u.B
        })), n.d(t, "x", (function() {
            return u.C
        })), n.d(t, "y", (function() {
            return u.D
        })), n.d(t, "z", (function() {
            return u.E
        })), n.d(t, "C", (function() {
            return u.F
        }));
        var r = n(23),
            i = n(1),
            o = n(8),
            a = n(0),
            c = n(7),
            u = n(65),
            s = Object(c.z)(c.g, {
                target: "eed86ay0"
            })("padding:0;flex-shrink:0;display:flex;align-items:center;justify-content:center;", (function(e) {
                var t = e.size;
                return {
                    width: t,
                    height: t
                }
            }), ";"),
            d = function(e) {
                var t = e.buttonSize,
                    n = void 0 === t ? 32 : t,
                    r = e.iconSize,
                    c = void 0 === r ? 24 : r,
                    d = Object(o.a)(e, ["buttonSize", "iconSize"]);
                return a.createElement(s, Object(i.a)({
                    size: n
                }, d), a.createElement(u.n, {
                    size: c
                }, a.createElement(u.f, {
                    size: c
                })))
            },
            l = Object(c.z)("div", {
                target: "e1viqdiv0"
            })("margin:8px 16px;background:", (function(e) {
                return e.theme.colors.surface.light
            }), ";box-shadow:", (function(e) {
                return e.theme.boxShadow.sm
            }), ";", (function(e) {
                var t = e.stickToEdge,
                    n = void 0 !== t && t,
                    r = e.theme;
                return {
                    marginBottom: n ? "0" : "8px",
                    borderRadius: n ? r.borderRadius.md + " " + r.borderRadius.md + " " + r.borderRadius.none + " " + r.borderRadius.none : r.borderRadius.md,
                    "@media (orientation: landscape)": {
                        maxWidth: "50%",
                        margin: n ? "0 auto" : "0 auto 8px"
                    }
                }
            }), ";"),
            f = (n(95), n(2), n(154), n(207), n(223), n(153), n(222), n(114), n(117)),
            p = (Object(i.a)({}, f.a, {
                colors: Object(i.a)({}, f.a.colors, {
                    cta: "#427fe1"
                })
            }), (new Date).toISOString(), n(21)),
            m = n(4);

        function v() {
            var e = Object(p.a)(["\n\t0% {\n\t\ttransform: scale(", ");\n\t}\n\n\t25% {\n\t\ttransform: scale(", ");\n\t}\n\n\t50% {\n\t\ttransform: scale(", ");\n\t}\n\n\t100% {\n\t\ttransform: scale(1.0);\n\t}\n"]);
            return v = function() {
                return e
            }, e
        }
        var b = Object(c.z)("div", {
            target: "eyqxlol0"
        })("display:flex;align-items:center;justify-content:center;width:auto;min-width:1.5em;border-radius:", (function(e) {
            return e.theme.borderRadius.xl
        }), ";padding:0 4px;flex-shrink:0;background-color:", (function(e) {
            return e.theme.colors.notification
        }), ";color:", (function(e) {
            return e.theme.colors.text.white
        }), ";height:1.5em;line-height:1.5em;text-align:center;font-size:0.8em;box-shadow:", (function(e) {
            return e.theme.boxShadow.xs
        }), ";font-weight:bold;animation-name:", (function(e) {
            return function(e, t) {
                return void 0 === e && (e = 0), void 0 === t && (t = 1.3), Object(m.e)(v(), e, e, t)
            }(e.minScale, e.maxScale)
        }), ";animation-duration:0.625s;animation-timing-function:", (function(e) {
            return e.theme.transitions.easings.spring
        }), ";");
        var h = Object(c.z)(c.g, {
                target: "e1l1ek6a1"
            })("padding:0;flex-shrink:0;display:flex;align-items:center;justify-content:center;", (function(e) {
                var t = e.size;
                return {
                    width: t,
                    height: t
                }
            }), ";"),
            g = Object(c.z)(u.a, {
                target: "e1l1ek6a0"
            })({
                name: "jbgpyq",
                styles: "transform:rotate(90deg)"
            }),
            y = function(e) {
                var t = e.buttonSize,
                    n = void 0 === t ? 32 : t,
                    r = e.iconSize,
                    c = void 0 === r ? 24 : r,
                    s = Object(o.a)(e, ["buttonSize", "iconSize"]);
                return a.createElement(h, Object(i.a)({
                    size: n
                }, s), a.createElement(u.n, {
                    size: c
                }, a.createElement(g, {
                    size: c
                })))
            },
            O = n(45);
        var j = Object(c.z)("span", {
                target: "e1tnd1n32"
            })({
                name: "2h1wr3",
                styles: "flex-grow:1;flex-shrink:1"
            }),
            _ = Object(c.z)("div", {
                target: "e1tnd1n31"
            })("display:flex;cursor:pointer;justify-content:flex-start;align-items:center;", (function(e) {
                return e.theme.typography.basic
            }), ";"),
            w = Object(c.z)(b, {
                target: "e1tnd1n30"
            })({
                name: "1oi6uwp",
                styles: "margin:0 6px;flex-shrink:0;box-shadow:none"
            }),
            x = function(e) {
                var t = e.unseenCount,
                    n = e.text,
                    r = e.stickToEdge,
                    c = e.onClose,
                    u = e.onClick,
                    s = Object(o.a)(e, ["unseenCount", "text", "stickToEdge", "onClose", "onClick"]);
                return a.createElement(l, Object(i.a)({
                    stickToEdge: r
                }, s), a.createElement(_, {
                    "aria-label": "new messages notification",
                    onClick: u
                }, a.createElement(w, null, t < 100 ? t : "99+"), a.createElement(j, {
                    ellipsis: !0
                }, a.createElement(O.a, null, n)), a.createElement(y, {
                    onClick: u,
                    "aria-label": "scroll to latest " + (t > 1 ? t + " messages" : "message")
                }), a.createElement(d, {
                    "aria-label": "close notification",
                    onClick: function(e) {
                        e.stopPropagation(), c()
                    }
                })))
            };
        r.g, r.c, r.f, r.a, r.b, r.e
    }, , function(e, t, n) {
        "use strict";
        n.d(t, "a", (function() {
            return i
        })), n.d(t, "b", (function() {
            return o
        })), n.d(t, "c", (function() {
            return a
        })), n.d(t, "d", (function() {
            return c
        }));
        var r = n(25),
            i = r.d.CONNECTED,
            o = r.d.DISCONNECTED,
            a = "fakely_connected",
            c = (r.d.NOT_INITIALIZED, r.d.RECONNECTING)
    }, , , function(e, t, n) {
        "use strict";

        function r() {
            var e = {};
            return e.promise = new Promise((function(t, n) {
                e.resolve = t, e.reject = n
            })), e
        }
        n.d(t, "a", (function() {
            return r
        }))
    }, , , , , , , function(e, t, n) {
        "use strict";
        n.d(t, "a", (function() {
            return d
        })), n.d(t, "b", (function() {
            return l
        })), n.d(t, "c", (function() {
            return f
        })), n.d(t, "d", (function() {
            return g
        })), n.d(t, "e", (function() {
            return y
        })), n.d(t, "f", (function() {
            return O
        })), n.d(t, "g", (function() {
            return j
        })), n.d(t, "h", (function() {
            return _
        })), n.d(t, "i", (function() {
            return w
        })), n.d(t, "j", (function() {
            return x
        })), n.d(t, "k", (function() {
            return E
        })), n.d(t, "l", (function() {
            return P
        })), n.d(t, "m", (function() {
            return D
        })), n.d(t, "n", (function() {
            return B
        })), n.d(t, "o", (function() {
            return q
        })), n.d(t, "p", (function() {
            return N
        })), n.d(t, "q", (function() {
            return V
        })), n.d(t, "r", (function() {
            return F
        })), n.d(t, "s", (function() {
            return U
        })), n.d(t, "t", (function() {
            return H
        })), n.d(t, "u", (function() {
            return G
        })), n.d(t, "v", (function() {
            return W
        })), n.d(t, "w", (function() {
            return K
        })), n.d(t, "x", (function() {
            return Z
        })), n.d(t, "y", (function() {
            return J
        })), n.d(t, "z", (function() {
            return X
        })), n.d(t, "A", (function() {
            return Q
        })), n.d(t, "B", (function() {
            return $
        })), n.d(t, "C", (function() {
            return ee
        })), n.d(t, "D", (function() {
            return te
        })), n.d(t, "E", (function() {
            return ne
        })), n.d(t, "F", (function() {
            return re
        }));
        var r = n(21),
            i = n(4),
            o = n(11);

        function a() {
            var e = Object(r.a)(["\n\tto {\n\t\tstroke-dashoffset: 0;\n\t}\n"]);
            return a = function() {
                return e
            }, e
        }
        var c = Object(i.e)(a()),
            u = Object(i.c)("fill:none;stroke:currentColor;stroke-width:2;stroke-linecap:round;stroke-linejoin:round;animation-fill-mode:forwards;animation-name:", c, ";animation-duration:0.5s;animation-iteration-count:1;animation-timing-function:cubic-bezier(0, 0, 1, 1);stroke-dasharray:9.7;stroke-dashoffset:9.7;"),
            s = (Object(o.a)(Object(i.d)("polyline", {
                css: u,
                points: "4.3,8.1 5.3,9.1 6.8,10.5 9,8.2 11.1,6.1 "
            }), {
                size: 16,
                viewBox: "0 0 16 16"
            }), n(0)),
            d = Object(o.a)(s.createElement("path", {
                d: "M23.7,16.7l-6,6c-0.4,0.4-1,0.4-1.4,0c-0.4-0.4-0.4-0.9-0.1-1.3l0.1-0.1l4.3-4.3H10c-0.5,0-0.9-0.4-1-0.9L9,16 c0-0.5,0.4-0.9,0.9-1l0.1,0h10.6l-4.3-4.3c-0.4-0.4-0.4-0.9-0.1-1.3l0.1-0.1c0.4-0.4,0.9-0.4,1.3-0.1l0.1,0.1l6,6 C24.1,15.7,24.1,16.2,23.7,16.7L23.7,16.7z"
            }), {
                size: 32,
                viewBox: "0 0 32 32"
            }),
            l = Object(o.a)(s.createElement("path", {
                d: "M22,12.3c0.4,0.4,0.4,1,0,1.4l-6.4,6.4c-1.1,1.1-3,1.3-4,0.2l-0.4-0.4c-1.1-1.1-0.9-2.9,0.2-4l7.8-7.8 c1.6-1.6,4.3-1.4,6,0.4l0.7,0.7c1.7,1.7,1.9,4.4,0.4,6l-8.5,8.5c-2.7,2.7-7.2,2.7-9.9,0s-2.7-7.2,0-9.9l5.7-5.7c0.4-0.4,1-0.4,1.4,0 c0.4,0.4,0.4,1,0,1.4l-5.7,5.7c-2,2-2,5.1,0,7.1s5.1,2,7.1,0l8.5-8.5c0.8-0.8,0.6-2.2-0.4-3.2l-0.7-0.7c-1-1-2.4-1.1-3.2-0.4 l-7.8,7.8c-0.4,0.4-0.5,1-0.2,1.2l0.4,0.4c0.3,0.3,0.8,0.2,1.2-0.2l6.4-6.4c0.2-0.2,0.5-0.3,0.7-0.3C21.6,12,21.8,12.1,22,12.3z"
            }), {
                size: 32,
                viewBox: "0 0 32 32"
            }),
            f = Object(o.a)(s.createElement("path", {
                d: "M12,18c-0.6,0-1-0.4-1-1c0-0.6,0.4-1,1-1s1,0.4,1,1C13,17.6,12.6,18,12,18z M10.5,7.1 C10.5,6.5,11.2,6,12,6s1.5,0.5,1.5,1.1c0.1,5.2-0.4,7.9-1.5,7.9S10.4,12.4,10.5,7.1z"
            }), {
                size: 32,
                viewBox: "0 0 24 24"
            }),
            p = n(1),
            m = n(8),
            v = n(7),
            b = n(126),
            h = Object(v.z)("path", {
                target: "e1nep2br0"
            })((function(e) {
                var t = e.collapsed;
                return {
                    opacity: t ? 0 : 1,
                    transform: "scale(" + (t ? 0 : 1) + ")"
                }
            }), " transform-origin:50% 50%;transition:200ms ", (function(e) {
                return e.theme.transitions.easings.spring
            }), " 50ms;"),
            g = function(e) {
                var t = e.backgroundColor,
                    n = e.color,
                    r = e.filled,
                    i = void 0 !== r && r,
                    o = Object(m.a)(e, ["backgroundColor", "color", "filled"]);
                return s.createElement(b.a, Object(p.a)({
                    viewBox: "0 0 32 32"
                }, o), s.createElement("path", {
                    fill: n,
                    d: "M12.63,26.46H8.83a6.61,6.61,0,0,1-6.65-6.07,89.05,89.05,0,0,1,0-11.2A6.5,6.5,0,0,1,8.23,3.25a121.62,121.62,0,0,1,15.51,0A6.51,6.51,0,0,1,29.8,9.19a77.53,77.53,0,0,1,0,11.2,6.61,6.61,0,0,1-6.66,6.07H19.48L12.63,31V26.46"
                }), s.createElement(h, {
                    collapsed: i,
                    fill: t,
                    d: "M19.57,21.68h3.67a2.08,2.08,0,0,0,2.11-1.81,89.86,89.86,0,0,0,0-10.38,1.9,1.9,0,0,0-1.84-1.74,113.15,113.15,0,0,0-15,0A1.9,1.9,0,0,0,6.71,9.49a74.92,74.92,0,0,0-.06,10.38,2,2,0,0,0,2.1,1.81h3.81V26.5Z"
                }))
            },
            y = Object(o.a)(s.createElement("path", {
                d: "M21.3331175,12.2868932 C21.7144399,11.9043689 22.3326857,11.9043689 22.7140082,12.2868932 C23.0953306,12.6694174 23.0953306,13.2896117 22.7140082,13.6721359 L17.1904454,19.2131068 C16.8091229,19.5956311 16.1908771,19.5956311 15.8095546,19.2131068 L10.2859918,13.6721359 C9.90466939,13.2896117 9.90466939,12.6694174 10.2859918,12.2868932 C10.6673143,11.9043689 11.2855601,11.9043689 11.6668825,12.2868932 L16.5,17.1352427 L21.3331175,12.2868932 Z"
            }), {
                size: 32,
                viewBox: "0 0 32 32",
                fill: "none",
                stroke: "none",
                strokeWidth: 1,
                fillRule: "evenodd"
            }),
            O = Object(o.a)(s.createElement("path", {
                d: "M17.4,16l5.3,5.3c0.4,0.4,0.4,1,0,1.4c-0.4,0.4-1,0.4-1.4,0L16,17.4l-5.3,5.3c-0.4,0.4-1,0.4-1.4,0\tc-0.4-0.4-0.4-1,0-1.4l5.3-5.3l-5.3-5.3c-0.4-0.4-0.4-1,0-1.4c0.4-0.4,1-0.4,1.4,0l5.3,5.3l5.3-5.3c0.4-0.4,1-0.4,1.4,0\tc0.4,0.4,0.4,1,0,1.4L17.4,16z"
            }), {
                size: 32,
                viewBox: "0 0 32 32"
            }),
            j = Object(o.a)(s.createElement("path", {
                d: "M8,18c-1.1,0-2-0.9-2-2s0.9-2,2-2s2,0.9,2,2S9.1,18,8,18z M16,18c-1.1,0-2-0.9-2-2s0.9-2,2-2\ns2,0.9,2,2S17.1,18,16,18z M24,18c-1.1,0-2-0.9-2-2s0.9-2,2-2s2,0.9,2,2S25.1,18,24,18z"
            }), {
                size: 32,
                viewBox: "0 0 32 32"
            }),
            _ = Object(o.a)(s.createElement("path", {
                d: "M6,18h12c0.6,0,1,0.4,1,1c0,0.5-0.4,0.9-0.9,1L18,20H6c-0.6,0-1-0.4-1-1c0-0.5,0.4-0.9,0.9-1L6,18h12H6z M11.4,6\nL15,9.6l-6.1,6.1C8.7,15.9,8.5,16,8.3,16l-0.1,0H6.1c-0.5,0-1-0.4-1-0.9l0-0.1v-2.1c0-0.2,0.1-0.5,0.2-0.6l0.1-0.1L11.4,6z M15.4,3.2l0.1,0.1l2.2,2.2c0.4,0.4,0.4,1,0.1,1.4L17.7,7l-2,2L12,5.3l2-2C14.3,2.9,15,2.9,15.4,3.2z"
            }), {
                size: 24,
                viewBox: "0 0 24 24"
            }),
            w = Object(o.a)(s.createElement("path", {
                d: "M16,6l0.3,0c5.4,0.1,9.7,4.6,9.7,10c0,5.5-4.5,10-10,10S6,21.5,6,16S10.5,6,16,6z M16,8l-0.2,0 C11.4,8.1,8,11.7,8,16s3.4,7.9,7.8,8l0.2,0l0.2,0c4.3-0.1,7.8-3.7,7.8-8C24,11.6,20.4,8,16,8z M13,17.7c0.4,1.3,1.6,2.3,3,2.3 c1.4,0,2.7-0.9,3-2.2c0.1-0.5,0.7-0.8,1.2-0.7s0.8,0.7,0.7,1.2c-0.6,2.2-2.6,3.7-5,3.7c-2.3,0-4.4-1.5-5-3.7 c-0.1-0.5,0.2-1.1,0.7-1.2C12.3,16.9,12.8,17.2,13,17.7z M12.5,12c0.8,0,1.5,0.7,1.5,1.5S13.3,15,12.5,15S11,14.3,11,13.5 S11.7,12,12.5,12z M19.5,12c0.8,0,1.5,0.7,1.5,1.5S20.3,15,19.5,15S18,14.3,18,13.5S18.7,12,19.5,12z"
            }), {
                size: 32,
                viewBox: "0 0 32 32"
            }),
            x = Object(o.a)(s.createElement("path", {
                d: "M17.6,17H7c-0.6,0-1-0.4-1-1s0.4-1,1-1h10.6l-2.3-2.3c-0.4-0.4-0.4-1,0-1.4c0.4-0.4,1-0.4,1.4,0l4,4 c0.4,0.4,0.4,1,0,1.4l-4,4c-0.4,0.4-1,0.4-1.4,0c-0.4-0.4-0.4-1,0-1.4L17.6,17L17.6,17z M8,12c0,0.6-0.4,1-1,1s-1-0.4-1-1V8.1 C6,7,7,6,8.1,6h15.8C25,6,26,7,26,8.1v15.8c0,1.2-1,2.1-2.1,2.1H8.1C7,26,6,25,6,23.9V20c0-0.6,0.4-1,1-1s1,0.4,1,1v3.9 C8,23.9,8.1,24,8.1,24h15.8c0.1,0,0.1-0.1,0.1-0.1V8.1C24,8.1,23.9,8,23.9,8H8.1C8.1,8,8,8.1,8,8.1V12z"
            }), {
                size: 32,
                viewBox: "0 0 32 32"
            }),
            E = Object(o.a)(s.createElement("path", {
                d: "M16,4c0.6,0,1.3,0.4,1.7,0.8l7.8,7.8c0.3,0.3,0.5,0.7,0.5,1.4v12c0,1.6-1.2,2.9-2.8,3L23,29H8 c-1.6,0-2.9-1.2-3-2.8L5,26V7c0-1.6,1.2-2.9,2.8-3L8,4H16z M16,6H8C7.5,6,7.1,6.4,7,6.9L7,7v19c0,0.5,0.4,0.9,0.9,1L8,27h15 c0.5,0,0.9-0.4,1-0.9l0-0.1V14h-7c-0.5,0-0.9-0.4-1-0.9l0-0.1V6z M22,12l-4-4v4H22z"
            }), {
                size: 32,
                viewBox: "0 0 32 32"
            });

        function C() {
            var e = Object(r.a)(["\n                  75% {\n                    opacity: 1;\n                  }\n                  0% {\n                    opacity: 1;\n                  }\n                  100% {\n                    opacity: 1;\n                  }\n                "]);
            return C = function() {
                return e
            }, e
        }

        function I() {
            var e = Object(r.a)(["\n                0% {\n                  transform: translate(16px, 24px) scale(1, 1) translate(-16px, -24px);\n                }\n                40% {\n                  transform: translate(16px, 24px) scale(1, 1.4) translate(-16px, -24px);\n                }\n                68.33% {\n                  transform: translate(16px, 24px) scale(1, 1.6) translate(-16px, -24px);\n                }\n                86.67% {\n                  transform: translate(16px, 24px) scale(1, 1.6) translate(-16px, -24px);\n                }\n                88.33% {\n                  transform: translate(16px, 24px) scale(1, 1.4) translate(-16px, -24px);\n                }\n                91.67% {\n                  transform: translate(16px, 24px) scale(0.8, 1.3) translate(-16px, -24px);\n                }\n                96.67% {\n                  transform: translate(16px, 24px) scale(0.45, 1.6) translate(-16px, -24px);\n                }\n                100% {\n                  transform: translate(16px, 24px) scale(0.45, 1.6) translate(-16px, -24px);\n                }\n              "]);
            return I = function() {
                return e
            }, e
        }

        function S() {
            var e = Object(r.a)(["\n              75% {\n                transform: translate(16px, 24px) rotate(0deg) translate(-16px, -24px);\n              }\n              78.33% {\n                transform: translate(16px, 24px) rotate(36deg) translate(-16px, -24px);\n              }\n              83.33% {\n                transform: translate(16px, 24px) rotate(90deg) translate(-16px, -24px);\n              }\n              91.67% {\n                transform: translate(16px, 24px) rotate(180deg) translate(-16px, -24px);\n              }\n              0% {\n                transform: translate(16px, 24px) rotate(0deg) translate(-16px, -24px);\n              }\n              100% {\n                transform: translate(16px, 24px) rotate(180deg) translate(-16px, -24px);\n              }\n            "]);
            return S = function() {
                return e
            }, e
        }

        function T() {
            var e = Object(r.a)(["\n            0% {\n              transform: translate(16px, 24px) translate(-16px, -24px) translate(0px, 2px);\n            }\n            40% {\n              transform: translate(16px, 24px) translate(-16px, -24px) translate(0px, 0px);\n            }\n            75% {\n              transform: translate(16px, 24px) translate(-16px, -24px) translate(0px, 0px);\n            }\n            76.67% {\n              transform: translate(16px, 24px) translate(-16px, -24px)\n                translate(-2px, 0px);\n            }\n            78.33% {\n              transform: translate(16px, 24px) translate(-16px, -24px)\n                translate(-4px, -1px);\n            }\n            81.67% {\n              transform: translate(16px, 24px) translate(-16px, -24px)\n                translate(-8px, -6px);\n            }\n            83.33% {\n              transform: translate(16px, 24px) translate(-16px, -24px)\n                translate(-8px, -8px);\n            }\n            85% {\n              transform: translate(16px, 24px) translate(-16px, -24px)\n                translate(-8px, -11px);\n            }\n            88.33% {\n              transform: translate(16px, 24px) translate(-16px, -24px)\n                translate(-4px, -13px);\n            }\n            91.67% {\n              transform: translate(16px, 24px) translate(-16px, -24px)\n                translate(0px, -13px);\n            }\n            96.67% {\n              transform: translate(16px, 24px) translate(-16px, -24px)\n                translate(0px, -11px);\n            }\n            100% {\n              transform: translate(16px, 24px) translate(-16px, -24px)\n                translate(0px, -11px);\n            }\n          "]);
            return T = function() {
                return e
            }, e
        }

        function k() {
            var e = Object(r.a)(["\n            0% {\n              stroke-dasharray: 6, 0, 6, 6;\n            }\n            100% {\n              stroke-dasharray: 6, 0, 6, 6;\n            }\n          "]);
            return k = function() {
                return e
            }, e
        }

        function A() {
            var e = Object(r.a)(["\n            0% {\n              stroke-dashoffset: 12;\n            }\n            68.33% {\n              stroke-dashoffset: -6;\n            }\n            100% {\n              stroke-dashoffset: -6;\n            }\n          "]);
            return A = function() {
                return e
            }, e
        }

        function z() {
            var e = Object(r.a)(["\n              58.33% {\n                opacity: 1;\n              }\n              60% {\n                opacity: 0;\n              }\n              91.67% {\n                opacity: 0;\n              }\n              96.67% {\n                opacity: 1;\n              }\n              0% {\n                opacity: 1;\n              }\n              100% {\n                opacity: 1;\n              }\n            "]);
            return z = function() {
                return e
            }, e
        }

        function M() {
            var e = Object(r.a)(["\n            0% {\n              transform: translate(16px, 15px) scale(1, 1) translate(-16px, -15px);\n            }\n            61.67% {\n              transform: translate(16px, 15px) scale(0, 0) translate(-16px, -15px);\n            }\n            63.33% {\n              transform: translate(16px, 15px) scale(1, 1) translate(-16px, -15px);\n            }\n            100% {\n              transform: translate(16px, 15px) scale(1, 1) translate(-16px, -15px);\n            }\n          "]);
            return M = function() {
                return e
            }, e
        }

        function L() {
            var e = Object(r.a)(["\n            75% {\n              transform: translate(16px, 16px) rotate(0deg) translate(-16px, -16px);\n            }\n            91.67% {\n              transform: translate(16px, 16px) rotate(180deg) translate(-16px, -16px);\n            }\n            0% {\n              transform: translate(16px, 16px) rotate(0deg) translate(-16px, -16px);\n            }\n            100% {\n              transform: translate(16px, 16px) rotate(180deg) translate(-16px, -16px);\n            }\n          "]);
            return L = function() {
                return e
            }, e
        }
        var P = Object(o.a)(Object(i.d)(s.Fragment, null, Object(i.d)("g", {
                css: Object(i.c)("fill:none;transform:translate(16px, 16px) rotate(0deg) translate(-16px, -16px);animation-fill-mode:backwards;animation-timing-function:cubic-bezier(0, 0, 1, 1);animation-name:", Object(i.e)(L()), ";")
            }, Object(i.d)("path", {
                d: "M22,22 L22,26 L10,26 L10,22 L16,16 L22,22 Z M22,10 L16,16 L10,10 L10,6 L22,6 L22,10 Z",
                strokeLinejoin: "round",
                css: {
                    name: "9mktyj",
                    styles: "stroke:currentColor;stroke-width:2"
                }
            })), Object(i.d)("g", {
                css: Object(i.c)("transform:translate(16px, 15px) scale(1, 1) translate(-16px, -15px);animation-fill-mode:backwards;animation-name:", Object(i.e)(M()), ";animation-timing-function:cubic-bezier(0.42, 0, 1, 1);")
            }, Object(i.d)("polygon", {
                points: "12 11 20 11 16 15",
                css: Object(i.c)("fill:currentColor;opacity:1;animation-fill-mode:backwards;animation-timing-function:cubic-bezier(0, 0, 1, 1);animation-name:", Object(i.e)(z()), ";")
            })), Object(i.d)("path", {
                d: "M16,17 L16,23",
                css: Object(i.c)("stroke:currentColor;stroke-width:2;stroke-dashoffset:12;stroke-dasharray:6,0,6,6;animation-fill-mode:backwards,backwards;animation-timing-function:cubic-bezier(0.42, 0, 1, 1),cubic-bezier(0, 0, 1, 1);animation-name:", Object(i.e)(A()), ",", Object(i.e)(k()), ";")
            }), Object(i.d)("g", {
                css: Object(i.c)("transform:translate(16px, 24px) translate(-16px, -24px) translate(0px, 2px);animation-fill-mode:backwards;animation-timing-function:cubic-bezier(0, 0, 1, 1);animation-name:", Object(i.e)(T()), ";")
            }, Object(i.d)("g", {
                css: Object(i.c)("transform:translate(16px, 24px) rotate(0deg) translate(-16px, -24px);animation-fill-mode:backwards;animation-timing-function:cubic-bezier(0, 0, 1, 1);animation-name:", Object(i.e)(S()), ";")
            }, Object(i.d)("g", {
                css: Object(i.c)("transform:translate(16px, 24px) scale(1, 1) translate(-16px, -24px);animation-fill-mode:backwards;animation-timing-function:cubic-bezier(0, 0, 1, 1);animation-name:", Object(i.e)(I()), ";")
            }, Object(i.d)("rect", {
                x: "10",
                y: "23",
                width: "12",
                height: "2",
                css: Object(i.c)("fill:currentColor;opacity:1;animation-fill-mode:backwards;animation-timing-function:cubic-bezier(0, 0, 1, 1);animation-name:", Object(i.e)(C()), ";")
            }))))), {
                size: 32,
                viewBox: "0 0 32 32",
                css: {
                    name: "2mc0ji",
                    styles: "*{animation-duration:2s;animation-iteration-count:infinite;animation-timing-function:cubic-bezier(0, 0, 1, 1);}"
                }
            }),
            R = n(143),
            D = Object(v.z)(s.forwardRef((function(e, t) {
                var n = e.onPress,
                    r = e.disabled,
                    i = Object(m.a)(e, ["onPress", "disabled"]);
                t = t || s.useRef(null);
                var o = Object(R.a)(Object(p.a)({
                        onPress: n,
                        isDisabled: r
                    }, i), t).buttonProps,
                    a = (o.ref, Object(m.a)(o, ["ref"]));
                return s.createElement(v.g, Object(p.a)({
                    ref: t
                }, i, a))
            })), {
                target: "e1mwfyk10"
            })("padding:0;display:flex;justify-content:center;align-items:center;border-radius:", (function(e) {
                return e.theme.borderRadius.def
            }), ";"),
            B = Object(v.z)("div", {
                target: "e1ykiqc40"
            })("display:inline-block;", (function(e) {
                var t = e.size;
                return {
                    width: t,
                    height: t
                }
            }), " &:hover{background-color:", (function(e) {
                return e.theme.colors.surface.lightVariant
            }), ";border-radius:", (function(e) {
                return e.theme.borderRadius.sm
            }), ";}"),
            q = Object(v.z)("div", {
                target: "eg7dzwm0"
            })("width:100%;height:100%;display:flex;align-items:center;justify-content:center;border-radius:", (function(e) {
                return e.theme.borderRadius.sm
            }), ";background-color:", (function(e) {
                return e.theme.colors.surface.lightVariant
            }), ";"),
            N = (Object(o.a)(s.createElement("path", {
                d: "M6.1,22.1l5.3-4.8c0.4-0.3,1-0.3,1.3,0l3.2,2.8l6.5-5.8c0.4-0.3,1-0.3,1.3,0l2.3,2.1V9c0-0.6-0.4-1-1-1h-18 c-0.6,0-1,0.4-1,1L6.1,22.1C6.1,22,6.1,22,6.1,22.1z M8,23h8.1l-4.1-3.7L8,23z M19.1,23h5.9c0.6,0,1-0.4,1-1v-3l-3-2.7l-5.7,5.1 L19.1,23z M7.1,6h18c1.7,0,3,1.3,3,3v13c0,1.7-1.3,3-3,3h-18c-1.7,0-3-1.3-3-3V9C4.1,7.3,5.4,6,7.1,6z M15.1,16c-1.7,0-3-1.3-3-3 s1.3-3,3-3s3,1.3,3,3S16.8,16,15.1,16z M15.1,14c0.6,0,1-0.4,1-1s-0.4-1-1-1c-0.6,0-1,0.4-1,1S14.5,14,15.1,14z"
            }), {
                size: 32,
                viewBox: "0 0 32 32"
            }), Object(o.a)(s.createElement("path", {
                d: "M17,13c0.5,0,1,0.5,1,1c0,4.7,0,7.3,0,8s0.3,1,1,1v0c0.6,0,1,0.5,1,1c0,0.5-0.4,0.9-0.9,1L19,25l-2,0l0,0h-3 c-0.6,0-1-0.4-1-1c0-0.5,0.4-0.9,0.9-1l0.1,0c0.7,0,1-0.3,1-1c0-1,0-4.9,0-5.9S14,15,14,15c-0.6,0-1-0.5-1-1c0-0.5,0.4-1,1-1H17z M16,7c1.1,0,2,0.9,2,2s-0.9,2-2,2s-2-0.9-2-2S14.9,7,16,7z"
            }), {
                size: 32,
                viewBox: "0 0 32 32"
            })),
            V = Object(o.a)(s.createElement("path", {
                d: "M5.5,6l6.5,5.7L18.5,6H5.5z M20,7.3l-7.3,6.4c-0.4,0.3-0.9,0.3-1.3,0L4,7.3V17c0,0.6,0.4,1,1,1h14 c0.6,0,1-0.4,1-1V7.3z M5,4h14c1.7,0,3,1.3,3,3v10c0,1.7-1.3,3-3,3H5c-1.7,0-3-1.3-3-3V7C2,5.3,3.3,4,5,4z"
            }), {
                size: 24,
                viewBox: "0 0 24 24"
            }),
            F = Object(o.a)(s.createElement("path", {
                d: "M11,22c-0.6,0-1-0.4-1-1s0.4-1,1-1h15c0.6,0,1,0.4,1,1s-0.4,1-1,1H11z"
            }), {
                size: 32,
                viewBox: "0 0 32 32"
            }),
            U = Object(o.a)(s.createElement("path", {
                d: "M17,2 L17.1762728,2.00509269 C18.6320946,2.08944495 19.8094139,3.21190551 19.9790092,4.64325277 L19.9949073,4.82372721 L20,5 L20,19 L19.9949073,19.1762728 C19.9070404,20.6927538 18.6927538,21.9070404 17.1762728,21.9949073 L17,22 L11,22 L10.8237272,21.9949073 C9.30724616,21.9070404 8.09295962,20.6927538 8.00509269,19.1762728 L8,19 L8.00672773,18.8833789 C8.06449284,18.3860402 8.48716416,18 9,18 C9.51283584,18 9.93550716,18.3860402 9.99327227,18.8833789 L10.0067277,19.1166211 C10.0600494,19.575703 10.424297,19.9399506 10.8833789,19.9932723 L11,20 L17,20 L17.1166211,19.9932723 C17.575703,19.9399506 17.9399506,19.575703 17.9932723,19.1166211 L18,19 L18,5 L17.9932723,4.88337887 C17.9443941,4.46255383 17.6342517,4.12141588 17.2292908,4.02641071 L17.1166211,4.00672773 L17,4 L11,4 L10.8833789,4.00672773 C10.4625538,4.0556059 10.1214159,4.36574828 10.0264107,4.77070917 L10.0067277,4.88337887 L9.99327227,5.11662113 C9.93550716,5.61395981 9.51283584,6 9,6 C8.52661307,6 8.13005271,5.67106635 8.02641071,5.22929083 L8.00672773,5.11662113 L8,5 L8.00509269,4.82372721 C8.08944495,3.3679054 9.21190551,2.19058606 10.6432528,2.02099079 L10.8237272,2.00509269 L11,2 L17,2 Z M14,17 C14.5522847,17 15,17.4477153 15,18 C15,18.5522847 14.5522847,19 14,19 C13.4477153,19 13,18.5522847 13,18 C13,17.4477153 13.4477153,17 14,17 Z M6.61289944,7.20970461 L6.70710678,7.29289322 L10.7071068,11.2928932 C10.7355731,11.3213595 10.7623312,11.3515341 10.787214,11.3832499 L10.7071068,11.2928932 C10.7425008,11.3282873 10.774687,11.3656744 10.8036654,11.4046934 C10.8215099,11.4288693 10.8382813,11.453725 10.8539326,11.4793398 C10.8613931,11.4913869 10.8685012,11.5036056 10.8753288,11.5159379 C10.8862061,11.5357061 10.8966234,11.5561086 10.9063462,11.5769009 C10.914321,11.5939015 10.9218036,11.6112044 10.9287745,11.628664 C10.9366843,11.6484208 10.9438775,11.6682023 10.9504533,11.6882636 C10.9552713,11.7031487 10.9599023,11.7185367 10.9641549,11.734007 C10.9701664,11.7555635 10.9753602,11.7772539 10.9798348,11.7992059 C10.9832978,11.8166247 10.9863719,11.834051 10.9889822,11.8515331 C10.9920328,11.8714753 10.9944666,11.892114 10.9962623,11.912935 C10.9978436,11.9317345 10.9989053,11.9497336 10.9994829,11.9677454 C10.9998183,11.9777892 11,11.9888734 11,12 L10.9994506,12.0332468 C10.9988772,12.050591 10.997855,12.0679231 10.996384,12.0852242 L11,12 C11,12.0506203 10.9962388,12.1003621 10.9889807,12.1489612 C10.9863719,12.165949 10.9832978,12.1833753 10.9797599,12.2007258 C10.9753602,12.2227461 10.9701664,12.2444365 10.964279,12.2658396 C10.9599023,12.2814633 10.9552713,12.2968513 10.9502619,12.3121425 C10.9438775,12.3317977 10.9366843,12.3515792 10.928896,12.3710585 C10.9218036,12.3887956 10.914321,12.4060985 10.9063266,12.4232215 C10.8966234,12.4438914 10.8862061,12.4642939 10.8751242,12.484277 C10.8685012,12.4963944 10.8613931,12.5086131 10.8540045,12.5207088 C10.8382813,12.546275 10.8215099,12.5711307 10.8036865,12.5951593 C10.7992821,12.6012086 10.7948255,12.6070733 10.7902954,12.6128994 C10.7849289,12.6196628 10.7826279,12.6225624 10.7803112,12.625449 L10.7071068,12.7071068 L6.70710678,16.7071068 C6.31658249,17.0976311 5.68341751,17.0976311 5.29289322,16.7071068 C4.93240926,16.3466228 4.90467972,15.7793918 5.20970461,15.3871006 L5.29289322,15.2928932 L7.585,13 L2,13 C1.44771525,13 1,12.5522847 1,12 C1,11.4871642 1.38604019,11.0644928 1.88337887,11.0067277 L2,11 L7.585,11 L5.29289322,8.70710678 C4.93240926,8.34662282 4.90467972,7.77939176 5.20970461,7.38710056 L5.29289322,7.29289322 C5.65337718,6.93240926 6.22060824,6.90467972 6.61289944,7.20970461 Z"
            }), {
                size: 24,
                viewBox: "0 0 24 24"
            }),
            H = Object(o.a)(s.createElement("path", {
                d: "M18,10.6l1.3-1.3c0.4-0.4,1-0.4,1.4,0c0.4,0.4,0.4,1,0,1.4L19.4,12l1.3,1.3c0.4,0.4,0.4,1,0,1.4 c-0.4,0.4-1,0.4-1.4,0L18,13.4l-1.3,1.3c-0.4,0.4-1,0.4-1.4,0c-0.4-0.4-0.4-1,0-1.4l1.3-1.3l-1.3-1.3c-0.4-0.4-0.4-1,0-1.4 c0.4-0.4,1-0.4,1.4,0L18,10.6L18,10.6z M7,8l4.3-3.7C11.9,3.7,13,4.1,13,5v14c0,0.9-1.1,1.3-1.7,0.7L7.2,16H4c-0.6,0-1-0.4-1-1V9 c0-0.6,0.4-1,1-1H7z M11,7.4L8.3,9.7C8.1,9.9,7.9,10,7.6,10H5v4h2.6c0.3,0,0.5,0.1,0.7,0.3l2.7,2.3V7.4z"
            }), {
                size: 24,
                viewBox: "0 0 24 24"
            }),
            G = Object(o.a)(s.createElement("path", {
                d: "M9.1,8H12c0.6,0,1,0.4,1,1c0,0.5-0.4,0.9-0.9,1L12,10H9.1C9.1,10,9,10,9,10.1l0,0v12.8 C9,22.9,9,23,9.1,23l0,0h12.8c0.1,0,0.1,0,0.1-0.1l0,0V20c0-0.6,0.4-1,1-1c0.5,0,0.9,0.4,1,0.9l0,0.1v2.9c0,1.1-0.9,2-2,2.1l-0.2,0 H9.1c-1.1,0-2-0.9-2.1-2l0-0.2V10.1C7,9,7.9,8.1,9,8L9.1,8H12H9.1z M23,8L23,8C23,8,23.1,8,23,8L23,8c0.1,0,0.1,0,0.1,0 c0,0,0,0,0.1,0c0,0,0,0,0.1,0c0,0,0,0,0,0c0,0,0,0,0.1,0c0,0,0,0,0.1,0c0,0,0,0,0.1,0c0,0,0,0,0,0c0,0,0.1,0,0.1,0.1 c0,0,0.1,0.1,0.1,0.1l-0.1-0.1c0.1,0,0.1,0.1,0.2,0.2c0,0,0,0,0,0c0,0,0,0,0.1,0.1c0,0,0,0,0,0c0,0,0,0,0,0.1c0,0,0,0,0,0.1 c0,0,0,0,0,0.1c0,0,0,0,0,0c0,0,0,0,0,0.1c0,0,0,0,0,0.1c0,0,0,0,0,0.1c0,0,0,0,0,0.1c0,0,0,0,0,0v6c0,0.6-0.4,1-1,1s-1-0.4-1-1 l0-3.6l-5.3,5.3c-0.4,0.4-0.9,0.4-1.3,0.1l-0.1-0.1c-0.4-0.4-0.4-1,0-1.4l5.3-5.3H17c-0.6,0-1-0.4-1-1s0.4-1,1-1H23z"
            }), {
                size: 32,
                viewBox: "0 0 32 32"
            }),
            W = Object(o.a)(s.createElement("path", {
                d: "M18.8,16.3C17.9,16.8,17,17,16,17c-1,0-1.9-0.2-2.8-0.7c-3.2,0.8-5.2,2.8-5.2,5c0,0.8,0,0.9,0,2c0,0,0,0,0.1,0\tc0.4,0.1,1,0.3,1.9,0.4c1.6,0.2,3.8,0.3,6.1,0.3s4.5-0.1,6.1-0.3c0.8-0.1,1.4-0.2,1.9-0.4c0,0,0.1,0,0.1,0v-2\tC24,19.2,21.9,17.1,18.8,16.3z M20.6,14.8c3.2,1.2,5.4,3.7,5.4,6.5v2.4c0,1.8-3.7,2.2-10,2.2S6,25.5,6,23.8c0-1.5,0-1.5,0-2.4\tc0-2.9,2.2-5.3,5.4-6.5c-0.9-1-1.4-2.4-1.4-3.8c0-3.3,2.7-6,6-6s6,2.7,6,6C22,12.5,21.5,13.8,20.6,14.8z M16,15c2.2,0,4-1.8,4-4\ts-1.8-4-4-4s-4,1.8-4,4S13.8,15,16,15z"
            }), {
                size: 32,
                viewBox: "0 0 32 32"
            }),
            Y = Object(v.z)("path", {
                target: "e7kg0vt0"
            })("fill-rule:nonzero;fill:", (function(e) {
                return e.theme.colors.text.muted
            }), ";"),
            K = Object(o.a)(s.createElement(Y, {
                d: "M7,10.75 L7,8.5 C7,7.675 7.675,7 8.5,7 L10.75,7 C11.1642136,7 11.5,6.66421356 11.5,6.25 L11.5,5.5 C11.5,4.67157288 12.1715729,4 13,4 C13.8284271,4 14.5,4.67157288 14.5,5.5 L14.5,6.25 C14.5,6.66421356 14.8357864,7 15.25,7 L17.5,7 C18.3284271,7 19,7.67157288 19,8.5 L19,10.75 C19,11.1642136 18.6642136,11.5 18.25,11.5 L17.5,11.5 C16.6715729,11.5 16,12.1715729 16,13 C16,13.8284271 16.6715729,14.5 17.5,14.5 L18.25,14.5 C18.6642136,14.5 19,14.8357864 19,15.25 L19,17.5 C19,18.3284271 18.3284271,19 17.5,19 L15.25,19 C14.8357864,19 14.5,18.6642136 14.5,18.25 L14.5,17.5 C14.5,16.6715729 13.8284271,16 13,16 C12.1715729,16 11.5,16.6715729 11.5,17.5 L11.5,18.25 C11.5,18.6642136 11.1642136,19 10.75,19 L8.5,19 C7.67157288,19 7,18.3284271 7,17.5 L7,15.25 C7,14.8357864 6.66421356,14.5 6.25,14.5 L5.5,14.5 C4.67157288,14.5 4,13.8284271 4,13 C4,12.1715729 4.67157288,11.5 5.5,11.5 L6.25,11.5 C6.66421356,11.5 7,11.1642136 7,10.75 Z M19,15.25 L19,17.5 C19,18.3284271 18.3284271,19 17.5,19 L15.25,19 C14.8357864,19 14.5,18.6642136 14.5,18.25 L14.5,17.5 C14.5,16.6715729 13.8284271,16 13,16 C12.1715729,16 11.5,16.6715729 11.5,17.5 L11.5,18.25 C11.5,18.6642136 11.1642136,19 10.75,19 L8.5,19 C7.67157288,19 7,18.3284271 7,17.5 L7,15.25 C7,14.8357864 6.66421356,14.5 6.25,14.5 L5.5,14.5 C4.67157288,14.5 4,13.8284271 4,13 C4,12.1715729 4.67157288,11.5 5.5,11.5 L6.25,11.5 C6.66421356,11.5 7,11.1642136 7,10.75 L7,10.3 C7.405,10.12 7.885,10 8.4775,10 C11.4775,10 11.4775,13 14.4925,13 C15.1225,13 15.6175,12.865 16.0375,12.6625 C15.9346018,13.1080984 16.0406047,13.576297 16.3254017,13.934119 C16.6101988,14.291941 17.0426753,14.5002933 17.5,14.5 L18.25,14.5 C18.6642136,14.5 19,14.8357864 19,15.25 Z"
            }), {
                size: 24,
                viewBox: "0 0 24 24"
            }),
            Z = Object(o.a)(s.createElement("path", {
                d: "M16.9,9c0.6,0,1,0.4,1,1l0,0.1l-0.8,9c0,0.5-0.5,0.9-1,0.9H7.9c-0.5,0-1-0.4-1-0.9l-0.8-9 C6,9.5,6.5,9,7,9l0,0L16.9,9z M14,3c0.6,0,0.9,0.5,1,1l0,1h3c0.5,0,0.9,0.4,1,0.9L19,6c0,0.5-0.4,0.9-0.9,1L18,7H6C5.4,7,5,6.6,5,6 c0-0.5,0.4-0.9,0.9-1L6,5h3l0-1c0-0.6,0.2-0.9,0.8-1l0.1,0L14,3z"
            }), {
                size: 24,
                viewBox: "0 0 24 24"
            }),
            J = Object(o.a)(s.createElement("path", {
                d: "M19,18.5c1.2-1.3,2-3.1,2-5.1c0-4.1-3.3-7.5-7.5-7.5S6,9.3,6,13.5s3.3,7.5,7.5,7.5c1.4,0,2.8-0.4,3.9-1.1 l5.9,5.9c0.4,0.4,1,0.4,1.4,0s0.4-1,0-1.4L19,18.5L19,18.5z M13.5,18.9c-3,0-5.5-2.5-5.5-5.5S10.4,8,13.5,8s5.5,2.5,5.5,5.5 S16.5,18.9,13.5,18.9z"
            }), {
                size: 32,
                viewBox: "0 0 32 32"
            }),
            X = Object(o.a)(s.createElement("path", {
                d: "M6.4,5.6l21,9.5c0.5,0.2,0.7,0.8,0.5,1.3c-0.1,0.2-0.3,0.4-0.5,0.5l-21,9.5\tc-0.5,0.2-1.1,0-1.3-0.5c-0.1-0.3-0.1-0.6,0-0.8L8.6,18L20.5,16L8.6,14.1L5.1,6.9c-0.2-0.5,0-1.1,0.5-1.3C5.8,5.5,6.1,5.5,6.4,5.6z"
            }), {
                size: 32,
                viewBox: "0 0 32 32"
            }),
            Q = Object(o.a)(s.createElement("path", {
                d: "M16.5,21.1l-6.3,3.8C9,25.5,7.6,24.3,8.1,23l2.2-5.7l-3.8-3.7c-1-0.9-0.4-2.6,1-2.6h5.3l2.3-5.1 c0.5-1.2,2.2-1.2,2.8,0l2.3,5.1h5.4c1.4,0,2,1.7,1,2.6l-3.9,3.7l2.2,5.7c0.5,1.3-0.9,2.5-2.2,1.8L16.5,21.1z M10.5,22.3l5.3-3.1l0,0 c0.4-0.2,1-0.2,1.5,0l5.3,3.1l-1.8-4.7c-0.2-0.6,0-1.2,0.4-1.6l3.2-3h-4.4c-0.6,0-1.1-0.4-1.4-0.9l-2-4.4l-2,4.4 c-0.2,0.6-0.8,0.9-1.4,0.9H8.8l3.1,3c0.4,0.4,0.6,1,0.4,1.6L10.5,22.3z"
            }), {
                size: 32,
                viewBox: "0 0 32 32"
            }),
            $ = Object(o.a)(s.createElement("path", {
                d: "M20,19H18.56c-.35.5-.91,1.35-1.64,2.53a3.75,3.75,0,0,0-.24.44,6.74,6.74,0,0,0-.52,2.42C16,26.18,15.49,27,14,27c-1.66,0-2.74-1.2-3-3V19H8c-3,0-3.64-2.26-2.4-6.65S7.58,7,11,7h6a1.11,1.11,0,0,1,.75.3L19.48,9H20V9a1,1,0,0,1,1-1h4a1,1,0,0,1,1,1V19a1,1,0,0,1-1,1H21a1,1,0,0,1-1-1Zm0-2V11h-.94a1,1,0,0,1-.71-.3L16.65,9H11c-2.38,0-2.45.15-3.51,3.9C6.58,16.21,6.75,17,8,17h4a1,1,0,0,1,1,1v5.92c.12.81.46,1.07,1,1.08a4.54,4.54,0,0,0,.12-.81,8.39,8.39,0,0,1,.69-3.06q.17-.33.36-.66a34.1,34.1,0,0,1,2.07-3.11,1,1,0,0,1,.76-.36Zm4,1V10H22v8Z"
            }), {
                size: 32,
                viewBox: "0 0 32 32"
            }),
            ee = Object(o.a)(s.createElement("path", {
                d: "M11,14h1.47c.35-.5.9-1.35,1.64-2.53a3.68,3.68,0,0,0,.23-.44,6.34,6.34,0,0,0,.52-2.42C15.05,6.82,15.51,6,17,6c1.66,0,2.65,1.06,2.92,2.86V14h3c3,0,3.76,2.26,2.51,6.65S23.35,26,19.93,26H14a1,1,0,0,1-.71-.3L11.55,24H11v0a1,1,0,0,1-1,1H6a1,1,0,0,1-1-1V14a1,1,0,0,1,1-1h4a1,1,0,0,1,1,1Zm0,2v6h1a1,1,0,0,1,.7.3L14.37,24H20c2.37,0,2.44-.15,3.51-3.9.94-3.31.68-4.1-.6-4.1h-4A1,1,0,0,1,18,15V9.08C17.87,8.27,17.54,8,17,8a5.27,5.27,0,0,0-.13.81,8.19,8.19,0,0,1-.69,3.06,5.37,5.37,0,0,1-.36.66,34.81,34.81,0,0,1-2.06,3.11A1,1,0,0,1,13,16ZM7,15v8H9V15Z"
            }), {
                size: 32,
                viewBox: "0 0 32 32"
            }),
            te = Object(o.a)(s.createElement("path", {
                d: "M8.7,15.2c-0.4-0.4-1-0.4-1.4,0c-0.4,0.4-0.4,1,0,1.4l5.7,5.7c0.4,0.4,1,0.4,1.4,0l9.9-9.9 c0.4-0.4,0.4-1,0-1.4c-0.4-0.4-1-0.4-1.4,0l-9.2,9.2L8.7,15.2z"
            }), {
                size: 32,
                viewBox: "0 0 32 32"
            }),
            ne = Object(o.a)(s.createElement("path", {
                d: "M15,19v-2c2.8,0,5-2.2,5-5s-2.2-5-5-5V5c3.9,0,7,3.1,7,7S18.9,19,15,19z M15,16v-2c1.1,0,2-0.9,2-2s-0.9-2-2-2 V8c2.2,0,4,1.8,4,4S17.2,16,15,16z M7,8l4.3-3.7C11.9,3.7,13,4.1,13,5v14c0,0.9-1.1,1.3-1.7,0.7L7.2,16H4c-0.6,0-1-0.4-1-1V9 c0-0.6,0.4-1,1-1H7z M11,7.4L8.3,9.7C8.1,9.9,7.9,10,7.6,10H5v4h2.6c0.3,0,0.5,0.1,0.7,0.3l2.7,2.3V7.4z"
            }), {
                size: 24,
                viewBox: "0 0 24 24"
            }),
            re = Object(o.a)(s.createElement("path", {
                d: "M20,7 C21.5976809,7 22.9036609,8.24891996 22.9949073,9.82372721 L23,10 L23,13.928 L27.292478,9.63704135 C27.8950531,9.03446626 28.9067656,9.41648044 28.9936015,10.2305172 L28.9995848,10.3441481 L28.9995848,21.6578566 C28.9995848,22.5100265 28.0140712,22.9552904 27.377058,22.4410818 L27.292478,22.3649634 L23,18.073 L23,22 C23,23.5976809 21.75108,24.9036609 20.1762728,24.9949073 L20,25 L6,25 C4.40231912,25 3.09633912,23.75108 3.00509269,22.1762728 L3,22 L3,10 C3,8.40231912 4.24891996,7.09633912 5.82372721,7.00509269 L6,7 L20,7 Z M20,9 L6,9 C5.48716416,9 5.06449284,9.38604019 5.00672773,9.88337887 L5,10 L5,22 C5,22.5128358 5.38604019,22.9355072 5.88337887,22.9932723 L6,23 L20,23 C20.5128358,23 20.9355072,22.6139598 20.9932723,22.1166211 L21,22 L21,10 C21,9.48716416 20.6139598,9.06449284 20.1166211,9.00672773 L20,9 Z M13,11 C14.6568542,11 16,12.3431458 16,14 C16,14.5467286 15.8537493,15.0592984 15.5982359,15.5007215 C16.9548251,16.0711623 17.9059057,17.090655 17.9934086,18.3542924 L18,18.5456435 L18,19.5002598 C18,20.6194095 17.0786223,20.9135858 14.6819503,20.981557 L13.8901786,20.9960521 L13,21 L12.1098214,20.9960521 C9.21524131,20.9665724 8.07193908,20.7493906 8.00330943,19.6131156 L8,19.5002598 L8,18.5456435 C8,17.1937269 8.97734547,16.0996844 10.4021695,15.5004954 C10.1462507,15.0592984 10,14.5467286 10,14 C10,12.3431458 11.3431458,11 13,11 Z M26.9983216,12.7596249 L23.7569441,16.0010024 L26.9983216,19.2423799 L26.9983216,12.7596249 Z M13,17 C11.3462727,17 10.1069811,17.7448466 10.0065778,18.4534823 L10,18.5456435 L10,18.833 L10.1239193,18.8521038 L10.3603748,18.8811749 C11.0486755,18.957613 12.0028781,19 13,19 C13.9971219,19 14.9513245,18.957613 15.6396252,18.8811749 L15.8006868,18.8620278 L15.8006868,18.8620278 L16,18.833 L16,18.5456435 C16,17.8722422 14.9291739,17.1346401 13.4215296,17.0163828 L13.2132937,17.0041599 L13,17 Z M13,13 C12.4477153,13 12,13.4477153 12,14 C12,14.5522847 12.4477153,15 13,15 C13.5522847,15 14,14.5522847 14,14 C14,13.4477153 13.5522847,13 13,13 Z"
            }), {
                size: 32,
                viewBox: "0 0 32 32"
            })
    }, , function(e, t, n) {
        "use strict";
        n.d(t, "c", (function() {
            return r
        })), n.d(t, "b", (function() {
            return i
        })), n.d(t, "a", (function() {
            return o
        })), n.d(t, "d", (function() {
            return a
        }));
        var r = "bb9e5b2f1ab480e4a715977b7b1b4279",
            i = "feade1d6c3f17748ae4c8d917a1e1068",
            o = "a9f288b2883da20306d30e179067406f",
            a = "632cead4b282481a422dd4e1d1567449"
    }, , , , , , , , , , function(e, t, n) {
        "use strict";
        var r = n(78);
        t.a = Object(r.b)() ? window.localStorage : r.a
    }, , function(e, t, n) {
        "use strict";
        n.d(t, "a", (function() {
            return b
        })), n.d(t, "d", (function() {
            return h
        })), n.d(t, "b", (function() {
            return g
        })), n.d(t, "c", (function() {
            return y
        }));
        var r = n(8),
            i = n(1),
            o = n(47),
            a = n(2),
            c = n(14),
            u = n(13),
            s = {};
        var d = function(e, t) {
                var n = void 0 === t ? {} : t,
                    r = n.query,
                    o = void 0 === r ? {} : r,
                    d = n.jsonpParam,
                    l = void 0 === d ? "jsonp" : d,
                    f = n.callbackName;
                return new Promise((function(t, n) {
                    Object(c.h)().then((function(r) {
                        var d, p = document.createElement("script"),
                            m = f || Object(a.w)(s);
                        s[m] = !0;
                        var v = "__" + m;
                        window[v] = function(e) {
                            delete s[m], delete window[v], Object(c.k)(p), t(e)
                        }, p.src = e + "?" + Object(u.a)(Object(i.a)({}, o, ((d = {})[l] = v, d))), p.addEventListener("error", (function() {
                            setTimeout((function() {
                                return n(new Error("JSONP request failed."))
                            }), 100)
                        })), r.appendChild(p)
                    }))
                }))
            },
            l = n(95),
            f = function(e) {
                var t = Object(u.l)(e);
                return "https://" + (!Object(a.D)("cdn.livechatinc.com/cloud/?uri", t) && !Object(a.D)(".livechat-static.com/", t) ? "cdn.livechatinc.com/cloud/?" + Object(u.a)({
                    uri: "https://" + t
                }) : t)
            },
            p = /\.([a-z]{1,})$/i,
            m = function(e) {
                var t = e.__priv,
                    n = {
                        enabled: !0,
                        x: parseInt(t.group["embedded_chat.eye_grabber.x"]) + 15,
                        y: parseInt(t.group["embedded_chat.eye_grabber.y"]),
                        src: f(t.group["embedded_chat.eye_grabber.path"])
                    };
                if (-1 !== n.src.indexOf("/default/eyeCatchers/")) {
                    var r = n.src.match(p)[1];
                    n.srcset = {
                        "1x": n.src,
                        "2x": n.src.replace(new RegExp("\\." + r, "i"), "-2x." + r)
                    }
                }
                return n
            },
            v = function(e, t) {
                return function(e) {
                    var t = e.licenseId,
                        n = e.region;
                    return "https://api" + (n ? "-" + n : "") + function(e) {
                        return 1520 === e ? ".staging" : ""
                    }(t) + ".livechatinc.com"
                }(t) + "/v3.3/customer/action/" + e
            },
            b = function e(t) {
                var n = v("get_dynamic_configuration", t);
                return d(n, {
                    query: Object(i.a)({
                        license_id: t.licenseId,
                        url: t.url
                    }, "number" === typeof t.groupId && {
                        group_id: t.groupId
                    }, t.channelType && {
                        channel_type: t.channelType
                    }, t.skipCodeInstallationTracking && {
                        test: 1
                    })
                }).then((function(n) {
                    if (n.error) switch (n.error.type) {
                        case "misdirected_request":
                            return e(Object(i.a)({}, t, {
                                region: n.error.data.region
                            }));
                        default:
                            var r = new Error(n.error.message);
                            throw r.code = n.error.type.toUpperCase(), r
                    }
                    if (!n.domain_allowed) {
                        var o = new Error("Current domain is not added to the allowlist.");
                        throw o.code = "DOMAIN_NOT_ALLOWED", o
                    }
                    return {
                        groupId: n.group_id,
                        clientLimitExceeded: n.client_limit_exceeded,
                        configVersion: n.config_version,
                        localizationVersion: n.localization_version,
                        onlineGroupIds: n.online_group_ids || [],
                        region: t.region || null
                    }
                }))
            },
            h = function(e) {
                var t = v("get_configuration", e);
                return d(t, {
                    callbackName: "lc_static_config",
                    query: Object(i.a)({
                        license_id: e.licenseId,
                        version: e.version
                    }, "number" === typeof e.groupId && {
                        group_id: e.groupId
                    })
                }).then((function(e) {
                    var t = e.buttons,
                        n = e.allowed_domains,
                        o = e.prechat_form,
                        a = e.ticket_form,
                        c = e.__priv,
                        u = Object(r.a)(e, ["buttons", "allowed_domains", "prechat_form", "ticket_form", "__priv"]);
                    return Object(i.a)({}, u, o && {
                        prechatForm: Object(l.b)(o)
                    }, a && {
                        ticketForm: Object(l.b)(a)
                    }, {
                        buttons: t.map((function(e) {
                            return "image" === e.type ? {
                                id: e.id,
                                type: e.type,
                                onlineValue: f(e.online_value),
                                offlineValue: f(e.offline_value)
                            } : {
                                id: e.id,
                                type: e.type,
                                onlineValue: e.online_value,
                                offlineValue: e.offline_value
                            }
                        }))
                    }, n && {
                        allowedDomains: n
                    }, {
                        __unsafeProperties: Object(i.a)({}, c.s && {
                            s: !0
                        }, {
                            group: {
                                chatBoosters: c.group.chat_boosters,
                                disabledMinimized: "1" === c.group["chat_window.disable_minimized"],
                                disabledMinimizedOnMobile: "1" === c.group["chat_window.mobile_disable_minimized"],
                                disabledOnMobile: "1" === c.group["chat_window.hide_on_mobile"],
                                eyeCatcher: "1" === c.group["embedded_chat.display_eye_catcher"] ? m(e) : {
                                    enabled: !1
                                },
                                hasAgentAvatarsEnabled: "1" === c.group["chat_window.display_avatar"],
                                hasCustomMobileSettings: "1" === c.group["chat_window.custom_mobile_settings"],
                                hasHiddenTrademark: "1" === c.group["chat_window.hide_trademark"],
                                hasSoundsEnabled: "0" === c.group["chat_window.disable_sounds"],
                                initiallyHidden: "1" === c.group["chat_window.hide_on_init"] || "1" === c.group["chat_window.disable_minimized"],
                                initiallyHiddenOnMobile: "1" === c.group["chat_window.mobile_hide_on_init"] || "1" === c.group["chat_window.mobile_disable_minimized"],
                                language: c.group.language,
                                linksUnfurlingEnabled: "1" === c.group.links_unfurling,
                                logo: "1" === c.group["chat_window.display_logo"] ? {
                                    enabled: !0,
                                    src: c.group["chat_window.logo_path"]
                                } : {
                                    enabled: !1
                                },
                                minimizedType: c.group["chat_window.theme.minimized"],
                                minimizedTypeOnMobile: c.group["chat_window.mobile_minimized_theme"],
                                offlineMessagesEnabled: "0" === c.group.tickets_enabled,
                                offsetX: parseInt(c.group["chat_window.offset_x"]),
                                offsetXOnMobile: parseInt(c.group["chat_window.mobile_offset_x"]),
                                offsetY: parseInt(c.group["chat_window.offset_y"]),
                                offsetYOnMobile: parseInt(c.group["chat_window.mobile_offset_y"]),
                                prechatFormAfterGreetingEnabled: "1" === c.group.pre_chat_survey_after_greeting,
                                ratingEnabled: "1" === c.group["rate_me.enabled"],
                                screenPosition: c.group["chat_window.screen_position"],
                                screenPositionOnMobile: c.group["chat_window.mobile_screen_position"],
                                transcriptButtonEnabled: "1" === c.group["chat_window.display_transcript_button"],
                                theme: {
                                    name: c.group["chat_window.new_theme.name"],
                                    customJson: c.group["chat_window.new_theme.custom_json"],
                                    agentbarBackgroundColor: c.group["chat_window.new_theme.agentbar_background_color"],
                                    agentbarText: c.group["chat_window.new_theme.agentbar_text"],
                                    agentMessageColorBackground: c.group["chat_window.new_theme.agent_message_color_background"],
                                    agentMessageColorText: c.group["chat_window.new_theme.agent_message_color_text"],
                                    backgroundColor: c.group["chat_window.new_theme.background_color"],
                                    ctaColor: c.group["chat_window.new_theme.cta_color"],
                                    minimizedColorBackground: c.group["chat_window.new_theme.minimized_color_background"],
                                    minimizedColorIcon: c.group["chat_window.new_theme.minimized_color_icon"],
                                    minimizedColorText: c.group["chat_window.new_theme.minimized_color_text"],
                                    systemMessageColor: c.group["chat_window.new_theme.system_message_color"],
                                    titlebarBackgroundColor: c.group["chat_window.new_theme.titlebar_background_color"],
                                    titlebarText: c.group["chat_window.new_theme.titlebar_text"],
                                    visitorMessageColorBackground: c.group["chat_window.new_theme.visitor_message_color_background"],
                                    visitorMessageColorText: c.group["chat_window.new_theme.visitor_message_color_text"]
                                }
                            },
                            license: {
                                continuousChatWidgetEnabled: "1" === c.license.continuous_chat_widget_enabled,
                                creditCardMaskingEnabled: "1" === c.license.mask_credit_cards,
                                customerHistoryEnabled: "1" === c.license.customer_history_enabled,
                                fileSharingEnabled: "1" === c.license["attachments.enable_for_visitors"],
                                inboundForwardingToHelpdeskEnabled: "1" === c.license["helpdesk.inbound_forwarding"],
                                nonProfit: "1" === c.license.non_profit
                            }
                        })
                    })
                }))
            },
            g = function(e) {
                var t = v("get_localization", e);
                return d(t, {
                    callbackName: "lc_localization",
                    query: Object(i.a)({
                        license_id: e.licenseId,
                        version: e.version,
                        language: e.language
                    }, "number" === typeof e.groupId && {
                        group_id: e.groupId
                    })
                }).then((function(e) {
                    return Object(a.O)((function(e) {
                        return e.toLowerCase()
                    }), e)
                }))
            },
            y = function(e) {
                var t = v("get_localization", e);
                return Object(o.a)(t + "?" + Object(u.a)(Object(i.a)({
                    license_id: e.licenseId,
                    version: e.version,
                    language: e.language
                }, "number" === typeof e.groupId && {
                    group_id: e.groupId
                }))).then((function(e) {
                    return e.json()
                })).then((function(e) {
                    return Object(a.O)((function(e) {
                        return e.toLowerCase()
                    }), e)
                }))
            }
    }, , , , function(e, t, n) {
        "use strict";
        t.a = function(e) {
            var t = e.min,
                n = void 0 === t ? 1e3 : t,
                r = e.max,
                i = void 0 === r ? 5e3 : r,
                o = e.jitter,
                a = void 0 === o ? .5 : o,
                c = 0;
            return {
                duration: function() {
                    var e = n * Math.pow(2, c++);
                    if (a) {
                        var t = Math.random(),
                            r = Math.floor(t * a * e);
                        e = 0 === (1 & Math.floor(10 * t)) ? e - r : e + r
                    }
                    return 0 | Math.min(e, i)
                },
                reset: function() {
                    c = 0
                }
            }
        }
    }, , function(e, t, n) {
        var r = n(267)("wks"),
            i = n(202),
            o = n(112).Symbol,
            a = "function" == typeof o;
        (e.exports = function(e) {
            return r[e] || (r[e] = a && o[e] || (a ? o : i)("Symbol." + e))
        }).store = r
    }, , , , function(e, t, n) {
        "use strict";
        t.a = function(e) {
            return new Promise((function(t) {
                t(e())
            }))
        }
    }, , , function(e, t, n) {
        "use strict";
        n.d(t, "b", (function() {
            return i
        })), n.d(t, "c", (function() {
            return u
        }));
        var r = n(2),
            i = function() {
                return Object(r.x)("webkit.messageHandlers.iosMobileWidget.postMessage", window) ? "ios" : !!Object(r.x)("androidMobileWidget.postMessage", window) && "android"
            },
            o = function(e) {
                return window.androidMobileWidget.postMessage(JSON.stringify(e))
            },
            a = function(e) {
                return window.webkit.messageHandlers.iosMobileWidget.postMessage(e)
            },
            c = function() {
                var e = i();
                return "android" === e ? o : "ios" === e ? a : null
            }(),
            u = function() {
                return Boolean(i())
            };
        t.a = function(e) {
            c && (c({
                messageType: "uiReady"
            }), e.on("add_event", (function(t) {
                var n = t.event;
                if ("message" === n.type) {
                    var r = e.getUser(n.author).name;
                    c({
                        messageType: "newMessage",
                        text: n.properties.text,
                        id: n.id,
                        timestamp: n.timestamp,
                        author: {
                            name: r
                        }
                    })
                }
            })), e.on("mobile_wrapper_minimize_intent", (function() {
                c({
                    messageType: "hideChatWindow"
                })
            })))
        }
    }, function(e, t, n) {
        "use strict";
        var r = n(1),
            i = n(2),
            o = n(23),
            a = n(18);
        t.a = function(e) {
            var t = e.customJson || {},
                n = Object(a.g)(e.titlebarBackgroundColor) ? "rgba(255, 255, 255, 0.3)" : "rgba(0, 0, 0, 0.05)",
                c = Object(a.g)(e.agentbarBackgroundColor) ? "rgba(255, 255, 255, 0.3)" : "rgba(0, 0, 0, 0.05)",
                u = Object(a.g)(e.agentbarBackgroundColor) ? "rgba(255, 255, 255, 0.3)" : "rgba(0, 0, 0, 0.1)",
                s = Object(a.h)(e.ctaColor) ? o.c.text.black : o.c.text.white;
            return Object(i.T)({
                name: e.name,
                iconTheme: e.name,
                showMessageAvatar: "modern" !== e.name,
                colors: {
                    agentBarText: e.agentbarText,
                    agentBarBackground: e.agentbarBackgroundColor,
                    cta: e.ctaColor,
                    ctaText: s,
                    minimizedIcon: e.minimizedColorIcon,
                    minimizedBackground: e.minimizedColorBackground,
                    background: e.backgroundColor,
                    visitorMessageText: e.visitorMessageColorText,
                    visitorMessageBackground: e.visitorMessageColorBackground,
                    systemMessage: e.systemMessageColor,
                    agentMessageBackground: e.agentMessageColorBackground,
                    agentMessageText: e.agentMessageColorText,
                    minimizedText: e.minimizedColorText,
                    titleBarText: e.titlebarText,
                    titleBarBackgroundColor: e.titlebarBackgroundColor
                },
                AgentBar: {
                    css: {
                        background: e.agentbarBackgroundColor,
                        color: e.agentbarText
                    },
                    IconButton: {
                        css: {
                            background: {
                                default: c,
                                active: e.ctaColor
                            },
                            color: Object(r.a)({
                                default: "inherit"
                            }, "modern" !== e.name && {
                                active: s
                            })
                        }
                    }
                },
                Form: {
                    IconButton: {
                        css: {
                            background: {
                                default: "rgba(0, 0, 0, 0.05)",
                                active: e.ctaColor
                            },
                            color: {
                                default: "#8f8f8f",
                                active: s
                            }
                        }
                    }
                },
                ChatSummary: {
                    Icon: {
                        color: e.minimizedColorIcon
                    }
                },
                Divider: {
                    css: {
                        borderColor: c
                    }
                },
                Maximized: {
                    css: {
                        background: e.backgroundColor
                    }
                },
                Message: {
                    own: {
                        Bubble: {
                            css: {
                                background: "modern" === e.name ? "transparent" : e.visitorMessageColorBackground,
                                color: e.visitorMessageColorText
                            }
                        }
                    },
                    system: {
                        Bubble: {
                            css: {
                                color: e.systemMessageColor
                            }
                        }
                    },
                    Bubble: {
                        css: {
                            background: "modern" === e.name ? "transparent" : e.agentMessageColorBackground,
                            color: e.agentMessageColorText
                        }
                    },
                    css: {
                        color: e.systemMessageColor
                    }
                },
                TypingIndicator: {
                    css: {
                        color: e.systemMessageColor
                    }
                },
                Minimized: {
                    MinimizedBubble: {
                        css: {
                            color: e.minimizedColorText,
                            backgroundColor: {
                                default: e.minimizedColorBackground,
                                hasAvatar: "transparent"
                            }
                        },
                        Icon: {
                            color: e.minimizedColorIcon
                        }
                    },
                    MinimizedBar: {
                        css: {
                            color: e.minimizedColorText,
                            backgroundColor: e.minimizedColorBackground
                        },
                        Icon: {
                            color: e.minimizedColorIcon
                        }
                    }
                },
                TitleBar: {
                    css: {
                        color: e.titlebarText,
                        backgroundColor: e.titlebarBackgroundColor
                    },
                    HourGlassLabel: {
                        css: {
                            backgroundColor: n
                        }
                    }
                },
                DividerLabel: {
                    css: {
                        color: e.systemMessageColor,
                        borderColor: u
                    }
                },
                TextComposer: {
                    IconButton: {
                        active: {
                            Icon: {
                                color: e.ctaColor
                            }
                        }
                    }
                }
            }, t)
        }
    }, function(e, t, n) {
        "use strict";
        n.d(t, "a", (function() {
            return i
        })), n.d(t, "b", (function() {
            return o
        })), n.d(t, "c", (function() {
            return a
        }));
        var r = n(2),
            i = function(e) {
                var t = e.license,
                    n = e.group;
                return t + (e.uniqueGroups ? ":" + n : "") + ":state"
            },
            o = function(e) {
                return Object(r.D)(e, ["ar", "he", "fa"])
            },
            a = function(e) {
                document.documentElement.lang = e
            }
    }, function(e, t, n) {
        "use strict";
        n.d(t, "c", (function() {
            return en
        })), n.d(t, "b", (function() {
            return Xn
        })), n.d(t, "a", (function() {
            return yr
        }));
        var r = {};
        n.r(r), n.d(r, "CHAT_DEACTIVATED", (function() {
            return Ye
        })), n.d(r, "CHAT_PROPERTIES_DELETED", (function() {
            return Ke
        })), n.d(r, "CHAT_PROPERTIES_UPDATED", (function() {
            return Ze
        })), n.d(r, "CHAT_TRANSFERRED", (function() {
            return Je
        })), n.d(r, "CUSTOMER_DISCONNECTED", (function() {
            return Xe
        })), n.d(r, "CUSTOMER_PAGE_UPDATED", (function() {
            return Qe
        })), n.d(r, "CUSTOMER_SIDE_STORAGE_UPDATED", (function() {
            return $e
        })), n.d(r, "CUSTOMER_UPDATED", (function() {
            return et
        })), n.d(r, "EVENT_PROPERTIES_DELETED", (function() {
            return tt
        })), n.d(r, "EVENT_PROPERTIES_UPDATED", (function() {
            return nt
        })), n.d(r, "EVENT_UPDATED", (function() {
            return rt
        })), n.d(r, "EVENTS_MARKED_AS_SEEN", (function() {
            return it
        })), n.d(r, "GREETING_ACCEPTED", (function() {
            return ot
        })), n.d(r, "GREETING_CANCELED", (function() {
            return at
        })), n.d(r, "INCOMING_CHAT", (function() {
            return ct
        })), n.d(r, "INCOMING_EVENT", (function() {
            return ut
        })), n.d(r, "INCOMING_GREETING", (function() {
            return st
        })), n.d(r, "INCOMING_MULTICAST", (function() {
            return dt
        })), n.d(r, "INCOMING_RICH_MESSAGE_POSTBACK", (function() {
            return lt
        })), n.d(r, "INCOMING_TYPING_INDICATOR", (function() {
            return ft
        })), n.d(r, "QUEUE_POSITION_UPDATED", (function() {
            return pt
        })), n.d(r, "THREAD_PROPERTIES_DELETED", (function() {
            return mt
        })), n.d(r, "THREAD_PROPERTIES_UPDATED", (function() {
            return vt
        })), n.d(r, "USER_ADDED_TO_CHAT", (function() {
            return bt
        })), n.d(r, "USER_REMOVED_FROM_CHAT", (function() {
            return ht
        }));
        var i = {};
        n.r(i), n.d(i, "CONNECTING", (function() {
            return _n
        })), n.d(i, "OPEN", (function() {
            return wn
        })), n.d(i, "CLOSED", (function() {
            return xn
        }));
        var o = n(1),
            a = n(8),
            c = n(78),
            u = Object(c.b)() ? window.localStorage : c.a,
            s = {
                setItem: function(e, t) {
                    return new Promise((function(n) {
                        return n(u.setItem(e, t))
                    }))
                },
                getItem: function(e) {
                    return new Promise((function(t) {
                        return t(u.getItem(e))
                    }))
                },
                removeItem: function(e) {
                    return new Promise((function(t) {
                        return t(u.removeItem(e))
                    }))
                }
            },
            d = n(2),
            l = n(13),
            f = n(47),
            p = n(14),
            m = function(e) {
                var t = e.code,
                    n = e.message,
                    r = new Error(n);
                return r.code = t, r
            },
            v = function(e, t) {
                if ("identity_exception" in e) throw m({
                    code: "SSO_IDENTITY_EXCEPTION",
                    message: e.identity_exception
                });
                if ("oauth_exception" in e) throw m({
                    code: "SSO_OAUTH_EXCEPTION",
                    message: e.oauth_exception
                });
                return {
                    accessToken: e.access_token,
                    entityId: e.entity_id,
                    expiresIn: 1e3 * e.expires_in,
                    tokenType: e.token_type,
                    creationDate: Date.now(),
                    licenseId: t
                }
            },
            b = "https://accounts.livechatinc.com",
            h = function(e, t) {
                return "" + ("production" === t ? b : b.replace("accounts.", "accounts." + t + ".")) + function(e) {
                    var t = e.uniqueGroups,
                        n = e.licenseId,
                        r = e.groupId;
                    return (t ? "/licence/g" + n + "_" + r : "") + "/customer"
                }(e)
            },
            g = "https://accounts.livechatinc.com",
            y = "@livechat/customer-auth",
            O = function(e, t) {
                var n = function(e, t) {
                        var n = e.clientId,
                            r = e.licenseId;
                        return {
                            license_id: String(r),
                            flow: "button",
                            response_type: "token",
                            client_id: n,
                            redirect_uri: t,
                            post_message_uri: t,
                            state: y
                        }
                    }(e, Object(l.e)(String(window.location)) + window.location.pathname),
                    r = document.createElement("iframe");
                return r.style.display = "none", r.setAttribute("src", h(e, t) + "?" + Object(l.a)(n)), r
            };

        function j(e, t) {
            var n = e.licenseId,
                r = function(e) {
                    return "production" === e ? g : g.replace("accounts.", "accounts." + e + ".")
                }(t);
            return new Promise((function(i, o) {
                var a = O(e, t),
                    c = function() {
                        Object(p.k)(a), window.removeEventListener("message", s, !1)
                    },
                    u = setTimeout((function() {
                        c(), o(m({
                            message: "Request timed out.",
                            code: "REQUEST_TIMEOUT"
                        }))
                    }), 15e3),
                    s = function(e) {
                        var t = e.origin,
                            a = e.data;
                        if (t === r && function(e) {
                                return e && e.state === y
                            }(a)) {
                            clearTimeout(u), c();
                            try {
                                i(v(a, n))
                            } catch (s) {
                                o(s)
                            }
                        }
                    };
                window.addEventListener("message", s, !1), Object(p.h)().then((function(e) {
                    e.appendChild(a)
                }))
            }))
        }
        var _ = function(e, t) {
                return e.uniqueGroups ? j(e, t) : Object(f.a)(h(e, t) + "/token", {
                    method: "POST",
                    credentials: "include",
                    body: JSON.stringify({
                        response_type: "token",
                        grant_type: "cookie",
                        client_id: e.clientId,
                        license_id: e.licenseId,
                        redirect_uri: Object(l.e)(String(window.location)) + window.location.pathname
                    })
                }).then((function(e) {
                    return e.json()
                })).then((function(t) {
                    return v(t, e.licenseId)
                }))
            },
            w = (d.V, function(e) {
                var t = e.licenseId,
                    n = e.clientId;
                if ("number" !== typeof t || "string" !== typeof n) throw new Error("You need to pass valid configuration object: { licenseId, clientId }.")
            }),
            x = function(e, t) {
                w(e);
                var n = "@@lc_auth_token:" + e.licenseId + (e.uniqueGroups ? ":" + e.groupId : ""),
                    r = null,
                    i = null,
                    o = s.getItem(n).then((function(e) {
                        null !== o && (o = null, e && (i = JSON.parse(e)))
                    })),
                    a = function() {
                        return r = _(e, t).then((function(e) {
                            return r = null, s.setItem(n, JSON.stringify(e)), i = e, e
                        }), (function(e) {
                            throw r = null, e
                        }))
                    };
                return {
                    getFreshToken: a,
                    getToken: function e() {
                        return r || (i && ! function(e) {
                            var t = e.creationDate,
                                n = e.expiresIn;
                            return Date.now() >= t + n
                        }(i) ? Promise.resolve(i) : o ? o.then(e) : a())
                    },
                    hasToken: function e() {
                        return o ? o.then(e) : Promise.resolve(!!i)
                    },
                    invalidate: function() {
                        return i = null, o = null, s.removeItem(n)
                    }
                }
            },
            E = n(29),
            C = "change_region",
            I = "check_goals",
            S = "destroy",
            T = "fail_all_requests",
            k = "login_success",
            A = "pause_connection",
            z = "prefetch_token",
            M = "push_received",
            L = "push_response_received",
            P = "reconnect",
            R = "request_failed",
            D = "response_received",
            B = "send_request",
            q = "set_chat_active",
            N = "set_self_id",
            V = "socket_connected",
            F = "socket_disconnected",
            U = "socket_recovered",
            H = "socket_unstable",
            G = "start_connection",
            W = "update_customer_page",
            Y = "CONNECTION_LOST",
            K = "IDENTITY_MISMATCH",
            Z = "MISDIRECTED_CONNECTION",
            J = "MISSING_CHAT_THREAD",
            X = "SDK_DESTROYED",
            Q = "accept_greeting",
            $ = "cancel_greeting",
            ee = "deactivate_chat",
            te = "delete_chat_properties",
            ne = "delete_event_properties",
            re = "delete_thread_properties",
            ie = "get_chat",
            oe = "get_customer",
            ae = "get_form",
            ce = "get_predicted_agent",
            ue = "get_url_info",
            se = "list_chats",
            de = "list_group_statuses",
            le = "list_threads",
            fe = "login",
            pe = "mark_events_as_seen",
            me = "resume_chat",
            ve = "send_event",
            be = "send_rich_message_postback",
            he = "send_sneak_peek",
            ge = "set_customer_session_fields",
            ye = "start_chat",
            Oe = "update_chat_properties",
            je = "update_customer",
            _e = "update_customer_page",
            we = "update_event_properties",
            xe = "update_thread_properties",
            Ee = n(63),
            Ce = n(105),
            Ie = n(12),
            Se = "connected",
            Te = "destroyed",
            ke = "disconnected",
            Ae = "agent",
            ze = "customer";

        function Me(e) {
            var t = function(e, t) {
                if ("object" !== typeof e || null === e) return e;
                var n = e[Symbol.toPrimitive];
                if (void 0 !== n) {
                    var r = n.call(e, t || "default");
                    if ("object" !== typeof r) return r;
                    throw new TypeError("@@toPrimitive must return a primitive value.")
                }
                return ("string" === t ? String : Number)(e)
            }(e, "string");
            return "symbol" === typeof t ? t : String(t)
        }
        var Le = function(e) {
                return e.connection.status
            },
            Pe = function(e, t) {
                return e.requests[t]
            },
            Re = function(e) {
                return e.users.self.id
            },
            De = function(e, t) {
                var n = e.chats[t];
                return !!n && n.active
            },
            Be = function(e) {
                return Le(e) === Se
            },
            qe = function(e) {
                var t = e.region;
                return "https://api" + (t ? "-" + t : "") + function(e) {
                    var t = e.licenseId,
                        n = e.env;
                    return 1520 === t ? ".staging" : "production" === n ? "" : "." + n
                }(e) + ".livechatinc.com"
            },
            Ne = function(e) {
                return qe(e) + "/v3.3/customer"
            },
            Ve = function(e, t) {
                var n = t.id,
                    r = e.requests,
                    i = (r[n], Object(a.a)(r, [n].map(Me)));
                return Object(o.a)({}, e, {
                    requests: i
                })
            },
            Fe = function(e, t) {
                return Object(o.a)({}, t, {
                    connection: Object(o.a)({}, t.connection, {
                        status: e
                    })
                })
            };

        function Ue(e) {
            var t = d.C,
                n = Object(Ce.a)(),
                r = Object(Ee.c)(function(e) {
                    var t;
                    return Object(Ie.d)(e, ((t = {}).change_region = function(e, t) {
                        var n = t.region;
                        return Object(o.a)({}, e, {
                            region: n
                        })
                    }, t.destroy = function(e) {
                        return Fe(Te, e)
                    }, t.login_success = function(e) {
                        return Fe(Se, e)
                    }, t.pause_connection = function(e) {
                        return Fe("paused", e)
                    }, t.request_failed = Ve, t.response_received = Ve, t.push_response_received = Ve, t.send_request = function(e, t) {
                        var n, r = t.promise,
                            i = t.resolve,
                            a = t.reject,
                            c = t.id,
                            u = t.request;
                        return Object(o.a)({}, e, {
                            requests: Object(o.a)({}, e.requests, (n = {}, n[c] = {
                                id: c,
                                promise: r,
                                resolve: i,
                                reject: a,
                                request: u
                            }, n))
                        })
                    }, t.set_chat_active = function(e, t) {
                        var n, r = t.id,
                            i = t.active;
                        return Object(o.a)({}, e, {
                            chats: Object(o.a)({}, e.chats, (n = {}, n[r] = Object(o.a)({}, e.chats[r], {
                                active: i
                            }), n))
                        })
                    }, t.set_self_id = function(e, t) {
                        return Object(o.a)({}, e, {
                            users: Object(o.a)({}, e.users, {
                                self: Object(o.a)({}, e.users.self, {
                                    id: t.id
                                })
                            })
                        })
                    }, t.socket_disconnected = function(e) {
                        var t = Le(e),
                            n = Fe(t === ke ? ke : "reconnecting", e);
                        return Object(o.a)({}, n, {
                            requests: {}
                        })
                    }, t.update_customer_page = function(e, t) {
                        return Object(o.a)({}, e, {
                            page: Object(o.a)({}, e.page, t)
                        })
                    }, t))
                }(function(e) {
                    var t = e.application,
                        n = void 0 === t ? {} : t,
                        r = e.licenseId,
                        i = e.groupId,
                        a = void 0 === i ? null : i,
                        c = e.env,
                        u = e.page,
                        s = void 0 === u ? null : u,
                        d = e.region,
                        l = void 0 === d ? null : d,
                        f = e.referrer,
                        p = void 0 === f ? null : f,
                        m = e.uniqueGroups,
                        v = void 0 !== m && m,
                        b = e.mobile,
                        h = void 0 !== b && b;
                    return {
                        application: Object(o.a)({}, n, {
                            name: "chat_widget",
                            version: "8a35b8498503f3b8de3f3c0be29843a382ad8421"
                        }),
                        licenseId: r,
                        env: c,
                        groupId: a,
                        chats: {},
                        connection: {
                            status: ke
                        },
                        page: s,
                        region: l,
                        referrer: p,
                        requests: {},
                        users: {
                            self: {
                                id: null,
                                type: ze
                            },
                            others: {}
                        },
                        uniqueGroups: v,
                        mobile: h
                    }
                }(e)), t(Object(Ee.a)(n)));
            return r.addSideEffectsHandler = n.add, r
        }

        function He(e) {
            var t = e.message,
                n = e.code,
                r = new Error(t);
            return r.code = n, r
        }
        var Ge = "customer_banned",
            We = "product_version_changed",
            Ye = "chat_deactivated",
            Ke = "chat_properties_deleted",
            Ze = "chat_properties_updated",
            Je = "chat_transferred",
            Xe = "customer_disconnected",
            Qe = "customer_page_updated",
            $e = "customer_side_storage_updated",
            et = "customer_updated",
            tt = "event_properties_deleted",
            nt = "event_properties_updated",
            rt = "event_updated",
            it = "events_marked_as_seen",
            ot = "greeting_accepted",
            at = "greeting_canceled",
            ct = "incoming_chat",
            ut = "incoming_event",
            st = "incoming_greeting",
            dt = "incoming_multicast",
            lt = "incoming_rich_message_postback",
            ft = "incoming_typing_indicator",
            pt = "queue_position_updated",
            mt = "thread_properties_deleted",
            vt = "thread_properties_updated",
            bt = "user_added_to_chat",
            ht = "user_removed_from_chat",
            gt = "file",
            yt = "form",
            Ot = "filled_form",
            jt = "message",
            _t = "rich_message",
            wt = "system_message",
            xt = "custom",
            Et = function(e) {
                var t = {};
                return "string" === typeof e.customId && (t.custom_id = e.customId), Object(d.H)(e.properties) && (t.properties = e.properties), t
            },
            Ct = function(e) {
                switch (e.type) {
                    case jt:
                        var t = Object(o.a)({}, Et(e), {
                            type: e.type,
                            text: e.text
                        });
                        return e.postback && (t.postback = {
                            id: e.postback.id,
                            thread_id: e.postback.threadId,
                            event_id: e.postback.eventId,
                            type: e.postback.type,
                            value: e.postback.value
                        }), t;
                    case gt:
                        return Object(o.a)({}, Et(e), {
                            type: e.type,
                            url: e.url,
                            alternative_text: e.alternativeText
                        });
                    case Ot:
                        return Object(o.a)({}, Et(e), {
                            type: e.type,
                            form_id: e.formId,
                            fields: e.fields.map((function(e) {
                                switch (e.type) {
                                    case "group_chooser":
                                        if (!e.answer) return e;
                                        var t = e.answer,
                                            n = t.groupId,
                                            r = Object(a.a)(t, ["groupId"]);
                                        return Object(o.a)({}, e, {
                                            answer: Object(o.a)({}, r, {
                                                group_id: n
                                            })
                                        });
                                    default:
                                        return e
                                }
                            }))
                        });
                    case wt:
                        var n = Object(o.a)({}, Et(e), {
                            type: e.type,
                            text: e.text,
                            system_message_type: e.systemMessageType
                        });
                        return e.recipients && (n.recipients = e.recipients), n;
                    case xt:
                        var r = Object(o.a)({}, Et(e), {
                            type: e.type
                        });
                        return e.content && (r.content = e.content), r
                }
            },
            It = function(e) {
                var t = e.active,
                    n = void 0 === t || t,
                    r = e.chat,
                    i = e.continuous,
                    o = {
                        active: n,
                        chat: {}
                    };
                if ("boolean" === typeof i && (o.continuous = i), !r) return o;
                var a = r.access,
                    c = r.thread,
                    u = r.properties;
                return a && a.groupIds && (o.chat.access = {
                    group_ids: a.groupIds
                }), u && (o.chat.properties = u), c && (o.chat.thread = function(e) {
                    var t = {},
                        n = e.events,
                        r = e.properties;
                    return n && (t.events = n.map(Ct)), r && (t.properties = r), t
                }(c)), o
            },
            St = function(e) {
                return Object(d.wb)(e).map((function(e) {
                    var t, n = e[0],
                        r = e[1];
                    return (t = {})[n] = r, t
                }))
            },
            Tt = function(e) {
                var t = Object(d.fb)(["avatar", "name", "email"], e);
                return e.sessionFields && (t.session_fields = St(e.sessionFields)), t
            },
            kt = function(e) {
                return {
                    type: S,
                    payload: {
                        reason: e
                    }
                }
            },
            At = function(e) {
                return {
                    type: A,
                    payload: {
                        reason: e
                    }
                }
            },
            zt = function(e) {
                return void 0 === e && (e = !1), {
                    type: z,
                    payload: {
                        fresh: e
                    }
                }
            },
            Mt = function(e) {
                return {
                    type: P,
                    payload: {
                        delay: e
                    }
                }
            },
            Lt = function(e, t, n) {
                return {
                    type: B,
                    payload: Object(o.a)({
                        request: {
                            action: e,
                            payload: t
                        }
                    }, n && {
                        source: n
                    })
                }
            },
            Pt = function(e, t) {
                return {
                    type: q,
                    payload: {
                        id: e,
                        active: t
                    }
                }
            },
            Rt = function(e) {
                return {
                    type: N,
                    payload: {
                        id: e
                    }
                }
            },
            Dt = n(58),
            Bt = function(e, t) {
                t.payload.id = Object(d.w)(e.getState().requests);
                var n = Object(Dt.a)(),
                    r = n.resolve,
                    i = n.reject,
                    o = n.promise;
                return t.payload.promise = o, t.payload.resolve = r, t.payload.reject = i, e.dispatch(t), o
            },
            qt = n(89),
            Nt = n(83),
            Vt = function(e) {
                var t = e.getState(),
                    n = t.licenseId,
                    r = t.groupId;
                return "side_storage_" + n + (t.uniqueGroups ? ":" + r : "")
            },
            Ft = function(e) {
                return s.getItem(Vt(e)).catch(d.V).then((function(e) {
                    return JSON.parse(e || "{}")
                })).catch((function() {
                    return {}
                }))
            },
            Ut = function(e, t, n) {
                return Bt(e, Lt(t, n, "login"))
            };

        function Ht(e, t) {
            var n, r, i = null,
                a = {
                    min: 300,
                    max: 6e4,
                    jitter: .3
                },
                c = Object(Nt.a)(a),
                u = Object(Nt.a)(Object(o.a)({}, a, {
                    min: 1e3
                })),
                s = c,
                l = function(e) {
                    return n.dispatch(kt(e))
                },
                f = function() {
                    return n.dispatch(Mt(s.duration()))
                },
                p = function() {
                    return Promise.all([e.getToken(), Ft(n)])
                },
                m = function(e) {
                    var t = e[0],
                        r = e[1],
                        i = Re(n.getState());
                    if (null === i) n.dispatch(Rt(t.entityId));
                    else if (i !== t.entityId) {
                        var o = new Error("Identity has changed.");
                        throw o.code = K, o
                    }
                    return [t, r]
                },
                v = function(e) {
                    var r, o = e[0],
                        a = e[1],
                        c = n.getState(),
                        u = c.application,
                        s = c.groupId,
                        l = c.page,
                        f = c.referrer,
                        p = c.mobile,
                        m = {
                            token: o.tokenType + " " + o.accessToken,
                            customer: "function" === typeof t ? Tt(t()) : {},
                            customer_side_storage: a,
                            is_mobile: p,
                            application: Object(d.cb)(["name", "version"], u)
                        };
                    return "number" === typeof s && (m.group_id = s), u.channelType && (m.application.channel_type = u.channelType), null !== l && (i = l, m.customer_page = l), null !== f && (m.referrer = f), Promise.race([Ut(n, fe, m), (r = 15e3, new Promise((function(e) {
                        setTimeout(e, r)
                    }))).then((function() {
                        return Promise.reject(He({
                            message: "Request timed out.",
                            code: "REQUEST_TIMEOUT"
                        }))
                    }))])
                };
            return {
                sendLogin: function(t) {
                    var o;
                    n = t, null == (o = r) || o.cancel(), r = function(e, t, n) {
                        var r = e.slice(0),
                            i = !1;
                        return function e(o) {
                            var a = r.shift();
                            Object(qt.a)((function() {
                                return a(o)
                            })).then((function(n) {
                                i || (r.length ? e(n) : t(n))
                            }), (function(e) {
                                i || n(e)
                            }))
                        }(), {
                            cancel: function() {
                                i = !0
                            }
                        }
                    }([p, m, v], (function(e) {
                        r = null, c.reset(), u.reset(), s = c,
                            function() {
                                var e = n.getState().page;
                                i !== e && Ut(n, _e, e).catch(d.V), i = null
                            }(), n.dispatch({
                                type: k,
                                payload: e
                            })
                    }), (function(t) {
                        switch (r = null, t.code) {
                            case "AUTHENTICATION":
                                return e.getFreshToken(), void f();
                            case Y:
                            case Z:
                            case X:
                                return;
                            case "SSO_IDENTITY_EXCEPTION":
                            case "SSO_OAUTH_EXCEPTION":
                                return "server_error" === t.message || "temporarily_unavailable" === t.message ? void f() : void l(t.message);
                            case "USERS_LIMIT_REACHED":
                                return void n.dispatch(At(t.code.toLowerCase()));
                            case K:
                            case "CUSTOMER_BANNED":
                            case "WRONG_PRODUCT_VERSION":
                                return void l(t.code.toLowerCase());
                            case "SERVICE_TEMPORARILY_UNAVAILABLE":
                                return s = u, void f();
                            default:
                                return void f()
                        }
                    }))
                },
                cancel: function() {
                    var e;
                    null == (e = r) || e.cancel()
                }
            }
        }
        var Gt, Wt = function(e, t, n) {
                return t.getToken().then((function(t) {
                    var r = e.getState();
                    null === Re(r) && e.dispatch(Rt(t.entityId));
                    var i = r.page;
                    if (i && i.url) {
                        var o = Object(l.a)({
                                license_id: r.licenseId
                            }),
                            a = {
                                session_fields: St(n || {}),
                                group_id: r.groupId || 0,
                                page_url: i.url
                            };
                        return Object(f.a)(Ne(r) + "/action/check_goals?" + o, {
                            method: "POST",
                            headers: {
                                "Content-Type": "application/json",
                                Authorization: t.tokenType + " " + t.accessToken
                            },
                            body: JSON.stringify(a)
                        }).then((function() {}))
                    }
                }))
            },
            Yt = function(e, t) {
                var n = e.getState,
                    r = e.dispatch,
                    i = function(e) {
                        return e.requests
                    }(n());
                r({
                    type: T,
                    payload: {
                        rejects: Object.keys(i).map((function(e) {
                            return i[e].reject
                        })),
                        reason: t
                    }
                })
            },
            Kt = function(e, t, n) {
                var r = e.getState,
                    i = e.dispatch,
                    o = t.payload.id;
                i({
                    type: R,
                    payload: {
                        id: o,
                        reject: r().requests[o].reject,
                        error: n
                    }
                })
            },
            Zt = Object.freeze({
                success: !0
            }),
            Jt = function(e, t) {
                var n = {
                    id: t.id,
                    authorId: t.author_id,
                    createdAt: t.created_at,
                    threadId: e,
                    properties: t.properties || {}
                };
                return void 0 !== t.custom_id && (n.customId = t.custom_id), n
            },
            Xt = function(e, t) {
                var n, r, i, o, a;
                t.height > t.width ? (r = "height", i = "width", o = t.height, a = t.width) : (r = "width", i = "height", o = t.width, a = t.height);
                var c = e / o;
                return (n = {})[r] = Math.ceil(Math.min(o, e)), n[i] = Math.ceil(Math.min(c * a, a)), n
            },
            Qt = function(e, t) {
                return void 0 !== t.width && void 0 !== t.height ? function(e, t) {
                    return Object(o.a)({}, Jt(e, t), {
                        type: gt,
                        contentType: t.content_type,
                        url: t.url,
                        name: t.name,
                        width: t.width,
                        height: t.height,
                        thumbnails: {
                            default: Object(o.a)({
                                url: t.thumbnail_url
                            }, Xt(300, t)),
                            high: Object(o.a)({
                                url: t.thumbnail2x_url
                            }, Xt(600, t))
                        }
                    }, t.alternative_text && {
                        alternativeText: t.alternative_text
                    })
                }(e, t) : Object(o.a)({}, Jt(e, t), {
                    type: gt,
                    contentType: t.content_type,
                    url: t.url,
                    name: t.name
                })
            },
            $t = function(e) {
                var t = {};
                if ("string" === typeof e.title && (t.title = e.title), "string" === typeof e.subtitle && (t.subtitle = e.subtitle), e.image) {
                    var n = e.image;
                    t.image = Object(o.a)({
                        url: n.url,
                        name: n.name
                    }, n.alternative_text && {
                        alternativeText: n.alternative_text
                    })
                }
                return e.buttons && (t.buttons = e.buttons.map((function(e) {
                    switch (e.type) {
                        case "message":
                        case "phone":
                            return {
                                type: e.type,
                                text: e.text,
                                postbackId: e.postback_id,
                                userIds: e.user_ids,
                                value: e.value,
                                role: e.role || "default"
                            };
                        case "cancel":
                            return {
                                type: e.type,
                                text: e.text,
                                postbackId: e.postback_id,
                                userIds: e.user_ids,
                                role: e.role || "default"
                            };
                        case "url":
                            var t = {
                                type: e.type,
                                text: e.text,
                                postbackId: e.postback_id,
                                userIds: e.user_ids,
                                value: e.value,
                                role: e.role || "default"
                            };
                            return e.target && (t.target = e.target), t;
                        case "webview":
                            var n = {
                                type: e.type,
                                text: e.text,
                                postbackId: e.postback_id,
                                userIds: e.user_ids,
                                value: e.value,
                                role: e.role || "default"
                            };
                            return "string" === typeof e.webview_height && (n.webviewHeight = e.webview_height), n;
                        default:
                            return {
                                text: e.text,
                                postbackId: e.postback_id,
                                userIds: e.user_ids,
                                role: e.role || "default"
                            }
                    }
                }))), t
            },
            en = function(e, t) {
                switch (t.template_id) {
                    case "cards":
                    case "quick_replies":
                    case "sticker":
                        return Object(o.a)({}, Jt(e, t), {
                            type: _t,
                            template: t.template_id,
                            elements: t.elements.map($t)
                        });
                    default:
                        return null
                }
            },
            tn = function(e, t) {
                switch (t.type) {
                    case gt:
                        return Qt(e, t);
                    case yt:
                        return function(e, t) {
                            return Object(o.a)({}, Jt(e, t), {
                                authorId: "system",
                                type: yt,
                                formId: t.form_id,
                                fields: t.fields
                            })
                        }(e, t);
                    case Ot:
                        return function(e, t) {
                            return Object(o.a)({}, Jt(e, t), {
                                type: Ot,
                                formId: t.form_id,
                                fields: t.fields.map((function(e) {
                                    switch (e.type) {
                                        case "group_chooser":
                                            if (!e.answer) return e;
                                            var t = e.answer,
                                                n = t.group_id,
                                                r = Object(a.a)(t, ["group_id"]);
                                            return Object(o.a)({}, e, {
                                                answer: Object(o.a)({}, r, {
                                                    groupId: n
                                                })
                                            });
                                        default:
                                            return e
                                    }
                                }))
                            })
                        }(e, t);
                    case jt:
                        return function(e, t) {
                            return Object(o.a)({}, Jt(e, t), {
                                type: jt,
                                text: t.text
                            })
                        }(e, t);
                    case _t:
                        return en(e, t);
                    case wt:
                        return function(e, t) {
                            var n = Object(o.a)({}, Jt(e, Object(o.a)({}, t, {
                                author_id: "system"
                            })), {
                                type: wt,
                                text: t.text,
                                systemMessageType: t.system_message_type
                            });
                            return t.text_vars && (n.textVars = t.text_vars), n
                        }(e, t);
                    case xt:
                        return function(e, t) {
                            return Object(o.a)({}, Jt(e, t), {
                                type: xt
                            }, t.content && {
                                content: t.content
                            })
                        }(e, t);
                    default:
                        return null
                }
            },
            nn = function(e) {
                return {
                    id: e.id,
                    addon: e.addon || null,
                    uniqueId: e.unique_id,
                    displayedFirstTime: e.displayed_first_time,
                    accepted: e.accepted || !1,
                    subtype: e.subtype || "greeting",
                    event: tn(null, e.event),
                    agent: {
                        id: e.agent.id,
                        name: e.agent.name,
                        avatar: e.agent.avatar,
                        jobTitle: e.agent.job_title,
                        isBot: e.agent.is_bot || !1
                    }
                }
            },
            rn = function(e) {
                return void 0 === e && (e = {}), e.group_ids ? {
                    groupIds: e.group_ids
                } : {}
            },
            on = function(e) {
                return Object(d.P)((function(e) {
                    return e.events_seen_up_to ? e.events_seen_up_to : null
                }), Object(d.K)("id", e))
            },
            an = function(e, t) {
                var n = t.properties || {};
                return {
                    id: t.id,
                    chatId: e,
                    active: t.active,
                    access: rn(t.access),
                    createdAt: t.created_at,
                    userIds: t.user_ids,
                    events: t.events.map((function(e) {
                        return tn(t.id, e)
                    })).filter(Boolean),
                    properties: n,
                    previousThreadId: t.previous_thread_id || null,
                    nextThreadId: t.next_thread_id || null,
                    queue: t.queue ? pn(t.queue) : null
                }
            },
            cn = function(e) {
                return {
                    id: e.id,
                    access: rn(e.access),
                    users: e.users.map(mn),
                    properties: e.properties || {},
                    eventsSeenUpToMap: on(e.users)
                }
            },
            un = function(e) {
                var t = Object(d.fb)(["avatar", "email", "name"], e);
                return e.session_fields && (t.sessionFields = e.session_fields.reduce((function(e, t) {
                    var n = Object.keys(t)[0];
                    return e[n] = t[n], e
                }), {})), t
            },
            sn = function(e) {
                var t = un(e);
                return Object(o.a)({
                    id: e.id,
                    type: ze
                }, t, {
                    sessionFields: t.sessionFields || {}
                })
            },
            dn = function(e) {
                var t = e.statistics;
                return Object(o.a)({}, sn(e), {
                    statistics: {
                        chatsCount: t.chats_count,
                        threadsCount: t.threads_count,
                        visitsCount: t.visits_count,
                        pageViewsCount: t.page_views_count,
                        greetingsShownCount: t.greetings_shown_count,
                        greetingsAcceptedCount: t.greetings_accepted_count
                    }
                })
            },
            ln = function(e) {
                var t = e.agent,
                    n = e.queue;
                return {
                    agent: {
                        id: t.id,
                        type: Ae,
                        name: t.name,
                        avatar: t.avatar,
                        jobTitle: t.job_title,
                        isBot: t.is_bot
                    },
                    queue: n
                }
            },
            fn = function(e) {
                return {
                    position: e.position,
                    waitTime: e.wait_time
                }
            },
            pn = function(e) {
                return Object(o.a)({}, fn(e), {
                    queuedAt: e.queued_at
                })
            },
            mn = function(e) {
                return e.type === ze ? (n = e, Object(o.a)({}, sn(n), {
                    present: n.present
                })) : {
                    id: (t = e).id,
                    type: Ae,
                    name: t.name,
                    avatar: t.avatar,
                    jobTitle: t.job_title,
                    present: t.present
                };
                var t, n
            },
            vn = ((Gt = {}).CONNECTION_LOST = "Connection lost.", Gt.MISDIRECTED_CONNECTION = "Connected to wrong region.", Gt),
            bn = function(e, t) {
                var n = e.getState();
                switch (t.type) {
                    case L:
                    case M:
                        switch (t.payload.action) {
                            case Ye:
                                return void e.dispatch(Pt(t.payload.payload.chatId, !1));
                            case ct:
                                return void e.dispatch(Pt(t.payload.payload.chat.id, !0));
                            default:
                                return
                        }
                    case D:
                        switch (t.payload.action) {
                            case se:
                                return void t.payload.payload.chatsSummary.filter((function(e) {
                                    var t = e.id,
                                        r = e.active;
                                    return De(n, t) !== r
                                })).forEach((function(t) {
                                    var n = t.id,
                                        r = t.active;
                                    e.dispatch(Pt(n, r))
                                }));
                            default:
                                return
                        }
                }
            },
            hn = function(e, t) {
                t.forEach((function(t) {
                    if ("present" in t) {
                        t.present;
                        var n = Object(a.a)(t, ["present"]);
                        e("user_data", n)
                    } else if (t.type !== ze) e("user_data", t);
                    else {
                        t.statistics;
                        var r = Object(a.a)(t, ["statistics"]);
                        e("user_data", r)
                    }
                }))
            },
            gn = function(e, t) {
                var n = e.emit,
                    r = e.store,
                    i = t.payload;
                switch (i.action) {
                    case vt:
                        return i.payload.properties.lc2 && "queue_pos" in i.payload.properties.lc2 && n(pt, {
                            chatId: i.payload.chatId,
                            threadId: i.payload.threadId,
                            queue: {
                                position: i.payload.properties.lc2.queue_pos,
                                waitTime: i.payload.properties.lc2.queue_waiting_time
                            }
                        }), void n("thread_properties_updated", i.payload);
                    case $e:
                        return void
                        function(e, t) {
                            s.setItem(Vt(e), JSON.stringify(t)).catch(d.V)
                        }(r, i.payload.customer_side_storage);
                    case Xe:
                        switch (i.payload.reason) {
                            case "access_token_expired":
                                r.dispatch(zt(!0)), r.dispatch(Mt(100)), n("disconnected", i.payload);
                                break;
                            case Ge:
                            case "customer_temporarily_blocked":
                            case "license_not_found":
                            case We:
                            case "too_many_connections":
                            case "unsupported_version":
                                r.dispatch(kt(i.payload.reason));
                                break;
                            case "misdirected_connection":
                                Yt(r, Z), r.dispatch({
                                    type: C,
                                    payload: i.payload.data
                                });
                                break;
                            case "service_temporarily_unavailable":
                            case "too_many_unauthorized_connections":
                                Yt(r, i.payload.reason.toUpperCase());
                                break;
                            default:
                                r.dispatch(Mt(100)), n("disconnected", i.payload)
                        }
                        return;
                    case ct:
                        return hn(n, i.payload.chat.users), void n(i.action, i.payload);
                    case ut:
                        if (null === i.payload.event) return;
                        return void n(i.action, i.payload);
                    case ft:
                        return void n(i.action, i.payload);
                    case dt:
                        return function(e, t) {
                            var n = t.type,
                                r = t.content;
                            if ("lc2" === n && "groups_update" === r.name && "groups" in r && !Object(d.F)(r.groups)) {
                                e("availability_updated", {
                                    availability: "offline" === r.groups[0].status ? "offline" : "online"
                                })
                            }
                        }(n, i.payload), void n(i.action, i.payload);
                    case bt:
                        return hn(n, [i.payload.user]), void n(i.action, i.payload);
                    default:
                        return void n(i.action, i.payload)
                }
            },
            yn = function(e, t) {
                var n = e.emit,
                    r = t.payload;
                switch (r.action) {
                    case Ye:
                        return void r.resolve(Zt);
                    case ie:
                        return hn(n, r.payload.users), void r.resolve(r.payload);
                    case ct:
                        return hn(n, r.payload.chat.users), void r.resolve(r.payload);
                    case ut:
                        return void r.resolve(r.payload.event);
                    case se:
                        return hn(n, r.payload.users), void r.resolve(r.payload);
                    default:
                        return void r.resolve(r.payload)
                }
            },
            On = function(e) {
                var t = e.auth,
                    n = e.customerDataProvider,
                    i = e.emitter,
                    a = e.socket,
                    c = i.emit,
                    u = Ht(t, n);
                return function(e, n) {
                    switch (e.type) {
                        case C:
                            return void a.reinitialize();
                        case I:
                            return void Wt(n, t, e.payload.sessionFields).catch(d.V);
                        case S:
                            var s = e.payload;
                            switch (u.cancel(), a.destroy(), s.reason) {
                                case "manual":
                                    Yt(n, X);
                                    break;
                                case Ge:
                                case "license_expired":
                                case We:
                                    Yt(n, Y), c("disconnected", s);
                                    break;
                                default:
                                    c("disconnected", s)
                            }
                            return void i.off();
                        case T:
                            var l = e.payload,
                                f = l.reason,
                                p = l.rejects,
                                m = {
                                    message: vn[f],
                                    code: f
                                };
                            return void p.forEach((function(e) {
                                e(He(m))
                            }));
                        case k:
                            var v = e.payload,
                                b = v.dynamicConfig,
                                h = v.customer,
                                g = v.chats,
                                y = v.greeting,
                                O = v.availability,
                                j = Object(o.a)({
                                    customer: h,
                                    availability: O
                                }, y && {
                                    greeting: y
                                });
                            return Object.defineProperty(j, "__unsafeDynamicConfig", {
                                value: b
                            }), Object.defineProperty(j, "__unsafeChats", {
                                value: g
                            }), void c("connected", j);
                        case A:
                            var _ = e.payload;
                            return a.disconnect(), void("manual" !== _.reason && c("disconnected", _));
                        case z:
                            return e.payload.fresh ? void t.getFreshToken().catch(d.V) : void t.hasToken().then((function(e) {
                                return e ? t.getToken().then((function(e) {
                                    if (!(e.creationDate + e.expiresIn - Date.now() > 36e5)) return t.invalidate().then(t.getFreshToken)
                                })) : t.getToken()
                            })).catch(d.V);
                        case M:
                            return e.payload.action === Xe || bn(n, e), void gn({
                                emit: c,
                                store: n
                            }, e);
                        case L:
                            return bn(n, e), void yn({
                                emit: c
                            }, e);
                        case P:
                            return Yt(n, Y), void a.reconnect(e.payload.delay);
                        case R:
                            var w = e.payload;
                            return void(0, w.reject)(He(w.error));
                        case D:
                            return bn(n, e), void yn({
                                emit: c
                            }, e);
                        case B:
                            var x = n.getState();
                            return function(e) {
                                return Le(e) === Te
                            }(x) ? void Kt(n, e, {
                                code: X,
                                message: "SDK destroyed."
                            }) : Be(x) || "login" === e.payload.source ? void
                            function(e, t) {
                                var n = t.payload,
                                    i = n.id,
                                    a = n.request,
                                    c = Object(o.a)({
                                        request_id: i
                                    }, a);
                                switch (c.action) {
                                    case fe:
                                        var u = [];
                                        return void e.emit(Object(o.a)({}, c, {
                                            version: "3.3",
                                            payload: Object(o.a)({}, c.payload, {
                                                pushes: {
                                                    3.3: Object(d.Bb)(r).filter((function(e) {
                                                        return e !== Xe && !Object(d.D)(e, u)
                                                    }))
                                                }
                                            })
                                        }));
                                    default:
                                        e.emit(c)
                                }
                            }(a, e): void Kt(n, e, {
                                code: "NO_CONNECTION",
                                message: "No connection."
                            });
                        case N:
                            return void c("customer_id", e.payload.id);
                        case F:
                            return void c("disconnected", {
                                reason: "connection_lost"
                            });
                        case V:
                            return void u.sendLogin(n);
                        case U:
                            if (!Be(n.getState())) return;
                            return void c("connection_recovered");
                        case H:
                            if (!Be(n.getState())) return;
                            return void c("connection_unstable");
                        case G:
                            return a.connect(), void n.dispatch(zt());
                        case W:
                            if (!Be(n.getState())) return;
                            return void Bt(n, Lt(_e, e.payload)).catch(d.V);
                        default:
                            return
                    }
                }
            },
            jn = function(e, t) {
                var n = {
                        status: "idle",
                        queuedTasks: [],
                        nextPageId: null
                    },
                    r = function r(i, o) {
                        switch (n.status) {
                            case "idle":
                                return n.status = "fetching", void e.listThreads(n.nextPageId ? {
                                    chatId: t,
                                    pageId: n.nextPageId
                                } : {
                                    chatId: t,
                                    minEventsCount: 25
                                }).then((function(e) {
                                    var t = e.threads,
                                        o = e.nextPageId;
                                    n.nextPageId = o, n.nextPageId ? (n.status = "idle", i({
                                        value: {
                                            threads: [].concat(t).reverse()
                                        },
                                        done: !1
                                    })) : (n.status = "done", i({
                                        value: {
                                            threads: [].concat(t).reverse()
                                        },
                                        done: !0
                                    }));
                                    var a = n.queuedTasks.shift();
                                    a && r(a.resolve, a.reject)
                                }), (function(e) {
                                    var t = n.queuedTasks;
                                    n.status = "idle", n.queuedTasks = [], o(e), t.forEach((function(t) {
                                        return t.reject(e)
                                    }))
                                }));
                            case "fetching":
                                return void n.queuedTasks.push({
                                    resolve: i,
                                    reject: o
                                });
                            case "done":
                                return void i({
                                    value: void 0,
                                    done: !0
                                })
                        }
                    };
                return {
                    next: function(e) {
                        function t() {
                            return e.apply(this, arguments)
                        }
                        return t.toString = function() {
                            return e.toString()
                        }, t
                    }((function() {
                        return new Promise(r)
                    }))
                }
            },
            _n = 0,
            wn = 1,
            xn = 3,
            En = function(e, t) {
                var n, r = (void 0 === t ? {} : t).query,
                    i = void 0 === r ? {} : r,
                    o = Object(l.a)(i),
                    a = o ? e + "?" + o : e,
                    c = Object(E.a)(),
                    u = Object(Nt.a)({
                        min: 1e3,
                        max: 5e3,
                        jitter: .5
                    }),
                    s = xn,
                    d = null,
                    f = function() {
                        s = wn, u.reset(), c.emit("connect")
                    },
                    p = function() {
                        v(), h(), c.emit("disconnect")
                    },
                    m = function(e) {
                        var t = e.data;
                        c.emit("message", t)
                    },
                    v = function() {
                        var e;
                        (clearTimeout(n), s = xn, d) && ((e = d).removeEventListener("open", f), e.removeEventListener("close", p), e.removeEventListener("message", m), d.close(), d = null)
                    },
                    b = function() {
                        var e;
                        s = _n, d = new WebSocket(a), (e = d).addEventListener("open", f), e.addEventListener("close", p), e.addEventListener("message", m)
                    },
                    h = function(e) {
                        void 0 === e && (e = u.duration()), v(), 0 !== e ? n = setTimeout(b, e) : b()
                    };
                return {
                    connect: function(e) {
                        function t() {
                            return e.apply(this, arguments)
                        }
                        return t.toString = function() {
                            return e.toString()
                        }, t
                    }((function() {
                        if (s !== xn) throw new Error("Socket is already open or connecting.");
                        clearTimeout(n), b()
                    })),
                    destroy: function() {
                        c.off(), v()
                    },
                    disconnect: v,
                    reconnect: h,
                    emit: function(e) {
                        if (s !== wn) throw new Error("Socket is not connected.");
                        d.send(e)
                    },
                    getReadyState: function() {
                        return s
                    },
                    on: c.on,
                    off: c.off
                }
            },
            Cn = function() {
                var e, t = d.V;
                return {
                    cancel: function() {
                        clearTimeout(e), t = d.V
                    },
                    check: function() {
                        var n = Object(Dt.a)();
                        return t = n.resolve, e = setTimeout((function() {
                            var e = new Error("Timeout.");
                            e.code = "TIMEOUT", n.reject(e)
                        }), 2e3), n.promise
                    },
                    resolve: function(e) {
                        function t() {
                            return e.apply(this, arguments)
                        }
                        return t.toString = function() {
                            return e.toString()
                        }, t
                    }((function() {
                        clearTimeout(e), t()
                    }))
                }
            },
            In = function(e, t) {
                var n, r, a = void 0 === t ? {} : t,
                    c = a.query,
                    u = void 0 === c ? {} : c,
                    s = a.emitter,
                    d = void 0 === s ? Object(E.a)() : s,
                    l = En(e, {
                        query: u
                    }),
                    f = Cn(),
                    p = function() {
                        return l.getReadyState() === i.OPEN
                    },
                    m = function() {
                        f.cancel()
                    };
                return n = l, r = d, ["connect", "disconnect"].forEach((function(e) {
                    n.on(e, (function(t) {
                        r.emit(e, t)
                    }))
                })), l.on("disconnect", m), l.on("message", (function(e) {
                    f.resolve();
                    var t = JSON.parse(e);
                    d.emit("message", t)
                })), "undefined" !== typeof window && "undefined" !== typeof window.addEventListener && (window.addEventListener("online", (function() {
                    p() && f.check().then((function() {
                        f.cancel(), d.emit("connection_recovered")
                    }), (function(e) {
                        if (f.cancel(), "TIMEOUT" !== e.code) throw e;
                        l.reconnect()
                    }))
                })), window.addEventListener("offline", (function() {
                    f.cancel(), p() && d.emit("connection_unstable")
                }))), Object(o.a)({}, l, {
                    destroy: function() {
                        m(), l.destroy()
                    },
                    disconnect: function() {
                        m(), l.disconnect()
                    },
                    reconnect: function(e) {
                        m(), l.reconnect(e)
                    },
                    emit: function(e) {
                        l.emit(JSON.stringify(e))
                    },
                    on: d.on,
                    off: d.off
                })
            },
            Sn = function(e, t) {
                var n = e.getState(),
                    r = (Ne(n) + "/rtm/ws").replace(/^https/, "wss");
                return In(r, {
                    query: {
                        license_id: n.licenseId
                    },
                    emitter: t
                })
            },
            Tn = function(e) {
                var t = Object(E.a)(),
                    n = Sn(e, t);
                return Object(o.a)({}, Object.keys(n).reduce((function(e, t) {
                    return e[t] = function() {
                        var e;
                        return (e = n)[t].apply(e, arguments)
                    }, e
                }), {}), {
                    reinitialize: function() {
                        n.disconnect(), (n = Sn(e, t)).connect()
                    }
                })
            },
            kn = function(e) {
                return {
                    chatId: e.chat_id,
                    properties: e.properties
                }
            },
            An = function(e) {
                var t = {
                    chatId: e.chat_id,
                    threadId: e.thread_id,
                    transferredTo: Object(o.a)({}, e.transferred_to.agent_ids && {
                        agentIds: e.transferred_to.agent_ids
                    }, e.transferred_to.group_ids && {
                        groupIds: e.transferred_to.group_ids
                    }),
                    queue: e.queue ? pn(e.queue) : null
                };
                return "manual" === e.reason ? Object(o.a)({}, t, {
                    reason: e.reason,
                    requesterId: e.requester_id
                }) : Object(o.a)({}, t, {
                    reason: e.reason
                })
            },
            zn = function(e) {
                return {
                    url: e.url,
                    title: e.title,
                    openedAt: e.opened_at
                }
            },
            Mn = function(e) {
                return Object(o.a)({
                    id: e.id
                }, un(e))
            },
            Ln = function(e) {
                return {
                    chatId: e.chat_id,
                    threadId: e.thread_id,
                    eventId: e.event_id,
                    properties: e.properties
                }
            },
            Pn = function(e) {
                return {
                    chatId: e.chat_id,
                    threadId: e.thread_id,
                    eventId: e.event_id,
                    properties: e.properties
                }
            },
            Rn = function(e) {
                var t = e.thread_id;
                return {
                    chatId: e.chat_id,
                    threadId: t,
                    event: tn(t, e.event)
                }
            },
            Dn = function(e) {
                return {
                    chatId: e.chat_id,
                    userId: e.user_id,
                    seenUpTo: e.seen_up_to
                }
            },
            Bn = function(e) {
                return {
                    uniqueId: e.unique_id
                }
            },
            qn = function(e) {
                var t = e.chat;
                return {
                    chat: Object(o.a)({}, cn(t), {
                        thread: an(t.id, t.thread)
                    })
                }
            },
            Nn = function(e) {
                return {
                    chatId: e.chat_id,
                    event: tn(e.thread_id, e.event)
                }
            },
            Vn = function(e) {
                return nn(e)
            },
            Fn = function(e) {
                return {
                    userId: e.user_id,
                    chatId: e.chat_id,
                    threadId: e.thread_id,
                    eventId: e.event_id,
                    postback: e.postback
                }
            },
            Un = function(e) {
                var t = e.chat_id,
                    n = e.typing_indicator;
                return {
                    chatId: t,
                    typingIndicator: {
                        authorId: n.author_id,
                        isTyping: n.is_typing
                    }
                }
            },
            Hn = function(e) {
                return {
                    chatId: e.chat_id,
                    threadId: e.thread_id,
                    queue: fn(e.queue)
                }
            },
            Gn = function(e) {
                return {
                    chatId: e.chat_id,
                    threadId: e.thread_id,
                    properties: e.properties
                }
            },
            Wn = function(e) {
                return {
                    chatId: e.chat_id,
                    threadId: e.thread_id,
                    properties: e.properties
                }
            },
            Yn = function(e) {
                return {
                    chatId: e.chat_id,
                    user: mn(e.user),
                    present: e.user.present
                }
            },
            Kn = function(e) {
                return {
                    chatId: e.chat_id,
                    userId: e.user_id
                }
            },
            Zn = function(e) {
                return e.map((function(e) {
                    switch (e.type) {
                        case "group_chooser":
                            return Object(o.a)({}, e, {
                                options: e.options.map((function(e) {
                                    var t = e.group_id,
                                        n = Object(a.a)(e, ["group_id"]);
                                    return Object(o.a)({}, n, {
                                        groupId: t
                                    })
                                }))
                            });
                        case "rating":
                            var t = e.comment_label,
                                n = Object(a.a)(e, ["comment_label"]);
                            return Object(o.a)({}, n, {
                                commentLabel: t
                            });
                        default:
                            return e
                    }
                }))
            },
            Jn = function(e) {
                var t = e.map((function(e, t) {
                    return Object(o.a)({}, e, {
                        id: String(t)
                    })
                }));
                return Zn(t)
            },
            Xn = function(e) {
                var t = !("id" in e.fields[0]);
                return {
                    id: e.id,
                    fields: t ? Jn(e.fields) : Zn(e.fields)
                }
            },
            Qn = function(e) {
                return e.enabled ? Object(o.a)({}, e, {
                    form: Xn(e.form)
                }) : e
            },
            $n = function(e) {
                var t = {
                    url: e.url
                };
                return e.title && (t.title = e.title), e.description && (t.description = e.description), e.image_url && (t.imageUrl = "https://" + e.image_url, e.image_width && e.image_height && (t.imageWidth = e.image_width, t.imageHeight = e.image_height)), t
            },
            er = function(e) {
                var t = e.online_groups_ids,
                    n = e.customer_groups;
                if (!t) return "offline";
                var r = n.monitoring.id;
                return Object(d.D)(r, t) ? "online" : "offline"
            },
            tr = function(e) {
                var t = e.chats_summary.map((function(e) {
                    var t = e.id,
                        n = e.active,
                        r = e.access,
                        i = e.last_thread_created_at,
                        o = e.last_thread_id,
                        a = e.last_event_per_type,
                        c = e.properties,
                        u = void 0 === c ? {} : c,
                        s = e.users,
                        l = {
                            id: t,
                            active: n,
                            access: rn(r),
                            properties: u,
                            users: s.map(mn),
                            lastThreadId: o || null,
                            lastThreadCreatedAt: i || null,
                            eventsSeenUpToMap: on(s)
                        };
                    if (!a) return l;
                    l.lastEventsPerType = Object(d.P)((function(e) {
                        return tn(e.thread_id, e.event)
                    }), a);
                    var f = a,
                        p = Object.keys(f).map((function(e) {
                            return f[e]
                        })),
                        m = Object(d.M)(p.sort((function(e, t) {
                            return e.thread_id === t.thread_id ? Object(d.pb)(e.event.created_at, t.event.created_at) : Object(d.pb)(e.thread_created_at, t.thread_created_at)
                        })));
                    return m && (l.lastEvent = l.lastEventsPerType[m.event.type]), l
                }));
                return {
                    chatsSummary: Object(d.W)((function(e) {
                        var t = e.lastEvent,
                            n = e.order;
                        return -1 * (void 0 !== t ? t.timestamp : n)
                    }), t),
                    totalChats: e.total_chats,
                    users: Object(d.zb)((function(e) {
                        return e.id
                    }), Object(d.s)((function(e) {
                        return e.users
                    }), t)),
                    previousPageId: e.previous_page_id || null,
                    nextPageId: e.next_page_id || null
                }
            },
            nr = function(e) {
                return e.groups_status
            },
            rr = function(e, t) {
                return {
                    threads: t.threads.map((function(t) {
                        return an(e.payload.chat_id, t)
                    })),
                    previousPageId: t.previous_page_id || null,
                    nextPageId: t.next_page_id || null
                }
            },
            ir = function(e) {
                var t = e.__priv_dynamic_config,
                    n = e.chats,
                    r = e.greeting;
                return Object(o.a)({
                    dynamicConfig: t,
                    customer: dn(e.customer),
                    availability: er(t),
                    chats: n.map((function(t) {
                        return {
                            id: t.chat_id,
                            active: "has_active_thread" in t ? t.has_active_thread : e.has_active_thread,
                            hasUnreadEvents: t.has_unread_events
                        }
                    }))
                }, r && {
                    greeting: nn(r)
                })
            },
            or = function(e) {
                switch (e.action) {
                    case Ye:
                        return {
                            action: e.action,
                            payload: {
                                chatId: e.payload.chat_id
                            }
                        };
                    case Ke:
                        return {
                            action: e.action,
                            payload: (t = e.payload, {
                                chatId: t.chat_id,
                                properties: t.properties
                            })
                        };
                    case Ze:
                        return {
                            action: e.action,
                            payload: kn(e.payload)
                        };
                    case Je:
                        return {
                            action: e.action,
                            payload: An(e.payload)
                        };
                    case $e:
                    case Xe:
                        return {
                            action: e.action,
                            payload: e.payload
                        };
                    case Qe:
                        return {
                            action: e.action,
                            payload: zn(e.payload)
                        };
                    case et:
                        return {
                            action: e.action,
                            payload: Mn(e.payload)
                        };
                    case tt:
                        return {
                            action: e.action,
                            payload: Ln(e.payload)
                        };
                    case nt:
                        return {
                            action: e.action,
                            payload: Pn(e.payload)
                        };
                    case rt:
                        return {
                            action: e.action,
                            payload: Rn(e.payload)
                        };
                    case it:
                        return {
                            action: e.action,
                            payload: Dn(e.payload)
                        };
                    case ot:
                    case at:
                        return {
                            action: e.action,
                            payload: Bn(e.payload)
                        };
                    case ct:
                        return {
                            action: e.action,
                            payload: qn(e.payload)
                        };
                    case ut:
                        return {
                            action: e.action,
                            payload: Nn(e.payload)
                        };
                    case st:
                        return {
                            action: e.action,
                            payload: Vn(e.payload)
                        };
                    case dt:
                        return {
                            action: e.action,
                            payload: e.payload
                        };
                    case lt:
                        return {
                            action: e.action,
                            payload: Fn(e.payload)
                        };
                    case ft:
                        return {
                            action: e.action,
                            payload: Un(e.payload)
                        };
                    case pt:
                        return {
                            action: e.action,
                            payload: Hn(e.payload)
                        };
                    case mt:
                        return {
                            action: e.action,
                            payload: Gn(e.payload)
                        };
                    case vt:
                        return {
                            action: e.action,
                            payload: Wn(e.payload)
                        };
                    case bt:
                        return {
                            action: e.action,
                            payload: Yn(e.payload)
                        };
                    case ht:
                        return {
                            action: e.action,
                            payload: Kn(e.payload)
                        }
                }
                var t
            },
            ar = function(e, t) {
                var n = e.dispatch,
                    r = e.getState,
                    i = t.request_id,
                    a = Pe(r(), i),
                    c = a.promise,
                    u = a.resolve,
                    s = function(e) {
                        var t, n = e.request,
                            r = e.response;
                        switch (r.action) {
                            case Q:
                            case $:
                            case te:
                            case ne:
                            case re:
                                return {
                                    action: r.action,
                                    payload: Zt
                                };
                            case ie:
                                return {
                                    action: r.action,
                                    payload: (t = r.payload, Object(o.a)({}, cn(t), {
                                        thread: t.thread ? an(t.id, t.thread) : null
                                    }))
                                };
                            case oe:
                                return {
                                    action: r.action,
                                    payload: dn(r.payload)
                                };
                            case ae:
                                return {
                                    action: r.action,
                                    payload: Qn(r.payload)
                                };
                            case ce:
                                return {
                                    action: r.action,
                                    payload: ln(r.payload)
                                };
                            case ue:
                                return {
                                    action: r.action,
                                    payload: $n(r.payload)
                                };
                            case se:
                                return {
                                    action: r.action,
                                    payload: tr(r.payload)
                                };
                            case de:
                                return {
                                    action: r.action,
                                    payload: nr(r.payload)
                                };
                            case le:
                                return {
                                    action: r.action,
                                    payload: rr(n, r.payload)
                                };
                            case fe:
                                return {
                                    action: r.action,
                                    payload: ir(r.payload)
                                };
                            case pe:
                            case he:
                            case ge:
                            case be:
                            case Oe:
                            case je:
                            case _e:
                            case we:
                            case xe:
                                return {
                                    action: r.action,
                                    payload: Zt
                                }
                        }
                    }({
                        request: a.request,
                        response: t
                    });
                n({
                    type: D,
                    payload: Object(o.a)({
                        id: i,
                        promise: c,
                        resolve: u
                    }, s)
                })
            },
            cr = function(e, t) {
                var n = e.dispatch;
                return t.on("connect", (function() {
                    n({
                        type: V
                    })
                })), t.on("message", (function(t) {
                    if ("response" === t.type) {
                        if (!t.success) return void
                        function(e, t) {
                            var n, r = e.dispatch,
                                i = e.getState,
                                o = t.request_id,
                                a = t.payload,
                                c = Pe(i(), o).reject;
                            r({
                                type: R,
                                payload: {
                                    id: o,
                                    reject: c,
                                    error: (n = a.error, {
                                        code: n.type.toUpperCase(),
                                        message: n.message
                                    })
                                }
                            })
                        }(e, t);
                        switch (t.action) {
                            case ee:
                            case me:
                            case ve:
                            case ye:
                                return;
                            default:
                                return void ar(e, t)
                        }
                    }
                    if ("request_id" in t) switch (t.action) {
                        case Ye:
                        case ct:
                        case ut:
                            return void
                            function(e, t) {
                                var n = e.dispatch,
                                    r = e.getState,
                                    i = t.request_id,
                                    a = Pe(r(), i),
                                    c = a.promise,
                                    u = a.resolve,
                                    s = or(t);
                                n({
                                    type: L,
                                    payload: Object(o.a)({
                                        id: i,
                                        promise: c,
                                        resolve: u
                                    }, s)
                                })
                            }(e, t)
                    }! function(e, t) {
                        var n = or(t);
                        n && e.dispatch({
                            type: M,
                            payload: n
                        })
                    }(e, t)
                })), t.on("disconnect", (function() {
                    Yt(e, Y), Le(e.getState()) === Se && e.dispatch({
                        type: F
                    })
                })), t.on("connection_unstable", (function() {
                    n({
                        type: H
                    })
                })), t.on("connection_recovered", (function() {
                    n({
                        type: U
                    })
                })), t.off
            },
            ur = "incorrect requester structure",
            sr = function(e, t) {
                return e.length ? e + "\n" + t : t
            },
            dr = function(e, t, n) {
                var r = n.filledForm,
                    i = n.groupId,
                    a = n.timeZone;
                return t.getToken().then((function(t) {
                    var n = e.getState();
                    null === Re(n) && e.dispatch(Rt(t.entityId));
                    var c = qe(n) + "/v2/tickets/new",
                        u = function(e, t) {
                            var n = t.fields,
                                r = t.customerId,
                                i = t.groupId,
                                a = void 0 === i ? e.groupId : i,
                                c = t.timeZone,
                                u = Object(o.a)({
                                    licence_id: e.licenseId,
                                    ticket_message: "",
                                    offline_message: "",
                                    visitor_id: r,
                                    requester: {}
                                }, "number" === typeof a && {
                                    group: a
                                }, e.page && {
                                    source: {
                                        url: e.page.url
                                    }
                                }, c && {
                                    timezone: c
                                });
                            return n.reduce((function(e, t) {
                                switch (t.type) {
                                    case "subject":
                                        var n = t.answer,
                                            r = n ? t.label + " " + n : t.label;
                                        return n && (e.subject = n), e.offline_message = sr(e.offline_message, r), e;
                                    case "name":
                                        var i = t.answer,
                                            o = i ? t.label + " " + i : t.label;
                                        return i && (e.requester.name = i), e.offline_message = sr(e.offline_message, o), e;
                                    case "email":
                                        var a = t.answer,
                                            c = a ? t.label + " " + a : t.label;
                                        return e.requester.mail = a, e.offline_message = sr(e.offline_message, c), e;
                                    case "question":
                                    case "textarea":
                                        var u = t.answer,
                                            s = u ? t.label + " " + u : t.label;
                                        return e.offline_message = sr(e.offline_message, s), e.ticket_message = sr(e.ticket_message, s), e;
                                    case "radio":
                                    case "select":
                                        var d = t.answer && t.answer.label,
                                            l = d ? t.label + " " + d : t.label;
                                        return e.offline_message = sr(e.offline_message, l), e.ticket_message = sr(e.ticket_message, l), e;
                                    case "checkbox":
                                        var f = t.answers && t.answers.map((function(e) {
                                                return e.label
                                            })).join(", "),
                                            p = f ? t.label + " " + f : t.label;
                                        return e.offline_message = sr(e.offline_message, p), e.ticket_message = sr(e.ticket_message, p), e;
                                    default:
                                        return e
                                }
                            }), u)
                        }(n, {
                            fields: r.fields,
                            customerId: t.entityId,
                            groupId: i,
                            timeZone: a
                        });
                    return Object(f.a)(c, {
                        method: "POST",
                        headers: {
                            "Content-Type": "application/json"
                        },
                        body: JSON.stringify(u)
                    }).then((function(e) {
                        if (e.ok) return e.json().then((function(e) {
                            return Object(o.a)({}, e, {
                                text: u.ticket_message
                            })
                        }));
                        if (400 === e.status || 422 === e.status) {
                            var t = function(e) {
                                if (!e || !e.errors) throw new Error;
                                var t = e.errors[0];
                                if (Object.keys(t)[0] === ur) throw He({
                                    message: t[ur][0],
                                    code: "VALIDATION"
                                });
                                throw new Error
                            };
                            return e.json().then(t, t)
                        }
                        throw new Error
                    }))
                }))
            },
            lr = "UPLOAD_FAILED",
            fr = function(e, t, n) {
                var r = void 0 === n ? {} : n,
                    i = r.headers,
                    o = r.method,
                    a = void 0 === o ? "POST" : o,
                    c = r.onProgress,
                    u = r.withCredentials,
                    s = void 0 !== u && u,
                    d = new XMLHttpRequest;
                return {
                    promise: new Promise((function(n, r) {
                        "function" === typeof c && (d.upload.onprogress = function(e) {
                            c(e.loaded / e.total)
                        }), d.onload = function() {
                            var e;
                            try {
                                e = JSON.parse(d.response)
                            } catch (t) {
                                e = d.response
                            }
                            if (d.status >= 200 && d.status < 300) n(e);
                            else {
                                var t = new Error("Upload failed.");
                                t.code = lr, t.response = e, r(t)
                            }
                        }, d.onerror = function() {
                            var e = new Error("Upload failed.");
                            e.code = lr, r(e)
                        }, d.onabort = function() {
                            var e = new Error("Upload canceled.");
                            e.code = "UPLOAD_CANCELED", r(e)
                        }, d.open(a, e), d.withCredentials = s, i && Object.keys(i).forEach((function(e) {
                            return d.setRequestHeader(e, i[e])
                        })), d.send(function(e) {
                            var t = new FormData;
                            return Object.keys(e).forEach((function(n) {
                                return t.append(n, e[n])
                            })), t
                        }(t))
                    })),
                    cancel: function() {
                        d.abort()
                    }
                }
            },
            pr = 1048576,
            mr = 10485760,
            vr = function(e, t) {
                if (void 0 === t && (t = 2), e < 1024) return e + " b";
                var n = e / 1024;
                if (e < pr) return n.toFixed(t) + " kb";
                var r = n / 1024;
                return e < 1073741824 ? r.toFixed(t) + " MB" : (r / 1024).toFixed(t) + " GB"
            },
            br = function(e) {
                if (e.size > mr) throw He({
                    message: "The file is too big (max size is " + vr(mr) + ").",
                    code: "TOO_BIG_FILE"
                })
            },
            hr = function(e, t) {
                var n, r = e.auth,
                    i = e.store,
                    o = t.file,
                    a = t.onProgress,
                    c = !1;
                return {
                    promise: new Promise((function(e, t) {
                        br(o);
                        var u = i.getState(),
                            s = Object(l.a)({
                                license_id: u.licenseId
                            }),
                            d = Ne(u) + "/action/upload_file?" + s,
                            f = {
                                file: o
                            };
                        r.getToken().then((function(r) {
                            c ? t(new Error("Upload cancelled.")) : (n = fr(d, f, {
                                headers: {
                                    Authorization: r.tokenType + " " + r.accessToken
                                },
                                onProgress: a
                            })).promise.then(e, (function(e) {
                                if (e.response) {
                                    var n = e.response.error,
                                        r = n.type,
                                        i = n.message;
                                    t(He({
                                        message: i,
                                        code: r.toUpperCase()
                                    }))
                                } else t(e)
                            }))
                        }))
                    })),
                    cancel: function() {
                        c || (c = !0, n && n.cancel())
                    }
                }
            },
            gr = function(e) {
                e.env, e.licenseId, e.eventName;
                return Promise.resolve()
            },
            yr = function(e, t) {
                void 0 === t && (t = "production"), w(e);
                var n = e.autoConnect,
                    r = void 0 === n || n,
                    i = e.customerDataProvider,
                    c = e.identityProvider,
                    u = Object(a.a)(e, ["autoConnect", "customerDataProvider", "identityProvider"]),
                    s = Ue(Object(o.a)({}, u, {
                        env: t
                    })),
                    l = Object(E.a)(),
                    f = Tn(s),
                    p = "function" === typeof c ? c() : x(u, t);
                s.addSideEffectsHandler(On({
                    emitter: l,
                    socket: f,
                    auth: p,
                    customerDataProvider: i
                })), cr(s, f);
                var m = Bt.bind(null, s),
                    v = function() {
                        s.dispatch({
                            type: G
                        })
                    },
                    b = Object.freeze({
                        acceptGreeting: function(e) {
                            var t = e.greetingId,
                                n = e.uniqueId;
                            return m(Lt(Q, {
                                greeting_id: t,
                                unique_id: n
                            }))
                        },
                        auth: p,
                        cancelGreeting: function(e) {
                            var t = e.uniqueId;
                            return m(Lt($, {
                                unique_id: t
                            }))
                        },
                        cancelRate: function(e) {
                            var t = e.chatId,
                                n = e.properties,
                                r = void 0 === n ? ["score"] : n;
                            return b.listThreads({
                                chatId: t
                            }).then((function(e) {
                                var n = e.threads;
                                if (!n.length) throw He({
                                    message: 'There is no thread in "' + t + '".',
                                    code: J
                                });
                                return b.deleteThreadProperties({
                                    chatId: t,
                                    threadId: n[0].id,
                                    properties: {
                                        rating: r
                                    }
                                })
                            }))
                        },
                        connect: v,
                        deactivateChat: function(e) {
                            var t = e.id;
                            return m(Lt(ee, {
                                id: t
                            }))
                        },
                        deleteChatProperties: function(e) {
                            var t = e.id,
                                n = e.properties;
                            return m(Lt(te, {
                                id: t,
                                properties: n
                            }))
                        },
                        deleteEventProperties: function(e) {
                            var t = e.chatId,
                                n = e.threadId,
                                r = e.eventId,
                                i = e.properties;
                            return m(Lt(ne, {
                                chat_id: t,
                                thread_id: n,
                                event_id: r,
                                properties: i
                            }))
                        },
                        deleteThreadProperties: function(e) {
                            var t = e.chatId,
                                n = e.threadId,
                                r = e.properties;
                            return m(Lt(re, {
                                chat_id: t,
                                thread_id: n,
                                properties: r
                            }))
                        },
                        destroy: function() {
                            s.dispatch(kt("manual"))
                        },
                        disconnect: function() {
                            s.dispatch(At("manual"))
                        },
                        getChat: function(e) {
                            var t = e.chatId,
                                n = e.threadId;
                            return m(Lt(ie, {
                                chat_id: t,
                                thread_id: n
                            }))
                        },
                        getChatHistory: function(e) {
                            var t = e.chatId;
                            return jn(b, t)
                        },
                        getCustomer: function() {
                            return m(Lt(oe, {}))
                        },
                        getForm: function(e) {
                            var t = e.groupId,
                                n = e.type;
                            return m(Lt(ae, {
                                group_id: t,
                                type: n
                            }))
                        },
                        getPredictedAgent: function(e) {
                            void 0 === e && (e = {});
                            var t = e.groupId;
                            return m(Lt(ce, "number" === typeof t ? {
                                group_id: t
                            } : {}))
                        },
                        getUrlInfo: function(e) {
                            var t = e.url;
                            return m(Lt(ue, {
                                url: t
                            }))
                        },
                        listChats: function(e) {
                            return void 0 === e && (e = {}), "limit" in e && "number" === typeof e.limit && e.limit > 25 ? Promise.reject(new Error("Specified limit is too high (max 25).")) : m(Lt(se, void 0 === e.pageId ? {
                                limit: e.limit || 10
                            } : {
                                page_id: e.pageId
                            }))
                        },
                        listGroupStatuses: function(e) {
                            var t = (void 0 === e ? {} : e).groupIds;
                            return m(Lt(de, t ? {
                                group_ids: t
                            } : {
                                all: !0
                            }))
                        },
                        listThreads: function(e) {
                            return m(Lt(le, void 0 === e.pageId ? {
                                chat_id: e.chatId,
                                sort_order: e.sortOrder,
                                limit: e.limit,
                                min_events_count: e.minEventsCount
                            } : {
                                chat_id: e.chatId,
                                page_id: e.pageId
                            }))
                        },
                        markEventsAsSeen: function(e) {
                            var t = e.chatId,
                                n = e.seenUpTo;
                            return m(Lt(pe, {
                                chat_id: t,
                                seen_up_to: n
                            }))
                        },
                        on: l.on,
                        once: l.once,
                        off: l.off,
                        rateChat: function(e) {
                            var t = e.chatId,
                                n = e.rating;
                            return b.listThreads({
                                chatId: t
                            }).then((function(e) {
                                var r = e.threads;
                                if (!r.length) throw He({
                                    message: 'There is no thread in "' + t + '".',
                                    code: J
                                });
                                return b.updateThreadProperties({
                                    chatId: t,
                                    threadId: r[0].id,
                                    properties: {
                                        rating: n
                                    }
                                })
                            }))
                        },
                        resumeChat: function(n) {
                            return gr({
                                env: t,
                                licenseId: e.licenseId,
                                eventName: "chat_started"
                            }), m(Lt(me, function(e) {
                                var t = It(e);
                                return Object(o.a)({}, t, {
                                    chat: Object(o.a)({}, t.chat, {
                                        id: e.chat.id
                                    })
                                })
                            }(n)))
                        },
                        sendEvent: function(e) {
                            function t(t) {
                                return e.apply(this, arguments)
                            }
                            return t.toString = function() {
                                return e.toString()
                            }, t
                        }((function(e) {
                            return m(function(e) {
                                var t = e.chatId,
                                    n = e.event,
                                    r = e.attachToLastThread,
                                    i = {
                                        chat_id: t,
                                        event: Ct(n)
                                    };
                                return r && (i.attach_to_last_thread = !0), Lt(ve, i)
                            }(e))
                        })),
                        sendTicketForm: function(e) {
                            return dr(s, p, e)
                        },
                        sendRichMessagePostback: function(e) {
                            var t = e.chatId,
                                n = e.threadId,
                                r = e.eventId,
                                i = e.postback;
                            return m(Lt(be, {
                                chat_id: t,
                                event_id: r,
                                thread_id: n,
                                postback: i
                            }))
                        },
                        setCustomerSessionFields: function(e) {
                            var t = e.sessionFields;
                            return m(Lt(ge, {
                                session_fields: St(t)
                            }))
                        },
                        setSneakPeek: function(e) {
                            var t = e.chatId,
                                n = e.sneakPeekText,
                                r = s.getState();
                            De(r, t) && Be(r) && m(Lt(he, {
                                chat_id: t,
                                sneak_peek_text: n
                            })).catch(d.V)
                        },
                        startChat: function(n) {
                            return void 0 === n && (n = {}), gr({
                                env: t,
                                licenseId: e.licenseId,
                                eventName: "chat_started"
                            }), m(Lt(ye, It(n)))
                        },
                        updateChatProperties: function(e) {
                            var t = e.id,
                                n = e.properties;
                            return m(Lt(Oe, {
                                id: t,
                                properties: n
                            }))
                        },
                        updateCustomer: function(e) {
                            return m(Lt(je, Tt(e)))
                        },
                        updateCustomerPage: function(e) {
                            s.dispatch({
                                type: W,
                                payload: Object(d.fb)(["title", "url"], e)
                            })
                        },
                        updateEventProperties: function(e) {
                            var t = e.chatId,
                                n = e.threadId,
                                r = e.eventId,
                                i = e.properties;
                            return m(Lt(we, {
                                chat_id: t,
                                event_id: r,
                                thread_id: n,
                                properties: i
                            }))
                        },
                        updateThreadProperties: function(e) {
                            var t = e.chatId,
                                n = e.threadId,
                                r = e.properties;
                            return m(Lt(xe, {
                                chat_id: t,
                                thread_id: n,
                                properties: r
                            }))
                        },
                        uploadFile: function(e) {
                            return hr({
                                auth: p,
                                store: s
                            }, e)
                        }
                    });
                return r ? v() : s.dispatch({
                    type: I,
                    payload: {
                        sessionFields: "function" === typeof i ? i().sessionFields : {}
                    }
                }), b
            }
    }, function(e, t, n) {
        "use strict";
        n.d(t, "a", (function() {
            return r
        }));
        var r = 430
    }, , function(e, t) {
        e.exports = function(e) {
            return "object" === typeof e ? null !== e : "function" === typeof e
        }
    }, , , , , , , function(e, t, n) {
        "use strict";
        t.a = function() {
            var e = [],
                t = function(t) {
                    return function(n) {
                        return function(r) {
                            var i = n(r);
                            return e.forEach((function(e) {
                                e(r, t)
                            })), i
                        }
                    }
                };
            return t.add = function(t) {
                e.push(t)
            }, t
        }
    }, function(e, t, n) {
        "use strict";
        n.d(t, "a", (function() {
            return o
        }));
        var r = /^\s+$/,
            i = /^(?:\s+|[\u2700-\u27bf]|(?:\ud83c[\udde6-\uddff]){2}|[\ud800-\udbff][\udc00-\udfff])[\ufe0e\ufe0f]?(?:[\u0300-\u036f\ufe20-\ufe23\u20d0-\u20f0]|\ud83c[\udffb-\udfff])?(?:\u200d(?:[^\ud800-\udfff]|(?:\ud83c[\udde6-\uddff]){2}|[\ud800-\udbff][\udc00-\udfff])[\ufe0e\ufe0f]?(?:[\u0300-\u036f\ufe20-\ufe23\u20d0-\u20f0]|\ud83c[\udffb-\udfff])?)*/;

        function o(e) {
            for (var t = null, n = 0; t = i.exec(e);) {
                var o = t[0];
                if (e = e.slice(o.length), r.test(o) || n++, n > 3) return !1
            }
            return !e
        }
    }, , , function(e, t, n) {
        "use strict";
        n.d(t, "a", (function() {
            return r
        }));
        new RegExp("^message-group");
        var r = "system-card"
    }, function(e, t, n) {
        "use strict";
        var r = n(1),
            i = n(0),
            o = n(7),
            a = n(17);
        var c = function(e) {
                return e.stopPropagation()
            },
            u = Object(o.z)("a", {
                target: "ecc17ou0"
            })({
                name: "c5z5om",
                styles: "color:inherit;&:focus{outline-offset:-1px;}"
            });
        t.a = function(e) {
            var t = Object(a.f)();
            return i.createElement(u, Object(r.a)({
                rel: "nofollow noopener",
                target: "_blank",
                textWrap: !0
            }, e, {
                onClick: c
            }, t))
        }
    }, function(e, t) {
        var n, r, i = e.exports = {};

        function o() {
            throw new Error("setTimeout has not been defined")
        }

        function a() {
            throw new Error("clearTimeout has not been defined")
        }

        function c(e) {
            if (n === setTimeout) return setTimeout(e, 0);
            if ((n === o || !n) && setTimeout) return n = setTimeout, setTimeout(e, 0);
            try {
                return n(e, 0)
            } catch (t) {
                try {
                    return n.call(null, e, 0)
                } catch (t) {
                    return n.call(this, e, 0)
                }
            }
        }! function() {
            try {
                n = "function" === typeof setTimeout ? setTimeout : o
            } catch (e) {
                n = o
            }
            try {
                r = "function" === typeof clearTimeout ? clearTimeout : a
            } catch (e) {
                r = a
            }
        }();
        var u, s = [],
            d = !1,
            l = -1;

        function f() {
            d && u && (d = !1, u.length ? s = u.concat(s) : l = -1, s.length && p())
        }

        function p() {
            if (!d) {
                var e = c(f);
                d = !0;
                for (var t = s.length; t;) {
                    for (u = s, s = []; ++l < t;) u && u[l].run();
                    l = -1, t = s.length
                }
                u = null, d = !1,
                    function(e) {
                        if (r === clearTimeout) return clearTimeout(e);
                        if ((r === a || !r) && clearTimeout) return r = clearTimeout, clearTimeout(e);
                        try {
                            r(e)
                        } catch (t) {
                            try {
                                return r.call(null, e)
                            } catch (t) {
                                return r.call(this, e)
                            }
                        }
                    }(e)
            }
        }

        function m(e, t) {
            this.fun = e, this.array = t
        }

        function v() {}
        i.nextTick = function(e) {
            var t = new Array(arguments.length - 1);
            if (arguments.length > 1)
                for (var n = 1; n < arguments.length; n++) t[n - 1] = arguments[n];
            s.push(new m(e, t)), 1 !== s.length || d || c(p)
        }, m.prototype.run = function() {
            this.fun.apply(null, this.array)
        }, i.title = "browser", i.browser = !0, i.env = {}, i.argv = [], i.version = "", i.versions = {}, i.on = v, i.addListener = v, i.once = v, i.off = v, i.removeListener = v, i.removeAllListeners = v, i.emit = v, i.prependListener = v, i.prependOnceListener = v, i.listeners = function(e) {
            return []
        }, i.binding = function(e) {
            throw new Error("process.binding is not supported")
        }, i.cwd = function() {
            return "/"
        }, i.chdir = function(e) {
            throw new Error("process.chdir is not supported")
        }, i.umask = function() {
            return 0
        }
    }, function(e, t) {
        var n = e.exports = "undefined" != typeof window && window.Math == Math ? window : "undefined" != typeof self && self.Math == Math ? self : Function("return this")();
        "number" == typeof __g && (__g = n)
    }, , function(e, t, n) {
        "use strict";
        n.d(t, "a", (function() {
            return l
        }));
        var r = n(1),
            i = n(8),
            o = n(4),
            a = n(17),
            c = n(7),
            u = n(22),
            s = n(18),
            d = n(45);
        var l = {
                name: "1bw4iei",
                styles: "margin:0 4px;margin-bottom:8px;padding:8px;border-radius:6px!important"
            },
            f = Object(c.z)(c.p, {
                target: "ecz5hmt0"
            })("font-family:'Noto Sans';font-size:0.9em;", (function(e) {
                var t = e.theme;
                return Object(o.c)("color:", Object(s.h)(t.colors.cta) ? Object(u.f)(.6, t.colors.cta) : t.colors.cta, ";border-color:", Object(s.h)(t.colors.cta) ? Object(u.f)(.6, t.colors.cta) : t.colors.cta, ";")
            }), ";"),
            p = function(e) {
                return e.stopPropagation()
            };
        t.b = function(e) {
            var t = e.replies,
                n = e.onSelect,
                u = Object(i.a)(e, ["replies", "onSelect"]),
                s = Object(a.f)();
            return Object(o.d)(c.o, Object(r.a)({
                onSelect: n
            }, u, s), t.map((function(e, t) {
                var n = e.text;
                return Object(o.d)(f, {
                    key: t,
                    onClick: p,
                    value: t,
                    css: l
                }, Object(o.d)(d.a, null, n.length > 20 ? n.slice(0, 20).trim() + "\u2026" : n))
            })))
        }
    }, function(e, t, n) {
        "use strict";
        n.d(t, "a", (function() {
            return a
        })), n.d(t, "b", (function() {
            return u
        }));
        var r = n(1),
            i = n(2);

        function o(e, t) {
            return null != t && null != e && "object" === typeof t && "object" === typeof e ? a(t, e) : e
        }

        function a(e, t) {
            var n;
            if (Array.isArray(e)) {
                n = e.slice(0, t.length);
                for (var a = 0; a < t.length; a++) void 0 !== t[a] && (n[a] = o(t[a], n[a]))
            } else
                for (var c in n = Object(r.a)({}, e), t) Object(i.B)(c, t) && (void 0 === t[c] ? delete n[c] : n[c] = o(t[c], n[c]));
            return n
        }

        function c(e, t) {
            return "object" === typeof e && "object" === typeof t ? u(e, t) : e
        }

        function u(e, t) {
            var n;
            if (Array.isArray(e)) {
                n = new Array(e.length);
                for (var r = 0; r < e.length; r++) e[r] !== t[r] && (n[r] = c(e[r], t[r]))
            } else n = {}, Object.keys(e).forEach((function(r) {
                e[r] !== t[r] && (n[r] = c(e[r], t[r]))
            }));
            return n
        }
    }, , function(e, t, n) {
        "use strict";
        var r = n(1),
            i = n(21),
            o = n(4),
            a = n(23),
            c = n(16);

        function u() {
            var e = Object(i.a)(["\n\t100% {\n\t\topacity: 0.3;\n\t}\n"]);
            return u = function() {
                return e
            }, e
        }
        var s = Object(o.e)(u()),
            d = Object(r.a)({}, c.a, {
                borderRadius: Object(r.a)({}, c.a.borderRadius, {
                    def: c.a.borderRadius.md
                }),
                vars: {
                    "primary-color": c.a.colors.accent,
                    "secondary-color": c.a.colors.text.white,
                    "tertiary-color": c.a.colors.divider
                },
                ApplicationWrapper: {
                    css: {
                        padding: {
                            default: "1em 1em 1em 1em",
                            expandToEdge: "0"
                        }
                    }
                },
                AgentBar: {
                    Avatar: {
                        size: "40px"
                    },
                    IconButton: {
                        css: {
                            width: "40px",
                            height: "40px",
                            textAlign: "center",
                            display: "flex",
                            justifyContent: "center",
                            alignItems: "center",
                            marginLeft: "6px",
                            fontSize: Object(a.d)(32),
                            opacity: {
                                default: "1",
                                disabled: "0.15"
                            },
                            color: {
                                active: c.a.colors.text.white
                            }
                        }
                    },
                    Title: {
                        css: {
                            fontSize: ".9em",
                            fontWeight: "bold"
                        }
                    },
                    SubTitle: {
                        css: {
                            fontSize: "0.9em",
                            opacity: "1"
                        }
                    },
                    css: {
                        backgroundColor: c.a.colors.surface.light,
                        zIndex: "1",
                        color: c.a.colors.text.black,
                        padding: "1rem"
                    }
                },
                Avatar: {
                    size: "20px",
                    css: {
                        border: 0
                    }
                },
                Bubble: {
                    sharpBorderRadius: "6px",
                    ovalBorderRadius: "6px",
                    css: {
                        boxShadow: c.a.boxShadow.xs,
                        border: "0"
                    }
                },
                ImagePreview: {
                    css: {
                        maxWidth: "200px",
                        maxHeight: "300px",
                        borderRadius: c.a.borderRadius.md
                    }
                },
                IconButton: {
                    css: {
                        padding: "0 .5em"
                    }
                },
                Footer: {
                    css: {
                        fontSize: "0.65em",
                        padding: "0.3em 0",
                        width: "100%",
                        textAlign: "center",
                        backgroundColor: c.a.colors.surface.lightVariant
                    },
                    FooterLink: {
                        css: {
                            textDecoration: "none",
                            padding: "0.2em",
                            borderRadius: c.a.borderRadius.md
                        }
                    }
                },
                MessageButtons: {
                    css: {
                        color: c.a.colors.accent
                    }
                },
                MessageText: {
                    css: {
                        fontSize: "14px"
                    }
                },
                Message: {
                    css: {
                        animation: {
                            default: "none",
                            sending: s + " 2s 2s forwards"
                        },
                        opacity: {
                            default: "1",
                            failed: "0.7"
                        },
                        color: c.a.colors.text.black,
                        justifyContent: {
                            default: "flex-start",
                            system: "center"
                        }
                    },
                    Bubble: {
                        sharpBorderRadius: "6px",
                        ovalBorderRadius: "6px",
                        css: {
                            boxShadow: c.a.boxShadow.xs,
                            border: "0"
                        }
                    },
                    system: {
                        Bubble: {
                            css: {
                                background: "transparent",
                                textAlign: "center",
                                border: "0",
                                width: "100%",
                                boxShadow: "none"
                            }
                        },
                        MessageText: {
                            css: {
                                padding: "0 1em"
                            }
                        }
                    },
                    fullWidth: {
                        Content: {
                            css: {
                                width: "100%"
                            }
                        }
                    }
                },
                MinimizedBar: {
                    Icon: {
                        color: "var(--primary-color)"
                    },
                    css: {
                        position: "relative"
                    }
                },
                MinimizedBubble: {
                    Icon: {
                        color: c.a.colors.text.white
                    },
                    css: {
                        position: "relative",
                        background: {
                            default: "var(--primary-color)",
                            hasAvatar: "transparent"
                        }
                    }
                },
                Minimized: {
                    Avatar: {
                        css: {
                            border: "0",
                            backgroundColor: "transparent"
                        }
                    }
                },
                Invitation: {
                    IconButton: {
                        css: {
                            visibility: {
                                mobile: "visible"
                            }
                        }
                    },
                    Bubble: {
                        sharpBorderRadius: "6px",
                        ovalBorderRadius: "6px",
                        css: {
                            border: "0"
                        }
                    }
                },
                TitleBar: {
                    css: {
                        backgroundColor: c.a.colors.surface.light,
                        color: c.a.colors.text.black,
                        fontWeight: "700!important",
                        fontSize: "1em",
                        textAlign: "center",
                        height: "56px"
                    },
                    TitleBarTitle: {
                        css: {
                            fontSize: Object(a.d)(14)
                        }
                    },
                    Avatar: {
                        size: "30px",
                        css: {
                            border: "0"
                        }
                    }
                },
                TextComposer: {
                    css: {
                        fontSize: {
                            default: "14px",
                            mobile: "16px"
                        },
                        boxShadow: "0 -1em 1em rgba(0, 0, 0, 0.03)",
                        zIndex: "1"
                    },
                    IconButton: {
                        css: {
                            opacity: {
                                active: 1,
                                default: .4
                            }
                        }
                    },
                    Icon: {
                        color: "unset"
                    }
                },
                View: {
                    css: {
                        color: c.a.colors.text.black
                    },
                    Bubble: {
                        sharpBorderRadius: "6px",
                        ovalBorderRadius: "6px",
                        css: {
                            boxShadow: c.a.boxShadow.xs,
                            border: "0"
                        }
                    }
                },
                SystemCard: {
                    css: {
                        border: "0",
                        boxShadow: c.a.boxShadow.xs,
                        left: {
                            default: "50%",
                            rtl: "auto"
                        },
                        right: {
                            default: "auto",
                            rtl: "50%"
                        },
                        transform: {
                            default: "translateX(-50%)",
                            rtl: "translateX(50%)"
                        }
                    }
                }
            });
        t.a = d
    }, , function(e, t, n) {
        "use strict";
        n.d(t, "b", (function() {
            return m
        }));
        var r = n(1),
            i = n(0),
            o = n(145),
            a = n.n(o),
            c = n(2),
            u = n(13),
            s = Array.prototype.map,
            d = ["A", "UL", "OL", "LI", "STRONG", "EM", "BR"],
            l = new o.Renderer;
        l.list = function(e, t, n) {
            var r = n;
            return e.replace(f, (function() {
                return t ? r++ + ". " : "- "
            }))
        }, l.listitem = function(e) {
            return "" + f + e
        };
        var f = "%list-item%",
            p = function(e) {
                return e.replace(/\n+$/, "")
            };

        function m(e) {
            var t = a()(e, {
                    renderer: l
                }),
                n = (new DOMParser).parseFromString(t, "text/html").body;
            return n ? p(n.textContent || "") : ""
        }
        t.a = function(e) {
            var t, n, o = e.template,
                f = e.root,
                m = e.preserveLists,
                v = e.limit,
                b = null != (t = null == f ? void 0 : f.props) ? t : {},
                h = null != (n = null == f ? void 0 : f.component) ? n : i.Fragment,
                g = i.useMemo((function() {
                    var e = new DOMParser,
                        t = p(a()(o, m ? {
                            renderer: l
                        } : {})),
                        n = e.parseFromString(t, "text/html").body;
                    return n ? function(e, t) {
                        var n = 0,
                            o = !1;
                        return function e(a) {
                            return s.call(a, (function(a, s) {
                                if ("#text" === a.nodeName) return t ? o ? null : a.textContent && a.textContent.length + n < t ? (n += a.textContent.length, a.textContent) : (o = !0, Object(c.lb)(t - n, a.textContent)) : a.textContent;
                                if (!Object(c.D)(a.nodeName, d)) return a.hasChildNodes() ? e(a.childNodes) : null;
                                var l = Object(r.a)({
                                    key: s
                                }, a.hasChildNodes() && {
                                    children: e(a.childNodes)
                                });
                                if ("A" === a.nodeName) {
                                    var f = a.getAttribute("href");
                                    if (!f || Object(u.k)(f)) return e(a.childNodes);
                                    /\S+@\S+\.\S+/.test(f) || Object(u.g)(f) || (f = "https://" + f);
                                    var p = Object(r.a)({}, l, {
                                        href: f,
                                        target: "_blank",
                                        rel: "nofollow noopener"
                                    });
                                    return i.createElement("a", p)
                                }
                                return i.createElement(a.nodeName.toLowerCase(), l)
                            }))
                        }(e)
                    }(n.childNodes, v) : ""
                }), [o, m, v]);
            return i.createElement(h, b, g)
        }
    }, , function(e, t) {
        var n = e.exports = {
            version: "2.6.3"
        };
        "number" == typeof __e && (__e = n)
    }, , , , , function(e, t, n) {
        "use strict";
        var r = n(1),
            i = n(8),
            o = n(4),
            a = n(23),
            c = n(20),
            u = function(e) {
                return Object(o.c)("display:inline-block;flex-shrink:0;width:1em;height:1em;font-size:", e ? Object(a.d)(e) : "inherit", ";user-select:none;fill:currentColor;")
            };
        t.a = function(e) {
            var t = e.size,
                n = e.label,
                a = e.color,
                s = void 0 === a ? "inherit" : a,
                d = e.children,
                l = Object(i.a)(e, ["size", "label", "color", "children"]),
                f = Object(c.l)(),
                p = n ? {
                    "aria-labelledby": f
                } : {};
            return Object(o.d)("svg", Object(r.a)({
                color: s,
                css: u(t)
            }, l, p), n && Object(o.d)("title", {
                id: f
            }, n), d)
        }
    }, function(e, t, n) {
        "use strict";
        n.d(t, "a", (function() {
            return r
        }));
        var r = function(e) {
            return e.replace(/\?+$/, "")
        }
    }, function(e, t, n) {
        "use strict";
        n.d(t, "a", (function() {
            return a
        })), n.d(t, "b", (function() {
            return c
        }));
        var r = /\.(\w+)$/i,
            i = new Audio,
            o = {
                mp3: "audio/mpeg",
                ogg: "audio/ogg"
            },
            a = function(e) {
                var t = function(e) {
                    var t = e.match(r);
                    return t ? t[1].toLowerCase() : ""
                }(e);
                if (t in o) {
                    if ("" !== i.canPlayType(o[t])) return !0
                } else 0;
                return !1
            },
            c = function() {
                return "function" === typeof window.webkitAudioContext
            }
    }, , , function(e, t, n) {
        var r = n(112),
            i = n(146),
            o = n(135),
            a = n(202)("src"),
            c = "toString",
            u = Function.toString,
            s = ("" + u).split(c);
        n(121).inspectSource = function(e) {
            return u.call(e)
        }, (e.exports = function(e, t, n, c) {
            var u = "function" == typeof n;
            u && (o(n, "name") || i(n, "name", t)), e[t] !== n && (u && (o(n, a) || i(n, a, e[t] ? "" + e[t] : s.join(String(t)))), e === r ? e[t] = n : c ? e[t] ? e[t] = n : i(e, t, n) : (delete e[t], i(e, t, n)))
        })(Function.prototype, c, (function() {
            return "function" == typeof this && this[a] || u.call(this)
        }))
    }, function(e, t, n) {
        var r = n(133),
            i = n(329),
            o = n(268),
            a = Object.defineProperty;
        t.f = n(134) ? Object.defineProperty : function(e, t, n) {
            if (r(e), t = o(t, !0), r(n), i) try {
                return a(e, t, n)
            } catch (c) {}
            if ("get" in n || "set" in n) throw TypeError("Accessors not supported!");
            return "value" in n && (e[t] = n.value), e
        }
    }, function(e, t, n) {
        var r = n(98);
        e.exports = function(e) {
            if (!r(e)) throw TypeError(e + " is not an object!");
            return e
        }
    }, function(e, t, n) {
        e.exports = !n(147)((function() {
            return 7 != Object.defineProperty({}, "a", {
                get: function() {
                    return 7
                }
            }).a
        }))
    }, function(e, t) {
        var n = {}.hasOwnProperty;
        e.exports = function(e, t) {
            return n.call(e, t)
        }
    }, , , , , , , function(e, t, n) {
        "use strict";
        n.d(t, "a", (function() {
            return J
        })), n.d(t, "b", (function() {
            return ee
        })), n.d(t, "c", (function() {
            return re
        }));
        var r = n(36),
            i = n.n(r),
            o = n(42),
            a = n(2),
            c = n(29),
            u = n(31),
            s = n.n(u),
            d = n(50),
            l = n.n(d),
            f = n(43),
            p = n(107),
            m = n(48),
            v = n(40),
            b = n.n(v),
            h = n(61),
            g = n(71),
            y = "call",
            O = "emit",
            j = "@@livechat/postmessenger",
            _ = "@@livechat/4way",
            w = "handshake",
            x = "handshake_echo",
            E = "response",
            C = n(1),
            I = n(66),
            S = n(130),
            T = n(57),
            k = n(30),
            A = n(51),
            z = n.n(A),
            M = function(e) {
                return !!e.data && e.data[j]
            },
            L = Object(a.ab)((function() {
                return Object(m.a)(i()((function(e) {
                    return e.data.origin = e.origin, e.data
                }))(s()(M)(Object(k.a)(window, "message"))))
            }));

        function P(e) {
            return function(t) {
                return Object(T.a)(i()(e)(t))
            }
        }
        var R = 0,
            D = function(e, t, n, r) {
                return void 0 === r && (r = R++), Object(I.a)((function() {
                    return n.request = r, t(n), b()(1)(P((function(e) {
                        if (!e.data.error) return Object(f.a)((function() {
                            return e.data.result
                        }));
                        var t = e.data.result,
                            n = t.real,
                            r = t.error;
                        if (!n) return Object(S.a)(r);
                        var i = new Error(r.message);
                        return Object(a.B)("code", r) && (i.code = r.code), Object(S.a)(i)
                    }))(s()((function(e) {
                        return e.type === E && e.request === r
                    }))(e)))
                }))
            },
            B = function(e, t, n, r, i) {
                return void 0 === i && (i = null), Object(C.a)({}, e, {
                    call: function(e) {
                        for (var i = arguments.length, a = new Array(i > 1 ? i - 1 : 0), c = 1; c < i; c++) a[c - 1] = arguments[c];
                        return Object(o.a)(D(t, r, n(y, {
                            method: e,
                            args: a
                        })))
                    },
                    emit: function(e, t) {
                        r(n(O, {
                            event: e,
                            arg: t
                        }))
                    },
                    data: i
                })
            },
            q = n(87),
            N = n.n(q);

        function V() {
            var e = N()();
            return [e, function() {
                var t = new Error("Destroyed.");
                t.code = "DESTROYED", e(2, t)
            }]
        }
        var F = function(e, t, n, r) {
                var i;
                return (i = {})[j] = !0, i.owner = e, i.instance = t, i.type = n, i.data = r, i
            },
            U = n(89),
            H = function(e, t, n, r) {
                return function(i) {
                    switch (i.type) {
                        case y:
                            return void Object(U.a)((function() {
                                var t = i.data,
                                    n = t.method,
                                    o = t.args;
                                return r[n].apply(e, o)
                            })).then((function(e) {
                                i.type = E, i.data = {
                                    error: !1,
                                    result: e
                                }, n(i)
                            }), (function(e) {
                                var t;
                                i.type = E, e instanceof Error ? (t = {
                                    real: !0,
                                    error: {
                                        message: e.message
                                    }
                                }, Object(a.B)("code", e) && (t.error.code = e.code)) : t = {
                                    real: !1,
                                    error: e
                                }, i.data = {
                                    error: !0,
                                    result: t
                                }, n(i)
                            }));
                        case O:
                            var o = i.data,
                                c = o.event,
                                u = o.arg;
                            return void t(c, u);
                        default:
                            return
                    }
                }
            },
            G = function(e) {
                return Object(a.bb)((function(e) {
                    return "function" === typeof e
                }), e)
            },
            W = Object(a.v)(),
            Y = 0;

        function K(e, t) {
            var n = e.frame,
                r = e.targetOrigin,
                o = void 0 === r ? function(e) {
                    var t = document.createElement("a");
                    return t.href = e, t.origin ? "null" === t.origin ? "*" : t.origin : (t.protocol.length > 4 ? t.protocol : window.location.protocol) + "//" + (t.host.length ? "80" === t.port || "443" === t.port ? t.hostname : t.host : window.location.host)
                }(n.src) : r,
                a = e.handshakeRetry,
                u = void 0 === a ? {} : a;
            void 0 === t && (t = {});
            var d = G(t),
                v = d[0],
                y = d[1],
                O = V(),
                j = O[0],
                E = O[1],
                C = Y++,
                I = n.contentWindow,
                S = Object(c.a)(),
                T = function(e, t) {
                    return F(W, C, e, t)
                },
                k = function(e) {
                    I.postMessage(e, o)
                },
                A = Object(m.a)(Object(h.a)(j)(s()((function(e) {
                    return e.owner === W && e.instance === C
                }))(L()))),
                z = B(S, A, T, k),
                M = Object(m.a)(Object(h.a)(j)(P((function(e) {
                    return _ in e ? i()((function() {
                        return e.data
                    }))(D(A, k, T(x))) : Object(f.a)((function() {
                        return e
                    }))
                }))(b()(1)(Object(p.a)(u.count || 5)(Object(g.a)(u.interval || 500)(D(A, k, T(w, y), null))))))),
                R = H(z, S.emit, k, v);
            return l()(R)(P((function() {
                return A
            }))(M)), {
                api: z,
                destroy: E,
                handshake$: M
            }
        }
        var Z = n(100);

        function J(e, t) {
            void 0 === e && (e = {});
            var n = (void 0 === t ? {} : t).handshakeTimeout,
                r = void 0 === n ? 3e3 : n;
            var u, d = (u = function(t) {
                var n, r = window.parent,
                    o = t.origin,
                    a = function(e) {
                        r.postMessage(e, o)
                    };
                return a(Object(C.a)({}, t, {
                    type: E,
                    data: {
                        error: !1,
                        result: (n = {}, n["@@livechat/4way"] = !0, n.data = G(e)[1], n)
                    }
                })), b()(1)(i()((function(e) {
                    return e.type = E, e.data = {
                        error: !1,
                        result: null
                    }, a(e), t
                }))(s()((function(e) {
                    return e.owner === t.owner && e.instance === t.instance && e.type === x
                }))(L())))
            }, function(e) {
                return function(e) {
                    return function(t, n) {
                        if (0 === t) {
                            var r, i = !1,
                                o = [],
                                a = function() {
                                    o.forEach((function(e) {
                                        e(2)
                                    }))
                                };
                            e(0, (function(e, t) {
                                if (0 === e) r = t, n(0, c);
                                else if (1 === e) {
                                    var u = t,
                                        s = o.length;
                                    u(0, (function(e, t) {
                                        if (0 !== e)
                                            if (i) n(e, t);
                                            else {
                                                var r = o.splice(s, 1);
                                                i = !0, c(2), o = r, n(e, t)
                                            }
                                        else o.push(t)
                                    }))
                                } else 2 === e && t ? (r = null, a(), n(2, t)) : 2 === e && (r = null, o.length || n(2))
                            }))
                        }

                        function c(e) {
                            2 === e && (a(), r && r(2))
                        }
                    }
                }(i()(u)(e))
            })(P((function() {
                return Object(g.a)(r)(Object(Z.a)(50)(s()((function(e) {
                    return e.type === w
                }))(L())))
            }))(b()(1)(Object(m.a)(s()((function() {
                return "complete" === document.readyState
            }))(z()(Object(f.a)(a.V), Object(k.a)(document, "readystatechange")))))));
            return {
                promise: Object(o.a)(i()((function(t) {
                    var n = t.instance,
                        r = t.owner,
                        i = t.origin,
                        o = G(e)[0],
                        a = window.parent,
                        u = Object(c.a)(),
                        d = function(e) {
                            a.postMessage(e, i)
                        },
                        f = s()((function(e) {
                            return e.owner === r
                        }))(L()),
                        p = B(u, f, (function(e, t) {
                            return F(r, n, e, t)
                        }), d, t.data),
                        m = H(p, u.emit, d, o);
                    return l()(m)(f), p
                }))(d))
            }
        }
        var X = n(8),
            Q = n(14),
            $ = function(e, t) {
                var n = document.createElement("iframe");
                return e.appendChild(n), n.src = t, n
            };

        function ee(e, t) {
            var n, r = e.container,
                a = e.url,
                c = Object(X.a)(e, ["container", "url"]),
                u = $(r, a),
                s = function() {
                    Object(Q.k)(u), n && n.destroy()
                };
            return {
                destroy: s,
                frame: u,
                promise: Object(o.a)(b()(1)(i()((function(e) {
                    var t = n.api;
                    return t.data = e, t.destroy = s, t.frame = u, t
                }))(P((function() {
                    return (n = K(Object(C.a)({}, c, {
                        frame: u
                    }), t)).handshake$
                }))(Object(k.a)(u, "load")))))
            }
        }
        var te = n(72),
            ne = n.n(te);

        function re(e, t) {
            var n, r = e.onConnected,
                a = Object(X.a)(e, ["onConnected"]),
                c = !a.frame,
                u = function(e) {
                    if (e.frame) return e.frame;
                    var t = e.container,
                        n = e.url;
                    return $(t, n)
                }(a),
                s = V(),
                d = s[0],
                f = s[1],
                m = function() {
                    c && Object(Q.k)(u), n ? n.destroy() : f()
                };
            return l()((function(e) {
                e.destroy = m, e.frame = u, r(e)
            }))(Object(h.a)(d)(Object(p.a)()(P((function() {
                return ne()((function(e, r) {
                    var c = function(e, t) {
                        var n = K(e, t),
                            r = n.api,
                            a = n.destroy,
                            c = n.handshake$;
                        return {
                            destroy: a,
                            promise: Object(o.a)(i()((function(e) {
                                return r.data = e, r.destroy = a, r
                            }))(c))
                        }
                    }(Object(C.a)({}, a, {
                        frame: u
                    }), t);
                    return c.promise.then(e, r), n = c, c.destroy
                }))
            }))(Object(k.a)(u, "load"))))), {
                destroy: m,
                frame: u
            }
        }
    }, , , , function(e, t, n) {
        var r = n(132),
            i = n(236);
        e.exports = n(134) ? function(e, t, n) {
            return r.f(e, t, i(1, n))
        } : function(e, t, n) {
            return e[t] = n, e
        }
    }, function(e, t) {
        e.exports = function(e) {
            try {
                return !!e()
            } catch (t) {
                return !0
            }
        }
    }, function(e, t, n) {
        "use strict";
        n.d(t, "b", (function() {
            return c
        })), n.d(t, "c", (function() {
            return u
        })), n.d(t, "a", (function() {
            return s
        }));
        var r = n(17),
            i = n(35),
            o = !1,
            a = "function" === typeof document.hasFocus ? function() {
                return document.hasFocus()
            } : function() {
                return !1
            },
            c = function() {
                return !(!a() && !o) && (o = !1, !0)
            },
            u = function() {
                return c() && !Object(i.g)()
            },
            s = function(e, t) {
                e.on("host_focus_shifted", (function() {
                    o = !1
                })), t.on("set_host_modality", (function(e) {
                    o = !0, Object(r.d)(e)
                }))
            }
    }, , , , , function(e, t, n) {
        "use strict";
        n.d(t, "b", (function() {
            return h
        })), n.d(t, "a", (function() {
            return p.d
        }));
        var r = n(1),
            i = n(8),
            o = n(4),
            a = n(0),
            c = n(120),
            u = n.n(c),
            s = n(110),
            d = n(25),
            l = n(2),
            f = n(17);
        var p = n(41),
            m = n(45);
        var v = {
                name: "1y4r7fy",
                styles: "padding-top:0.5em"
            },
            b = {
                name: "1p6jvwd",
                styles: "padding-bottom:0.5em"
            },
            h = function(e) {
                var t = e.card,
                    n = e.onButtonClick,
                    c = void 0 === n ? l.V : n,
                    h = e.onShowMoreButtonClick,
                    g = e.horizontalLayout,
                    y = void 0 !== g && g,
                    O = e.TitleComponent,
                    j = void 0 === O ? p.l : O,
                    _ = Object(i.a)(e, ["card", "onButtonClick", "onShowMoreButtonClick", "horizontalLayout", "TitleComponent"]),
                    w = Object(f.f)(),
                    x = a.useRef(null),
                    E = function(e) {
                        return e.buttons ? Object(r.a)({}, e, {
                            buttons: e.buttons.map((function(e) {
                                switch (e.type) {
                                    case "phone":
                                        e.type;
                                        var t = e.value,
                                            n = e.role,
                                            o = Object(i.a)(e, ["type", "value", "role"]);
                                        return Object(r.a)({}, o, {
                                            href: "tel:" + t,
                                            target: "_parent",
                                            variant: n
                                        });
                                    case "url":
                                        e.type;
                                        var a = e.value,
                                            c = e.role,
                                            u = Object(i.a)(e, ["type", "value", "role"]);
                                        return "invitation" in e ? Object(r.a)({}, u, {
                                            variant: c
                                        }) : Object(r.a)({}, u, {
                                            href: a,
                                            target: "_blank",
                                            variant: c
                                        });
                                    default:
                                        if ("value" in e) {
                                            e.type, e.value;
                                            var s = e.role,
                                                d = Object(i.a)(e, ["type", "value", "role"]);
                                            return Object(r.a)({}, d, {
                                                variant: s
                                            })
                                        }
                                        e.type;
                                        var l = e.role,
                                            f = Object(i.a)(e, ["type", "role"]);
                                        return Object(r.a)({}, f, {
                                            variant: l
                                        })
                                }
                            }))
                        }) : e
                    }(t),
                    C = E.title,
                    I = E.subtitle,
                    S = E.image,
                    T = E.buttons,
                    k = void 0 === T ? [] : T,
                    A = C || I,
                    z = !!h,
                    M = z && k.length > 3,
                    L = k.length > 1,
                    P = L ? p.c : p.i,
                    R = L ? p.b : p.h;
                return Object(o.d)(p.d, Object(r.a)({
                    ref: x,
                    horizontalLayout: y
                }, _), S && Object(o.d)(p.f, Object(r.a)({}, S, {
                    horizontalLayout: y
                })), Object(o.d)(p.e, {
                    narrow: S && y
                }, A && Object(o.d)(u.a, {
                    component: s.a
                }, Object(o.d)(p.k, Object(r.a)({
                    css: [!Object(l.F)(k) && b, ""]
                }, w), C && Object(o.d)(j, {
                    textWrap: !0,
                    preserveLines: !0
                }, Object(o.d)(m.a, null, C)), I && Object(o.d)(p.j, {
                    textWrap: !0,
                    preserveLines: !0
                }, Object(o.d)(m.a, null, I)))), !Object(l.F)(k) && Object(o.d)(P, {
                    css: A && v,
                    compact: !!h
                }, (M ? k.slice(0, 3) : k).map((function(e, t) {
                    var n = e.text,
                        a = Object(i.a)(e, ["text"]),
                        u = n.length > 20 ? n.slice(0, 20).trim() + "\u2026" : n;
                    return Object(o.d)(R, {
                        key: t,
                        compact: z
                    }, Object(o.d)(p.a, Object(r.a)({
                        label: Object(o.d)(m.a, null, u),
                        onPress: function() {
                            c(t)
                        }
                    }, a)))
                }))), M && Object(o.d)(d.a, null, (function(e) {
                    return Object(o.d)(p.g, {
                        label: e("show_more"),
                        onPress: h
                    })
                }))))
            }
    }, function(e, t, n) {
        "use strict";
        n.d(t, "a", (function() {
            return c
        })), n.d(t, "c", (function() {
            return s
        })), n.d(t, "d", (function() {
            return f
        })), n.d(t, "b", (function() {
            return p
        })), n.d(t, "e", (function() {
            return m
        }));
        var r = n(1),
            i = n(8),
            o = n(13),
            a = n(106),
            c = function(e) {
                var t = e.id,
                    n = e.authorId,
                    r = e.timestamp,
                    i = e.serverId,
                    o = void 0 === i ? t : i,
                    a = e.threadId,
                    c = void 0 === a ? null : a,
                    u = e.seen;
                return {
                    id: t,
                    serverId: o,
                    thread: c,
                    author: n,
                    timestamp: r,
                    seen: void 0 !== u && u
                }
            },
            u = function(e) {
                e.id, e.customId, e.authorId, e.timestamp, e.threadId, e.properties, e.seen, e.serverId, e.type, e.text, e.urlDetails;
                return Object(i.a)(e, ["id", "customId", "authorId", "timestamp", "threadId", "properties", "seen", "serverId", "type", "text", "urlDetails"])
            },
            s = function(e) {
                if (e.urlDetails) {
                    var t = e.urlDetails;
                    return Object(r.a)({}, c(e), {
                        type: "url_preview",
                        properties: {
                            serverType: e.type,
                            title: t.title,
                            description: t.description,
                            image: {
                                url: t.imageUrl,
                                link: t.url
                            }
                        }
                    })
                }
                return Object(a.a)(e.text) ? Object(r.a)({}, c(e), {
                    type: "emoji",
                    properties: Object(r.a)({
                        serverType: e.type,
                        text: e.text
                    }, u(e))
                }) : Object(r.a)({}, c(e), {
                    type: "message",
                    properties: Object(r.a)({
                        serverType: e.type,
                        text: e.text
                    }, u(e))
                })
            },
            d = function(e) {
                switch (e.type) {
                    case "url":
                        return Object(o.k)(e.value) ? null : e;
                    case "webview":
                        if (Object(o.k)(e.value)) return null;
                        var t = Object(o.e)(e.value);
                        if (!t) return e;
                        if (/chatbot\.com$/.test(t)) {
                            var n = Object(o.b)(Object(o.m)(Object(o.j)(e.value)));
                            if (n.p) try {
                                var i = JSON.parse(atob(n.p));
                                if (i.url) return Object(r.a)({}, e, {
                                    proxiedValue: i.url
                                })
                            } catch (a) {
                                return e
                            }
                        }
                        return e;
                    default:
                        return e
                }
            },
            l = function(e) {
                var t = {};
                return "string" === typeof e.title && (t.title = e.title), "string" === typeof e.subtitle && (t.subtitle = e.subtitle), e.image && (t.image = Object(r.a)({}, e.image, {
                    link: e.image.url
                })), e.buttons && (t.buttons = e.buttons.map(d).filter(Boolean)), t
            },
            f = function(e) {
                switch (e.template) {
                    case "quick_replies":
                        var t = e.elements[0];
                        return Object(r.a)({}, c(e), {
                            type: "message",
                            properties: {
                                serverType: e.type,
                                text: t.title,
                                quickReplies: t.buttons.map((function(e) {
                                    return {
                                        type: e.type,
                                        text: e.text,
                                        value: e.value,
                                        postbackId: e.postbackId
                                    }
                                }))
                            }
                        });
                    case "sticker":
                        var n = e.elements[0].image;
                        return Object(r.a)({}, c(e), {
                            type: "sticker",
                            properties: {
                                serverType: e.type,
                                url: n.url,
                                name: n.name
                            }
                        });
                    default:
                        if (e.elements.length > 1) return Object(r.a)({}, c(e), {
                            type: "carousel",
                            properties: {
                                serverType: e.type,
                                cards: e.elements.map(l)
                            }
                        });
                        var i = e.elements[0];
                        if (1 === Object.keys(i).length && i.image) {
                            var o = i.image;
                            return Object(r.a)({}, c(e), {
                                type: "image_preview",
                                properties: Object(r.a)({
                                    name: o.name,
                                    serverType: e.type,
                                    url: o.url
                                }, o.alternativeText && {
                                    alternativeText: o.alternativeText
                                })
                            })
                        }
                        return Object(r.a)({}, c(e), {
                            type: "rich_message",
                            properties: {
                                serverType: e.type,
                                card: l(i)
                            }
                        })
                }
            },
            p = function(e) {
                if (e.thumbnails) {
                    var t = e.thumbnails,
                        n = Object(r.a)({}, c(e), {
                            type: "image_preview",
                            properties: Object(r.a)({
                                name: e.name,
                                serverType: e.type
                            }, t.default, {
                                link: e.url,
                                srcSet: t.default.url + " 1x, " + t.high.url + " 2x"
                            })
                        });
                    return e.alternativeText && (n.properties.alternativeText = e.alternativeText), n
                }
                return Object(r.a)({}, c(e), {
                    type: "message",
                    properties: Object(r.a)({
                        serverType: e.type,
                        text: e.name,
                        url: e.url
                    }, e.alternativeText && {
                        alternativeText: e.alternativeText
                    })
                })
            },
            m = function(e) {
                var t = Object(r.a)({}, c(e), {
                    type: "system_message",
                    properties: {
                        serverType: e.type,
                        systemMessageType: e.systemMessageType,
                        defaultText: e.text
                    }
                });
                return e.textVars && (t.properties.textVariables = e.textVars), t
            }
    }, , , , function(e, t, n) {
        "use strict";
        var r = n(2);
        t.a = function(e) {
            return new Promise((function(t) {
                var n = performance.getEntriesByName(e);
                if (Object(r.F)(n))
                    if ("undefined" !== typeof PerformanceObserver) {
                        var i = setTimeout((function() {
                                o.disconnect(), t(null)
                            }), 6e4),
                            o = new PerformanceObserver((function(n) {
                                var a = Object(r.o)((function(t) {
                                    return t.name === e
                                }), n.getEntries());
                                a && (o.disconnect(), clearTimeout(i), t(a))
                            }));
                        o.observe({
                            entryTypes: ["paint"]
                        })
                    } else t(null);
                else t(n[0])
            }))
        }
    }, function(e, t, n) {
        "use strict";
        n.d(t, "c", (function() {
            return ye
        })), n.d(t, "a", (function() {
            return Oe
        }));
        var r = n(1),
            i = n(8),
            o = n(0),
            a = n(54),
            c = n(75),
            u = n(25),
            s = n(2),
            d = n(28),
            l = n(4),
            f = n(68),
            p = n(157),
            m = n(56),
            v = n(7),
            b = n(249),
            h = n(139),
            g = n(21),
            y = n(726),
            O = n(725),
            j = n(164),
            _ = n(3),
            w = n(9),
            x = (n(109), n(17)),
            E = n(20),
            C = n(221),
            I = n(53),
            S = function(e) {
                return Object(l.c)("display:flex;width:", e ? "24px" : "32px", ";height:", e ? "24px" : "32px", ";align-items:center;justify-content:center;")
            },
            T = Object(v.z)("div", {
                target: "e1dmt1bi1"
            })("position:relative;transition:transform 200ms ", (function(e) {
                return e.theme.transitions.easings.spring
            }), " 50ms;", (function(e) {
                var t = e.compact;
                return S(t)
            }), " ", (function(e) {
                return {
                    transform: "scale(" + (e.isScaled ? 1.25 : 1) + ")"
                }
            }), ";"),
            k = Object(v.z)("div", {
                target: "e1dmt1bi0"
            })("position:absolute;z-index:1;left:0;right:0;bottom:1px;transition:opacity 150ms ", (function(e) {
                return e.theme.transitions.easings.smooth
            }), " 50ms;", (function(e) {
                var t = e.compact;
                return S(t)
            }), " ", (function(e) {
                return {
                    opacity: e.isVisible ? 1 : 0
                }
            }), ";"),
            A = function(e) {
                var t = e.on,
                    n = e.compact,
                    a = void 0 !== n && n,
                    c = Object(i.a)(e, ["on", "compact"]),
                    u = o.useState(t),
                    s = u[0],
                    d = u[1],
                    l = Object(f.g)();
                return o.useEffect((function() {
                    if (!t) {
                        var e = setTimeout((function() {
                            return d(!1)
                        }), 200);
                        return function() {
                            return clearTimeout(e)
                        }
                    }
                    d(!0)
                }), [t]), o.createElement(T, Object(r.a)({
                    isScaled: t,
                    compact: a
                }, c), o.createElement(I.c, {
                    filled: t,
                    size: a ? 24 : 32,
                    color: l.colors.minimizedIcon,
                    backgroundColor: l.colors.minimizedBackground
                }), o.createElement(k, {
                    isVisible: t,
                    compact: a
                }, s && o.createElement(C.a, {
                    width: a ? "14px" : "18px",
                    animationDuration: 1,
                    animationIterationCount: 1,
                    color: l.colors.minimizedBackground
                })))
            },
            z = Object(v.z)("div", {
                target: "e3vrje60"
            })("width:5px;height:5px;border-radius:", (function(e) {
                return e.theme.borderRadius.round
            }), ";background-color:", (function(e) {
                return e.theme.colors.surface.light
            }), ";"),
            M = function(e, t) {
                return Object(l.c)("z-index:1;position:absolute;border:3px solid white;right:", e || t ? -7 : -3, "px;top:", e || t ? -7 : -3, "px;")
            },
            L = function(e) {
                var t = e.mobile,
                    n = void 0 !== t && t,
                    r = e.unseenEventsCount,
                    i = void 0 === r ? 0 : r,
                    o = e.bar;
                return Object(l.d)(I.A, {
                    css: M(n, o),
                    minScale: i > 1 ? 1 : 0,
                    maxScale: i > 1 ? 1.75 : 1.3,
                    "aria-label": "new message indicator",
                    tabIndex: 0,
                    role: "img"
                }, Object(l.d)(z, null))
            },
            P = n(224),
            R = n(45),
            D = Object(v.z)("div", {
                displayName: "MinimizedBar",
                section: !0,
                target: "e16i86ec1"
            })("position:relative;width:255px;height:50px;box-shadow:", (function(e) {
                return e.theme.boxShadow.floating
            }), ";background:", (function(e) {
                return e.theme.colors.surface.light
            }), ";border-radius:", (function(e) {
                var t = e.theme;
                return [t.borderRadius.lg, t.borderRadius.lg, t.borderRadius.none, t.borderRadius.none].join(" ")
            }), ";display:flex;padding:0 0.9em;align-items:center;&:hover{cursor:pointer;}"),
            B = Object(v.z)(P.a, {
                target: "e16i86ec0"
            })("flex-grow:1;font-weight:700;font-size:0.9em;margin-right:", (function(e) {
                return e.theme.spaces.space2
            }), ";"),
            q = function(e) {
                var t = e.text,
                    n = e.hasUnseenEvents,
                    r = e.unseenEventsCount,
                    i = e.onClick,
                    a = Object(x.i)({}),
                    c = a.isHovered,
                    u = a.hoverProps,
                    s = Object(x.f)();
                return o.createElement(D, Object(E.h)({
                    onClick: i
                }, u, s), n ? o.createElement(L, {
                    bar: !0,
                    key: r,
                    unseenEventsCount: r
                }) : null, o.createElement(B, {
                    ellipsis: !0
                }, o.createElement(R.a, null, t)), o.createElement(I.j, {
                    onPress: i,
                    "aria-label": "Open LiveChat chat widget"
                }, o.createElement(A, {
                    compact: !0,
                    on: c
                })))
            };
        var N = Object(v.z)("div", {
                displayName: "MinimizedBubble",
                section: !0,
                target: "e1ybl9g10"
            })("display:flex;width:", (function(e) {
                return e.mobile ? "40px" : "60px"
            }), ";height:", (function(e) {
                return e.mobile ? "40px" : "60px"
            }), ";box-shadow:", (function(e) {
                return e.theme.boxShadow.floating
            }), ";border-radius:", (function(e) {
                return e.theme.borderRadius.round
            }), ";background:", (function(e) {
                return e.theme.colors.surface.lightVariant
            }), ";justify-content:center;", (function(e) {
                var t = e.mobile,
                    n = e.screenPosition;
                return t ? Object(l.c)("margin-bottom:24px;margin-", "left" === n ? "right" : "left", ":8px;") : Object(l.c)("margin-", "left" === n ? "right" : "left", ":auto;")
            }), " &:hover{cursor:pointer;}"),
            V = {
                name: "1btxy8w",
                styles: "padding:0;width:100%;display:flex;justify-content:center;align-items:center"
            },
            F = function(e) {
                var t = e.mobile,
                    n = e.avatar,
                    i = e.hasUnseenEvents,
                    o = e.unseenEventsCount,
                    a = e.screenPosition,
                    c = e.onClick,
                    u = Object(x.i)({}),
                    s = u.isHovered,
                    d = u.hoverProps;
                return Object(l.d)(N, Object(r.a)({
                    mobile: t,
                    hasAvatar: Boolean(n),
                    screenPosition: a
                }, Object(E.h)({
                    onClick: c
                }, d)), i ? Object(l.d)(L, {
                    mobile: t,
                    key: o,
                    unseenEventsCount: o
                }) : null, Object(l.d)(I.j, {
                    onPress: c,
                    css: V,
                    "aria-label": "Open LiveChat chat widget"
                }, n ? Object(l.d)(v.b, {
                    "aria-hidden": !0,
                    imgUrl: n,
                    size: t ? "40px" : "60px"
                }) : Object(l.d)(A, {
                    "aria-hidden": !0,
                    compact: t,
                    on: s
                })))
            },
            U = n(83);

        function H(e, t) {
            var n = (void 0 === t ? {} : t).retriesCount,
                r = void 0 === n ? 1 / 0 : n,
                i = Object(U.a)({
                    min: 100,
                    max: 1e4
                });
            return new Promise((function(t, n) {
                var o = 0;
                ! function a() {
                    return e().then(t, (function() {
                        r === 1 / 0 || o++ < r ? setTimeout(a, i.duration()) : n(new Error("Maximum retries count (" + r + ") reached"))
                    }))
                }()
            }))
        }
        var G = o.lazy((function() {
                return H((function() {
                    return n.e(9).then(n.bind(null, 751))
                }))
            })),
            W = function(e) {
                var t = e.minimizedType,
                    n = e.position;
                return "bar" === t ? "0.8em 0.8em 0 0.8em" : "left" === n ? "0.5em 1em 1em 0.5em" : "0.5em 0.5em 1em 1em"
            },
            Y = Object(v.z)("div", {
                displayName: "Minimized",
                section: !0,
                target: "eqd5v0k0"
            })("max-width:100%;position:absolute;bottom:0;z-index:2;display:flex;align-items:flex-end;will-change:width,height,transform,opacity;backface-visibility:hidden;", (function(e) {
                var t;
                return (t = {
                    padding: W(e)
                })[e.position] = 0, t.justifyContent = "right" === e.position && "flex-end", t
            }), ";"),
            K = Object(u.c)((function(e) {
                var t, n = e.getApplicationState(),
                    r = n.availability,
                    i = n.eagerFetchingMode,
                    o = n.hasUnseenEvents,
                    a = n.mobile,
                    c = "online" === r,
                    u = e.getChat(_.d).active,
                    d = w.d(e),
                    l = !d || w.O(e, d) ? null : d.id,
                    f = w.g("agentAvatar", e).enabled && (c || u) ? w.c(_.d, e) : null,
                    p = e.getLastEvent(_.d),
                    m = p && (null == (t = p.properties) ? void 0 : t.invitation) && !p.seen;
                return {
                    mobile: a,
                    visibleGreetingId: l,
                    avatar: Object(s.y)(!1, "avatar", f),
                    minimizedType: w.l(e),
                    screenPosition: w.q(e),
                    minimizedText: w.k(_.d, e),
                    hasUnseenEvents: i ? e.getUnseenCount(_.d) > 0 : m || o,
                    unseenEventsCount: i ? e.getUnseenCount(_.d) : m || o ? 1 : 0,
                    newMessageAlert: e.localize("new_message")
                }
            }))((function(e) {
                var t, r, i = e.dir,
                    a = e.mobile,
                    c = e.avatar,
                    u = e.onMaximize,
                    d = e.minimizedText,
                    l = e.minimizedType,
                    f = e.newMessageAlert,
                    p = e.screenPosition,
                    m = e.hasUnseenEvents,
                    b = e.unseenEventsCount,
                    g = e.visibleGreetingId,
                    y = e.innerRef,
                    O = void 0 === y ? s.V : y,
                    j = e.onResize,
                    _ = void 0 === j ? s.V : j,
                    w = null,
                    x = null;
                if (g && (w = o.createElement(o.Suspense, {
                        fallback: null
                    }, o.createElement(G, {
                        key: g,
                        id: g,
                        onPress: u,
                        onResize: _
                    }))), "circle" === l) {
                    var E = g && a;
                    x = o.createElement(F, {
                        avatar: c,
                        onClick: u,
                        hasUnseenEvents: m,
                        unseenEventsCount: b,
                        mobile: E,
                        screenPosition: p
                    })
                }
                return "bar" === l && (x = o.createElement(q, {
                    text: d,
                    hasUnseenEvents: m,
                    unseenEventsCount: b,
                    onClick: u
                })), o.createElement(Y, {
                    dir: i,
                    role: "main",
                    ref: O,
                    minimizedType: l,
                    position: p,
                    onMouseOver: function() {
                        return Promise.all([n.e(4), n.e(2)]).then(n.bind(null, 750)).catch(s.V)
                    }
                }, o.createElement(o.Fragment, null, m && o.createElement(h.b, {
                    key: b,
                    message: f,
                    "aria-live": "polite",
                    clearOnUnmount: !0
                }), a && "circle" === l ? (t = "left" === p, r = [o.createElement(v.f, {
                    key: "greeting-column"
                }, o.createElement(v.q, null, w)), o.createElement(v.f, {
                    key: "bubble-column",
                    noShrink: !0
                }, o.createElement(v.q, null, x))], t ? r.reverse() : r) : o.createElement(v.f, null, o.createElement(v.q, null, w), o.createElement(v.q, null, x))))
            })),
            Z = n(96),
            J = n(19),
            X = n(148);
        var Q = o.lazy((function() {
                return H((function() {
                    return Promise.all([n.e(4), n.e(2)]).then(n.bind(null, 750))
                }))
            })),
            $ = Object(v.z)("div", {
                displayName: "ApplicationWrapper",
                target: "edvz03i1"
            })({
                name: "jcdn5o",
                styles: "position:absolute;top:0;left:auto;right:0;bottom:0;width:100%;height:100%;will-change:tranform,opacity;backface-visibility:hidden"
            }),
            ee = Object(v.z)("div", {
                displayName: "Maximized",
                target: "edvz03i0"
            })("position:relative;display:flex;flex-direction:column;min-width:0;height:100%;box-shadow:", (function(e) {
                return e.theme.boxShadow.floating
            }), ";overflow:hidden;background:", (function(e) {
                return e.theme.colors.surface.light
            }), ";", (function(e) {
                var t = e.expandToEdge,
                    n = e.theme;
                return {
                    borderRadius: t ? n.borderRadius.none + " !important" : n.borderRadius.lg
                }
            }), ";"),
            te = {
                name: "dhssmq",
                styles: "flex-grow:1;display:flex;align-items:center;justify-content:center"
            },
            ne = function() {
                var e = Object(f.g)(),
                    t = o.useState(!1),
                    n = t[0],
                    r = t[1];
                return Object(d.w)((function() {
                    return r(!0)
                }), 500), Object(l.d)("div", {
                    css: te
                }, n && Object(l.d)(I.c, {
                    size: 64,
                    css: v.y,
                    color: e.colors.border,
                    backgroundColor: e.colors.surface.lightVariant
                }))
            },
            re = o.forwardRef((function(e, t) {
                var n = e.dir,
                    r = e.showMinimizedButton,
                    i = e.isMainViewVisible,
                    a = e.expandToEdge,
                    c = e.onMinimizeButtonPress;
                return Object(l.d)($, {
                    dir: n,
                    expandToEdge: a,
                    ref: t
                }, Object(l.d)(ee, {
                    expandToEdge: a,
                    role: "main"
                }, i ? Object(l.d)(o.Suspense, {
                    fallback: Object(l.d)(ne, null)
                }, Object(l.d)(Q, {
                    showMinimizedButton: r,
                    onMinimizeButtonPress: c
                })) : Object(l.d)(ne, null)))
            }));

        function ie() {
            var e = Object(g.a)(["\n\t&-enter {\n\t\ttransform: translate3d(", "40%, 40%, 0) scale(0.1);\n\n\t\t[role='main'] > * {\n\t\t\topacity: 0;\n\t\t\ttransform: translate3d(0, 20%, 0);\n\t\t}\n\t}\n\n\t&-enter&-enter-active {\n\t\ttransform: translate3d(0%, 0%, 0) scale(1);\n\t\ttransition: transform ", "ms ", ";\n\n\t\t[role='main'] > * {\n\t\t\topacity: 1;\n\t\t\ttransform: translate3d(0, 0%, 0);\n\t\t\ttransition: opacity 160ms ", " 270ms,\n\t\t\t\ttransform 160ms ", " 270ms;\n\t\t}\n\t}\n\n\t&-exit {\n\t\ttransform: translate3d(0%, 0%, 0) scale(1);\n\t\topacity: 1;\n\t\t[role='main'] > * {\n\t\t\topacity: 1;\n\t\t\ttransform: translate3d(0, 0%, 0);\n\t\t}\n\t}\n\n\t&-exit&-exit-active {\n\t\topacity: 0;\n\t\ttransform: translate3d(", "40%, 40%, 0) scale(0.1);\n\t\ttransition: transform ", "ms ", ", opacity 300ms ease;\n\t\t[role='main'] > * {\n\t\t\topacity: 0;\n\t\t\ttransform: translate3d(0, 10%, 0);\n\t\t\ttransition: opacity 160ms ", ", transform 160ms ", ";\n\t\t}\n\t}\n"]);
            return ie = function() {
                return e
            }, e
        }

        function oe() {
            var e = Object(g.a)(["\n\t&-enter {\n\t\topacity: 0;\n\t\ttransform: translate3d(0, 100%, 0);\n\t}\n\n\t&-enter&-enter-active {\n\t\topacity: 1;\n\t\ttransform: translate3d(0, 0%, 0);\n\t\ttransition: opacity 140ms ease 200ms, transform 140ms ease 200ms;\n\t}\n\n\t&-exit {\n\t\topacity: 1;\n\t\ttransform: translate3d(0, 0%, 0);\n\t}\n\n\t&-exit&-exit-active {\n\t\topacity: 0;\n\t\ttransform: translate3d(0, 100%, 0);\n\t\ttransition: opacity 140ms ease, transform 140ms ease;\n\t}\n"]);
            return oe = function() {
                return e
            }, e
        }
        var ae = function(e) {
                return e(oe())
            },
            ce = function(e, t, n) {
                return e(ie(), "right" === t ? "" : "-", Z.a, n.transitions.easings.sharp, n.transitions.easings.sharp, n.transitions.easings.sharp, "right" === t ? "" : "-", Z.a, n.transitions.easings.sharp, n.transitions.easings.sharp, n.transitions.easings.sharp)
            };
        var ue = Object(u.c)((function(e) {
                var t = function(t) {
                    t ? Object(J.t)(e) : Object(J.v)(e)
                };
                return function(e) {
                    var n = e.getApplicationState(),
                        r = n.mobile,
                        i = n.embedded,
                        o = n.actingAsDirectLink,
                        a = n.isInCustomContainer,
                        c = n.rtl;
                    return {
                        embedded: i,
                        mobile: r,
                        expandToEdge: r || !i || a,
                        setMaximizedState: t,
                        visibilityState: e.getApplicationState("visibility").state,
                        showMinimized: !o && w.Q(e),
                        screenPosition: w.q(e),
                        dir: c ? "rtl" : "ltr",
                        showMinimizedButton: w.hb(e)
                    }
                }
            }))((function(e) {
                var t = e.embedded,
                    n = e.expandToEdge,
                    r = e.setMaximizedState,
                    i = e.screenPosition,
                    a = e.showMinimizedButton,
                    c = e.showMinimized,
                    u = e.onAnimationEnd,
                    d = void 0 === u ? s.V : u,
                    f = e.onMinimizeButtonPress,
                    p = void 0 === f ? s.V : f,
                    m = e.onMaximizeButtonPress,
                    v = void 0 === m ? s.V : m,
                    b = e.onMinimizedRef,
                    h = void 0 === b ? s.V : b,
                    g = e.onMinimizedResize,
                    _ = e.dir,
                    w = e.visibilityState,
                    x = o.useRef(),
                    E = o.useRef(),
                    C = o.useState("maximized" === w),
                    I = C[0],
                    S = C[1];
                return o.createElement(l.a, null, (function(e) {
                    var u = e.css,
                        l = e.theme;
                    return o.createElement(y.a, {
                        appear: !0,
                        component: null
                    }, "maximized" === w && o.createElement(O.a, {
                        classNames: ce(u, i, l),
                        nodeRef: E,
                        onExited: d,
                        onEntered: function() {
                            return S(!0)
                        },
                        onExit: function() {
                            return S(!1)
                        },
                        timeout: Z.a
                    }, o.createElement(re, {
                        dir: _,
                        ref: E,
                        isMainViewVisible: I,
                        showMinimizedButton: a,
                        expandToEdge: n,
                        onMinimizeButtonPress: function() {
                            t && r(!1), p()
                        }
                    })), Object(s.D)(w, ["minimized", "hidden"]) && c && o.createElement(O.a, {
                        classNames: ae(u),
                        nodeRef: x,
                        onExited: d,
                        timeout: Z.a
                    }, o.createElement(j.a, {
                        autoFocus: Object(X.b)()
                    }, o.createElement(K, {
                        dir: _,
                        onMaximize: function() {
                            r(!0), v()
                        },
                        innerRef: function(e) {
                            x.current = e, h(e)
                        },
                        onResize: g
                    }))))
                }))
            })),
            se = n(38),
            de = function(e) {
                function t() {
                    for (var t, n = arguments.length, r = new Array(n), i = 0; i < n; i++) r[i] = arguments[i];
                    return (t = e.call.apply(e, [this].concat(r)) || this).state = {
                        crashed: !1
                    }, t
                }
                Object(se.a)(t, e);
                var n = t.prototype;
                return n.componentDidCatch = function(e, t) {
                    this.setState({
                        crashed: !0
                    }), this.props.onError(e, t)
                }, n.render = function() {
                    return this.state.crashed ? null : this.props.children
                }, t
            }(o.Component);
        de.defaultProps = {
            onError: s.V
        };
        var le = n(199),
            fe = n(117),
            pe = n(23),
            me = n(16),
            ve = Object(r.a)({}, me.a, {
                borderRadius: Object(r.a)({}, me.a.borderRadius, {
                    def: me.a.borderRadius.sm
                }),
                TitleBar: {
                    css: {
                        fontWeight: "700!important",
                        fontSize: "1.1em",
                        textAlign: "center!important",
                        height: "42px",
                        justifyContent: "flex-start"
                    },
                    TitleBarTitle: {
                        css: {
                            fontSize: Object(pe.d)(14)
                        }
                    },
                    Avatar: {
                        css: {
                            border: "0"
                        }
                    }
                },
                IconButton: {
                    css: {
                        padding: "0 .5em"
                    }
                },
                MessageList: {
                    css: {
                        backgroundColor: me.a.colors.surface.light
                    }
                },
                Maximized: {
                    css: {
                        borderRadius: [me.a.borderRadius.sm, me.a.borderRadius.sm, me.a.borderRadius.none, me.a.borderRadius.none].join(" ")
                    }
                },
                Footer: {
                    css: {
                        position: "relative",
                        right: 0,
                        bottom: 0,
                        fontSize: "0.6em",
                        backgroundColor: me.a.colors.surface.lightVariant,
                        textAlign: "center",
                        padding: "1em"
                    },
                    FooterLink: {
                        css: {
                            textDecoration: "none",
                            fontWeight: "bold"
                        }
                    }
                },
                ApplicationWrapper: {
                    css: {
                        padding: {
                            default: "1em 1em 0 1em",
                            expandToEdge: "0"
                        }
                    }
                },
                AgentBar: {
                    css: {
                        padding: "0.6em"
                    },
                    Avatar: {
                        size: "60px",
                        css: {
                            borderRadius: me.a.borderRadius.none
                        }
                    },
                    SubTitle: {
                        css: {
                            fontSize: ".8em"
                        }
                    },
                    Title: {
                        css: {
                            fontSize: "1em",
                            fontWeight: "bold"
                        }
                    },
                    IconButton: {
                        css: {
                            fontSize: Object(pe.d)(24),
                            backgroundColor: "transparent !important",
                            color: {
                                default: "inherit"
                            },
                            opacity: {
                                default: "0.3",
                                disabled: "0.15",
                                active: "0.6"
                            }
                        }
                    }
                },
                Button: {
                    css: {
                        boxShadow: "none"
                    }
                },
                Message: {
                    horizontalAlign: "left",
                    own: {
                        horizontalAlign: "left",
                        Content: {
                            css: {
                                alignItems: "flex-start"
                            }
                        }
                    },
                    system: {
                        MessageText: {
                            css: {
                                fontSize: ".9em"
                            }
                        }
                    },
                    css: {
                        flexDirection: "row"
                    },
                    Bubble: {
                        sharpBorderRadius: "0px",
                        ovalBorderRadius: "0px",
                        css: {
                            border: "0",
                            padding: "0",
                            background: "transparent",
                            boxShadow: "none"
                        }
                    },
                    ImagePreview: {
                        css: {
                            maxWidth: "150px",
                            maxHeight: "250px",
                            borderRadius: me.a.borderRadius.none
                        }
                    },
                    Button: {
                        css: {
                            borderTop: "0!important"
                        }
                    }
                },
                MessageText: {
                    css: {
                        padding: "0",
                        fontSize: "14px"
                    }
                },
                MessageGroup: {
                    css: {
                        marginBottom: ".5em"
                    }
                },
                MinimizedBar: {
                    css: {
                        borderRadius: [me.a.borderRadius.sm, me.a.borderRadius.sm, me.a.borderRadius.none, me.a.borderRadius.none].join(" "),
                        height: "40px"
                    },
                    Icon: {
                        css: {
                            transform: "scale(0.8)"
                        }
                    }
                },
                MinimizedBubble: {
                    css: {
                        position: "relative"
                    }
                },
                View: {
                    Bubble: {
                        css: {
                            border: "0",
                            padding: "0",
                            background: "transparent",
                            boxShadow: "none"
                        }
                    },
                    ViewContent: {
                        css: {
                            paddingTop: ".5em"
                        }
                    },
                    css: {
                        paddingBottom: "0"
                    }
                },
                TextInput: {
                    css: {
                        lineHeight: "1.1em"
                    }
                },
                Form: {
                    css: {
                        fontSize: "0.9em"
                    },
                    IconButton: {
                        css: {
                            color: {
                                default: me.a.colors.text.muted,
                                active: me.a.colors.text.white
                            }
                        }
                    }
                },
                Tooltip: {
                    css: {
                        padding: "0.5em 0.8em",
                        fontSize: ".7em"
                    }
                },
                TooltipArrow: {
                    css: {
                        marginTop: "-1em"
                    }
                },
                Invitation: {
                    Bubble: {
                        sharpBorderRadius: "6px",
                        ovalBorderRadius: "6px",
                        css: {
                            padding: ".5em"
                        }
                    }
                },
                InformationField: {
                    css: {
                        fontSize: "1.1em"
                    }
                },
                SystemCard: {
                    css: {
                        maxWidth: "368px",
                        width: "calc(100% - 0.6em)",
                        margin: "0.3em",
                        boxShadow: "none",
                        border: "1px solid " + me.a.colors.divider
                    }
                },
                TextComposer: {
                    IconButton: {
                        css: {
                            opacity: {
                                active: 1,
                                default: .4
                            }
                        }
                    }
                },
                NewMessageHorizontalDivider: {
                    css: {
                        margin: "8px -0.5em"
                    }
                },
                BoosterContainer: {
                    css: {
                        border: "1px solid " + me.a.colors.divider,
                        maxWidth: "368px",
                        width: "calc(100% - 0.6em)",
                        margin: "0.3em",
                        boxShadow: "none",
                        borderRadius: me.a.borderRadius.md
                    }
                },
                BoosterButton: {
                    css: {
                        boxShadow: "none"
                    }
                }
            });

        function be(e) {
            var t, n = e.children,
                r = Object(d.d)((function() {
                    return "widget-global-" + Object(s.v)()
                })),
                i = Object(c.useFrame)().document;
            return t = function() {
                var e = "https://fonts.googleapis.com/css?family=Noto+Sans:400,700&subset=latin-ext&display=swap",
                    t = i.querySelector("head"),
                    n = t.querySelectorAll("link");
                if (!Object(s.o)((function(t) {
                        return t.href === e
                    }), n)) {
                    var r = i.createElement("link");
                    r.setAttribute("href", e), r.setAttribute("rel", "stylesheet"), t.appendChild(r)
                }
            }, Object(d.d)(t), o.createElement(o.Fragment, null, o.createElement(l.b, {
                styles: Object(l.c)("#", r, " *{font-family:'Noto Sans',sans-serif;box-sizing:border-box;-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale;-webkit-tap-highlight-color:transparent;}body{margin:0;}")
            }), o.createElement("div", {
                id: r
            }, n))
        }
        var he = Object(u.c)((function(e) {
                return {
                    mobile: e.getApplicationState("mobile"),
                    theme: e.getApplicationState("config").theme
                }
            }))((function(e) {
                var t = e.mobile,
                    n = e.theme,
                    r = e.children,
                    i = Object(s.T)("modern" === n.name ? ve : fe.a, n);
                return o.createElement(v.v, {
                    theme: t ? Object(s.T)(i, {
                        typography: {
                            input: {
                                fontSize: "16px"
                            },
                            placeholder: {
                                fontSize: "16px"
                            }
                        }
                    }) : i
                }, r)
            })),
            ge = function() {
                var e = null,
                    t = function(t, n) {
                        return e[n] || t
                    };
                return function(n, r, i, o) {
                    if (!e) {
                        e = {};
                        try {
                            return o(n, r, i, o), (a = n).value = "", a.root = null, a.parent = null, a.type = "", a.props = [], a.children = [], a.length = 0, void(a.return = "")
                        } finally {
                            e = null
                        }
                    }
                    var a;
                    if (n.type === m.a)
                        if (45 === n.props.charCodeAt(0) && 45 === n.props.charCodeAt(1)) {
                            var c = n.props.trim(),
                                u = n.children;
                            e[c] = u, n.return = "", n.value = ""
                        } else n.children.indexOf("var(") > -1 && (n.value = n.value.replace(/var\((.*)\)/g, t))
                }
            },
            ye = function(e, t) {
                void 0 === t && (t = "lc");
                var n = Object(p.a)({
                    key: t,
                    container: e,
                    stylisPlugins: [ge(), m.l]
                });
                return n.compat = !0, n
            },
            Oe = function(e) {
                var t = e.store,
                    n = e.onError,
                    r = e.amplitude,
                    a = Object(i.a)(e, ["store", "onError", "amplitude"]),
                    s = Object(d.d)((function() {
                        return (null == r ? void 0 : r.AmplitudeProvider) || function(e) {
                            return e.children
                        }
                    })),
                    l = Object(c.useFrame)(),
                    p = !t || t.getApplicationState("isPreview"),
                    m = Object(d.d)((function() {
                        return ye(l.document.head)
                    })),
                    v = o.createElement(le.a, {
                        value: p
                    }, o.createElement(s, null, o.createElement(h.a, null, o.createElement(f.a, {
                        value: m
                    }, o.createElement(he, {
                        isPreview: p
                    }, o.createElement(be, null, o.createElement(b.a, null, o.createElement(ue, a))))))));
                return t ? o.createElement(de, {
                    onError: n
                }, o.createElement(u.b, {
                    store: t
                }, v)) : o.createElement(de, {
                    onError: n
                }, v)
            };
        t.b = function(e, t) {
            var n = Object(r.a)({}, t);
            a.render(o.createElement(Oe, n), e)
        }
    }, function(e, t, n) {
        "use strict";
        var r = n(1),
            i = n(25),
            o = n(2),
            a = n(13),
            c = n(3),
            u = n(115),
            s = n(77);

        function d(e, t) {
            var n, i = t.schema,
                a = t.preSave,
                c = Object(o.P)((function(e) {
                    return e.defaultValue
                }), i),
                d = Object.keys(i),
                l = Object(o.g)((function(e) {
                    return Object(r.a)({}, c, e)
                }), (function(e) {
                    return Object(o.P)((function(e) {
                        return e.value
                    }), e)
                }), (function(e) {
                    var t = Date.now();
                    return Object(o.Z)((function(e, n) {
                        return e.expires < t || void 0 === i[n]
                    }), e)
                }), JSON.parse, Object(o.j)("{}"), (function() {
                    return s.a.getItem(e)
                })),
                f = Object(o.g)(JSON.stringify, (function(e) {
                    var t = Date.now() + 18e5;
                    return Object(o.P)((function(e) {
                        return {
                            value: e,
                            expires: t
                        }
                    }), e)
                }));
            return {
                persist: function(t) {
                    return t.subscribe((function() {
                        var r, c = (r = t.getState(), d.reduce((function(e, t) {
                                return e[t] = Object(o.x)(i[t].path, r), e
                            }), {})),
                            p = Object(u.b)(c, n);
                        Object(o.F)(p) || (s.a.setItem(e, f(a(Object(o.T)(l(), p)))), n = c)
                    })), t
                },
                rehydrate: function() {
                    return n = l(), e = n, d.reduce((function(t, n) {
                        return Object(o.jb)(i[n].path, e[n], t)
                    }), {});
                    var e
                }
            }
        }
        var l = n(58),
            f = function(e) {
                var t, n = [],
                    r = Object(l.a)();
                return e.startStateSync = function(i) {
                    t = e.getState(), i.emit("state", t);
                    var o = function() {
                            n.forEach((function(e) {
                                var t = e[0],
                                    n = e[1];
                                i.emit(t, n)
                            })), n.length = 0
                        },
                        a = function(e, t) {
                            1 === n.push([e, t]) && setTimeout(o, 0)
                        };
                    e.subscribe((function() {
                        var n = e.getState();
                        n !== t && (a("state_diff", Object(u.b)(n, t)), t = n)
                    }));
                    var c = /^request_/;
                    e.on("*", (function(e, t) {
                        c.test(e) || a("store_event", [e, t])
                    })), r.resolve(void 0)
                }, e.syncing = function() {
                    return r.promise
                }, e
            },
            p = n(35),
            m = n(24),
            v = {
                application: {
                    rtl: !1,
                    s: !1,
                    region: null,
                    actingAsDirectLink: !1,
                    availability: null,
                    isSendingFileEvents: !1,
                    clientLimitExceeded: !1,
                    clientLimitExceededLifted: !1,
                    limitReached: !1,
                    config: {
                        features: {
                            agentAvatar: {
                                enabled: !0
                            },
                            boosters: {
                                enabled: !1,
                                items: []
                            },
                            chatHistory: {
                                enabled: !1
                            },
                            continuousChat: {
                                enabled: !1
                            },
                            creditCardMasking: {
                                enabled: !1
                            },
                            disableSounds: {
                                enabled: !1
                            },
                            emailTranscript: {
                                enabled: !0
                            },
                            facebookButton: {
                                enabled: !1
                            },
                            fileSharing: {
                                enabled: !0
                            },
                            googlePlusButton: {
                                enabled: !1
                            },
                            hideOnInit: {
                                enabled: !1
                            },
                            hideOnMobile: {
                                enabled: !1
                            },
                            hideTrademark: {
                                enabled: !1
                            },
                            linksPreview: {
                                enabled: !0
                            },
                            logo: {
                                enabled: !0,
                                path: "https://cdn.livechatinc.com/cloud/?uri=http://livechat.s3.amazonaws.com/default/logo/c4bf6633aa89a76af7461279581d8bdb.png"
                            },
                            ticketForm: {
                                enabled: !0,
                                mode: "livechat"
                            },
                            preChatAfterGreeting: {
                                enabled: !0
                            },
                            preChatForm: {
                                enabled: !1
                            },
                            rating: {
                                enabled: !0
                            },
                            twitterButton: {
                                enabled: !1
                            },
                            mobileMinimized: {
                                enabled: !0
                            },
                            minimized: {
                                enabled: !0
                            }
                        },
                        minimizedType: "bar",
                        screenPosition: "right",
                        screenOffset: {
                            x: 0,
                            y: 0
                        },
                        properties: {
                            license: {},
                            group: {}
                        },
                        theme: {}
                    },
                    destroyed: !1,
                    eagerFetchingMode: !1,
                    embedded: !0,
                    requestedGroup: null,
                    mobileWrapper: null,
                    invitation: {
                        current: null,
                        hiddenIds: [],
                        displayedIds: []
                    },
                    isInCustomContainer: !1,
                    hasUnseenEvents: !1,
                    hidden: !1,
                    maximized: !1,
                    pageFocused: !1,
                    applicationFocused: !1,
                    mobile: Object(p.g)(),
                    muted: !1,
                    readyState: m.a.NOT_READY,
                    ready: !1,
                    loadedInitialHistory: !1,
                    integrationName: null,
                    language: null,
                    clientVisitNumber: 0,
                    clientChatNumber: 0,
                    visibility: {
                        state: "minimized"
                    },
                    greetingsMuted: !1,
                    isPreview: !1
                }
            },
            b = {
                boosters: !0,
                carousel: !0,
                emoji: !0,
                form: !0,
                image_preview: !0,
                message: !0,
                rich_message: !0,
                sticker: !0,
                system_message: !0,
                url_preview: !0,
                email_prompt: !0,
                message_draft: !0
            },
            h = {
                boosters: !0,
                carousel: !0,
                form: !0
            },
            g = function(e) {
                return Object(i.e)(e, {
                    shouldAddToTimeline: function(e) {
                        return b[e.type]
                    },
                    shouldCreateNewGroup: function(e) {
                        return h[e.type]
                    }
                })
            },
            y = function(e, t) {
                var n = d((t || {}).persistKey, {
                        schema: {
                            clientLimitExceededLifted: {
                                path: ["application", "clientLimitExceededLifted"],
                                defaultValue: !1
                            },
                            eyeCatcherHidden: {
                                path: ["application", "eyeCatcher", "hidden"],
                                defaultValue: !1
                            },
                            invitationHiddenIds: {
                                path: ["application", "invitation", "hiddenIds"],
                                defaultValue: []
                            },
                            invitationDisplayedIds: {
                                path: ["application", "invitation", "displayedIds"],
                                defaultValue: []
                            },
                            maximized: {
                                path: ["application", "maximized"],
                                defaultValue: !1
                            },
                            visibility: {
                                path: ["application", "visibility"],
                                defaultValue: {
                                    state: "minimized"
                                }
                            },
                            muted: {
                                path: ["application", "muted"],
                                defaultValue: !1
                            },
                            limitReached: {
                                path: ["application", "limitReached"],
                                defaultValue: !1
                            },
                            greetingsMuted: {
                                path: ["application", "greetingsMuted"],
                                defaultValue: !1
                            }
                        },
                        preSave: function(e) {
                            return Object(r.a)({}, e, {
                                visibility: {
                                    state: e.visibility && "hidden" === e.visibility.state ? "minimized" : e.visibility.state
                                }
                            })
                        }
                    }),
                    i = Object(o.T)(v, Object(o.T)(e, n.rehydrate()));
                return Object(o.g)(n.persist, f, g)(i)
            },
            O = function(e) {
                return g(Object(o.T)(v, e, {
                    application: {
                        isPreview: !0
                    }
                }))
            },
            j = [{
                id: "iframekb",
                template: "moment",
                title: "Knowledge Base",
                description: "Save time with Knowledge Base - easy to access know-how right in the LiveChat widget",
                icon: "https://www.knowledgebase.ai/apple-touch-icon.71342b95.png",
                action: {
                    type: "button",
                    label: "Search",
                    url: "https://livechat.kb.help/"
                }
            }];
        t.a = function(e, t, n) {
            var r = !!Object(a.h)("lc_boosters", window.location.search) ? function(e) {
                    return Object(o.T)(e, {
                        application: {
                            config: {
                                features: {
                                    boosters: {
                                        enabled: !0,
                                        items: j
                                    }
                                }
                            }
                        }
                    })
                }(e) : e,
                i = (n ? O : y)(r, t);
            return i.setCurrentView("Chat"), i.addView("Chat/information"), i.addView("loader"), i.addView("Chat/postchat"), i.addView("Chat/prechat"), i.addView("Chat/queue"), i.addView("Chat/timeline"), i.addView("minimized", {
                text: "Chat"
            }), i.addView("Chat/ticketForm"), i.addView("Moment", {
                show: !1,
                data: {}
            }), i.addChat({
                id: c.d,
                active: !1,
                properties: {
                    agentIsTyping: !1,
                    ended: !1,
                    fakeAgentMessageId: null,
                    hasMoreHistory: null,
                    lastThread: null,
                    loadingHistory: !1,
                    queued: !1,
                    rate: null,
                    rateComment: null,
                    starting: !1,
                    startChatAgainPending: !1,
                    eventsSeenUpToMap: {}
                }
            }), i
        }
    }, , , , , function(e, t, n) {
        var r = n(274),
            i = n(270);
        e.exports = function(e) {
            return r(i(e))
        }
    }, function(e, t, n) {
        var r = n(98);
        e.exports = function(e, t) {
            if (!r(e) || e._t !== t) throw TypeError("Incompatible receiver, " + t + " required!");
            return e
        }
    }, , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , function(e, t, n) {
        "use strict";
        n.d(t, "b", (function() {
            return f
        }));
        var r = n(8),
            i = n(1),
            o = n(0),
            a = n(68),
            c = n(7),
            u = n(4),
            s = n(17),
            d = n(198),
            l = n(22);
        var f = function(e) {
                return Object(u.c)("color:", e.colors.grayscale[500], ";background-color:", e.colors.grayscale[100], ";")
            },
            p = function(e, t, n) {
                return e ? t.grayscale[100] : n
            },
            m = Object(c.z)("button", {
                displayType: "Button",
                target: "esv0owm2"
            })("font-size:inherit;font-weight:bold;border:0;font-family:inherit;width:100%;max-width:320px;flex-shrink:0;cursor:pointer;display:flex;justify-content:center;align-items:center;outline-offset:2px;", (function(e) {
                var t = e.capitalize,
                    n = e.textColor,
                    r = e.backgroundColor,
                    o = e.disabled,
                    a = e.dark,
                    c = e.theme,
                    u = c.spaceBase,
                    s = c.typography,
                    d = c.borderRadius,
                    f = c.colors;
                return Object(i.a)({
                    borderRadius: d.def
                }, s.basicContrast, {
                    padding: 1.5 * u + "px",
                    color: n,
                    backgroundColor: "" + (a ? Object(l.a)(.2, r) : p(o, f, r))
                }, o ? {
                    "&:hover": {
                        cursor: "default"
                    }
                } : {}, t ? {
                    textTransform: "capitalize"
                } : {})
            }), " ", (function(e) {
                var t = e.disabled,
                    n = e.theme;
                return t && f(n)
            }), ";"),
            v = Object(c.z)("div", {
                target: "esv0owm1"
            })({
                name: "6dn33z",
                styles: "display:flex;margin-left:0.5em"
            }),
            b = Object(c.z)("div", {
                target: "esv0owm0"
            })("");
        t.a = function(e) {
            var t = e.children,
                n = e.destructive,
                c = e.disabled,
                u = void 0 !== c && c,
                l = e.pending,
                f = void 0 !== l && l,
                p = Object(r.a)(e, ["children", "destructive", "disabled", "pending"]),
                h = Object(a.g)(),
                g = n ? h.colors.error : h.colors.cta,
                y = n ? h.colors.text.white : h.colors.ctaText,
                O = Object(s.f)();
            return o.createElement(m, Object(i.a)({}, O, p, {
                disabled: u,
                dark: f,
                textColor: y,
                backgroundColor: g
            }), o.createElement(b, {
                ellipsis: !0
            }, t), f && o.createElement(v, {
                "aria-hidden": !0
            }, o.createElement(d.a, {
                size: "small",
                adjustToColor: g
            })))
        }
    }, function(e, t, n) {
        "use strict";
        var r = n(1),
            i = n(8),
            o = n(21),
            a = n(4),
            c = n(68),
            u = n(0),
            s = n(7),
            d = n(17),
            l = n(18),
            f = n(22);

        function p() {
            var e = Object(o.a)(["\n  0% {\n    transform: rotate(-90deg);\n  }\n  100% {\n    transform: rotate(270deg);\n  }\n"]);
            return p = function() {
                return e
            }, e
        }

        function m() {
            var e = Object(o.a)(["\n  0% {\n    stroke-dasharray: ", " ", ";\n  }\n  50% {\n    stroke-dasharray: ", " ", ";\n  }\n  100% {\n    stroke-dasharray: ", " ", ";\n  }\n"]);
            return m = function() {
                return e
            }, e
        }
        var v = Object(a.e)(p()),
            b = Object(s.z)("circle", {
                target: "e5pj4iq2"
            })("animation-duration:1s;transform-origin:center;animation-name:", (function(e) {
                return t = e.animationFactor, Object(a.e)(m(), 22 * t, 1e3 * t, 88 * t, 1e3 * t, 22 * t, 1e3 * t);
                var t
            }), ",", v, ";animation-iteration-count:infinite;animation-timing-function:linear;"),
            h = Object(s.z)("circle", {
                target: "e5pj4iq1"
            })("stroke-dasharray:130;transform-origin:center;transform:rotate(-90deg);transition:stroke-dashoffset 100ms ", (function(e) {
                return e.theme.transitions.easings.linear
            }), ";"),
            g = {
                r: "28",
                cx: "32",
                cy: "32",
                fill: "none",
                strokeLinecap: "round"
            },
            y = {
                small: {
                    sideLength: 16,
                    strokeWidth: 2
                },
                medium: {
                    sideLength: 24,
                    strokeWidth: 3
                },
                large: {
                    sideLength: 32,
                    strokeWidth: 4
                },
                xlarge: {
                    sideLength: 56,
                    strokeWidth: 4
                }
            },
            O = Object(s.z)("svg", {
                target: "e5pj4iq0"
            })("");
        t.a = function(e) {
            var t = e.size,
                n = e.adjustToColor,
                o = e.ariaLabel,
                a = e.progress,
                s = Object(i.a)(e, ["size", "adjustToColor", "ariaLabel", "progress"]),
                p = Object(c.g)(),
                m = n || p.colors.surface.light,
                v = Object(l.h)(p.colors.cta) ? Object(f.f)(.6, p.colors.cta) : p.colors.cta,
                j = Object(l.h)(m) ? "rgba(0, 0, 0, 0.1)" : "rgba(255, 255, 255, 0.1)",
                _ = Object(l.h)(m) ? v : p.colors.text.white,
                w = y[t],
                x = w.sideLength,
                E = w.strokeWidth,
                C = o ? {
                    "aria-labelledby": "loader-label"
                } : {},
                I = Object(d.f)();
            return u.createElement(O, Object(r.a)({
                height: x + "px",
                width: x + "px",
                viewBox: "0 0 64 64",
                role: "img"
            }, C, s, I), o && u.createElement("title", {
                id: "loader-label"
            }, o), u.createElement("circle", Object(r.a)({}, g, {
                strokeWidth: E,
                stroke: j,
                vectorEffect: "non-scaling-stroke"
            })), void 0 === a ? u.createElement(b, Object(r.a)({}, g, {
                strokeWidth: E,
                stroke: _,
                vectorEffect: "non-scaling-stroke",
                animationFactor: x / 56
            })) : u.createElement(h, Object(r.a)({}, g, {
                strokeWidth: E,
                stroke: _,
                vectorEffect: "non-scaling-stroke",
                style: {
                    strokeDashoffset: 130 - 65 * a
                }
            })))
        }
    }, function(e, t, n) {
        "use strict";
        n.d(t, "b", (function() {
            return o
        }));
        var r = n(0),
            i = r.createContext(!1),
            o = function() {
                return r.useContext(i)
            };
        t.a = i.Provider
    }, function(e, t, n) {
        "use strict";
        var r = n(1),
            i = n(8),
            o = n(4),
            a = n(7),
            c = n(120),
            u = n.n(c),
            s = n(45);
        var d = function(e) {
                return e.stopPropagation()
            },
            l = {
                name: "opde7s",
                styles: "color:inherit"
            },
            f = function(e) {
                var t = e.children,
                    n = Object(i.a)(e, ["children"]);
                return Object(o.d)("a", Object(r.a)({}, n, {
                    onClick: d,
                    css: l,
                    rel: "nofollow noopener",
                    target: "_blank"
                }), t)
            };
        t.a = function(e) {
            var t = e.text,
                n = e.url,
                r = e.eventId;
            return Object(o.d)(a.m, r && {
                id: r
            }, n ? Object(o.d)(f, {
                href: n
            }, Object(o.d)(s.a, null, t)) : Object(o.d)(u.a, {
                component: f
            }, Object(o.d)(s.a, null, t)))
        }
    }, function(e, t, n) {
        "use strict";
        var r = n(328),
            i = {};
        i[n(85)("toStringTag")] = "z", i + "" != "[object z]" && n(131)(Object.prototype, "toString", (function() {
            return "[object " + r(this) + "]"
        }), !0)
    }, function(e, t) {
        var n = 0,
            r = Math.random();
        e.exports = function(e) {
            return "Symbol(".concat(void 0 === e ? "" : e, ")_", (++n + r).toString(36))
        }
    }, function(e, t, n) {
        var r = n(442);
        e.exports = function(e, t, n) {
            if (r(e), void 0 === t) return e;
            switch (n) {
                case 1:
                    return function(n) {
                        return e.call(t, n)
                    };
                case 2:
                    return function(n, r) {
                        return e.call(t, n, r)
                    };
                case 3:
                    return function(n, r, i) {
                        return e.call(t, n, r, i)
                    }
            }
            return function() {
                return e.apply(t, arguments)
            }
        }
    }, function(e, t) {
        e.exports = {}
    }, function(e, t, n) {
        var r = n(332),
            i = n(277);
        e.exports = Object.keys || function(e) {
            return r(e, i)
        }
    }, function(e, t, n) {
        var r = n(202)("meta"),
            i = n(98),
            o = n(135),
            a = n(132).f,
            c = 0,
            u = Object.isExtensible || function() {
                return !0
            },
            s = !n(147)((function() {
                return u(Object.preventExtensions({}))
            })),
            d = function(e) {
                a(e, r, {
                    value: {
                        i: "O" + ++c,
                        w: {}
                    }
                })
            },
            l = e.exports = {
                KEY: r,
                NEED: !1,
                fastKey: function(e, t) {
                    if (!i(e)) return "symbol" == typeof e ? e : ("string" == typeof e ? "S" : "P") + e;
                    if (!o(e, r)) {
                        if (!u(e)) return "F";
                        if (!t) return "E";
                        d(e)
                    }
                    return e[r].i
                },
                getWeak: function(e, t) {
                    if (!o(e, r)) {
                        if (!u(e)) return !0;
                        if (!t) return !1;
                        d(e)
                    }
                    return e[r].w
                },
                onFreeze: function(e) {
                    return s && l.NEED && u(e) && !o(e, r) && d(e), e
                }
            }
    }, function(e, t, n) {
        "use strict";
        var r = n(0),
            i = n(7);
        var o = Object(i.z)("div", {
                target: "erkouar1"
            })({
                name: "olzfrd",
                styles: "max-width:300px;max-height:300px"
            }),
            a = Object(i.z)("img", {
                target: "erkouar0"
            })({
                name: "14j4j9s",
                styles: "display:block;width:auto;height:auto;max-width:100%;max-height:100%"
            });
        t.a = function(e) {
            var t = e.url,
                n = e.name;
            return r.createElement(o, null, r.createElement(a, {
                alt: n,
                src: t
            }))
        }
    }, function(e, t, n) {
        "use strict";
        var r = n(7),
            i = Object(r.z)("div", {
                target: "e7yhn050"
            })("background-color:", (function(e) {
                return e.theme.colors.surface.light
            }), ";border-radius:", (function(e) {
                return e.theme.borderRadius.md
            }), ";");
        t.a = i
    }, , , , , , , , , , , , , function(e, t, n) {
        "use strict";
        n.d(t, "b", (function() {
            return b
        })), n.d(t, "a", (function() {
            return m
        }));
        var r = n(68),
            i = n(4),
            o = n(7),
            a = n(1),
            c = n(8),
            u = n(0),
            s = n(21);

        function d() {
            var e = Object(s.a)(["\n        ", "\n    "]);
            return d = function() {
                return e
            }, e
        }
        var l = ["0px, 0px", "0px, -8px", "0px, -10px", "0px, -6px", "0px, -2px", "0px, 3px", "0px, 2px", "0px, -1px"],
            f = [
                ["0%, 66.67%, 100%", "6.67%", "13.33%, 20%", "26.67%", "33.33%", "40%", "46.67%", "53.33%"],
                ["0%, 6.67%, 73.33%, 100%", "13.33%", "20%, 26.67%", "33.33%", "40%", "46.67%", "53.33%", "60%"],
                ["0%, 13.33%, 80%, 100%", "20%", "26.67%, 33.33%", "40%", "46.67%", "53.33%", "60%", "66.67%"]
            ].map((function(e) {
                return Object(i.e)(d(), e.map((function(e, t) {
                    return e + " { transform: translate(" + l[t] + "); }"
                })))
            })),
            p = Object(o.z)("circle", {
                target: "epoxe490"
            })("transform-box:fill-box;transform-origin:50% 50%;animation-timing-function:", (function(e) {
                return e.theme.transitions.easings.linear
            }), ";animation-name:", (function(e) {
                return e.animationName
            }), ";animation-duration:", (function(e) {
                return (e.animationDuration || 1.5) + "s"
            }), ";animation-iteration-count:", (function(e) {
                return e.animationIterationCount || "infinite"
            }), ";"),
            m = function(e) {
                var t = e.height,
                    n = e.width,
                    i = e.animationDuration,
                    o = e.animationIterationCount,
                    s = e.color,
                    d = Object(c.a)(e, ["height", "width", "animationDuration", "animationIterationCount", "color"]),
                    l = Object(r.g)();
                return u.createElement("svg", Object(a.a)({
                    viewBox: "0 0 60 40",
                    height: t,
                    width: n,
                    fill: s || l.colors.text.black
                }, d), f.map((function(e, t) {
                    return u.createElement(p, {
                        r: "6",
                        cy: "20",
                        key: t,
                        cx: 9 + 21 * t,
                        animationName: e,
                        animationDuration: i,
                        animationIterationCount: o
                    })
                })))
            };
        n(109);
        var v = {
                name: "xr9539",
                styles: "overflow:hidden;margin-bottom:0"
            },
            b = function(e) {
                var t = e.avatar,
                    n = Object(r.g)();
                return Object(i.d)(o.j, {
                    avatar: t,
                    css: v
                }, Object(i.d)(o.i, null, Object(i.d)(o.c, null, Object(i.d)(o.m, null, Object(i.d)(m, {
                    height: "16px",
                    width: "24px",
                    color: n.colors.agentMessageText
                })))))
            }
    }, function(e, t, n) {
        "use strict";
        n.d(t, "a", (function() {
            return l
        }));
        var r = n(8),
            i = n(1),
            o = n(0),
            a = n(7),
            c = Object(a.z)(a.h, {
                target: "e1f2pv4c1"
            })("width:100%;height:100%;display:block;object-fit:", (function(e) {
                return e.scaleImage ? "cover" : "fill"
            }), ";"),
            u = Object(a.z)("div", {
                displayName: "ImagePreview",
                target: "e1f2pv4c0"
            })("display:flex;margin:0 auto;align-items:center;justify-content:center;overflow:hidden;background:", (function(e) {
                return e.theme.colors.divider
            }), ";color:", (function(e) {
                return e.theme.colors.text.black
            }), ";", (function(e) {
                var t = e.dimensions;
                return Object(i.a)({}, t)
            }), ";"),
            s = function(e) {
                return e.stopPropagation()
            },
            d = function(e) {
                var t = e.children,
                    n = Object(r.a)(e, ["children"]);
                return o.createElement("a", Object(i.a)({}, n, {
                    onClick: s,
                    rel: "noopener noreferrer nofollow",
                    target: "_blank"
                }), t)
            },
            l = function(e) {
                var t = e.link,
                    n = e.url,
                    a = e.width,
                    s = e.height,
                    l = e.maxWidth,
                    f = e.maxHeight,
                    p = e.srcSet,
                    m = e.alternativeText,
                    v = void 0 === m ? "" : m,
                    b = e.name,
                    h = void 0 === b ? "" : b,
                    g = Object(r.a)(e, ["link", "url", "width", "height", "maxWidth", "maxHeight", "srcSet", "alternativeText", "name"]),
                    y = !!a || !!s,
                    O = function(e) {
                        var t = void 0 === e ? {} : e,
                            n = t.width,
                            r = void 0 === n ? 230 : n,
                            i = t.height,
                            o = void 0 === i ? 150 : i,
                            a = t.maxWidth,
                            c = void 0 === a ? 200 : a,
                            u = t.maxHeight,
                            s = void 0 === u ? 300 : u,
                            d = r / o;
                        return r > c && (o = (r = c) / d), o > s && (r = (o = s) * d), {
                            width: r,
                            height: o
                        }
                    }({
                        width: a,
                        height: s,
                        maxWidth: l,
                        maxHeight: f
                    });
                return o.createElement(d, {
                    href: t || n
                }, o.createElement(u, {
                    dimensions: O
                }, o.createElement(c, Object(i.a)({}, g, {
                    alt: v || h,
                    src: n,
                    srcSet: p,
                    scaleImage: !y
                }))))
            }
    }, function(e, t, n) {
        "use strict";
        var r = n(4),
            i = n(68),
            o = n(0),
            a = n(7),
            c = n(200),
            u = n(28),
            s = n(1),
            d = n(17);
        var l = Object(a.z)("div", {
                target: "e1faam642"
            })({
                name: "fhxb3m",
                styles: "display:flex;flex-direction:row;align-items:center"
            }),
            f = Object(a.z)("span", {
                target: "e1faam641"
            })((function(e) {
                return e.theme.typography.caption
            }), ";color:", (function(e) {
                return e.theme.colors.text.muted
            }), ";"),
            p = Object(a.z)("button", {
                target: "e1faam640"
            })("background:none;border:none;cursor:pointer;appearance:none;", (function(e) {
                return e.theme.typography.caption
            }), ";color:", (function(e) {
                return e.theme.colors.cta
            }), ";"),
            m = function(e) {
                var t = e.visible,
                    n = e.onToggle,
                    r = Object(d.f)();
                return o.createElement(l, null, t && o.createElement(f, null, "Text translated"), o.createElement(p, Object(s.a)({}, r, {
                    onClick: function(e) {
                        e.stopPropagation(), n()
                    }
                }), t ? "Show original" : "Show translation"))
            };
        var v = function(e) {
                return "smooth" === e.name ? Object(r.c)("color:", e.colors.text.black, ";background-color:", e.colors.grayscale[100], ";") : Object(r.c)("color:", e.colors.text.muted, ";")
            },
            b = {
                name: "1jwcxx3",
                styles: "font-style:italic"
            };
        t.a = function(e) {
            var t = e.text,
                n = e.url,
                s = e.translation,
                d = e.radiusType,
                l = void 0 === d ? "single" : d,
                f = e.draft,
                p = void 0 !== f && f,
                h = e.own,
                g = void 0 !== h && h,
                y = e.eventId,
                O = void 0 === y ? "" : y,
                j = Object(i.g)(),
                _ = Object(u.x)(!g),
                w = _[0],
                x = _[1];
            return Object(r.d)(o.Fragment, null, Object(r.d)(a.c, {
                radiusType: l,
                css: [p && v(j), !!s && w && b, ""]
            }, Object(r.d)(c.a, {
                text: s && w ? s.targetMessage : t,
                url: n,
                eventId: O
            })), s && Object(r.d)(m, {
                visible: w,
                onToggle: x
            }))
        }
    }, function(e, t, n) {
        "use strict";
        var r = n(7);
        var i = Object(r.z)("p", {
            target: "ejp8d810"
        })({
            name: "oelr46",
            styles: "margin:1em 0"
        });
        t.a = i
    }, , , , , function(e, t, n) {
        "use strict";
        var r = n(2),
            i = n(158),
            o = function() {
                var e = "lc_get_time_" + Object(r.v)();
                window.performance && "function" === typeof window.performance.mark && window.performance.mark(e);
                var t = performance.getEntriesByName(e)[0].startTime;
                return performance.clearMarks(e), t
            },
            a = function() {
                if ("undefined" === typeof PerformanceObserver) return null;
                var e = o(),
                    t = [],
                    n = new PerformanceObserver((function(e) {
                        t.push.apply(t, e.getEntries())
                    }));
                n.observe({
                    entryTypes: ["longtask"]
                });
                var i = function() {
                    var n, i = Object(r.M)(t);
                    return i ? (n = i, o() - n.startTime + n.duration) : o() - e
                };
                return {
                    disconnect: function() {
                        return n.disconnect()
                    },
                    getLongTasks: function() {
                        return [].concat(t)
                    },
                    waitForIdle: function(e) {
                        return new Promise((function(r) {
                            ! function o() {
                                t.push.apply(t, n.takeRecords());
                                var a = i();
                                a >= e ? r() : setTimeout(o, Math.ceil(e - a))
                            }()
                        }))
                    }
                }
            };
        t.a = function(e) {
            void 0 === e && (e = "first-contentful-paint");
            var t = a();
            return t ? Object(i.a)(e).then((function(e) {
                return e ? t.waitForIdle(5e3).then((function() {
                    return t.disconnect(), t.getLongTasks()
                })) : null
            })) : Promise.resolve(null)
        }
    }, function(e, t, n) {
        "use strict";
        n.d(t, "a", (function() {
            return g
        })), n.d(t, "b", (function() {
            return y
        }));
        var r = n(6),
            i = n(2),
            o = n(128),
            a = function(e) {
                return new Promise((function(t, n) {
                    var r = new Audio(e);
                    r.onloadeddata = function() {
                        t(r)
                    }, r.onerror = n
                }))
            },
            c = function(e) {
                var t = e.play();
                return Object(i.I)(t) ? t : Promise.resolve()
            },
            u = function(e) {
                return "function" === typeof e.start && "function" === typeof e.stop
            },
            s = function(e) {
                u(e) ? e.start(0) : e.noteOn(0)
            },
            d = function() {
                var e = new(window.AudioContext || window.webkitAudioContext),
                    t = !0,
                    n = [],
                    r = function(t) {
                        return new Promise((function(n, r) {
                            e.decodeAudioData(t, n, r)
                        }))
                    },
                    i = function(t) {
                        return {
                            play: function() {
                                var n = e.createBufferSource();
                                return n.connect(e.destination), n.buffer = t, {
                                    playback: new Promise((function(t, r) {
                                        if (n.onended = function() {
                                                return t()
                                            }, s(n), "running" !== e.state) {
                                            var i = new Error("Playback failed, AudioContext is in incorrect state '" + e.state + "'");
                                            i.name = "PlaybackError", r(i)
                                        }
                                    })),
                                    stop: function() {
                                        ! function(e) {
                                            u(e) ? e.stop(0) : e.noteOff(0)
                                        }(n)
                                    }
                                }
                            }
                        }
                    };
                return {
                    preload: function(e) {
                        return function(e) {
                            return new Promise((function(t, n) {
                                var r = new XMLHttpRequest;
                                r.onload = function() {
                                    t(r.response)
                                }, r.onerror = n, r.open("GET", e), r.responseType = "arraybuffer", r.send()
                            }))
                        }(e).then(r).then(i)
                    },
                    playSound: function(e) {
                        var r = e.play();
                        return t && n.push(r), r.playback
                    },
                    unlock: function() {
                        return new Promise((function(r) {
                            document.addEventListener("click", (function i() {
                                document.removeEventListener("click", i, !0), t && (n.forEach((function(e) {
                                        e.stop()
                                    })), n = [], t = !1), e.resume(),
                                    function() {
                                        var t = e.createBuffer(1, 1, 22050),
                                            n = e.createBufferSource();
                                        n.buffer = t, n.connect(e.destination), s(n)
                                    }(), r()
                            }), !0)
                        }))
                    }
                }
            },
            l = function() {
                return Object(o.b)() ? function() {
                    var e = d(),
                        t = Object(i.R)((function(t) {
                            var n = e.preload(t);
                            return n.catch(i.V), n
                        }));
                    return {
                        play: function(n) {
                            var r = t(n).then(e.playSound);
                            return r.catch(i.V), r
                        },
                        preload: t,
                        unlock: function() {
                            return e.unlock()
                        }
                    }
                }() : function() {
                    var e = Object(i.R)(a);
                    return {
                        play: function(t) {
                            return e(t).then(c)
                        },
                        preload: e,
                        unlock: function() {
                            return Promise.resolve()
                        }
                    }
                }()
            },
            f = function(e) {
                var t = l(),
                    n = function(e) {
                        return Object.keys(e).reduce((function(t, n) {
                            var r = Object(i.o)((function(e) {
                                return Object(o.a)(e)
                            }), Object(i.l)(e[n]));
                            return t[n] = r, t
                        }), {})
                    }(e);
                return {
                    play: function(e) {
                        var r = n[e];
                        t.play(r).then(i.V, i.V)
                    },
                    preload: function(e) {
                        var r = n[e];
                        t.preload(r).then(i.V, i.V)
                    },
                    unlock: function() {
                        return t.unlock()
                    }
                }
            },
            p = n.p + "static/media/new_message.f3efb3d2.mp3",
            m = n.p + "static/media/new_message.34190d36.ogg",
            v = "new_message",
            b = function() {
                var e, t = f(((e = {}).new_message = [m, p], e));
                return t.unlock().then((function() {
                    return Object(i.N)(2e3, (function(e) {
                        t.play(e)
                    }))
                }))
            },
            h = function(e, t) {
                return "system" !== e.author && !e.properties.welcomeMessage && e.author !== t && "custom" !== e.type
            },
            g = function(e) {
                var t = !1;
                e.on("iframe_sound_unlocked", (function() {
                    return t = !0
                })), b().then((function(n) {
                    t || (e.emit("bridge_sound_unlocked"), e.on("add_event", (function(t) {
                        var i = t.event;
                        if (!Object(r.getApplicationState)(e.state, "muted")) {
                            var o = Object(r.getSessionUserId)(e.state);
                            h(i, o) && n(v)
                        }
                    })))
                }))
            },
            y = function(e) {
                var t = !1;
                e.on("bridge_sound_unlocked", (function() {
                    return t = !0
                })), b().then((function(n) {
                    t || (e.emit("iframe_sound_unlocked"), e.on("add_event", (function(t) {
                        var r = t.event;
                        if (!e.getApplicationState().muted) {
                            var i = e.getSessionUserId();
                            h(r, i) && n(v)
                        }
                    })))
                }))
            }
    }, , , , , function(e, t) {
        e.exports = !1
    }, function(e, t) {
        e.exports = function(e, t) {
            return {
                enumerable: !(1 & e),
                configurable: !(2 & e),
                writable: !(4 & e),
                value: t
            }
        }
    }, function(e, t, n) {
        var r = n(132).f,
            i = n(135),
            o = n(85)("toStringTag");
        e.exports = function(e, t, n) {
            e && !i(e = n ? e : e.prototype, o) && r(e, o, {
                configurable: !0,
                value: t
            })
        }
    }, function(e, t, n) {
        "use strict";
        var r = n(112),
            i = n(272),
            o = n(131),
            a = n(280),
            c = n(206),
            u = n(282),
            s = n(281),
            d = n(98),
            l = n(147),
            f = n(455),
            p = n(237),
            m = n(456);
        e.exports = function(e, t, n, v, b, h) {
            var g = r[e],
                y = g,
                O = b ? "set" : "add",
                j = y && y.prototype,
                _ = {},
                w = function(e) {
                    var t = j[e];
                    o(j, e, "delete" == e || "has" == e ? function(e) {
                        return !(h && !d(e)) && t.call(this, 0 === e ? 0 : e)
                    } : "get" == e ? function(e) {
                        return h && !d(e) ? void 0 : t.call(this, 0 === e ? 0 : e)
                    } : "add" == e ? function(e) {
                        return t.call(this, 0 === e ? 0 : e), this
                    } : function(e, n) {
                        return t.call(this, 0 === e ? 0 : e, n), this
                    })
                };
            if ("function" == typeof y && (h || j.forEach && !l((function() {
                    (new y).entries().next()
                })))) {
                var x = new y,
                    E = x[O](h ? {} : -0, 1) != x,
                    C = l((function() {
                        x.has(1)
                    })),
                    I = f((function(e) {
                        new y(e)
                    })),
                    S = !h && l((function() {
                        for (var e = new y, t = 5; t--;) e[O](t, t);
                        return !e.has(-0)
                    }));
                I || ((y = t((function(t, n) {
                    s(t, y, e);
                    var r = m(new g, t, y);
                    return void 0 != n && u(n, b, r[O], r), r
                }))).prototype = j, j.constructor = y), (C || S) && (w("delete"), w("has"), b && w("get")), (S || E) && w(O), h && j.clear && delete j.clear
            } else y = v.getConstructor(t, e, b, O), a(y.prototype, n), c.NEED = !0;
            return p(y, e), _[e] = y, i(i.G + i.W + i.F * (y != g), _), h || v.setStrong(y, e, b), y
        }
    }, function(e, t) {
        t.f = {}.propertyIsEnumerable
    }, , , , , , , , , , , , , function(e, t, n) {
        "use strict";
        t.a = null
    }, , , , , , , , , , , , function(e, t, n) {
        (function(e) {
            var r = "undefined" !== typeof e && e || "undefined" !== typeof self && self || window,
                i = Function.prototype.apply;

            function o(e, t) {
                this._id = e, this._clearFn = t
            }
            t.setTimeout = function() {
                return new o(i.call(setTimeout, r, arguments), clearTimeout)
            }, t.setInterval = function() {
                return new o(i.call(setInterval, r, arguments), clearInterval)
            }, t.clearTimeout = t.clearInterval = function(e) {
                e && e.close()
            }, o.prototype.unref = o.prototype.ref = function() {}, o.prototype.close = function() {
                this._clearFn.call(r, this._id)
            }, t.enroll = function(e, t) {
                clearTimeout(e._idleTimeoutId), e._idleTimeout = t
            }, t.unenroll = function(e) {
                clearTimeout(e._idleTimeoutId), e._idleTimeout = -1
            }, t._unrefActive = t.active = function(e) {
                clearTimeout(e._idleTimeoutId);
                var t = e._idleTimeout;
                t >= 0 && (e._idleTimeoutId = setTimeout((function() {
                    e._onTimeout && e._onTimeout()
                }), t))
            }, n(265), t.setImmediate = "undefined" !== typeof self && self.setImmediate || "undefined" !== typeof e && e.setImmediate || this && this.setImmediate, t.clearImmediate = "undefined" !== typeof self && self.clearImmediate || "undefined" !== typeof e && e.clearImmediate || this && this.clearImmediate
        }).call(this, n(69))
    }, function(e, t, n) {
        (function(e, t) {
            ! function(e, n) {
                "use strict";
                if (!e.setImmediate) {
                    var r, i = 1,
                        o = {},
                        a = !1,
                        c = e.document,
                        u = Object.getPrototypeOf && Object.getPrototypeOf(e);
                    u = u && u.setTimeout ? u : e, "[object process]" === {}.toString.call(e.process) ? r = function(e) {
                        t.nextTick((function() {
                            d(e)
                        }))
                    } : function() {
                        if (e.postMessage && !e.importScripts) {
                            var t = !0,
                                n = e.onmessage;
                            return e.onmessage = function() {
                                t = !1
                            }, e.postMessage("", "*"), e.onmessage = n, t
                        }
                    }() ? function() {
                        var t = "setImmediate$" + Math.random() + "$",
                            n = function(n) {
                                n.source === e && "string" === typeof n.data && 0 === n.data.indexOf(t) && d(+n.data.slice(t.length))
                            };
                        e.addEventListener ? e.addEventListener("message", n, !1) : e.attachEvent("onmessage", n), r = function(n) {
                            e.postMessage(t + n, "*")
                        }
                    }() : e.MessageChannel ? function() {
                        var e = new MessageChannel;
                        e.port1.onmessage = function(e) {
                            d(e.data)
                        }, r = function(t) {
                            e.port2.postMessage(t)
                        }
                    }() : c && "onreadystatechange" in c.createElement("script") ? function() {
                        var e = c.documentElement;
                        r = function(t) {
                            var n = c.createElement("script");
                            n.onreadystatechange = function() {
                                d(t), n.onreadystatechange = null, e.removeChild(n), n = null
                            }, e.appendChild(n)
                        }
                    }() : r = function(e) {
                        setTimeout(d, 0, e)
                    }, u.setImmediate = function(e) {
                        "function" !== typeof e && (e = new Function("" + e));
                        for (var t = new Array(arguments.length - 1), n = 0; n < t.length; n++) t[n] = arguments[n + 1];
                        var a = {
                            callback: e,
                            args: t
                        };
                        return o[i] = a, r(i), i++
                    }, u.clearImmediate = s
                }

                function s(e) {
                    delete o[e]
                }

                function d(e) {
                    if (a) setTimeout(d, 0, e);
                    else {
                        var t = o[e];
                        if (t) {
                            a = !0;
                            try {
                                ! function(e) {
                                    var t = e.callback,
                                        n = e.args;
                                    switch (n.length) {
                                        case 0:
                                            t();
                                            break;
                                        case 1:
                                            t(n[0]);
                                            break;
                                        case 2:
                                            t(n[0], n[1]);
                                            break;
                                        case 3:
                                            t(n[0], n[1], n[2]);
                                            break;
                                        default:
                                            t.apply(void 0, n)
                                    }
                                }(t)
                            } finally {
                                s(e), a = !1
                            }
                        }
                    }
                }
            }("undefined" === typeof self ? "undefined" === typeof e ? this : e : self)
        }).call(this, n(69), n(111))
    }, function(e, t) {
        var n = {}.toString;
        e.exports = function(e) {
            return n.call(e).slice(8, -1)
        }
    }, function(e, t, n) {
        var r = n(121),
            i = n(112),
            o = "__core-js_shared__",
            a = i[o] || (i[o] = {});
        (e.exports = function(e, t) {
            return a[e] || (a[e] = void 0 !== t ? t : {})
        })("versions", []).push({
            version: r.version,
            mode: n(235) ? "pure" : "global",
            copyright: "\xa9 2019 Denis Pushkarev (zloirock.ru)"
        })
    }, function(e, t, n) {
        var r = n(98);
        e.exports = function(e, t) {
            if (!r(e)) return e;
            var n, i;
            if (t && "function" == typeof(n = e.toString) && !r(i = n.call(e))) return i;
            if ("function" == typeof(n = e.valueOf) && !r(i = n.call(e))) return i;
            if (!t && "function" == typeof(n = e.toString) && !r(i = n.call(e))) return i;
            throw TypeError("Can't convert object to primitive value")
        }
    }, function(e, t) {
        var n = Math.ceil,
            r = Math.floor;
        e.exports = function(e) {
            return isNaN(e = +e) ? 0 : (e > 0 ? r : n)(e)
        }
    }, function(e, t) {
        e.exports = function(e) {
            if (void 0 == e) throw TypeError("Can't call method on  " + e);
            return e
        }
    }, function(e, t, n) {
        "use strict";
        var r = n(235),
            i = n(272),
            o = n(131),
            a = n(146),
            c = n(204),
            u = n(443),
            s = n(237),
            d = n(448),
            l = n(85)("iterator"),
            f = !([].keys && "next" in [].keys()),
            p = "keys",
            m = "values",
            v = function() {
                return this
            };
        e.exports = function(e, t, n, b, h, g, y) {
            u(n, t, b);
            var O, j, _, w = function(e) {
                    if (!f && e in I) return I[e];
                    switch (e) {
                        case p:
                        case m:
                            return function() {
                                return new n(this, e)
                            }
                    }
                    return function() {
                        return new n(this, e)
                    }
                },
                x = t + " Iterator",
                E = h == m,
                C = !1,
                I = e.prototype,
                S = I[l] || I["@@iterator"] || h && I[h],
                T = S || w(h),
                k = h ? E ? w("entries") : T : void 0,
                A = "Array" == t && I.entries || S;
            if (A && (_ = d(A.call(new e))) !== Object.prototype && _.next && (s(_, x, !0), r || "function" == typeof _[l] || a(_, l, v)), E && S && S.name !== m && (C = !0, T = function() {
                    return S.call(this)
                }), r && !y || !f && !C && I[l] || a(I, l, T), c[t] = T, c[x] = v, h)
                if (O = {
                        values: E ? T : w(m),
                        keys: g ? T : w(p),
                        entries: k
                    }, y)
                    for (j in O) j in I || o(I, j, O[j]);
                else i(i.P + i.F * (f || C), t, O);
            return O
        }
    }, function(e, t, n) {
        var r = n(112),
            i = n(121),
            o = n(146),
            a = n(131),
            c = n(203),
            u = function e(t, n, u) {
                var s, d, l, f, p = t & e.F,
                    m = t & e.G,
                    v = t & e.P,
                    b = t & e.B,
                    h = m ? r : t & e.S ? r[n] || (r[n] = {}) : (r[n] || {}).prototype,
                    g = m ? i : i[n] || (i[n] = {}),
                    y = g.prototype || (g.prototype = {});
                for (s in m && (u = n), u) l = ((d = !p && h && void 0 !== h[s]) ? h : u)[s], f = b && d ? c(l, r) : v && "function" == typeof l ? c(Function.call, l) : l, h && a(h, s, l, t & e.U), g[s] != l && o(g, s, f), v && y[s] != l && (y[s] = l)
            };
        r.core = i, u.F = 1, u.G = 2, u.S = 4, u.P = 8, u.B = 16, u.W = 32, u.U = 64, u.R = 128, e.exports = u
    }, function(e, t, n) {
        var r = n(133),
            i = n(444),
            o = n(277),
            a = n(276)("IE_PROTO"),
            c = function() {},
            u = function() {
                var e, t = n(330)("iframe"),
                    r = o.length;
                for (t.style.display = "none", n(447).appendChild(t), t.src = "javascript:", (e = t.contentWindow.document).open(), e.write("<script>document.F=Object<\/script>"), e.close(), u = e.F; r--;) delete u.prototype[o[r]];
                return u()
            };
        e.exports = Object.create || function(e, t) {
            var n;
            return null !== e ? (c.prototype = r(e), n = new c, c.prototype = null, n[a] = e) : n = u(), void 0 === t ? n : i(n, t)
        }
    }, function(e, t, n) {
        var r = n(266);
        e.exports = Object("z").propertyIsEnumerable(0) ? Object : function(e) {
            return "String" == r(e) ? e.split("") : Object(e)
        }
    }, function(e, t, n) {
        var r = n(269),
            i = Math.min;
        e.exports = function(e) {
            return e > 0 ? i(r(e), 9007199254740991) : 0
        }
    }, function(e, t, n) {
        var r = n(267)("keys"),
            i = n(202);
        e.exports = function(e) {
            return r[e] || (r[e] = i(e))
        }
    }, function(e, t) {
        e.exports = "constructor,hasOwnProperty,isPrototypeOf,propertyIsEnumerable,toLocaleString,toString,valueOf".split(",")
    }, function(e, t, n) {
        var r = n(270);
        e.exports = function(e) {
            return Object(r(e))
        }
    }, function(e, t, n) {
        for (var r = n(333), i = n(205), o = n(131), a = n(112), c = n(146), u = n(204), s = n(85), d = s("iterator"), l = s("toStringTag"), f = u.Array, p = {
                CSSRuleList: !0,
                CSSStyleDeclaration: !1,
                CSSValueList: !1,
                ClientRectList: !1,
                DOMRectList: !1,
                DOMStringList: !1,
                DOMTokenList: !0,
                DataTransferItemList: !1,
                FileList: !1,
                HTMLAllCollection: !1,
                HTMLCollection: !1,
                HTMLFormElement: !1,
                HTMLSelectElement: !1,
                MediaList: !0,
                MimeTypeArray: !1,
                NamedNodeMap: !1,
                NodeList: !0,
                PaintRequestList: !1,
                Plugin: !1,
                PluginArray: !1,
                SVGLengthList: !1,
                SVGNumberList: !1,
                SVGPathSegList: !1,
                SVGPointList: !1,
                SVGStringList: !1,
                SVGTransformList: !1,
                SourceBufferList: !1,
                StyleSheetList: !0,
                TextTrackCueList: !1,
                TextTrackList: !1,
                TouchList: !1
            }, m = i(p), v = 0; v < m.length; v++) {
            var b, h = m[v],
                g = p[h],
                y = a[h],
                O = y && y.prototype;
            if (O && (O[d] || c(O, d, f), O[l] || c(O, l, h), u[h] = f, g))
                for (b in r) O[b] || o(O, b, r[b], !0)
        }
    }, function(e, t, n) {
        var r = n(131);
        e.exports = function(e, t, n) {
            for (var i in t) r(e, i, t[i], n);
            return e
        }
    }, function(e, t) {
        e.exports = function(e, t, n, r) {
            if (!(e instanceof t) || void 0 !== r && r in e) throw TypeError(n + ": incorrect invocation!");
            return e
        }
    }, function(e, t, n) {
        var r = n(203),
            i = n(451),
            o = n(452),
            a = n(133),
            c = n(275),
            u = n(453),
            s = {},
            d = {};
        (t = e.exports = function(e, t, n, l, f) {
            var p, m, v, b, h = f ? function() {
                    return e
                } : u(e),
                g = r(n, l, t ? 2 : 1),
                y = 0;
            if ("function" != typeof h) throw TypeError(e + " is not iterable!");
            if (o(h)) {
                for (p = c(e.length); p > y; y++)
                    if ((b = t ? g(a(m = e[y])[0], m[1]) : g(e[y])) === s || b === d) return b
            } else
                for (v = h.call(e); !(m = v.next()).done;)
                    if ((b = i(v, g, m.value, t)) === s || b === d) return b
        }).BREAK = s, t.RETURN = d
    }, function(e, t) {
        t.f = Object.getOwnPropertySymbols
    }, , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , function(e, t, n) {
        "use strict";
        (function(t) {
            var n = setTimeout;

            function r() {}

            function i(e) {
                if (!(this instanceof i)) throw new TypeError("Promises must be constructed via new");
                if ("function" !== typeof e) throw new TypeError("not a function");
                this._state = 0, this._handled = !1, this._value = void 0, this._deferreds = [], d(e, this)
            }

            function o(e, t) {
                for (; 3 === e._state;) e = e._value;
                0 !== e._state ? (e._handled = !0, i._immediateFn((function() {
                    var n = 1 === e._state ? t.onFulfilled : t.onRejected;
                    if (null !== n) {
                        var r;
                        try {
                            r = n(e._value)
                        } catch (i) {
                            return void c(t.promise, i)
                        }
                        a(t.promise, r)
                    } else(1 === e._state ? a : c)(t.promise, e._value)
                }))) : e._deferreds.push(t)
            }

            function a(e, t) {
                try {
                    if (t === e) throw new TypeError("A promise cannot be resolved with itself.");
                    if (t && ("object" === typeof t || "function" === typeof t)) {
                        var n = t.then;
                        if (t instanceof i) return e._state = 3, e._value = t, void u(e);
                        if ("function" === typeof n) return void d((r = n, o = t, function() {
                            r.apply(o, arguments)
                        }), e)
                    }
                    e._state = 1, e._value = t, u(e)
                } catch (a) {
                    c(e, a)
                }
                var r, o
            }

            function c(e, t) {
                e._state = 2, e._value = t, u(e)
            }

            function u(e) {
                2 === e._state && 0 === e._deferreds.length && i._immediateFn((function() {
                    e._handled || i._unhandledRejectionFn(e._value)
                }));
                for (var t = 0, n = e._deferreds.length; t < n; t++) o(e, e._deferreds[t]);
                e._deferreds = null
            }

            function s(e, t, n) {
                this.onFulfilled = "function" === typeof e ? e : null, this.onRejected = "function" === typeof t ? t : null, this.promise = n
            }

            function d(e, t) {
                var n = !1;
                try {
                    e((function(e) {
                        n || (n = !0, a(t, e))
                    }), (function(e) {
                        n || (n = !0, c(t, e))
                    }))
                } catch (r) {
                    if (n) return;
                    n = !0, c(t, r)
                }
            }
            i.prototype.catch = function(e) {
                return this.then(null, e)
            }, i.prototype.then = function(e, t) {
                var n = new this.constructor(r);
                return o(this, new s(e, t, n)), n
            }, i.prototype.finally = function(e) {
                var t = this.constructor;
                return this.then((function(n) {
                    return t.resolve(e()).then((function() {
                        return n
                    }))
                }), (function(n) {
                    return t.resolve(e()).then((function() {
                        return t.reject(n)
                    }))
                }))
            }, i.all = function(e) {
                return new i((function(t, n) {
                    if (!e || "undefined" === typeof e.length) throw new TypeError("Promise.all accepts an array");
                    var r = Array.prototype.slice.call(e);
                    if (0 === r.length) return t([]);
                    var i = r.length;

                    function o(e, a) {
                        try {
                            if (a && ("object" === typeof a || "function" === typeof a)) {
                                var c = a.then;
                                if ("function" === typeof c) return void c.call(a, (function(t) {
                                    o(e, t)
                                }), n)
                            }
                            r[e] = a, 0 === --i && t(r)
                        } catch (u) {
                            n(u)
                        }
                    }
                    for (var a = 0; a < r.length; a++) o(a, r[a])
                }))
            }, i.resolve = function(e) {
                return e && "object" === typeof e && e.constructor === i ? e : new i((function(t) {
                    t(e)
                }))
            }, i.reject = function(e) {
                return new i((function(t, n) {
                    n(e)
                }))
            }, i.race = function(e) {
                return new i((function(t, n) {
                    for (var r = 0, i = e.length; r < i; r++) e[r].then(t, n)
                }))
            }, i._immediateFn = "function" === typeof t && function(e) {
                t(e)
            } || function(e) {
                n(e, 0)
            }, i._unhandledRejectionFn = function(e) {
                "undefined" !== typeof console && console && console.warn("Possible Unhandled Promise Rejection:", e)
            }, e.exports = i
        }).call(this, n(264).setImmediate)
    }, , , , , , , , , , , , , function(e, t, n) {
        var r = n(266),
            i = n(85)("toStringTag"),
            o = "Arguments" == r(function() {
                return arguments
            }());
        e.exports = function(e) {
            var t, n, a;
            return void 0 === e ? "Undefined" : null === e ? "Null" : "string" == typeof(n = function(e, t) {
                try {
                    return e[t]
                } catch (n) {}
            }(t = Object(e), i)) ? n : o ? r(t) : "Object" == (a = r(t)) && "function" == typeof t.callee ? "Arguments" : a
        }
    }, function(e, t, n) {
        e.exports = !n(134) && !n(147)((function() {
            return 7 != Object.defineProperty(n(330)("div"), "a", {
                get: function() {
                    return 7
                }
            }).a
        }))
    }, function(e, t, n) {
        var r = n(98),
            i = n(112).document,
            o = r(i) && r(i.createElement);
        e.exports = function(e) {
            return o ? i.createElement(e) : {}
        }
    }, function(e, t, n) {
        "use strict";
        var r = n(441)(!0);
        n(271)(String, "String", (function(e) {
            this._t = String(e), this._i = 0
        }), (function() {
            var e, t = this._t,
                n = this._i;
            return n >= t.length ? {
                value: void 0,
                done: !0
            } : (e = r(t, n), this._i += e.length, {
                value: e,
                done: !1
            })
        }))
    }, function(e, t, n) {
        var r = n(135),
            i = n(165),
            o = n(445)(!1),
            a = n(276)("IE_PROTO");
        e.exports = function(e, t) {
            var n, c = i(e),
                u = 0,
                s = [];
            for (n in c) n != a && r(c, n) && s.push(n);
            for (; t.length > u;) r(c, n = t[u++]) && (~o(s, n) || s.push(n));
            return s
        }
    }, function(e, t, n) {
        "use strict";
        var r = n(449),
            i = n(334),
            o = n(204),
            a = n(165);
        e.exports = n(271)(Array, "Array", (function(e, t) {
            this._t = a(e), this._i = 0, this._k = t
        }), (function() {
            var e = this._t,
                t = this._k,
                n = this._i++;
            return !e || n >= e.length ? (this._t = void 0, i(1)) : i(0, "keys" == t ? n : "values" == t ? e[n] : [n, e[n]])
        }), "values"), o.Arguments = o.Array, r("keys"), r("values"), r("entries")
    }, function(e, t) {
        e.exports = function(e, t) {
            return {
                value: t,
                done: !!e
            }
        }
    }, function(e, t, n) {
        "use strict";
        var r = n(132).f,
            i = n(273),
            o = n(280),
            a = n(203),
            c = n(281),
            u = n(282),
            s = n(271),
            d = n(334),
            l = n(454),
            f = n(134),
            p = n(206).fastKey,
            m = n(166),
            v = f ? "_s" : "size",
            b = function(e, t) {
                var n, r = p(t);
                if ("F" !== r) return e._i[r];
                for (n = e._f; n; n = n.n)
                    if (n.k == t) return n
            };
        e.exports = {
            getConstructor: function(e, t, n, s) {
                var d = e((function(e, r) {
                    c(e, d, t, "_i"), e._t = t, e._i = i(null), e._f = void 0, e._l = void 0, e[v] = 0, void 0 != r && u(r, n, e[s], e)
                }));
                return o(d.prototype, {
                    clear: function() {
                        for (var e = m(this, t), n = e._i, r = e._f; r; r = r.n) r.r = !0, r.p && (r.p = r.p.n = void 0), delete n[r.i];
                        e._f = e._l = void 0, e[v] = 0
                    },
                    delete: function(e) {
                        var n = m(this, t),
                            r = b(n, e);
                        if (r) {
                            var i = r.n,
                                o = r.p;
                            delete n._i[r.i], r.r = !0, o && (o.n = i), i && (i.p = o), n._f == r && (n._f = i), n._l == r && (n._l = o), n[v]--
                        }
                        return !!r
                    },
                    forEach: function(e) {
                        m(this, t);
                        for (var n, r = a(e, arguments.length > 1 ? arguments[1] : void 0, 3); n = n ? n.n : this._f;)
                            for (r(n.v, n.k, this); n && n.r;) n = n.p
                    },
                    has: function(e) {
                        return !!b(m(this, t), e)
                    }
                }), f && r(d.prototype, "size", {
                    get: function() {
                        return m(this, t)[v]
                    }
                }), d
            },
            def: function(e, t, n) {
                var r, i, o = b(e, t);
                return o ? o.v = n : (e._l = o = {
                    i: i = p(t, !0),
                    k: t,
                    v: n,
                    p: r = e._l,
                    n: void 0,
                    r: !1
                }, e._f || (e._f = o), r && (r.n = o), e[v]++, "F" !== i && (e._i[i] = o)), e
            },
            getEntry: b,
            setStrong: function(e, t, n) {
                s(e, t, (function(e, n) {
                    this._t = m(e, t), this._k = n, this._l = void 0
                }), (function() {
                    for (var e = this, t = e._k, n = e._l; n && n.r;) n = n.p;
                    return e._t && (e._l = n = n ? n.n : e._t._f) ? d(0, "keys" == t ? n.k : "values" == t ? n.v : [n.k, n.v]) : (e._t = void 0, d(1))
                }), n ? "entries" : "values", !n, !0), l(t)
            }
        }
    }, function(e, t, n) {
        var r = n(239),
            i = n(236),
            o = n(165),
            a = n(268),
            c = n(135),
            u = n(329),
            s = Object.getOwnPropertyDescriptor;
        t.f = n(134) ? s : function(e, t) {
            if (e = o(e), t = a(t, !0), u) try {
                return s(e, t)
            } catch (n) {}
            if (c(e, t)) return i(!r.f.call(e, t), e[t])
        }
    }, function(e, t, n) {
        t.f = n(85)
    }, function(e, t, n) {
        var r = n(266);
        e.exports = Array.isArray || function(e) {
            return "Array" == r(e)
        }
    }, function(e, t, n) {
        var r = n(332),
            i = n(277).concat("length", "prototype");
        t.f = Object.getOwnPropertyNames || function(e) {
            return r(e, i)
        }
    }, function(e, t, n) {
        var r = n(203),
            i = n(274),
            o = n(278),
            a = n(275),
            c = n(467);
        e.exports = function(e, t) {
            var n = 1 == e,
                u = 2 == e,
                s = 3 == e,
                d = 4 == e,
                l = 6 == e,
                f = 5 == e || l,
                p = t || c;
            return function(t, c, m) {
                for (var v, b, h = o(t), g = i(h), y = r(c, m, 3), O = a(g.length), j = 0, _ = n ? p(t, O) : u ? p(t, 0) : void 0; O > j; j++)
                    if ((f || j in g) && (b = y(v = g[j], j, h), e))
                        if (n) _[j] = b;
                        else if (b) switch (e) {
                    case 3:
                        return !0;
                    case 5:
                        return v;
                    case 6:
                        return j;
                    case 2:
                        _.push(v)
                } else if (d) return !1;
                return l ? -1 : s || d ? d : _
            }
        }
    }, function(e, t, n) {
        "use strict";
        var r = n(280),
            i = n(206).getWeak,
            o = n(133),
            a = n(98),
            c = n(281),
            u = n(282),
            s = n(340),
            d = n(135),
            l = n(166),
            f = s(5),
            p = s(6),
            m = 0,
            v = function(e) {
                return e._l || (e._l = new b)
            },
            b = function() {
                this.a = []
            },
            h = function(e, t) {
                return f(e.a, (function(e) {
                    return e[0] === t
                }))
            };
        b.prototype = {
            get: function(e) {
                var t = h(this, e);
                if (t) return t[1]
            },
            has: function(e) {
                return !!h(this, e)
            },
            set: function(e, t) {
                var n = h(this, e);
                n ? n[1] = t : this.a.push([e, t])
            },
            delete: function(e) {
                var t = p(this.a, (function(t) {
                    return t[0] === e
                }));
                return ~t && this.a.splice(t, 1), !!~t
            }
        }, e.exports = {
            getConstructor: function(e, t, n, o) {
                var s = e((function(e, r) {
                    c(e, s, t, "_i"), e._t = t, e._i = m++, e._l = void 0, void 0 != r && u(r, n, e[o], e)
                }));
                return r(s.prototype, {
                    delete: function(e) {
                        if (!a(e)) return !1;
                        var n = i(e);
                        return !0 === n ? v(l(this, t)).delete(e) : n && d(n, this._i) && delete n[this._i]
                    },
                    has: function(e) {
                        if (!a(e)) return !1;
                        var n = i(e);
                        return !0 === n ? v(l(this, t)).has(e) : n && d(n, this._i)
                    }
                }), s
            },
            def: function(e, t, n) {
                var r = i(o(t), !0);
                return !0 === r ? v(e).set(t, n) : r[e._i] = n, e
            },
            ufstore: v
        }
    }, , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , function(e, t, n) {
        n(201), n(331), n(279), n(450), e.exports = n(121).Map
    }, function(e, t, n) {
        var r = n(269),
            i = n(270);
        e.exports = function(e) {
            return function(t, n) {
                var o, a, c = String(i(t)),
                    u = r(n),
                    s = c.length;
                return u < 0 || u >= s ? e ? "" : void 0 : (o = c.charCodeAt(u)) < 55296 || o > 56319 || u + 1 === s || (a = c.charCodeAt(u + 1)) < 56320 || a > 57343 ? e ? c.charAt(u) : o : e ? c.slice(u, u + 2) : a - 56320 + (o - 55296 << 10) + 65536
            }
        }
    }, function(e, t) {
        e.exports = function(e) {
            if ("function" != typeof e) throw TypeError(e + " is not a function!");
            return e
        }
    }, function(e, t, n) {
        "use strict";
        var r = n(273),
            i = n(236),
            o = n(237),
            a = {};
        n(146)(a, n(85)("iterator"), (function() {
            return this
        })), e.exports = function(e, t, n) {
            e.prototype = r(a, {
                next: i(1, n)
            }), o(e, t + " Iterator")
        }
    }, function(e, t, n) {
        var r = n(132),
            i = n(133),
            o = n(205);
        e.exports = n(134) ? Object.defineProperties : function(e, t) {
            i(e);
            for (var n, a = o(t), c = a.length, u = 0; c > u;) r.f(e, n = a[u++], t[n]);
            return e
        }
    }, function(e, t, n) {
        var r = n(165),
            i = n(275),
            o = n(446);
        e.exports = function(e) {
            return function(t, n, a) {
                var c, u = r(t),
                    s = i(u.length),
                    d = o(a, s);
                if (e && n != n) {
                    for (; s > d;)
                        if ((c = u[d++]) != c) return !0
                } else
                    for (; s > d; d++)
                        if ((e || d in u) && u[d] === n) return e || d || 0;
                return !e && -1
            }
        }
    }, function(e, t, n) {
        var r = n(269),
            i = Math.max,
            o = Math.min;
        e.exports = function(e, t) {
            return (e = r(e)) < 0 ? i(e + t, 0) : o(e, t)
        }
    }, function(e, t, n) {
        var r = n(112).document;
        e.exports = r && r.documentElement
    }, function(e, t, n) {
        var r = n(135),
            i = n(278),
            o = n(276)("IE_PROTO"),
            a = Object.prototype;
        e.exports = Object.getPrototypeOf || function(e) {
            return e = i(e), r(e, o) ? e[o] : "function" == typeof e.constructor && e instanceof e.constructor ? e.constructor.prototype : e instanceof Object ? a : null
        }
    }, function(e, t, n) {
        var r = n(85)("unscopables"),
            i = Array.prototype;
        void 0 == i[r] && n(146)(i, r, {}), e.exports = function(e) {
            i[r][e] = !0
        }
    }, function(e, t, n) {
        "use strict";
        var r = n(335),
            i = n(166),
            o = "Map";
        e.exports = n(238)(o, (function(e) {
            return function() {
                return e(this, arguments.length > 0 ? arguments[0] : void 0)
            }
        }), {
            get: function(e) {
                var t = r.getEntry(i(this, o), e);
                return t && t.v
            },
            set: function(e, t) {
                return r.def(i(this, o), 0 === e ? 0 : e, t)
            }
        }, r, !0)
    }, function(e, t, n) {
        var r = n(133);
        e.exports = function(e, t, n, i) {
            try {
                return i ? t(r(n)[0], n[1]) : t(n)
            } catch (a) {
                var o = e.return;
                throw void 0 !== o && r(o.call(e)), a
            }
        }
    }, function(e, t, n) {
        var r = n(204),
            i = n(85)("iterator"),
            o = Array.prototype;
        e.exports = function(e) {
            return void 0 !== e && (r.Array === e || o[i] === e)
        }
    }, function(e, t, n) {
        var r = n(328),
            i = n(85)("iterator"),
            o = n(204);
        e.exports = n(121).getIteratorMethod = function(e) {
            if (void 0 != e) return e[i] || e["@@iterator"] || o[r(e)]
        }
    }, function(e, t, n) {
        "use strict";
        var r = n(112),
            i = n(132),
            o = n(134),
            a = n(85)("species");
        e.exports = function(e) {
            var t = r[e];
            o && t && !t[a] && i.f(t, a, {
                configurable: !0,
                get: function() {
                    return this
                }
            })
        }
    }, function(e, t, n) {
        var r = n(85)("iterator"),
            i = !1;
        try {
            var o = [7][r]();
            o.return = function() {
                i = !0
            }, Array.from(o, (function() {
                throw 2
            }))
        } catch (a) {}
        e.exports = function(e, t) {
            if (!t && !i) return !1;
            var n = !1;
            try {
                var o = [7],
                    c = o[r]();
                c.next = function() {
                    return {
                        done: n = !0
                    }
                }, o[r] = function() {
                    return c
                }, e(o)
            } catch (a) {}
            return n
        }
    }, function(e, t, n) {
        var r = n(98),
            i = n(457).set;
        e.exports = function(e, t, n) {
            var o, a = t.constructor;
            return a !== n && "function" == typeof a && (o = a.prototype) !== n.prototype && r(o) && i && i(e, o), e
        }
    }, function(e, t, n) {
        var r = n(98),
            i = n(133),
            o = function(e, t) {
                if (i(e), !r(t) && null !== t) throw TypeError(t + ": can't set as prototype!")
            };
        e.exports = {
            set: Object.setPrototypeOf || ("__proto__" in {} ? function(e, t, r) {
                try {
                    (r = n(203)(Function.call, n(336).f(Object.prototype, "__proto__").set, 2))(e, []), t = !(e instanceof Array)
                } catch (i) {
                    t = !0
                }
                return function(e, n) {
                    return o(e, n), t ? e.__proto__ = n : r(e, n), e
                }
            }({}, !1) : void 0),
            check: o
        }
    }, function(e, t, n) {
        n(201), n(331), n(279), n(459), e.exports = n(121).Set
    }, function(e, t, n) {
        "use strict";
        var r = n(335),
            i = n(166);
        e.exports = n(238)("Set", (function(e) {
            return function() {
                return e(this, arguments.length > 0 ? arguments[0] : void 0)
            }
        }), {
            add: function(e) {
                return r.def(i(this, "Set"), e = 0 === e ? 0 : e, e)
            }
        }, r)
    }, function(e, t, n) {
        n(461), n(201), e.exports = n(121).Symbol
    }, function(e, t, n) {
        "use strict";
        var r = n(112),
            i = n(135),
            o = n(134),
            a = n(272),
            c = n(131),
            u = n(206).KEY,
            s = n(147),
            d = n(267),
            l = n(237),
            f = n(202),
            p = n(85),
            m = n(337),
            v = n(462),
            b = n(463),
            h = n(338),
            g = n(133),
            y = n(98),
            O = n(165),
            j = n(268),
            _ = n(236),
            w = n(273),
            x = n(464),
            E = n(336),
            C = n(132),
            I = n(205),
            S = E.f,
            T = C.f,
            k = x.f,
            A = r.Symbol,
            z = r.JSON,
            M = z && z.stringify,
            L = p("_hidden"),
            P = p("toPrimitive"),
            R = {}.propertyIsEnumerable,
            D = d("symbol-registry"),
            B = d("symbols"),
            q = d("op-symbols"),
            N = Object.prototype,
            V = "function" == typeof A,
            F = r.QObject,
            U = !F || !F.prototype || !F.prototype.findChild,
            H = o && s((function() {
                return 7 != w(T({}, "a", {
                    get: function() {
                        return T(this, "a", {
                            value: 7
                        }).a
                    }
                })).a
            })) ? function(e, t, n) {
                var r = S(N, t);
                r && delete N[t], T(e, t, n), r && e !== N && T(N, t, r)
            } : T,
            G = function(e) {
                var t = B[e] = w(A.prototype);
                return t._k = e, t
            },
            W = V && "symbol" == typeof A.iterator ? function(e) {
                return "symbol" == typeof e
            } : function(e) {
                return e instanceof A
            },
            Y = function(e, t, n) {
                return e === N && Y(q, t, n), g(e), t = j(t, !0), g(n), i(B, t) ? (n.enumerable ? (i(e, L) && e[L][t] && (e[L][t] = !1), n = w(n, {
                    enumerable: _(0, !1)
                })) : (i(e, L) || T(e, L, _(1, {})), e[L][t] = !0), H(e, t, n)) : T(e, t, n)
            },
            K = function(e, t) {
                g(e);
                for (var n, r = b(t = O(t)), i = 0, o = r.length; o > i;) Y(e, n = r[i++], t[n]);
                return e
            },
            Z = function(e) {
                var t = R.call(this, e = j(e, !0));
                return !(this === N && i(B, e) && !i(q, e)) && (!(t || !i(this, e) || !i(B, e) || i(this, L) && this[L][e]) || t)
            },
            J = function(e, t) {
                if (e = O(e), t = j(t, !0), e !== N || !i(B, t) || i(q, t)) {
                    var n = S(e, t);
                    return !n || !i(B, t) || i(e, L) && e[L][t] || (n.enumerable = !0), n
                }
            },
            X = function(e) {
                for (var t, n = k(O(e)), r = [], o = 0; n.length > o;) i(B, t = n[o++]) || t == L || t == u || r.push(t);
                return r
            },
            Q = function(e) {
                for (var t, n = e === N, r = k(n ? q : O(e)), o = [], a = 0; r.length > a;) !i(B, t = r[a++]) || n && !i(N, t) || o.push(B[t]);
                return o
            };
        V || (c((A = function() {
            if (this instanceof A) throw TypeError("Symbol is not a constructor!");
            var e = f(arguments.length > 0 ? arguments[0] : void 0),
                t = function t(n) {
                    this === N && t.call(q, n), i(this, L) && i(this[L], e) && (this[L][e] = !1), H(this, e, _(1, n))
                };
            return o && U && H(N, e, {
                configurable: !0,
                set: t
            }), G(e)
        }).prototype, "toString", (function() {
            return this._k
        })), E.f = J, C.f = Y, n(339).f = x.f = X, n(239).f = Z, n(283).f = Q, o && !n(235) && c(N, "propertyIsEnumerable", Z, !0), m.f = function(e) {
            return G(p(e))
        }), a(a.G + a.W + a.F * !V, {
            Symbol: A
        });
        for (var $ = "hasInstance,isConcatSpreadable,iterator,match,replace,search,species,split,toPrimitive,toStringTag,unscopables".split(","), ee = 0; $.length > ee;) p($[ee++]);
        for (var te = I(p.store), ne = 0; te.length > ne;) v(te[ne++]);
        a(a.S + a.F * !V, "Symbol", {
            for: function(e) {
                return i(D, e += "") ? D[e] : D[e] = A(e)
            },
            keyFor: function(e) {
                if (!W(e)) throw TypeError(e + " is not a symbol!");
                for (var t in D)
                    if (D[t] === e) return t
            },
            useSetter: function() {
                U = !0
            },
            useSimple: function() {
                U = !1
            }
        }), a(a.S + a.F * !V, "Object", {
            create: function(e, t) {
                return void 0 === t ? w(e) : K(w(e), t)
            },
            defineProperty: Y,
            defineProperties: K,
            getOwnPropertyDescriptor: J,
            getOwnPropertyNames: X,
            getOwnPropertySymbols: Q
        }), z && a(a.S + a.F * (!V || s((function() {
            var e = A();
            return "[null]" != M([e]) || "{}" != M({
                a: e
            }) || "{}" != M(Object(e))
        }))), "JSON", {
            stringify: function(e) {
                for (var t, n, r = [e], i = 1; arguments.length > i;) r.push(arguments[i++]);
                if (n = t = r[1], (y(t) || void 0 !== e) && !W(e)) return h(t) || (t = function(e, t) {
                    if ("function" == typeof n && (t = n.call(this, e, t)), !W(t)) return t
                }), r[1] = t, M.apply(z, r)
            }
        }), A.prototype[P] || n(146)(A.prototype, P, A.prototype.valueOf), l(A, "Symbol"), l(Math, "Math", !0), l(r.JSON, "JSON", !0)
    }, function(e, t, n) {
        var r = n(112),
            i = n(121),
            o = n(235),
            a = n(337),
            c = n(132).f;
        e.exports = function(e) {
            var t = i.Symbol || (i.Symbol = o ? {} : r.Symbol || {});
            "_" == e.charAt(0) || e in t || c(t, e, {
                value: a.f(e)
            })
        }
    }, function(e, t, n) {
        var r = n(205),
            i = n(283),
            o = n(239);
        e.exports = function(e) {
            var t = r(e),
                n = i.f;
            if (n)
                for (var a, c = n(e), u = o.f, s = 0; c.length > s;) u.call(e, a = c[s++]) && t.push(a);
            return t
        }
    }, function(e, t, n) {
        var r = n(165),
            i = n(339).f,
            o = {}.toString,
            a = "object" == typeof window && window && Object.getOwnPropertyNames ? Object.getOwnPropertyNames(window) : [];
        e.exports.f = function(e) {
            return a && "[object Window]" == o.call(e) ? function(e) {
                try {
                    return i(e)
                } catch (t) {
                    return a.slice()
                }
            }(e) : i(r(e))
        }
    }, function(e, t, n) {
        n(201), n(333), n(466), e.exports = n(121).WeakMap
    }, function(e, t, n) {
        "use strict";
        var r, i = n(340)(0),
            o = n(131),
            a = n(206),
            c = n(469),
            u = n(341),
            s = n(98),
            d = n(147),
            l = n(166),
            f = "WeakMap",
            p = a.getWeak,
            m = Object.isExtensible,
            v = u.ufstore,
            b = {},
            h = function(e) {
                return function() {
                    return e(this, arguments.length > 0 ? arguments[0] : void 0)
                }
            },
            g = {
                get: function(e) {
                    if (s(e)) {
                        var t = p(e);
                        return !0 === t ? v(l(this, f)).get(e) : t ? t[this._i] : void 0
                    }
                },
                set: function(e, t) {
                    return u.def(l(this, f), e, t)
                }
            },
            y = e.exports = n(238)(f, h, g, u, !0, !0);
        d((function() {
            return 7 != (new y).set((Object.freeze || Object)(b), 7).get(b)
        })) && (c((r = u.getConstructor(h, f)).prototype, g), a.NEED = !0, i(["delete", "has", "get", "set"], (function(e) {
            var t = y.prototype,
                n = t[e];
            o(t, e, (function(t, i) {
                if (s(t) && !m(t)) {
                    this._f || (this._f = new r);
                    var o = this._f[e](t, i);
                    return "set" == e ? this : o
                }
                return n.call(this, t, i)
            }))
        })))
    }, function(e, t, n) {
        var r = n(468);
        e.exports = function(e, t) {
            return new(r(e))(t)
        }
    }, function(e, t, n) {
        var r = n(98),
            i = n(338),
            o = n(85)("species");
        e.exports = function(e) {
            var t;
            return i(e) && ("function" != typeof(t = e.constructor) || t !== Array && !i(t.prototype) || (t = void 0), r(t) && null === (t = t[o]) && (t = void 0)), void 0 === t ? Array : t
        }
    }, function(e, t, n) {
        "use strict";
        var r = n(205),
            i = n(283),
            o = n(239),
            a = n(278),
            c = n(274),
            u = Object.assign;
        e.exports = !u || n(147)((function() {
            var e = {},
                t = {},
                n = Symbol(),
                r = "abcdefghijklmnopqrst";
            return e[n] = 7, r.split("").forEach((function(e) {
                t[e] = e
            })), 7 != u({}, e)[n] || Object.keys(u({}, t)).join("") != r
        })) ? function(e, t) {
            for (var n = a(e), u = arguments.length, s = 1, d = i.f, l = o.f; u > s;)
                for (var f, p = c(arguments[s++]), m = d ? r(p).concat(d(p)) : r(p), v = m.length, b = 0; v > b;) l.call(p, f = m[b++]) && (n[f] = p[f]);
            return n
        } : u
    }, function(e, t, n) {
        n(201), n(279), n(471), e.exports = n(121).WeakSet
    }, function(e, t, n) {
        "use strict";
        var r = n(341),
            i = n(166),
            o = "WeakSet";
        n(238)(o, (function(e) {
            return function() {
                return e(this, arguments.length > 0 ? arguments[0] : void 0)
            }
        }), {
            add: function(e) {
                return r.def(i(this, o), e, !0)
            }
        }, r, !1, !0)
    }, function(e, t, n) {
        n(473).polyfill()
    }, function(e, t, n) {
        (function(t) {
            for (var r = n(474), i = "undefined" === typeof window ? t : window, o = ["moz", "webkit"], a = "AnimationFrame", c = i["request" + a], u = i["cancel" + a] || i["cancelRequest" + a], s = 0; !c && s < o.length; s++) c = i[o[s] + "Request" + a], u = i[o[s] + "Cancel" + a] || i[o[s] + "CancelRequest" + a];
            if (!c || !u) {
                var d = 0,
                    l = 0,
                    f = [];
                c = function(e) {
                    if (0 === f.length) {
                        var t = r(),
                            n = Math.max(0, 16.666666666666668 - (t - d));
                        d = n + t, setTimeout((function() {
                            var e = f.slice(0);
                            f.length = 0;
                            for (var t = 0; t < e.length; t++)
                                if (!e[t].cancelled) try {
                                    e[t].callback(d)
                                } catch (n) {
                                    setTimeout((function() {
                                        throw n
                                    }), 0)
                                }
                        }), Math.round(n))
                    }
                    return f.push({
                        handle: ++l,
                        callback: e,
                        cancelled: !1
                    }), l
                }, u = function(e) {
                    for (var t = 0; t < f.length; t++) f[t].handle === e && (f[t].cancelled = !0)
                }
            }
            e.exports = function(e) {
                return c.call(i, e)
            }, e.exports.cancel = function() {
                u.apply(i, arguments)
            }, e.exports.polyfill = function(e) {
                e || (e = i), e.requestAnimationFrame = c, e.cancelAnimationFrame = u
            }
        }).call(this, n(69))
    }, function(e, t, n) {
        (function(t) {
            (function() {
                var n, r, i, o, a, c;
                "undefined" !== typeof performance && null !== performance && performance.now ? e.exports = function() {
                    return performance.now()
                } : "undefined" !== typeof t && null !== t && t.hrtime ? (e.exports = function() {
                    return (n() - a) / 1e6
                }, r = t.hrtime, o = (n = function() {
                    var e;
                    return 1e9 * (e = r())[0] + e[1]
                })(), c = 1e9 * t.uptime(), a = o - c) : Date.now ? (e.exports = function() {
                    return Date.now() - i
                }, i = Date.now()) : (e.exports = function() {
                    return (new Date).getTime() - i
                }, i = (new Date).getTime())
            }).call(this)
        }).call(this, n(111))
    }, , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , function(e, t, n) {
        "use strict";
        n.r(t);
        var r = function() {
            window.performance && "function" === typeof window.performance.mark && window.performance.mark("lc_js_loaded")
        };
        r();
        var i, o, a, c = n(315),
            u = n.n(c),
            s = function() {
                for (var e; i;) {
                    e = i.fn, i = i.next;
                    try {
                        e()
                    } catch (t) {
                        throw i ? a() : o = void 0, t
                    }
                }
                o = void 0
            },
            d = window.MutationObserver || window.WebKitMutationObserver;
        if (d) {
            var l = document.createTextNode(""),
                f = !0;
            new d(s).observe(l, {
                characterData: !0
            }), a = function() {
                l.data = f = !f
            }
        } else a = function() {
            setTimeout(s, 0)
        };
        var p = function(e) {
            var t = {
                fn: e,
                next: void 0
            };
            o && (o.next = t), i || (i = t, a()), o = t
        };
        /native code/.test(window.Promise) || (window.Promise = u.a, window.Promise._immediateFn = p), "function" !== typeof window.Promise.prototype.finally && (window.Promise.prototype.finally = u.a.prototype.finally);
        n(440), n(458), n(460), n(465), n(470), n(472);
        var m = n(251),
            v = n.n(m),
            b = n(2);
        if (Object.assign = v.a, "function" !== typeof Array.from && (Array.from = function(e) {
                return [].slice.call(e)
            }), "function" !== typeof Array.prototype.find && (Array.prototype.find = function(e) {
                return Object(b.o)(e, this)
            }), "function" !== typeof Array.prototype.findIndex && (Array.prototype.findIndex = function(e) {
                return Object(b.p)(e, this)
            }), "function" !== typeof Object.values && (Object.values = b.Bb), "function" !== typeof Object.is && (Object.is = function(e, t) {
                return e === t ? 0 !== e || 1 / e === 1 / t : e !== e && t !== t
            }), "function" !== typeof Element.prototype.matches && (Element.prototype.matches = Element.prototype.msMatchesSelector), "function" !== typeof Element.prototype.closest && (Element.prototype.closest = function(e) {
                var t = this;
                do {
                    if (t.matches(e)) return t;
                    t = t.parentElement || t.parentNode
                } while (null !== t && t.nodeType === Node.ELEMENT_NODE);
                return null
            }), "msCrypto" in window) {
            var h = document.createTreeWalker;
            document.createTreeWalker = function(e, t, n, r) {
                return void 0 === r && (r = !1), h.call(document, e, t, n.acceptNode, r)
            }
        }
        var g = n(1),
            y = n(8),
            O = n(27),
            j = n(18),
            _ = new RegExp("(" + ["BetterJsPop", "LOCAL_STORAGE is null", "Can't find variable: auto", "Can't find variable: ext", "Can't find variable: $", "_avast_submit", "No license found in the URL.", "getNewsReadStatus4Vivo", "is banned!", "Object Not Found Matching Id"].join("|") + ")"),
            w = new RegExp("(" + ["chrome-extension://", "https://www.smybeds.com/"].join("|") + ")"),
            x = function(e) {
                return !!(e.message && _.test(e.message) || e.stack && w.test(e.stack))
            };
        window.addEventListener("error", (function(e) {
            var t = e.error;
            if (t)
                if (t.message && -1 !== t.message.indexOf("evaluating 'document.getElementById('view-chat').innerHTML'")) {
                    var n = Object(j.c)();
                    if (10095588 === n || 7243681 === n) return;
                    Object(O.c)("custom_mobile_hacks", t)
                } else x(t) || Object(O.c)("onerror", t)
        })), window.addEventListener("unhandledrejection", (function(e) {
            e && e.reason && (x(e.reason) || Object(O.c)("unhandledrejection", e.reason))
        }));
        var E = n(252),
            C = n(13),
            I = n(162),
            S = n(29),
            T = I.a.Model;
        I.a.Model = function() {
            return function(e) {
                var t = Object(S.a)(),
                    n = {};
                return e.resolveRemoteCall = function(e) {
                    var t = e.id,
                        r = e.value,
                        i = n[t];
                    delete n[t], i(r)
                }, e.emitEvent = function(e) {
                    var n = e.event,
                        r = e.data;
                    t.emit(n, r)
                }, new T(e).then((function(r) {
                    return r.call = function(e) {
                        for (var t = arguments.length, i = new Array(t > 1 ? t - 1 : 0), o = 1; o < t; o++) i[o - 1] = arguments[o];
                        return new Promise((function(t) {
                            var o = Object(b.w)(n);
                            n[o] = t, r.emit("remote-call", {
                                id: o,
                                method: e,
                                args: i
                            })
                        }))
                    }, e.remoteCall = function(t) {
                        var n = t.id,
                            i = t.method,
                            o = t.args,
                            a = "function" === typeof e[i] ? e[i].apply(r, o) : void 0;
                        a && "function" === typeof a.then ? a.then((function(e) {
                            r.call("resolveRemoteCall", {
                                id: n,
                                value: e
                            })
                        })) : r.call("resolveRemoteCall", {
                            id: n,
                            value: a
                        })
                    }, r.on = t.on, r.off = t.off, r
                }))
            }
        }();
        var k = I.a,
            A = n(160),
            z = n(19),
            M = n(9);
        var L, P = n(5),
            R = n(14),
            D = n(49),
            B = n(35),
            q = function() {
                return new Promise((function(e) {
                    return setTimeout(e, 0)
                }))
            },
            N = function(e) {
                return /px$/.test(e) ? Math.ceil(parseFloat(e)) + "px" : e
            },
            V = function(e, t) {
                var n = function() {
                    return e.call("resize", function(e) {
                        return Object(g.a)({}, e, {
                            width: N(e.width),
                            height: N(e.height)
                        })
                    }(t))
                };
                return Object(B.c)() ? new Promise((function(t) {
                    e.call("applyHiddenStyles").then((function() {
                        return requestAnimationFrame(t)
                    }))
                })).then(n) : n()
            },
            F = function(e) {
                var t = e.minimizedRef;
                return t ? Object(R.e)(["width", "height"], t) : {
                    width: "0px",
                    height: "0px"
                }
            },
            U = function(e) {
                var t = !1,
                    n = null,
                    r = function e() {
                        if (n && !t) {
                            var r = n;
                            return n = null, t = !0, r().then((function() {
                                return t = !1, e()
                            }))
                        }
                    };
                return function() {
                    for (var t = arguments.length, i = new Array(t), o = 0; o < t; o++) i[o] = arguments[o];
                    return n = e.bind.apply(e, [null].concat(i)), r()
                }
            }((function(e, t) {
                var n = t.getApplicationState(),
                    r = n.mobile,
                    i = n.invitation,
                    o = Object(M.W)(t, "maximized"),
                    a = L,
                    c = e.model,
                    u = c.fullWidth,
                    s = c.fullHeight,
                    d = c.parentWidth,
                    l = void 0 === d ? 330 : d,
                    f = c.parentHeight,
                    p = void 0 === f ? 400 : f,
                    m = Object(M.d)(t),
                    v = r && !!m && !Object(b.D)(m.properties.uniqueId, i.hiddenIds);
                L = o;
                var h = new Promise((function(n) {
                    a && o ? n() : !a || o ? a || !o ? e.minimizedRef ? (e.minimizedRef && (e.minimizedRef.style.width = "100%", e.minimizedRef.style.height = "100%"), q().then((function() {
                        ! function(e, t) {
                            var n = document.getElementById("root");
                            Object(R.b)({
                                width: e,
                                height: t,
                                position: "absolute",
                                bottom: 0,
                                right: 0
                            }, n)
                        }(r ? l + "px" : u, r ? p + "px" : s), e.minimizedRef && (e.minimizedRef.style.width = "", e.minimizedRef.style.height = ""), q().then((function() {
                            V(e, Object(g.a)({}, F(e), {
                                ignoreHorizontalOffset: v
                            })).then((function() {
                                return function() {
                                    var e = document.getElementById("root");
                                    Object(R.b)({
                                        width: "100%",
                                        height: "100%",
                                        position: "static"
                                    }, e)
                                }()
                            })).then(n)
                        }))
                    }))) : V(e, {
                        width: "0px",
                        height: "0px",
                        maximized: o,
                        ignoreHorizontalOffset: v
                    }).then(n) : V(e, {
                        width: u,
                        height: s,
                        maximized: o,
                        ignoreHorizontalOffset: v
                    }).then(n) : t.once("animation_end", (function() {
                        V(e, Object(g.a)({}, F(e), {
                            maximized: o,
                            ignoreHorizontalOffset: v
                        })).then(n)
                    }))
                }));
                return Object(B.c)() ? h.then((function() {
                    return e.call("show")
                })) : h
            })),
            H = function(e, t) {
                return L = Object(M.W)(t, "maximized"), Object(P.y)(Object(D.c)(t, (function(e) {
                    return e.application.visibility.state
                })), Object(P.B)(1), Object(P.j)((function() {
                    return U(e, t)
                }))), U(e, t)
            },
            G = n(94),
            W = n(54),
            Y = n(95),
            K = n(55),
            Z = n(58),
            J = n(89),
            X = n(47),
            Q = n(119),
            $ = {
                question: {
                    type: "text"
                },
                checkbox_for_email: {
                    type: "checkbox",
                    meta: "confirm_subscription"
                },
                header: {
                    type: "information"
                },
                skill: {
                    type: "group_select"
                }
            },
            ee = function(e) {
                return e.map((function(e, t) {
                    var n = {};
                    return Object(b.B)("label", e) && (n.label = e.label), Object(b.B)("checked", e) && (n.checked = e.checked), n.value = String(t), Object(b.B)("skill_id", e) && (n.value = String(e.skill_id)), Object(b.B)("embedded_chat_hide_when_offline", e) && (n.ticketFormDisabled = Boolean(e.embedded_chat_hide_when_offline)), Object(b.B)("queue_template", e) && (n.queueTemplate = e.queue_template), n
                }))
            },
            te = function(e) {
                var t = !1,
                    n = {
                        fields: e.fields.sort((function(e, t) {
                            return e.order - t.order
                        })).map((function(e, n) {
                            var r = {};
                            if ("facebookConnect" === e.type) return t = !0, !1;
                            e.id ? r.name = e.id : -1 === ["header", "information"].indexOf(e.type) && (r.name = String(n)), Object(b.B)("value", e) && (r.value = e.value), Object(b.B)("label", e) && (r.label = e.label), Object(b.B)("required", e) && (r.required = e.required), "rating" === e.type && (r.commentLabel = e.options[0]), e.skills && e.skills.length > 0 ? r.options = ee(e.skills) : e.options && e.options.length > 0 && (e.options_data ? r.options = ee(e.options_data) : Object(b.H)(e.options[0]) ? r.options = e.options.map((function(e, t) {
                                return {
                                    label: e.label,
                                    value: String(t)
                                }
                            })) : r.options = e.options.map((function(e, t) {
                                return {
                                    label: e,
                                    value: String(t)
                                }
                            }))), e.serverType && (r.serverType = e.serverType);
                            var i = function(e) {
                                    return {
                                        type: $[e] && $[e].type || e,
                                        meta: $[e] && $[e].meta || !1
                                    }
                                }(e.type),
                                o = i.type,
                                a = i.meta;
                            return r.type = o, a && (r.meta = a), r
                        })).filter(Boolean)
                    };
                return e.id && (n.id = e.id), t && (n.facebookConnect = !0), n
            },
            ne = function(e) {
                return Object(g.a)({}, e, {
                    fields: e.fields.map((function(e) {
                        switch (e.type) {
                            case "name":
                            case "subject":
                                return Object(g.a)({}, e, {
                                    maxLength: 1024
                                });
                            case "email":
                            case "textarea":
                                return Object(g.a)({}, e, {
                                    required: !0
                                });
                            default:
                                return e
                        }
                    }))
                })
            },
            re = function(e) {
                var t = e.license,
                    n = e.group,
                    r = e.pageUrl,
                    i = e.form,
                    o = function(e, t) {
                        var n = Object(b.O)((function(e) {
                            return "message" === e ? "textarea" : e
                        }), e);
                        return t.fields.map((function(e) {
                            if ("information" === e.type) return null;
                            var t = {
                                type: e.type,
                                text: "undefined" !== typeof document ? Object(Q.b)(e.label) : e.label,
                                serverType: e.serverType
                            };
                            return (e.name in n || e.type in n) && ("options" in e ? t.value = Object(b.l)(n[e.name]).map((function(t) {
                                return Object(b.o)((function(e) {
                                    return e.value === t
                                }), e.options).label
                            })).join(", ") : e.name in n ? t.value = n[e.name] : t.value = n[e.type], t.value = Object(b.yb)(t.value), t.text = t.text + " " + t.value), t
                        })).filter(Boolean)
                    }(e.answers, i),
                    a = Object(b.o)((function(e) {
                        return "email" === e.type || "email" === e.serverType
                    }), o),
                    c = Object(b.o)((function(e) {
                        return "name" === e.type || "name" === e.serverType
                    }), o);
                if (!a) throw new Error("Missing email");
                if (!Object(b.o)((function(e) {
                        return "textarea" === e.type
                    }), o)) throw new Error("Missing message");
                var u = Object(b.o)((function(e) {
                        return "subject" === e.type || "subject" === e.serverType
                    }), o),
                    s = o.filter((function(e) {
                        var t = e.type,
                            n = e.serverType;
                        return -1 === ["name", "email", "subject"].indexOf(n || t)
                    })).map((function(e) {
                        return e.text
                    })).join("\n");
                return Object(g.a)({}, u && u.value && {
                    subject: u.value
                }, {
                    message: {
                        text: s
                    },
                    requester: Object(g.a)({
                        email: a.value
                    }, c && c.value && {
                        name: c.value
                    }),
                    integration: Object(g.a)({
                        type: "livechat",
                        ID: String(t),
                        teamID: String(n)
                    }, r && {
                        referenceURL: r
                    })
                })
            },
            ie = n(3),
            oe = n(154),
            ae = function(e) {
                return e.replace(/index[0-9]*_/gi, "")
            },
            ce = function(e, t) {
                var n = Object(b.o)((function(e) {
                    return "groupSelect" === e.meta
                }), e);
                return Object.keys(t).reduce((function(r, i) {
                    var o = t[i];
                    if ("rateComment" === i) return r.rateComment = o, r;
                    if ("rating" === i) return r.rate = null === o ? o : ae(o), r;
                    var a = Object(b.o)((function(e) {
                            return e.name === i
                        }), e),
                        c = a.serverName;
                    return n && c && c === n.serverName && (r.choosenGroupIndex = t[n.name].match(/index([0-9]*)_/)[1], r.choosenGroup = parseInt(ae(o), 10)), a.options ? r.fields[c] = Object(b.E)(o) ? o.map(ae) : ae(o) : r.fields[c] = o, r
                }), {
                    fields: {}
                })
            };

        function ue(e) {
            var t = function(e, t) {
                if ("object" !== typeof e || null === e) return e;
                var n = e[Symbol.toPrimitive];
                if (void 0 !== n) {
                    var r = n.call(e, t || "default");
                    if ("object" !== typeof r) return r;
                    throw new TypeError("@@toPrimitive must return a primitive value.")
                }
                return ("string" === t ? String : Number)(e)
            }(e, "string");
            return "symbol" === typeof t ? t : String(t)
        }
        var se = {
                group_chooser: "select",
                header: "information",
                name: "text",
                question: "text",
                subject: "text",
                checkbox_for_email: "checkbox"
            },
            de = function(e, t) {
                return e.getSessionUser().serverId === t.authorId
            },
            le = function(e, t) {
                return de(e, t) ? e.getSessionUser().id : t.authorId
            },
            fe = function(e, t) {
                if ("file" === t.type) return t.id;
                if (de(e, t)) return "customId" in t && e.hasEvent(ie.d, t.customId) ? t.customId : t.id;
                var n = e.getEventByServerId(ie.d, t.id);
                return n ? n.id : t.id
            },
            pe = function(e) {
                return e.groupIds ? e.groupIds[0] : null
            },
            me = function(e, t) {
                var n = e.getSessionUser().serverId,
                    r = Object(b.M)(t.filter((function(e) {
                        return e.present && e.id !== n
                    })));
                return r ? r.id : null
            },
            ve = function(e, t) {
                var n = t.chat,
                    r = t.chat,
                    i = r.thread,
                    o = r.users;
                return {
                    id: n.id,
                    active: i.active,
                    agent: me(e, o),
                    events: i.events.map((function(t) {
                        return je(e, Object(g.a)({}, t, {
                            seen: !1
                        }))
                    })).filter(Boolean),
                    group: pe(n.access),
                    thread: i.id,
                    properties: Se(i)
                }
            },
            be = function(e, t) {
                return Object(g.a)({}, t, {
                    type: e,
                    fields: t.fields.reduce((function(e, t) {
                        var n = t.id,
                            r = Object(y.a)(t, ["id"]),
                            i = Object(g.a)({}, r, {
                                type: se[r.type] || r.type,
                                serverName: n,
                                serverType: r.type
                            });
                        if ("information" === i.type) i.value = i.label.replace(/<br(\s)?(\/)?>/gi, "\n");
                        else if ("checkbox_for_email" === r.type) i.meta = "confirm_subscription", i.label = "", i.options = [{
                            label: r.label,
                            checked: r.checked,
                            value: "index0_0",
                            originalValue: "0"
                        }], r.checked && (i.defaultValue = [i.options[0].value]);
                        else if (r.options) {
                            var o = "group_chooser" === r.type;
                            o && (i.meta = "groupSelect"), i.options = i.options.map((function(e, t) {
                                var n = o ? e.groupId : e.id;
                                return Object(g.a)({}, Object(b.X)(["id", "checked"], e), {
                                    value: "index" + t + "_" + n,
                                    originalValue: String(n)
                                })
                            }))
                        }
                        return i.name = Object(b.D)(r.type, ["name", "email", "rating"]) ? r.type : Object(b.v)() + "_" + n, "rating" === r.type ? [].concat(e, [i, {
                            name: "rateComment",
                            type: "textarea",
                            label: i.commentLabel,
                            required: !1,
                            dependOn: "rating"
                        }]) : [].concat(e, [i])
                    }), [])
                })
            },
            he = function(e) {
                return ne(be("ticket", e))
            },
            ge = function(e, t) {
                var n = e.getSessionUser().serverId,
                    r = t[n],
                    i = Object(y.a)(t, [n].map(ue));
                return {
                    sessionUserSeenUpTo: r,
                    latestOtherUserSeenUpTo: Object(b.M)(Object(b.Bb)(i).filter(Boolean).sort())
                }
            },
            ye = function(e, t) {
                var n = t.thread,
                    r = t.users,
                    i = t.eventsSeenUpToMap,
                    o = n.id,
                    a = n.active,
                    c = n.events,
                    u = n.access,
                    s = e.getSessionUser().serverId,
                    d = ge(e, i),
                    l = d.sessionUserSeenUpTo,
                    f = d.latestOtherUserSeenUpTo;
                return {
                    thread: n ? {
                        id: o,
                        active: a,
                        agent: a ? me(e, r) : null,
                        events: c.map((function(t) {
                            var n = t.authorId === s ? f >= t.createdAt : l >= t.createdAt;
                            return je(e, Object(g.a)({}, t, {
                                seen: n
                            }))
                        })).filter(Boolean),
                        group: pe(u),
                        properties: Se(n)
                    } : null,
                    eventsSeenUpToMap: i
                }
            },
            Oe = function(e) {
                var t = e.properties,
                    n = Object(y.a)(e, ["properties"]);
                if ("lc2" in t) {
                    var r = t.lc2;
                    if ("greeting_unique_id" in r) return function(e, t) {
                        var n = oe.c(Object(g.a)({}, e));
                        return n.properties = Object(g.a)({}, n.properties, {
                            invitation: !0,
                            subtype: e.subtype,
                            id: t.greeting_id,
                            uniqueId: t.greeting_unique_id
                        }), n
                    }(n, r);
                    if (r.welcome_message) return function(e) {
                        return oe.c(Object(g.a)({}, e, {
                            welcomeMessage: !0
                        }))
                    }(n)
                }
                return function(e, t) {
                    return oe.c(Object(g.a)({}, e, t.url_details && {
                        urlDetails: t.url_details
                    }, t.translation && {
                        translation: Ae(t.translation)
                    }))
                }(n, t)
            },
            je = function(e, t) {
                var n = Object(g.a)({}, t, {
                    id: fe(e, t),
                    serverId: t.id,
                    authorId: le(e, t),
                    timestamp: new Date(t.createdAt).getTime()
                });
                switch (n.type) {
                    case "form":
                        return we(n);
                    case "filled_form":
                        return xe(n);
                    case "message":
                        return Oe(n);
                    case "rich_message":
                        return function(e) {
                            if ("lc2" in e.properties && "greeting_unique_id" in e.properties.lc2) {
                                var t = oe.d(e);
                                return t.properties = Object(g.a)({}, t.properties, {
                                    invitation: !0,
                                    subtype: e.subtype,
                                    id: e.properties.lc2.greeting_id,
                                    uniqueId: e.properties.lc2.greeting_unique_id
                                }), t
                            }
                            return oe.d(e)
                        }(n);
                    case "file":
                        return oe.b(n);
                    case "system_message":
                        return Ee(n);
                    case "custom":
                        return _e(n);
                    default:
                        return null
                }
            },
            _e = function(e) {
                var t = e.properties,
                    n = e.customId;
                return Object(g.a)({}, oe.a(e), {
                    type: "custom",
                    properties: Object(g.a)({}, t, {
                        customId: n
                    })
                })
            },
            we = function(e) {
                var t, n = Object(g.a)({}, e, {
                    fields: e.fields.map((function(e) {
                        return e.id ? e : Object(g.a)({}, e, {
                            id: Object(b.v)()
                        })
                    }))
                });
                return Object(g.a)({}, oe.a(n), {
                    type: "form",
                    properties: {
                        answered: !1,
                        formType: (null == (t = n.properties.lc2) ? void 0 : t.form_type) || null,
                        fields: be("", n).fields,
                        formId: n.formId.replace(/_[0-9]+/, "")
                    }
                })
            },
            xe = function(e) {
                var t;
                return Object(g.a)({}, oe.a(e), {
                    type: "form",
                    properties: {
                        answered: !0,
                        formId: e.formId,
                        formType: (null == (t = e.properties.lc2) ? void 0 : t.form_type) || null,
                        fields: e.fields.filter((function(e) {
                            return "answer" in e || "answers" in e && 0 !== e.answers.length
                        })).map((function(e) {
                            if ("string" === typeof e.answer) return e;
                            if ("answers" in e) {
                                var t = e.answers,
                                    n = Object(y.a)(e, ["answers"]);
                                return Object(g.a)({}, n, {
                                    answer: t.map((function(e) {
                                        return e.label
                                    }))
                                })
                            }
                            return Object(g.a)({}, e, {
                                answer: e.answer.label
                            })
                        }))
                    }
                })
            },
            Ee = function(e) {
                switch (e.systemMessageType) {
                    case "archived_customer_disconnected":
                    case "routing.archived_inactive":
                        return oe.e(Object(g.a)({}, e, {
                            systemMessageType: "client_inactive"
                        }));
                    case "manual_archived_agent":
                        return oe.e(Object(g.a)({}, e, {
                            systemMessageType: "operator_closed_session",
                            textVars: {
                                operator: e.textVars.agent
                            }
                        }));
                    case "manual_archived_customer":
                        return oe.e(Object(g.a)({}, e, {
                            systemMessageType: "chat_closed_by_customer"
                        }));
                    case "system_archived":
                    case "customer_banned":
                    case "routing.archived_deleted":
                    case "routing.archived_disconnected":
                    case "routing.archived_offline":
                    case "routing.archived_other":
                    case "routing.archived_remotely_signed_out":
                    case "routing.archived_signed_out":
                        return oe.e(Object(g.a)({}, e, {
                            systemMessageType: "chat_session_closed"
                        }));
                    case "routing.assigned_other":
                        return oe.e(Object(g.a)({}, e, {
                            systemMessageType: "user_transfer",
                            textVars: {
                                operator: e.textVars.agent
                            }
                        }));
                    case "routing.assigned_deleted":
                    case "routing.assigned_disconnected":
                    case "routing.assigned_inactive":
                    case "routing.assigned_remotely_signed_out":
                    case "routing.assigned_signed_out":
                        return oe.e(Object(g.a)({}, e, {
                            systemMessageType: "user_transfer",
                            textVars: {
                                operator: e.textVars.agent_added
                            }
                        }));
                    case "chat_transferred":
                        return oe.e(Object(g.a)({}, e, {
                            systemMessageType: "user_transfer",
                            textVars: {
                                operator: e.textVars.targets
                            }
                        }));
                    case "agent_joined":
                    case "agent_added":
                        return oe.e(Object(g.a)({}, e, {
                            systemMessageType: "operator_joined_conference",
                            textVars: {
                                operator: e.textVars.agent
                            }
                        }));
                    case "agent_left":
                    case "agent_removed":
                        return oe.e(Object(g.a)({}, e, {
                            systemMessageType: "operator_left_conference",
                            textVars: {
                                operator: e.textVars.agent
                            }
                        }));
                    case "rating.chat_rated":
                        return oe.e(Object(g.a)({}, e, {
                            systemMessageType: "rate_me_confirmation_" + e.textVars.score
                        }));
                    case "rating.chat_commented":
                        return oe.e(Object(g.a)({}, e, {
                            systemMessageType: "rate_me_comment_added",
                            textVars: {
                                comment: e.textVars.comment
                            }
                        }));
                    case "rating.chat_rating_canceled":
                        return oe.e(Object(g.a)({}, e, {
                            systemMessageType: "rate_me_cancel"
                        }));
                    case "custom":
                        e.systemMessageType;
                        var t = Object(y.a)(e, ["systemMessageType"]);
                        return oe.e(t);
                    default:
                        return null
                }
            },
            Ce = function(e) {
                var t = e.score,
                    n = e.comment;
                return Object(g.a)({}, "number" === typeof t && {
                    rate: 1 === t ? "good" : "bad"
                }, "string" === typeof n && {
                    rateComment: n
                })
            },
            Ie = function(e) {
                return {
                    position: e.position,
                    waitingTime: e.waitTime
                }
            },
            Se = function(e) {
                return Object(g.a)({}, "rating" in e.properties && Ce(e.properties.rating), e.queue && {
                    queue: Ie(e.queue)
                })
            },
            Te = function(e, t) {
                var n, r = {
                    event: je(e, t.event),
                    author: Object(g.a)({}, t.agent, {
                        type: "agent"
                    })
                };
                return r.event.properties = Object(g.a)({}, r.event.properties, {
                    invitation: !0,
                    id: t.id,
                    addon: t.addon,
                    uniqueId: t.uniqueId,
                    accepted: t.accepted,
                    type: (n = r.event, n.properties.quickReplies ? "quick_replies" : "rich_message" === n.type ? "card" : "plain_text"),
                    subtype: t.subtype,
                    receivedFirstTime: t.displayedFirstTime
                }), r
            },
            ke = function(e, t) {
                var n = t.type,
                    r = t.id;
                switch (n) {
                    case "filled_form":
                        var i = t.formId,
                            o = Object(y.a)(t, ["formId"]);
                        return Object(g.a)({
                            customId: o.customId,
                            formId: i
                        }, o);
                    case "emoji":
                    case "message":
                    case "message_draft":
                    case "url_preview":
                        var a = t.properties,
                            c = a.text,
                            u = a.triggeredBy,
                            s = {
                                type: "message",
                                customId: r,
                                text: c
                            };
                        if (u) {
                            var d, l = e.getEvent(ie.d, u.event);
                            if (l && l.thread && l.serverId) s.postback = {
                                id: u.button.postbackId,
                                type: "message",
                                value: u.button.value,
                                eventId: l.serverId,
                                threadId: l.thread
                            };
                            else s.properties = ((d = {}).c5e4f61e1a6c3b1521b541bc5c5a2ac5 = {
                                postback_id: u.button.postbackId
                            }, d)
                        }
                        return s;
                    case "custom_system_message":
                        var f = t.properties,
                            p = f.recipients;
                        return {
                            type: "system_message",
                            customId: r,
                            text: f.text,
                            recipients: p,
                            systemMessageType: "custom"
                        };
                    default:
                        return void 0
                }
            },
            Ae = function(e) {
                return {
                    sourceLangCode: e.source_lang_code,
                    targetLangCode: e.target_lang_code,
                    targetMessage: e.target_message
                }
            },
            ze = n(79),
            Me = function(e, t) {
                var n = M.f(e, ie.d);
                return n ? Object(g.a)({}, t, {
                    events: t.events.map((function(e) {
                        return e.properties.welcomeMessage || e.properties.invitation ? Object(g.a)({}, e, {
                            id: n.id
                        }) : e
                    }))
                }) : t
            },
            Le = function(e) {
                return Object(g.a)({}, e, {
                    properties: Object(g.a)({}, e.properties, {
                        accepted: !0
                    })
                })
            },
            Pe = function(e, t) {
                var n = e.sdk,
                    r = t.event.properties,
                    i = r.uniqueId,
                    o = r.id;
                return n.acceptGreeting({
                    greetingId: o,
                    uniqueId: i
                }).then((function() {
                    return Le(t)
                }), (function(e) {
                    if ("INTERNAL" === e.code) return Le(t);
                    throw e
                }))
            },
            Re = function(e, t) {
                var n, r = e.sdk,
                    i = e.store,
                    o = void 0 === t ? {} : t,
                    a = o.group,
                    c = o.customerStartingEvent,
                    u = o.agentFakeEvent,
                    s = {
                        chat: {
                            thread: {
                                properties: {}
                            },
                            properties: {}
                        }
                    };
                M.H(i) && (s.continuous = !0, s.chat.properties.routing = {
                    email_follow_up: !0
                }), "number" === typeof a && (s.chat.access = {
                    groupIds: [a]
                });
                var d = {};
                if ("filled_form" === (null == c ? void 0 : c.type)) {
                    var l, f, p = Object(b.db)(Boolean, {
                        name: null == (l = Object(b.o)((function(e) {
                            return "name" === e.type
                        }), c.fields)) ? void 0 : l.answer,
                        email: null == (f = Object(b.o)((function(e) {
                            return "email" === e.type
                        }), c.fields)) ? void 0 : f.answer
                    });
                    d = Object(g.a)({}, p)
                }
                var m = i.getSessionUser();
                m.name && "Customer" !== m.name || (d.name = i.localize("client"));
                var v = Object(b.F)(d) ? Promise.resolve() : r.updateCustomer(d).catch((function(e) {
                    return Object(O.c)("update_customer_request_failed", e)
                }));
                if ("ticket" === (null == c || null == (n = c.properties.lc2) ? void 0 : n.form_type)) s.active = !1, s.chat.thread.properties.routing = {
                    offline_message: !0
                }, s.chat.thread.events = [ke(i, c)];
                else {
                    var h = i.getEvents(ie.d).filter((function(e) {
                        return e.type === ie.g && null === e.serverId
                    }));
                    if (Object(b.F)(h) || (s.chat.thread.events = h.map((function(e) {
                            return ke(i, e)
                        }))), c) {
                        var y = ke(i, c);
                        Object(b.E)(s.chat.thread.events) ? s.chat.thread.events.push(y) : s.chat.thread.events = [y]
                    }
                    u && (s.chat.thread.properties = function(e) {
                        return {
                            lc2: Object(g.a)({
                                welcome_author_id: e.author
                            }, e.properties.invitation ? {
                                greeting_id: e.properties.id,
                                greeting_unique_id: e.properties.uniqueId
                            } : {
                                welcome_text: e.properties.originalText
                            })
                        }
                    }(u))
                }
                var j = i.getChat(ie.d).serverId;
                return j ? v.then((function() {
                    return r.resumeChat(Object(g.a)({}, s, {
                        chat: Object(g.a)({}, s.chat, {
                            id: j
                        })
                    }))
                })).then((function(e) {
                    return Me(i, ve(i, e))
                })) : v.then((function() {
                    return r.startChat(s)
                })).then((function(e) {
                    return Me(i, ve(i, e))
                }))
            },
            De = function(e) {
                return e.sdk.listChats().then((function(e) {
                    var t = e.chatsSummary,
                        n = Object(b.M)(t);
                    return n ? function(e) {
                        var t = e.id,
                            n = e.active,
                            r = e.access;
                        return {
                            id: t,
                            active: n,
                            lastThreadId: e.lastThreadId,
                            group: pe(r)
                        }
                    }(n) : null
                }))
            },
            Be = function(e, t) {
                var n = e.sdk,
                    r = t.groupIds;
                return n.listGroupStatuses({
                    groupIds: r
                }).then((function(e) {
                    return r.reduce((function(t, n) {
                        var r = e[n];
                        return t[n] = r ? function(e) {
                            return "offline" === e ? "offline" : "online"
                        }(r) : "not_found", t
                    }), {})
                }))
            },
            qe = function(e, t) {
                var n = e.store;
                return Object(ze.b)({
                    licenseId: n.getApplicationState().license,
                    groupId: t.groupId,
                    region: t.region,
                    version: t.localizationVersion,
                    language: t.language
                })
            },
            Ne = function(e, t, n) {
                var r = e.sdk;
                return void 0 === n && (n = be), r.getForm(t).then((function(e) {
                    return e.enabled ? {
                        enabled: !0,
                        form: n(t.type, e.form)
                    } : e
                })).catch((function(e) {
                    return Object(O.c)("get_form_request_failed", e), {
                        enabled: !1
                    }
                }))
            },
            Ve = function(e, t) {
                return Ne(e, {
                    groupId: t,
                    type: "postchat"
                })
            },
            Fe = function(e, t) {
                return Ne(e, {
                    groupId: t,
                    type: "ticket"
                }, (function(e, t) {
                    return he(t)
                }))
            },
            Ue = function(e, t) {
                var n = e.store,
                    r = t.groupId,
                    i = n.getApplicationState(),
                    o = i.license,
                    a = i.region;
                return Object(ze.d)({
                    licenseId: o,
                    groupId: r,
                    region: a,
                    version: "tfm"
                }).then(j.d)
            },
            He = function(e, t) {
                var n = e.sdk,
                    r = t.chatId;
                return n.getChat({
                    chatId: r
                }).then((function(e) {
                    return {
                        users: e.users,
                        eventsSeenUpToMap: e.eventsSeenUpToMap
                    }
                }))
            },
            Ge = function(e, t) {
                var n = e.sdk,
                    r = e.store,
                    i = t.chatId,
                    o = t.threadId;
                return n.getChat({
                    chatId: i,
                    threadId: o
                }).then((function(e) {
                    return ye(r, e)
                }))
            },
            We = function(e, t) {
                return t.next().then((function(t) {
                    var n = t.value,
                        r = t.done;
                    return n ? {
                        value: n.threads.map((function(t) {
                            return function(e, t) {
                                var n = t.thread,
                                    r = n.id,
                                    i = n.active,
                                    o = n.events,
                                    a = n.access,
                                    c = e.getChat(ie.d).properties.eventsSeenUpToMap,
                                    u = e.getSessionUser().serverId,
                                    s = ge(e, c),
                                    d = s.sessionUserSeenUpTo,
                                    l = s.latestOtherUserSeenUpTo;
                                return {
                                    id: r,
                                    active: i,
                                    events: o.map((function(t) {
                                        var n = t.authorId === u ? l >= t.createdAt : d >= t.createdAt;
                                        return je(e, Object(g.a)({}, t, {
                                            seen: n
                                        }))
                                    })).filter(Boolean),
                                    group: pe(a),
                                    properties: Se(n)
                                }
                            }(e, {
                                thread: t
                            })
                        })),
                        done: r
                    } : {
                        value: n,
                        done: r
                    }
                })).catch((function(e) {
                    if ("NOT_FOUND" === e.code) return {
                        value: [],
                        done: !0
                    };
                    throw e
                }))
            },
            Ye = function(e, t) {
                var n = e.sdk,
                    r = e.store,
                    i = n.getChatHistory({
                        chatId: t
                    });
                return Promise.all([i.next(), He({
                    sdk: n,
                    store: r
                }, {
                    chatId: t
                })]).then((function(e) {
                    var t = e[0],
                        n = t.value,
                        o = t.done,
                        a = e[1],
                        c = a.users,
                        u = a.eventsSeenUpToMap,
                        s = Object(b.K)("id", c);
                    if (n && n.threads.some((function(e) {
                            return e.events.some((function(e) {
                                return "system" !== e.authorId && !(e.authorId in s)
                            }))
                        }))) {
                        var d = new Error;
                        throw d.code = "MISSING_USER", d
                    }
                    return {
                        threads: n && n.threads.map((function(e) {
                            return ye(r, {
                                thread: e,
                                users: c,
                                eventsSeenUpToMap: u
                            }).thread
                        })),
                        eventsSeenUpToMap: u,
                        hasMore: !o,
                        iterator: {
                            next: function() {
                                return We(r, i)
                            }
                        }
                    }
                })).catch((function(e) {
                    if ("NOT_FOUND" === e.code) return {
                        threads: [],
                        hasMore: !1
                    };
                    throw e
                }))
            },
            Ke = function(e, t) {
                return e.filter((function(e) {
                    return e.serverName in t
                })).map((function(e) {
                    return {
                        type: e.type,
                        label: e.label,
                        value: e.options ? Object(b.l)(t[e.serverName]).map((function(t) {
                            return Object(b.o)((function(e) {
                                return e.originalValue === t
                            }), e.options).label
                        })).join(", ") : t[e.serverName]
                    }
                }))
            },
            Ze = function(e, t, n, r) {
                e.emit("on_" + t + "_survey_submitted", {
                    form_data: Ke(n, r)
                })
            },
            Je = function(e, t) {
                e.emit("on_rating_comment_submitted", t)
            },
            Xe = function(e, t) {
                e.emit("on_rating_submitted", null === t ? "none" : t)
            },
            Qe = function(e, t, n) {
                e.emit("on_message", {
                    text: t.properties.text,
                    timestamp: n / 1e3,
                    user_type: "visitor",
                    visitor_name: e.getSessionUser().name
                })
            },
            $e = "CANCEL",
            et = "NOTHING",
            tt = "SET";
        var nt = function(e) {
                var t = Object.keys(e);
                return Promise.all(Object(b.Bb)(e)).then((function(e) {
                    return Object(b.u)(Object(b.Cb)(t, e))
                }))
            },
            rt = n(78),
            it = n(44),
            ot = function(e) {
                return e.fields.map((function(e) {
                    switch (e.type) {
                        case "question":
                        case "textarea":
                            var t = e.answer;
                            return t ? e.label + " " + t : e.label;
                        case "radio":
                        case "select":
                            var n, r = null == (n = e.answer) ? void 0 : n.label;
                            return r ? e.label + " " + r : e.label;
                        case "checkbox":
                            var i, o = null == (i = e.answers) ? void 0 : i.map((function(e) {
                                return e.label
                            })).join(", ");
                            return o ? e.label + " " + o : e.label;
                        default:
                            return ""
                    }
                })).filter(Boolean).join("\n")
            },
            at = n(24),
            ct = function(e, t) {
                return Object(b.c)(function() {
                    switch (t.code) {
                        case "TOO_BIG_FILE":
                            return e.localize("cannot_upload_a_file_over_10mb");
                        case "VALIDATION":
                            return "No active chat thread" === t.message ? e.localize("closed_chat_upload_failed") : e.localize("upload_failed");
                        default:
                            return e.localize("upload_failed")
                    }
                }())
            },
            ut = function(e) {
                var t = e.getChat(ie.d).properties,
                    n = t.rate,
                    r = t.rateComment,
                    i = t.queued,
                    o = e.getView("Chat/queue");
                return {
                    rate: n,
                    rateComment: r,
                    queue: i ? {
                        position: o.numberInQueue,
                        waitingTime: o.waitingTime
                    } : null
                }
            },
            st = {
                acceptingGreeting: !1,
                requestingPredictedWelcomeMessage: !1
            },
            dt = function(e, t, n) {
                var r = !t.getApplicationState("clientLimitExceeded") || !t.getApplicationState("embedded") || t.getApplicationState("actingAsDirectLink") || t.getApplicationState("isInCustomContainer"),
                    i = function(e, t) {
                        var n = t.license,
                            r = t.requestedGroup,
                            i = t.group,
                            o = t.region,
                            a = t.uniqueGroups,
                            c = t.autoConnect,
                            u = t.mobile,
                            s = t.identityProvider,
                            d = e.getApplicationState("page"),
                            l = {
                                licenseId: n,
                                clientId: "c5e4f61e1a6c3b1521b541bc5c5a2ac5",
                                mobile: u,
                                region: o,
                                page: Object(b.cb)(["url", "title"], d),
                                referrer: d.referrer,
                                autoConnect: c,
                                application: {
                                    channelType: Object(M.a)(e)
                                },
                                uniqueGroups: a,
                                identityProvider: s,
                                customerDataProvider: function() {
                                    var t = e.getSessionUser(),
                                        n = {};
                                    return t.name && (n.name = t.name), t.email && (n.email = t.email), t.properties && !Object(b.F)(t.properties) && (n.sessionFields = Object(b.L)(t.properties).length <= ie.f ? t.properties : Object(b.u)(Object(b.m)(t.properties).slice(0, ie.f))), n
                                }
                            };
                        return a ? l.groupId = i : null !== r && (l.groupId = r), Object(Y.a)(l, "production")
                    }(t, Object(g.a)({}, e, {
                        autoConnect: r
                    })),
                    o = {
                        sdk: i,
                        store: t
                    },
                    a = Object(Z.a)(),
                    c = null,
                    u = {};
                !0 === n.s && t.setApplicationState({
                    s: !0
                }), n.prechatForm && t.updateView("Chat/prechat", be("prechat", n.prechatForm)), n.ticketForm && t.updateView("Chat/ticketForm", he(n.ticketForm)), n.__unsafeProperties.group.chatBoosters && Object(z.h)(t, n.__unsafeProperties.group.chatBoosters);
                var s = function() {
                        (Object(M.db)(ie.d, t) || t.getApplicationState().destroyed) && (Object(z.r)(t), t.updateView("minimized", {
                            hidden: !0
                        }))
                    },
                    d = function() {
                        i.destroy(), t.setApplicationState({
                            destroyed: !0
                        }), s()
                    },
                    l = function(e, n) {
                        Object(M.E)(t) && !c && (c = n || function(e, t) {
                            var n = e.sdk,
                                r = e.store,
                                i = n.getChatHistory({
                                    chatId: t
                                });
                            return {
                                next: function() {
                                    return We(r, i)
                                }
                            }
                        }(o, {
                            chatId: e
                        }))
                    },
                    f = function(e) {
                        var n = e.id,
                            r = e.active,
                            i = e.group,
                            o = e.thread,
                            a = e.agent,
                            c = e.events,
                            u = e.properties,
                            s = !!u.queue;
                        if (l(n), c.forEach(k), Object(z.l)(t, {
                                id: n,
                                active: r,
                                thread: o,
                                group: i,
                                queued: s,
                                agent: a
                            }), Object(M.jb)(t)) {
                            var d = u.queue,
                                f = d.position,
                                p = d.waitingTime;
                            t.updateView("Chat/queue", {
                                numberInQueue: f,
                                waitingTime: p
                            })
                        }
                    },
                    p = function() {
                        return t.getChat(ie.d).properties.lastThread
                    },
                    m = function(e) {
                        return "good" === e ? 1 : "bad" === e ? 0 : null
                    },
                    v = function(e) {
                        return i.rateChat({
                            chatId: Object(M.b)(t),
                            rating: Object(b.f)({
                                comment: e.rateComment,
                                score: m(e.rating)
                            })
                        }).then((function() {
                            t.updateChat(ie.d, {
                                properties: Object(b.f)({
                                    rate: e.rating,
                                    rateComment: e.rateComment
                                })
                            })
                        }), b.V)
                    },
                    h = function(e) {
                        return i.cancelRate({
                            chatId: Object(M.b)(t),
                            properties: e
                        }).then((function() {
                            t.updateChat(ie.d, {
                                properties: e.reduce((function(e, t) {
                                    return "comment" === t ? e.rateComment = null : "score" === t && (e.rate = null), e
                                }), {})
                            })
                        }), b.V)
                    },
                    _ = function(e) {
                        var n = t.getChat(ie.d).properties,
                            r = n.rate,
                            i = n.rateComment,
                            o = {
                                comment: et,
                                score: et
                            };
                        e.rating !== r && (o.score = null === e.rating ? $e : tt);
                        var a = "string" === typeof e.rateComment && "" !== e.rateComment;
                        return i && !a || o.score === $e && i ? o.comment = $e : !a || i && e.rateComment === i || (o.comment = tt), o
                    },
                    w = function() {
                        return Fe(o, t.getApplicationState("group")).then((function(e) {
                            e.enabled ? (t.updateView("Chat/ticketForm", e.form), Object(z.I)(t), t.setCurrentView("Chat")) : t.setCurrentView("Chat")
                        }))
                    },
                    x = function() {
                        var e = Object(M.X)(t);
                        Object(z.k)(t), e || Ve(o, I()).then((function(e) {
                            var n = e.enabled,
                                r = e.form;
                            n && Object(z.G)(t, r)
                        }), b.V)
                    },
                    E = function(e) {
                        var t = e.getApplicationState().availability,
                            n = e.getChat(ie.d).properties.postponedGreeting;
                        "online" === t && n ? Promise.resolve().then((function() {
                            e.updateChat(ie.d, {
                                properties: {
                                    postponedGreeting: void 0
                                }
                            }), st.acceptingGreeting = !0, Pe(o, n).then((function(t) {
                                st.acceptingGreeting = !1, L(t), e.setDefaultView("Chat", "timeline")
                            }), (function() {
                                st.acceptingGreeting = !1
                            }))
                        })) : e.setDefaultView("Chat", "timeline")
                    },
                    I = function() {
                        var e = t.getChat(ie.d).properties.group,
                            n = t.getApplicationState("group");
                        return "number" === typeof e ? e : n
                    },
                    S = function(e) {
                        var n = function(e, t) {
                            if (t.id === e.getSessionUser().serverId || "customer" === t.type) {
                                var n = {
                                    id: t.id,
                                    type: "customer"
                                };
                                return t.name && "Customer" !== t.name && (n.name = t.name), t.email && (n.email = t.email), t.sessionFields && (n.properties = t.sessionFields), n
                            }
                            return {
                                id: t.id,
                                type: t.type,
                                name: t.name,
                                avatar: "https://" + Object(C.l)(t.avatar),
                                properties: {
                                    jobTitle: t.jobTitle,
                                    isBot: t.isBot || !1
                                }
                            }
                        }(t, e);
                        if (t.getSessionUser().serverId !== n.id) return t.getUser(n.id) ? (n.properties || Object(O.c)("no_parsed_user_properties", new Error, {
                            meta: JSON.stringify({
                                user: e,
                                parsedUser: n
                            })
                        }), void(n.properties.isBot && t.updateUser(n.id, {
                            properties: {
                                isBot: !0
                            }
                        }))) : void t.addUser(n);
                        t.updateUser(t.getSessionUserId(), Object(b.fb)(["name", "email", "properties"], n))
                    },
                    T = function(e) {
                        var n = ut(t),
                            r = {};
                        if ("rate" in e && n.rate !== e.rate && (r.rate = e.rate), "rateComment" in e && n.rateComment !== e.rateComment && (r.rateComment = e.rateComment), "queue" in e && !Object(b.kb)(n.queue, e.queue)) {
                            var i = e.queue;
                            !t.getChat(ie.d).properties.ended && i ? function(e, t) {
                                var n = t.thread,
                                    r = t.numberInQueue,
                                    i = t.waitingTime,
                                    o = {
                                        active: !0,
                                        properties: {
                                            queued: !0
                                        }
                                    };
                                n && (o.properties.lastThread = n), e.updateChat(ie.d, o), e.updateView("Chat/queue", {
                                    numberInQueue: r,
                                    waitingTime: i
                                })
                            }(t, {
                                numberInQueue: i.position,
                                waitingTime: i.waitingTime
                            }) : r.queued = !1
                        }
                        t.updateChat(ie.d, {
                            properties: r
                        })
                    },
                    k = function(e) {
                        Object(z.d)(t, ie.d, e), "message" === e.properties.serverType && t.getApplicationState("readyState") !== at.a.NOT_READY && function(e, t) {
                            var n = e.getEvent(ie.d, t),
                                r = n.author,
                                i = n.timestamp,
                                o = n.properties.text,
                                a = e.getUser(r),
                                c = a.type,
                                u = {
                                    text: o,
                                    timestamp: Math.floor(i / 1e3),
                                    user_type: "agent" === c ? c : "visitor"
                                };
                            "agent" === c ? (u.agent_name = a.name, u.agent_login = a.id) : u.visitor_name = a.name, e.emit("on_message", u)
                        }(t, e.id)
                    },
                    A = function(e) {
                        var n = je(t, e);
                        n && ("form" !== n.type || n.properties.answered || "ask_for_email" !== n.properties.formId || (Math.random() < .01 && Object(O.d)("ask_for_email_form_received", {}), t.hasEvent(ie.d, ie.b) && t.removeEvent(ie.d, ie.b)), k(n))
                    },
                    L = function(e) {
                        var n = e.author,
                            r = e.event;
                        S(n);
                        var i = t.getChat(ie.d),
                            o = i.serverId;
                        i.properties.ended && Object(z.z)(t, ie.d, {
                            chatId: o
                        });
                        var a = Object(M.f)(t, ie.d);
                        a && t.removeEvent(ie.d, a.id), Object(z.a)(t), Object(z.n)(t, r)
                    },
                    R = function(e) {
                        if (!st.requestingPredictedWelcomeMessage)
                            if (Object(M.L)(t, "postchat")) t.updateChat(ie.d, {
                                properties: {
                                    postponedGreeting: e
                                }
                            });
                            else if (Object(M.Z)(ie.d, t)) {
                            if (!e.event.properties.accepted) return t.getApplicationState("greetingsMuted") && !Object(M.W)(t, "maximized") ? (t.updateChat(ie.d, {
                                properties: {
                                    mutedGreeting: e
                                }
                            }), void L(e)) : (st.acceptingGreeting = !0, Pe(o, e).then((function(e) {
                                st.acceptingGreeting = !1, L(e)
                            }), (function() {
                                st.acceptingGreeting = !1
                            })));
                            L(e)
                        }
                    },
                    B = function(e) {
                        return !!e && -1 !== e.indexOf(t.getApplicationState("group"))
                    },
                    q = function(e) {
                        var n = (void 0 === e ? {} : e).withSystemMessage,
                            r = void 0 !== n && n;
                        if (t.setApplicationState({
                                limitReached: !0,
                                clientLimitExceededLifted: !1
                            }), Object(z.x)(t), r) {
                            var i = Object(M.D)(t) ? "Sorry we couldn't connect you with an agent, but you can still leave us a ticket" : "Sorry, but we couldn't connect you with an agent. Try refreshing the page or come back later.";
                            Object(z.b)(t, ie.d, {
                                text: i
                            })
                        }
                        Object(M.D)(t) && Object(z.I)(t)
                    };
                i.on("thread_properties_deleted", (function(e) {
                        var n = e.threadId,
                            r = e.properties;
                        n === p() && "rating" in r && Object(b.D)("score", r.rating) && T(Object(g.a)({}, ut(t), {
                            rate: null
                        }))
                    })), i.on("thread_properties_updated", (function(e) {
                        var n = e.threadId,
                            r = e.properties;
                        n === p() && "rating" in r && T(Object(g.a)({}, ut(t), Ce(r.rating)))
                    })), i.on("queue_position_updated", (function(e) {
                        var n = e.threadId,
                            r = e.queue;
                        n === p() && T(Object(g.a)({}, ut(t), {
                            queue: Ie(r)
                        }))
                    })), i.on("chat_transferred", (function(e) {
                        if ("groupIds" in e.transferredTo) {
                            var n = e.transferredTo.groupIds[0];
                            t.updateChat(ie.d, {
                                properties: {
                                    group: n
                                }
                            }), e.queue && T(Object(g.a)({}, ut(t), {
                                queue: Ie(e.queue)
                            }))
                        }
                    })), i.on("customer_updated", (function(e) {
                        var n = t.getSessionUserId();
                        t.updateUser(n, Object(b.fb)(["name", "email"], e)), e.sessionFields && t.setUserProperties(n, e.sessionFields), t.emit("customer_updated")
                    })), i.on("event_properties_updated", (function(e) {
                        var n = e.chatId,
                            r = e.threadId,
                            i = e.eventId,
                            o = e.properties;
                        if (n === Object(M.b)(t) && r === p() && "translation" in o) {
                            var a = t.getEventByServerId(ie.d, i);
                            if (!a) return;
                            t.updateEvent(ie.d, a.id, {
                                properties: {
                                    translation: Ae(o.translation)
                                }
                            })
                        }
                    })), i.on("event_updated", (function(e) {
                        var n = e.chatId,
                            r = e.threadId,
                            i = e.event;
                        if (n === Object(M.b)(t) && r === p() && Object(b.x)("properties.lc2.welcome_message", i)) {
                            var o = t.getEventByServerId(ie.d, i.id);
                            i.authorId !== o.author && (t.setEventData(ie.d, o.id, {
                                author: i.authorId
                            }), t.recalculateTimeline(ie.d)), i.text !== o.properties.text && t.updateEvent(ie.d, o.id, {
                                properties: {
                                    text: i.text
                                }
                            })
                        }
                    })), t.on("set_application_state", (function(e) {
                        var n = e.pageFocused;
                        Object(M.J)(t) && n && (t.setConnectionState(K.d), i.connect())
                    })), i.on("disconnected", (function(e) {
                        var n = e.reason;
                        switch (n) {
                            case "access_denied":
                            case "identity_mismatch":
                            case "too_many_connections":
                                return Object(O.c)(n), void d();
                            case "customer_banned":
                            case "license_not_found":
                            case "unsupported_version":
                            case "inactivity_timeout":
                                return void(t.getApplicationState("pageFocused") || (t.setConnectionState(K.b), i.disconnect()));
                            case "users_limit_reached":
                                return void q({
                                    withSystemMessage: !1
                                });
                            default:
                                return "connection_timeout" === n && Math.random() <= .1 ? Object(O.f)("connection_timeout") : Math.random() <= 1e-4 && Object(O.f)("disconnected", {
                                    reason: n
                                }), void t.setConnectionState(K.d)
                        }
                    })), i.on("user_added_to_chat", (function(e) {
                        var n = e.chatId,
                            r = e.user;
                        if (e.present && n === Object(M.b)(t) && t.getSessionUser().serverId !== r.id) {
                            var i = Object(M.c)(ie.d, t);
                            i && i.id === r.id || (T(Object(g.a)({}, ut(t), {
                                queue: null
                            })), Object(z.D)(t, r.id))
                        }
                    })), i.on("user_removed_from_chat", (function(e) {
                        var n = e.chatId,
                            r = e.userId;
                        if (n === Object(M.b)(t) && (t.removeParticipant(ie.d, r), t.getSessionUser().serverId !== r)) {
                            var i = Object(M.c)(ie.d, t);
                            i && i.id === r && (t.getChat(ie.d).properties.ended || Object(z.D)(t, null))
                        }
                    })), i.on("user_data", S),
                    function(e, t) {
                        e.on("send_snapshot", (function(n) {
                            var r = n.requestId,
                                i = n.snapshot,
                                o = n.screen;
                            t.uploadFile({
                                file: new Blob([i], {
                                    type: "text/plain;charset=utf-8"
                                })
                            }).promise.then((function(n) {
                                t.sendEvent({
                                    chatId: Object(M.b)(e),
                                    event: {
                                        type: "custom",
                                        customId: "cyber-finger-snapshot-" + r,
                                        content: {
                                            url: n.url,
                                            screen: o
                                        }
                                    }
                                }), Object(O.d)("snapshot_sent", {
                                    chatId: Object(M.b)(e)
                                })
                            })).catch(b.V)
                        }))
                    }(t, i), i.on("greeting_canceled", (function(e) {
                        var n = e.uniqueId,
                            r = t.getEvents(ie.d),
                            i = Object(b.q)((function(e) {
                                return e.properties.uniqueId === n
                            }), r);
                        i && (Object(M.mb)(t) && Object(M.I)(t) && t.setApplicationState({
                            greetingsMuted: !0
                        }), t.removeEvent(ie.d, i.id))
                    }));
                var N = function() {
                        Object(M.db)(ie.d, t) && Object(z.r)(t), t.setApplicationState({
                            readyState: at.a.READY,
                            ready: !0
                        })
                    },
                    V = function(e) {
                        var r = e.dynamicConfig,
                            i = e.chatId,
                            a = function(e, t) {
                                var n = e.monitoring,
                                    r = e.chats,
                                    i = Object.keys(r).find((function(e) {
                                        return Object(b.D)(t, r[e].chat_ids)
                                    }));
                                if (i !== n.id && r[i].language_config_url) {
                                    var o = r[i].language_config_url.split(".");
                                    return {
                                        groupId: parseInt(o[2]),
                                        language: o[1],
                                        localizationVersion: o[3]
                                    }
                                }
                            }(r.customer_groups, i);
                        if (a) return {
                            queueTemplate: qe(o, Object(g.a)({}, a, {
                                region: n.region
                            })).then((function(e) {
                                return e.user_in_queue
                            })).catch((function() {
                                var e;
                                return Promise.resolve(null == (e = t.getState().localization) ? void 0 : e.user_in_queue)
                            }))
                        }
                    },
                    F = function(e) {
                        var n = e.active,
                            r = e.chatId,
                            i = e.lastThreadId,
                            a = e.becameInactive;
                        if (Object(M.E)(t)) return {
                            fetchedHistory: Ye(o, r)
                        };
                        if (a) {
                            var c = t.getChat(ie.d);
                            return {
                                fetchedThread: Ge(o, {
                                    chatId: r,
                                    threadId: c.properties.lastThread
                                })
                            }
                        }
                        return n ? {
                            fetchedThread: Ge(o, {
                                chatId: r,
                                threadId: i
                            })
                        } : void 0
                    },
                    U = function(e) {
                        return e.filter((function(e) {
                            return !(t.hasEvent(ie.d, e.id) || "form" === e.type && "ticket" === e.properties.formType)
                        }))
                    },
                    H = function(e) {
                        U(e).forEach(k)
                    },
                    W = function(e, n) {
                        var r = e.eagerFetchingMode,
                            i = n.thread,
                            o = n.eventsSeenUpToMap;
                        if (i) {
                            var a = i.id,
                                c = i.active,
                                u = i.agent,
                                s = i.group,
                                d = i.events,
                                l = i.properties,
                                f = t.getChat(ie.d),
                                p = !c && f.active;
                            t.updateChat(ie.d, {
                                active: c,
                                properties: Object(g.a)({
                                    ended: f.properties.ended,
                                    lastThread: a,
                                    group: s,
                                    eventsSeenUpToMap: o
                                }, p && {
                                    ended: !0,
                                    queued: !1,
                                    agentIsTyping: !1
                                })
                            }), c && Object(z.D)(t, u), T(Object(g.a)({
                                rate: null
                            }, l, {
                                queue: c && "queue" in l ? l.queue : null
                            }, !r && !c && {
                                rate: null,
                                rateComment: null
                            })), c && Object(z.a)(t), H(d)
                        }
                    },
                    $ = function(e) {
                        null === Object(M.x)(t, ie.d) && t.updateChat(ie.d, {
                            properties: {
                                hasMoreHistory: e
                            }
                        })
                    };
                i.on("connected", (function(e) {
                    var n = e.__unsafeDynamicConfig,
                        r = e.__unsafeChats,
                        c = e.greeting,
                        d = e.availability,
                        f = e.customer;
                    clearTimeout(ee), t.getApplicationState().limitReached && t.setApplicationState({
                        limitReached: !1
                    });
                    var m, v = function(e) {
                        var n = t.getSessionUser(),
                            r = {};
                        return n.name && e.name !== n.name && (r.name = n.name), n.email && e.email !== n.email && (r.email = n.email), Object(b.F)(n.properties) || Object(b.kb)(n.properties, e.sessionFields) || (r.sessionFields = Object(b.F)(e.sessionFields) ? n.properties : Object(b.u)(Object(b.m)(n.properties).reduce((function(t, n) {
                            var r = n[0],
                                i = n[1];
                            return r in e.sessionFields ? t : [].concat(t, [
                                [r, i]
                            ])
                        }), []))), Object(b.F)(r) ? null : r
                    }(f);
                    v && function(e) {
                        var t = e.customerData,
                            n = e.usedSessionFieldsNumber,
                            r = function(e) {
                                i.updateCustomer(e).catch((function(e) {
                                    return Object(O.c)("update_customer_request_failed", e)
                                }))
                            };
                        t.sessionFields ? Object(b.m)(t.sessionFields).slice(0, ie.i - n).reduce((function(e, t) {
                            return Object(b.F)(e) || Object(b.M)(e).length >= ie.f ? e.push([t]) : Object(b.M)(e).push(t), e
                        }), []).map(b.u).reduce((function(e, n, i) {
                            return e.then((function() {
                                return r(Object(g.a)({}, 0 === i && t, {
                                    sessionFields: n
                                }))
                            }))
                        }), Promise.resolve()) : r(t)
                    }({
                        customerData: v,
                        usedSessionFieldsNumber: Object(b.L)(f.sessionFields || {}).length
                    }), S(f), "boolean" !== typeof t.getApplicationState().isReturning && t.setApplicationState({
                        isReturning: f.statistics.visitsCount > 1
                    }), t.setApplicationState({
                        clientChatNumber: f.statistics.threadsCount || 0,
                        clientVisitNumber: f.statistics.visitsCount || 0,
                        clientLastVisitTimestamp: n.customer_data.last_visit_timestamp,
                        clientPageViewsCount: f.statistics.pageViewsCount || 0
                    }), u = {
                        availability: d,
                        greeting: Object(M.lb)(t) && c && Te(t, c)
                    }, Promise.resolve().then((function() {
                        if (r.length) {
                            var e = r[0],
                                i = e.id,
                                a = e.active,
                                c = e.hasUnreadEvents;
                            Object(M.E)(t) && t.setApplicationState({
                                hasUnseenEvents: c
                            });
                            var u = !a && t.getChat(ie.d).active;
                            m = {
                                active: a,
                                chatId: i,
                                becameInactive: u,
                                dynamicConfig: n
                            }, null === t.getChat(ie.d).serverId && t.setChatServerId(ie.d, i);
                            var s = t.getApplicationState().eagerFetchingMode;
                            if (a || Object(M.W)(t, "maximized") || s) return De(o)
                        }
                    })).then((function(e) {
                        return e ? (m.group = e.group, m.lastThreadId = e.lastThreadId, m.becameInactive ? nt(Object(g.a)({
                            chatSummary: e
                        }, function(e) {
                            var n = e.group;
                            if (!Object(M.X)(t)) {
                                var r = Object(M.E)(t) ? n : I();
                                return {
                                    postchatForm: Ve(o, r).catch((function() {
                                        return {
                                            enabled: !1
                                        }
                                    }))
                                }
                            }
                        }(m), F(m))) : e.active ? nt(Object(g.a)({
                            chatSummary: e
                        }, V(m), F(m))) : nt(Object(g.a)({
                            chatSummary: e
                        }, F(m)))) : nt({})
                    })).then((function(e) {
                        return !!e.chatSummary && e.chatSummary.active ? e : nt(Object(g.a)({}, e, {
                            maximizedDecisionActions: ft() ? lt({
                                active: !1,
                                availability: u.availability,
                                connected: !0,
                                hasFakeAgentMessage: Object(M.z)(t, ie.d) || !!u.greeting
                            }) : null
                        }))
                    })).then((function(e) {
                        var n = e.queueTemplate,
                            r = e.chatSummary,
                            i = e.postchatForm,
                            o = e.maximizedDecisionActions,
                            a = Object(y.a)(e, ["queueTemplate", "chatSummary", "postchatForm", "maximizedDecisionActions"]),
                            c = u;
                        if (u = {}, n && t.setLocalization({
                                user_in_queue: n
                            }), t.setApplicationState({
                                availability: c.availability
                            }), !r) return o && (Object(z.a)(t), gt(o)), c.greeting ? R(c.greeting) : void 0;
                        var s = {
                            chatId: r.id,
                            eagerFetchingMode: t.getApplicationState().eagerFetchingMode
                        };
                        t.setApplicationState({
                            eagerFetchingMode: !0
                        });
                        var d = p() && r.lastThreadId !== p();
                        if (Object(M.E)(t)) {
                            var f = a.fetchedHistory;
                            (function(e, t) {
                                var n = e.getChat(ie.d).properties.lastThread;
                                return n && !t.some((function(e) {
                                    var t = e.id;
                                    return n === t
                                }))
                            })(t, f.threads) && Object(O.c)("threads_gap", null, {
                                    meta: JSON.stringify({
                                        stateLastThreadId: t.getChat(ie.d).properties.lastThread,
                                        fetchedThreads: f.threads.map((function(e) {
                                            return e.id
                                        }))
                                    })
                                }), d && Object(z.z)(t, ie.d, {
                                    chatId: t.getChat(ie.d).serverId
                                }),
                                function(e, t) {
                                    l(e.chatId, t.iterator), $(t.hasMore);
                                    var n = Object(b.ob)(-1, t.threads),
                                        r = n[0],
                                        i = n[1][0];
                                    H(Object(b.s)((function(e) {
                                        return e.events
                                    }), r)), W(e, {
                                        thread: i,
                                        eventsSeenUpToMap: t.eventsSeenUpToMap
                                    })
                                }(s, f)
                        } else a.fetchedThread && (d && r.active && Object(z.z)(t, ie.d, {
                            chatId: t.getChat(ie.d).serverId
                        }), W(s, a.fetchedThread));
                        if (o && (Object(z.a)(t), gt(o)), !r.active)
                            if (i && i.enabled) Object(z.G)(t, i.form);
                            else if (c.greeting) return R(c.greeting)
                    })).then((function() {
                        var e = t.getConnectionState() === K.d;
                        return t.setDefaultView("Chat", "timeline"), t.setConnectionState(K.a), s(), t.getChat(ie.d).active && Object(M.W)(t, "hidden") && Object(z.v)(t, !0), a.resolve(), e
                    })).then((function(e) {
                        var n = t.getChat(ie.d),
                            r = t.getApplicationState().availability;
                        e || !Object(M.H)(t) || !Object(M.S)(t) || n.active || "offline" !== r && !n.properties.ended || Object(z.H)(t)
                    })).catch((function(e) {
                        switch (u = {}, e.code) {
                            case "CONNECTION_LOST":
                                return;
                            case "REQUEST_TIMEOUT":
                            case "MISSING_USER":
                                return i.disconnect(), void i.connect();
                            case "INTERNAL":
                                return void Object(O.e)("connection_fetcher_internal_error");
                            default:
                                return void Object(O.c)("connection_fetcher_error", e)
                        }
                    }))
                })), Object(z.L)(n, t), i.once("customer_id", (function(e) {
                    return Object(z.E)(t, e)
                }));
                var ee, ae = Object(D.b)(t, at.a.READY),
                    ue = function(e) {
                        return Object(P.y)(ae, Object(P.E)(e))
                    },
                    se = Object(P.y)(Object(D.c)(t, (function(e) {
                        return Object(it.a)(e, "maximized")
                    })), Object(P.i)(Boolean), Object(P.s)((function() {
                        return {
                            type: "maximized"
                        }
                    })), P.z),
                    de = Object(P.y)(Object(D.c)(t, (function() {
                        return t.getSessionUser().serverId
                    })), Object(P.i)(Boolean), Object(P.F)(1), P.I),
                    le = Object(P.y)(Object(D.c)(t, (function(e) {
                        return e.localization
                    })), Object(P.i)((function(e) {
                        return Object.keys(e).length > 1
                    })), Object(P.F)(1), P.I);
                r ? (Math.random() <= .01 && "onLine" in navigator && (ee = setTimeout((function() {
                    navigator.onLine && Object(O.f)("unsuccessful_first_connect")
                }), 3e4)), t.setApplicationState({
                    clientLimitExceededLifted: !0
                }), le.then(t.setLocalization).then((function() {
                    return a.promise
                })).then(N)) : Promise.all([le, de]).then((function(e) {
                    var r, o = e[0];
                    t.setLocalization(o), r = n.onlineGroupIds, t.setApplicationState({
                        availability: B(r) ? "online" : "offline"
                    }), t.setConnectionState(K.c), s(), N();
                    var a = Object(P.k)(document, ["click", "touchstart"]);
                    Object(P.y)(Object(P.t)(a, se), Object(P.F)(1), Object(P.j)((function() {
                        t.setApplicationState({
                            clientLimitExceededLifted: !0
                        }), i.connect()
                    })))
                })), "ononline" in window && (i.on("connection_unstable", (function() {
                    t.setConnectionState(K.d)
                })), i.on("connection_recovered", (function() {
                    t.setConnectionState(K.a)
                }))), i.on("incoming_greeting", (function(e) {
                    if (Object(M.lb)(t)) {
                        var n = Te(t, e);
                        Object(M.G)(t) ? R(n) : u.greeting = n
                    }
                })), i.on("availability_updated", (function(e) {
                    var n = e.availability;
                    Object(M.G)(t) ? t.setApplicationState({
                        availability: n
                    }) : u.availability = n
                })), i.on("events_marked_as_seen", (function(e) {
                    var n, r = e.chatId,
                        i = e.userId,
                        o = e.seenUpTo;
                    if (r === Object(M.b)(t)) {
                        t.updateChat(ie.d, {
                            properties: {
                                eventsSeenUpToMap: Object(g.a)({}, t.getChat(ie.d).properties.eventsSeenUpToMap, (n = {}, n[i] = o, n))
                            }
                        });
                        var a = new Date(o).getTime();
                        (t.getSessionUser().serverId === i ? M.r : M.n)(ie.d, a, t).forEach((function(e) {
                            t.updateEvent(ie.d, e.id, {
                                seen: !0
                            })
                        }))
                    }
                })), i.on("incoming_event", (function(e) {
                    var n = e.chatId,
                        r = e.event;
                    n === Object(M.b)(t) && ("postchat" === Object(b.x)("properties.lc2.form_type", r) && (Object(z.w)(t), t.setDefaultView("Chat", "timeline")), Object(M.F)(ie.d, t) && Object(O.c)("received_event_during_chat_starting"), A(r))
                })), i.on("chat_deactivated", (function(e) {
                    e.chatId === Object(M.b)(t) && x()
                })), i.on("incoming_chat", (function(e) {
                    Object(z.z)(t, ie.d, {
                        chatId: e.chat.id
                    });
                    var n = ve(t, e);
                    f(n)
                }));
                var fe = function(e) {
                        var n = e.chatId,
                            r = e.typingIndicator;
                        if (n !== Object(M.b)(t)) return !1;
                        var i = Object(M.c)(ie.d, t);
                        return !!i && i.id === r.authorId
                    },
                    pe = Object(P.y)(Object(P.l)(i, "incoming_typing_indicator"), Object(P.i)((function(e) {
                        return e.typingIndicator.isTyping && fe(e)
                    })), Object(P.s)((function() {
                        return !0
                    }))),
                    me = Object(P.y)(Object(P.l)(i, "incoming_typing_indicator"), Object(P.i)((function(e) {
                        return !e.typingIndicator.isTyping && fe(e)
                    })), Object(P.s)((function() {
                        return !1
                    }))),
                    ge = Object(P.y)(Object(P.l)(i, "incoming_event"), Object(P.i)((function(e) {
                        var n = e.chatId,
                            r = e.event;
                        return n === Object(M.b)(t) && r.authorId !== t.getSessionUser().serverId && "system" !== r.authorId
                    })));
                Object(P.y)(Object(P.t)(Object(P.y)(pe, Object(P.i)((function() {
                    return !t.getChat(ie.d).properties.messageDraft
                }))), me, Object(P.y)(ge, Object(P.s)((function() {
                    return !1
                })))), Object(P.E)((function(e) {
                    return e ? Object(P.c)(Object(P.v)(!0), Object(P.y)(Object(P.H)(1e4), Object(P.s)((function() {
                        return !1
                    })))) : Object(P.v)(!1)
                })), Object(P.f)(), Object(P.j)((function(e) {
                    t.updateChat(ie.d, {
                        properties: {
                            agentIsTyping: e
                        }
                    })
                })));
                Object(P.y)(Object(D.c)(t, (function() {
                    return t.getChat(ie.d).properties.loadingHistory
                })), Object(P.i)(Boolean), Object(P.j)((function e() {
                    c.next().then((function(n) {
                        var r = n.value,
                            i = n.done,
                            o = t.getTimeline(ie.d).length,
                            a = U(Object(b.s)((function(e) {
                                return e.events.map((function(e) {
                                    return Object(g.a)({}, e, {
                                        seen: !0
                                    })
                                }))
                            }), r));
                        a.length > 0 && t.addHistoryEvents(ie.d, a), o !== t.getTimeline(ie.d).length || i ? t.updateChat(ie.d, {
                            properties: {
                                loadingHistory: !1,
                                hasMoreHistory: !i
                            }
                        }) : e()
                    }), (function() {
                        t.updateChat(ie.d, {
                            properties: {
                                loadingHistory: !1
                            }
                        })
                    }))
                }))), t.on("request_update_chat", (function(e) {
                    var n = e.resolve,
                        r = e.reject,
                        o = e.data,
                        a = o.properties,
                        c = void 0 === a ? {} : a,
                        u = Object(y.a)(o, ["properties"]);
                    if (c.rateComment) {
                        var s = c.rateComment;
                        Je(t, s), i.rateChat({
                            chatId: Object(M.b)(t),
                            rating: {
                                comment: s
                            }
                        }).then(n, r)
                    } else if ("undefined" !== typeof c.rate) {
                        Xe(t, c.rate);
                        var d = t.getApplicationState().testGroup;
                        if (Object(O.b)({
                                testGroup: d,
                                chatRating: null === c.rate ? "canceled" : c.rate,
                                chatRatingSource: "other"
                            }), null === c.rate) return void i.cancelRate({
                            chatId: Object(M.b)(t)
                        }).then((function() {
                            t.updateChat(ie.d, {
                                properties: {
                                    rateComment: null
                                }
                            }), n()
                        }), r);
                        i.rateChat({
                            chatId: Object(M.b)(t),
                            rating: {
                                score: m(c.rate)
                            }
                        }).then(n, r)
                    } else c.transcriptSentTo ? i.updateThreadProperties({
                        chatId: Object(M.b)(t),
                        threadId: p(),
                        properties: {
                            routing: {
                                transcript_email: c.transcriptSentTo
                            }
                        }
                    }).then(n, r) : !1 === u.active ? i.deactivateChat({
                        id: Object(M.b)(t)
                    }).then((function() {
                        x(), n()
                    }), r) : "string" === typeof c.messageDraft && (t.getChat(ie.d).active && i.setSneakPeek({
                        chatId: Object(M.b)(t),
                        sneakPeekText: c.messageDraft
                    }), n())
                }));
                var ye = function(e) {
                        return "subject" === e.serverType ? "subject" : "name" === e.name ? "name" : "text" === e.type ? "question" : e.type
                    },
                    Oe = function(e, t) {
                        var n = e.id,
                            r = e.serverId,
                            i = e.properties,
                            o = i.formType,
                            a = i.formId,
                            c = i.fields,
                            u = ce(c, t),
                            s = u.fields,
                            d = {
                                filledForm: Object(g.a)({
                                    type: "filled_form",
                                    formId: a
                                }, !r && {
                                    customId: n
                                }, {
                                    fields: c.filter((function(e) {
                                        return void 0 !== e.serverName && "rating" !== e.type && "information" !== e.type
                                    })).map((function(e) {
                                        if ("groupSelect" === e.meta) return {
                                            type: "group_chooser",
                                            id: e.serverName,
                                            label: Object(Q.b)(e.label),
                                            answer: {
                                                id: String(u.choosenGroupIndex),
                                                groupId: u.choosenGroup,
                                                label: e.options[u.choosenGroupIndex].label
                                            }
                                        };
                                        if ("confirm_subscription" === e.meta) {
                                            var t = s[e.serverName];
                                            return {
                                                type: "checkbox_for_email",
                                                id: e.serverName,
                                                label: e.options[0].label,
                                                answer: !!t && Object(b.D)(e.options[0].originalValue, t)
                                            }
                                        }
                                        if (Object(b.E)(e.options)) {
                                            var n = {
                                                    type: ye(e),
                                                    id: e.serverName,
                                                    label: Object(Q.b)(e.label)
                                                },
                                                r = Object(b.B)(e.serverName, s) ? Object(b.l)(s[e.serverName]) : [],
                                                i = e.options.filter((function(e) {
                                                    return Object(b.D)(e.originalValue, r)
                                                })).map((function(e) {
                                                    return {
                                                        label: e.label,
                                                        value: e.originalValue
                                                    }
                                                }));
                                            if ("checkbox" === n.type) n.answers = i.map((function(e) {
                                                return {
                                                    label: e.label,
                                                    id: e.value
                                                }
                                            }));
                                            else if (i.length) {
                                                var o = i[0];
                                                n.answer = {
                                                    id: o.value,
                                                    label: o.label
                                                }
                                            }
                                            return n
                                        }
                                        return Object(b.B)(e.serverName, s) ? {
                                            type: ye(e),
                                            id: e.serverName,
                                            label: Object(Q.b)(e.label),
                                            answer: s[e.serverName]
                                        } : {
                                            type: ye(e),
                                            id: e.serverName,
                                            label: Object(Q.b)(e.label)
                                        }
                                    })),
                                    properties: Object(g.a)({}, o && {
                                        lc2: {
                                            form_type: o
                                        }
                                    })
                                })
                            };
                        return void 0 !== u.choosenGroup && (d.choosenGroup = u.choosenGroup), d
                    },
                    _e = 0,
                    we = Object(b.xb)(300, (function(e) {
                        var n = Object(M.b)(t),
                            r = new Date(e).toISOString().replace(/Z$/, "999Z");
                        n && i.markEventsAsSeen({
                            chatId: n,
                            seenUpTo: r
                        }).catch(b.V)
                    }));
                t.on("request_update_event", (function(e) {
                    var n, r, a, c = t.getEvent(ie.d, e.id);
                    if (e.data.seen) e.resolve(), _e = Math.max(_e, t.getEvent(ie.d, e.id).timestamp), we(_e);
                    else if ("ticket" === c.properties.formType) {
                        var u = e.data.properties.answers,
                            s = c.properties.fields,
                            l = ce(s, u).fields,
                            f = t.getApplicationState(),
                            p = null,
                            m = null,
                            y = null;
                        switch (Object(M.g)("ticketForm", t).mode) {
                            case "helpdesk":
                                var j = re({
                                    license: f.license,
                                    group: f.group,
                                    pageUrl: f.page.url,
                                    form: (a = c.properties, ne(te(a))),
                                    answers: l
                                });
                                n = "production", r = j, p = Object(X.a)("https://api." + ("labs" === n ? "labs." : "") + "helpdesk.com/v1/externalTickets", {
                                    method: "POST",
                                    headers: {
                                        "Content-Type": "application/json"
                                    },
                                    body: JSON.stringify(r)
                                }).then((function(e) {
                                    return e.ok ? e.json() : Promise.reject()
                                })).then((function(e) {
                                    return {
                                        id: e.ID
                                    }
                                })), m = function(e) {
                                    return function(e, t) {
                                        var n = t.requester,
                                            r = t.message,
                                            i = t.subject,
                                            o = r.text,
                                            a = n.name,
                                            c = n.email;
                                        return Object(g.a)({
                                            id: e,
                                            text: o
                                        }, i && {
                                            subject: i
                                        }, {
                                            visitor: {
                                                name: a || null,
                                                email: c || null
                                            }
                                        })
                                    }(e.id, j)
                                }, y = z.j;
                                break;
                            case "offline_message":
                                var x = Oe(c, u).filledForm;
                                p = Le({
                                    customerStartingEvent: x,
                                    group: f.group
                                }), m = function(e) {
                                    var t, n, r = Object(b.o)((function(e) {
                                        return "subject" === e.type
                                    }), x.fields);
                                    return Object(g.a)({
                                        id: e.thread,
                                        text: ot(x),
                                        visitor: {
                                            name: (null == (t = Object(b.o)((function(e) {
                                                return "name" === e.type
                                            }), x.fields)) ? void 0 : t.answer) || null,
                                            email: (null == (n = Object(b.o)((function(e) {
                                                return "email" === e.type
                                            }), x.fields)) ? void 0 : n.answer) || null
                                        }
                                    }, (null == r ? void 0 : r.answer) && {
                                        subject: r.answer
                                    })
                                }, y = function(e, t, n) {
                                    n()
                                };
                                break;
                            default:
                                var C = Oe(c, u).filledForm,
                                    I = (new Intl.DateTimeFormat).resolvedOptions().timeZone;
                                p = i.sendTicketForm({
                                    filledForm: C,
                                    groupId: f.group,
                                    timeZone: "string" !== typeof I || /^Etc\//.test(I) || -1 === I.indexOf("/") && "UTC" !== I ? null : I
                                }), m = function(e) {
                                    var t, n, r = Object(b.o)((function(e) {
                                        return "subject" === e.type
                                    }), C.fields);
                                    return Object(g.a)({
                                        id: e.id,
                                        text: e.text,
                                        visitor: {
                                            name: (null == (t = Object(b.o)((function(e) {
                                                return "name" === e.type
                                            }), C.fields)) ? void 0 : t.answer) || null,
                                            email: (null == (n = Object(b.o)((function(e) {
                                                return "email" === e.type
                                            }), C.fields)) ? void 0 : n.answer) || null
                                        }
                                    }, (null == r ? void 0 : r.answer) && {
                                        subject: r.answer
                                    })
                                }, y = function(e, t, n) {
                                    e && "VALIDATION" === e.code ? /name must be at most \d+ characters long/.test(e.message) ? n({
                                        name: e.message
                                    }) : "mail must be a valid e-mail address" !== e.message ? n() : n({
                                        email: t("invalid_email")
                                    }) : n()
                                }
                        }
                        p.then((function(n) {
                            var r = c.properties.fields;
                            ! function(e, t, n, r) {
                                var i = r.id,
                                    o = r.text,
                                    a = r.visitor,
                                    c = a.email,
                                    u = a.name,
                                    s = r.subject,
                                    d = {
                                        form_data: Ke(t, n),
                                        ticket_id: i,
                                        text: o,
                                        visitor_name: u,
                                        visitor_email: c
                                    };
                                s && (d.ticket_subject = s), e.emit("on_ticket_created", d)
                            }(t, r, l, m(n)), e.resolve(), Object(z.M)(t, e.id), t.setCurrentView("Chat")
                        }), (function(n) {
                            y(n, t.localize, e.reject)
                        }))
                    } else if ("prechat" === c.properties.formType) {
                        var S = e.data.properties.answers,
                            T = c.properties.fields;
                        ! function(e, t, n) {
                            Ze(e, "prechat", t, n)
                        }(t, T, ce(T, S).fields);
                        var k = Oe(c, S),
                            L = k.filledForm,
                            P = k.choosenGroup,
                            R = function(t) {
                                switch (t.code) {
                                    case "SERVICE_UNAVAILABLE":
                                        return void q({
                                            withSystemMessage: !0
                                        });
                                    case "GROUPS_OFFLINE":
                                        return void w().then(e.resolve, e.reject);
                                    case "CUSTOMER_BANNED":
                                    case "GROUP_NOT_FOUND":
                                        return void d();
                                    default:
                                        e.reject()
                                }
                            },
                            D = function() {
                                return Le({
                                    customerStartingEvent: L,
                                    agentFakeEvent: Object(M.f)(t, ie.d),
                                    group: P
                                }).then((function(e) {
                                    Me(e), t.setDefaultView("Chat", "timeline")
                                })).catch((function(e) {
                                    return R(e)
                                }))
                            };
                        if (void 0 !== P) return void
                        function(e, t) {
                            var n = t.groupId;
                            return Be(e, {
                                groupIds: [n]
                            }).then((function(e) {
                                return e[n]
                            }))
                        }(o, {
                            groupId: P
                        }).then((function(e) {
                            if ("not_found" === e) {
                                var t = new Error('Group "' + P + '" not found (most likely it has been removed).');
                                throw t.code = "GROUP_NOT_FOUND", t
                            }
                            return e
                        })).then((function(n) {
                            var r = t.getApplicationState().group;
                            if (t.setApplicationState({
                                    group: P
                                }), !("online" === n)) return Object(M.H)(t) ? void D().then((function() {
                                t.setApplicationState({
                                    availability: "offline"
                                })
                            }), R) : void Promise.all([Fe(o, P), r !== P && Ue(o, {
                                groupId: P
                            })].filter(Boolean)).then((function(e) {
                                var n = e[0],
                                    r = e[1];
                                n.enabled ? (Object(z.i)(t, "ticketForm", r && {
                                    mode: r
                                }), t.updateView("Chat/ticketForm", n.form)) : Object(z.g)(t, "ticketForm"), t.setApplicationState({
                                    availability: "offline"
                                })
                            }), (function(t) {
                                "CONNECTION_LOST" !== t.code ? d() : e.reject()
                            }));
                            D().catch(R)
                        }), (function(t) {
                            "CONNECTION_LOST" !== t.code ? d() : e.reject()
                        }));
                        D()
                    } else if ("postchat" === c.properties.formType) {
                        var B = e.data.properties.answers,
                            N = c.properties.fields;
                        ! function(e, t, n) {
                            Ze(e, "postchat", t, n)
                        }(t, N, ce(N, B).fields);
                        var V = Oe(c, B).filledForm;
                        i.sendEvent({
                            chatId: Object(M.b)(t),
                            event: V,
                            attachToLastThread: !0
                        }).then((function(n) {
                            e.resolve(), Object(z.M)(t, e.id, je(t, n)), "rating" in B ? function(e, t) {
                                var n = _(t),
                                    r = e.getApplicationState().testGroup;
                                if (n.score === et && n.comment === et) return Promise.resolve(null);
                                Object(O.b)({
                                    testGroup: r,
                                    chatRating: n.score === $e ? "canceled" : t.rating,
                                    chatRatingSource: "postchat"
                                });
                                var i = [];
                                return n.score === tt && n.comment === tt ? (i.push(v(t)), Xe(e, t.rating), Je(e, t.rateComment)) : n.score === $e && n.comment === $e ? i.push(h(["comment", "score"])) : (n.score === $e ? i.push(h(["score"])) : n.score === tt && (i.push(v({
                                    rating: t.rating
                                })), Xe(e, t.rating)), n.comment === $e ? i.push(h(["comment"])) : n.comment === tt && (i.push(v({
                                    rateComment: t.rateComment
                                })), Je(e, t.rateComment))), Promise.all(i.map((function(e) {
                                    return e.catch(b.V)
                                })))
                            }(t, B).finally((function() {
                                return E(t)
                            })) : E(t)
                        })).catch((function(n) {
                            if (n.message === ie.c) return Object(z.z)(t, ie.d, {
                                forced: !0
                            }), lt(yt()).then((function(e) {
                                return gt(e)
                            }));
                            e.reject()
                        }))
                    } else if ("ask_for_email" === c.properties.formId) {
                        var F = e.data.properties.answers,
                            U = Oe(c, F).filledForm;
                        i.sendEvent({
                            chatId: Object(M.b)(t),
                            event: U,
                            attachToLastThread: !0
                        }).then((function(t) {
                            e.resolve(), A(t)
                        })).catch((function() {
                            return e.reject()
                        }))
                    }
                })), t.on("request_customer_token", (function() {
                    o.sdk.auth.getToken().then((function(e) {
                        return t.emit("customer_token_response", e)
                    })).catch((function(e) {
                        return t.emit("customer_token_error", e)
                    }))
                })), t.on("request_update_user", (function(e) {
                    var n = e.resolve,
                        r = e.id,
                        o = e.data,
                        a = o.properties,
                        c = Object(y.a)(o, ["properties"]);
                    if (t.getSessionUserId() === r) {
                        if (Object(M.G)(t)) {
                            var u = Object(b.f)({
                                name: c.name,
                                email: c.email,
                                sessionFields: a
                            });
                            i.updateCustomer(u).catch((function(e) {
                                return Object(O.c)("update_customer_request_failed", e)
                            }))
                        }
                        n()
                    }
                })), t.on("request_set_user_properties", (function(e) {
                    var n = e.resolve,
                        r = e.id,
                        o = e.properties;
                    t.getSessionUserId() === r && (Object(M.G)(t) && i.setCustomerSessionFields({
                        sessionFields: o
                    }).catch(b.V), n())
                }));
                var xe = function(e, n) {
                        var r = n.id,
                            i = n.timestamp,
                            o = n.threadId;
                        Qe(t, e, i), t.setEventServerId(ie.d, e.id, r), t.updateEvent(ie.d, e.id, {
                            delivered: !0,
                            serverTimestamp: i,
                            thread: o
                        })
                    },
                    Ee = function(e) {
                        t.updateEvent(ie.d, e.id, {
                            failed: !0
                        })
                    };
                t.on("send_file_events", (function() {
                    t.setApplicationState({
                        isSendingFileEvents: !0
                    });
                    var e = [].concat(Object(M.j)(t));
                    e.filter((function(e) {
                        return e.properties.failed
                    })).forEach((function(e) {
                        return t.updateEvent(ie.d, e.id, {
                            properties: {
                                canceled: !0
                            }
                        })
                    }));
                    var n = e.filter((function(e) {
                        var t = e.type,
                            n = e.delivered,
                            r = e.properties,
                            i = r.canceled,
                            o = r.finished;
                        return "file" === t && !n && !i && o
                    })).map((function(e) {
                        return i.sendEvent({
                            chatId: Object(M.b)(t),
                            event: {
                                type: "file",
                                customId: e.id,
                                url: e.properties.serverUrl,
                                alternativeText: e.properties.alternativeText
                            }
                        }).then((function(n) {
                            t.updateEvent(ie.d, e.id, {
                                delivered: !0
                            }), A(n), Promise.resolve().then((function() {
                                "image" === e.properties.fileType && URL.revokeObjectURL(e.properties.url)
                            }));
                            var r = e.properties.uploadSource;
                            ("clipboard" === r || Math.random() < .1) && Object(O.d)("file_upload_sent", {
                                uploadSource: r
                            })
                        }))
                    }));
                    Promise.all(n).finally((function() {
                        t.setApplicationState({
                            isSendingFileEvents: !1
                        })
                    }))
                }));
                var Se = {};
                t.on("cancel_upload", (function(e) {
                    var n = e.eventId,
                        r = t.getEvent(ie.d, n);
                    t.updateEvent(ie.d, n, {
                        properties: {
                            canceled: !0
                        }
                    }), Se[n] && Se[n].cancel(), Promise.resolve().then((function() {
                        "image" === r.properties.fileType && URL.revokeObjectURL(r.properties.url)
                    }))
                }));
                var ze = function(e) {
                        var n = e.event,
                            r = e.meta;
                        if ("file" === n.type) {
                            var o = i.uploadFile({
                                file: r.file,
                                onProgress: function(e) {
                                    return t.updateEvent(ie.d, n.id, {
                                        properties: {
                                            progress: e
                                        }
                                    })
                                }
                            });
                            return Se[n.id] = o, o.promise.then((function(e) {
                                var r = e.url;
                                t.updateEvent(ie.d, n.id, {
                                    properties: {
                                        serverUrl: r,
                                        finished: !0
                                    }
                                })
                            }), (function(e) {
                                "UPLOAD_CANCELED" !== e.code && t.updateEvent(ie.d, n.id, {
                                    properties: {
                                        failed: !0,
                                        failReason: ct(t, e)
                                    }
                                })
                            })).finally((function() {
                                delete Se[n.id]
                            }))
                        }
                        if (Object(b.D)(n.type, ["message", "emoji"])) return i.sendEvent({
                            chatId: Object(M.b)(t),
                            event: ke(t, n)
                        }).then((function(e) {
                            xe(n, e)
                        }), (function() {
                            Ee(n)
                        }));
                        if ("custom_system_message" === n.type) return i.sendEvent({
                            chatId: Object(M.b)(t),
                            event: ke(t, n)
                        }).then(A, b.V);
                        if ("rich_message_postback" === n.type) {
                            var a = n.properties,
                                c = a.eventId,
                                u = a.postback;
                            return i.sendRichMessagePostback({
                                chatId: Object(M.b)(t),
                                threadId: t.getEvent(ie.d, c).thread,
                                eventId: c,
                                postback: u
                            }).catch(b.V)
                        }
                        if ("url_preview" === n.type) {
                            var s = i.getUrlInfo({
                                url: n.properties.url
                            }).catch((function() {
                                return null
                            }));
                            return i.sendEvent({
                                chatId: Object(M.b)(t),
                                event: ke(t, n)
                            }).then((function(e) {
                                xe(n, e), s.then((function(r) {
                                    var o = r.title,
                                        a = r.description,
                                        c = r.url,
                                        u = r.imageUrl;
                                    return t.updateEvent(ie.d, n.id, {
                                        properties: {
                                            title: o,
                                            description: a,
                                            image: {
                                                url: u,
                                                link: c
                                            }
                                        }
                                    }), i.updateEventProperties({
                                        chatId: Object(M.b)(t),
                                        threadId: e.thread,
                                        eventId: e.id,
                                        properties: {
                                            url_details: {
                                                title: o,
                                                description: a,
                                                url: c,
                                                image_url: u,
                                                image_width: r.imageWidth,
                                                image_height: r.imageHeight
                                            }
                                        }
                                    })
                                })).catch(b.V)
                            }), (function() {
                                Ee(n)
                            }))
                        }
                    },
                    Me = function(e) {
                        var n = e.events,
                            r = Object(y.a)(e, ["events"]),
                            i = t.getSessionUser().id;
                        n.forEach((function(e) {
                            t.getEvent(ie.d, e.id) ? e.author === i ? function(e, t) {
                                var n = t.timestamp;
                                "message" === t.properties.serverType && Qe(e, t, n), e.setEventServerId(ie.d, t.id, t.serverId);
                                var r = {
                                    delivered: !0,
                                    serverTimestamp: n,
                                    thread: t.thread
                                };
                                "form" === t.type && (r.properties = {
                                    answered: !0,
                                    fields: t.properties.fields
                                }), e.updateEvent(ie.d, t.id, r)
                            }(t, e) : e.properties.welcomeMessage || e.properties.invitation ? function(e, t) {
                                var n = Object(M.f)(e, ie.d);
                                e.setEventServerId(ie.d, n.id, t.serverId);
                                var r = n.author !== t.author;
                                r && e.setEventData(ie.d, n.id, {
                                    author: t.author
                                });
                                var i = {
                                    delivered: !0,
                                    thread: t.thread,
                                    serverTimestamp: t.timestamp,
                                    properties: {}
                                };
                                n.properties.text !== t.properties.text && (i.properties.text = t.properties.text), e.updateEvent(ie.d, n.id, i), r && (Object(z.D)(e, t.author), e.recalculateTimeline(ie.d))
                            }(t, e) : k(e) : k(e)
                        })), f(Object(g.a)({}, r, {
                            events: []
                        }))
                    },
                    Le = function e(n) {
                        return t.updateChat(ie.d, {
                            properties: {
                                starting: !0
                            }
                        }), Re(o, n).then((function(e) {
                            return t.updateChat(ie.d, {
                                properties: {
                                    starting: !1
                                }
                            }), e
                        }), (function(r) {
                            if (r.message === ie.c) return Object(z.z)(t, ie.d, {
                                forced: !0
                            }), e(n);
                            throw t.updateChat(ie.d, {
                                properties: {
                                    starting: !1
                                }
                            }), r
                        }))
                    },
                    Ne = [],
                    He = function(e) {
                        if (Object(M.F)(ie.d, t)) Ne.push(e);
                        else {
                            var n = function() {
                                Object(M.ab)(t) && Object(z.c)(t)
                            };
                            t.getChat(ie.d).active ? e && ze(e).then(n) : Le(Object(g.a)({}, e && {
                                customerStartingEvent: e.event
                            }, {
                                agentFakeEvent: Object(M.f)(t, ie.d)
                            })).then((function(e) {
                                Me(e);
                                var t = Ne;
                                Ne = [], t.forEach(ze), n()
                            }), (function(n) {
                                t.updateEvent(ie.d, e.event.id, {
                                    failed: !0
                                });
                                var r = Ne;
                                switch (Ne = [], r.forEach((function(e) {
                                    t.updateEvent(ie.d, e.id, {
                                        failed: !0
                                    })
                                })), n.code) {
                                    case "SERVICE_UNAVAILABLE":
                                        return void q({
                                            withSystemMessage: !0
                                        });
                                    case "CUSTOMER_BANNED":
                                        return void d();
                                    case "GROUPS_OFFLINE":
                                        return void w();
                                    default:
                                        return
                                }
                            }))
                        }
                    };
                t.on("start_thread", He), t.on("send_event", He), t.on("request_cancel_greeting", (function(e) {
                    Object(M.W)(t, "maximized") && Object(z.v)(t), i.cancelGreeting({
                        uniqueId: e
                    })
                }));
                var dt = function(e) {
                        return Le({
                            agentFakeEvent: e
                        }).then((function(e) {
                            return [{
                                type: "hide_ticket_form"
                            }, {
                                type: "chat_activated",
                                payload: e
                            }]
                        }), (function(e) {
                            switch (e.code) {
                                case "WIDGET_DESTROYED":
                                case "CHAT_ALREADY_ACTIVE":
                                case "CHAT_LIMIT_REACHED":
                                    return {
                                        type: "nothing"
                                    };
                                case "GROUPS_OFFLINE":
                                    return Fe(o, t.getApplicationState("group")).then((function(e) {
                                        return e.enabled ? {
                                            type: "nothing"
                                        } : {
                                            type: "show_ticket_form",
                                            payload: e.form
                                        }
                                    }));
                                case "CUSTOMER_BANNED":
                                default:
                                    return {
                                        type: "panic"
                                    }
                            }
                        }))
                    },
                    lt = function(e) {
                        var n = e.active,
                            r = e.availability,
                            i = e.connected,
                            a = e.hasFakeAgentMessage,
                            c = e.startChatAgainPending,
                            u = e.limitReached,
                            s = e.hasMutedGreeting;
                        return Object(J.a)((function() {
                            return u || n ? {
                                type: "nothing"
                            } : "offline" === r ? Object(M.H)(t) ? c && Object(M.S)(t) ? {
                                type: "show_prechat"
                            } : {
                                type: "nothing"
                            } : Object(M.T)(t) ? Object(M.w)(t) ? {
                                type: "nothing"
                            } : {
                                type: "show_ticket_form"
                            } : {
                                type: "hide_prechat_form"
                            } : s ? {
                                type: "accept_muted_greeting"
                            } : a ? {
                                type: "hide_ticket_form"
                            } : Object(M.W)(t, "maximized") ? Object(M.S)(t) ? {
                                type: "show_prechat"
                            } : !i || st.acceptingGreeting ? {
                                type: "nothing"
                            } : (st.requestingPredictedWelcomeMessage = !0, le.then((function() {
                                return function(e) {
                                    var t = e.sdk,
                                        n = e.store;
                                    return t.getPredictedAgent().then((function(e) {
                                        var t, r = e.agent,
                                            i = e.queue,
                                            o = n.localize("welcome_to_chat");
                                        return {
                                            agent: r,
                                            groupHasQueue: i,
                                            message: oe.c((t = {
                                                id: Object(b.w)(n.getIndexedEvents(ie.d)),
                                                type: "message",
                                                authorId: r.id,
                                                text: Object(j.i)(n, o, {
                                                    agent: r.name
                                                }),
                                                originalText: o,
                                                welcomeMessage: !0
                                            }, Object(g.a)({}, t, {
                                                serverId: null,
                                                timestamp: Date.now(),
                                                seen: !0,
                                                properties: t.properties || {}
                                            })))
                                        }
                                    }))
                                }(o)
                            })).then((function(e) {
                                var t = e.agent,
                                    n = e.message,
                                    r = e.groupHasQueue;
                                return st.requestingPredictedWelcomeMessage = !1, t.isBot ? dt(n) : [{
                                    type: "hide_ticket_form"
                                }, {
                                    type: "predicted_welcome_message",
                                    payload: {
                                        agent: t,
                                        message: n,
                                        groupHasQueue: r
                                    }
                                }]
                            }), (function(e) {
                                if (st.requestingPredictedWelcomeMessage = !1, "offline" === t.getApplicationState("availability")) return {
                                    type: "nothing"
                                };
                                switch (e.code) {
                                    case "GROUP_UNAVAILABLE":
                                        return dt();
                                    case "GROUP_OFFLINE":
                                        return {
                                            type: "nothing"
                                        };
                                    default:
                                        return {
                                            type: "panic"
                                        }
                                }
                            }))) : {
                                type: "nothing"
                            }
                        })).then(b.l)
                    },
                    ft = function() {
                        var e = t.getChat(ie.d);
                        return (!e.active || e.properties.queued) && !e.properties.starting && !e.properties.ended
                    },
                    pt = function() {
                        t.updateView("minimized", {
                            hidden: !1
                        })
                    };
                Object(P.y)(se, Object(P.j)(pt));
                var mt = Object(P.y)(Object(D.c)(t, (function(e) {
                    return e.application.destroyed
                })), Object(P.i)(Boolean), Object(P.F)(1), P.z);
                Object(P.y)(ae, Object(P.F)(1), Object(P.s)((function() {
                    var e = Object(G.a)(Object(b.cb)(["license", "group", "requestedGroup"], t.getApplicationState()));
                    return [Object(rt.b)("session") && window.sessionStorage.getItem(e), e]
                })), Object(P.i)((function(e) {
                    var t = e[0];
                    return Boolean(t)
                })), Object(P.j)((function(e) {
                    var n = e[0],
                        r = e[1];
                    ! function(e) {
                        var n, r = p();
                        try {
                            n = JSON.parse(e)
                        } catch (i) {
                            return
                        }
                        n && r && n.forEach((function(e) {
                            t.getEvent(ie.d, e.id) || Object(z.d)(t, ie.d, {
                                thread: r,
                                id: e.id,
                                type: "file",
                                own: !0,
                                author: t.getSessionUser().id,
                                delivered: !1,
                                failed: !1,
                                properties: e
                            })
                        }))
                    }(n), window.sessionStorage.removeItem(r)
                })));
                var vt = Object(P.y)(Object(D.c)(t, (function(e) {
                        return e.application.availability
                    })), Object(P.B)(1), P.A, Object(P.s)((function(e) {
                        return {
                            type: e
                        }
                    })), Object(P.x)((function(e) {
                        return "online" === e.type
                    }))),
                    bt = vt[0],
                    ht = vt[1];
                Object(P.y)(ue((function() {
                    return ht
                })), Object(P.i)(ft), Object(P.j)((function() {
                    !Object(M.L)(t, "prechat") && Object(M.H)(t) && Object(M.S)(t) && "offline" === t.getApplicationState().availability && !t.getChat(ie.d).active && Object(z.H)(t), Object(M.L)(t, "prechat") && (Object(z.x)(t), Object(M.H)(t) && Object(z.H)(t)), s()
                }))), Object(P.y)(bt, Object(P.i)(ft), Object(P.j)((function() {
                    t.getView("minimized").hidden && pt(), !Object(M.T)(t) && Object(M.Q)(t) && Object(M.W)(t, "hidden") && Object(z.v)(t)
                }))), Object(P.y)(ue((function() {
                    if (!Object(M.S)(t)) return P.u;
                    var e = Object(D.c)(t, (function() {
                        return Object(M.L)(t, "prechat")
                    }));
                    return Object(P.y)(Object(P.t)(se, e), Object(P.i)((function() {
                        return Object(M.L)(t, "prechat")
                    })), Object(P.E)((function() {
                        var e = t.getLastEvent(ie.d);
                        return Object(P.y)(Object(P.o)(function(e, t) {
                            var n = Object(b.p)((function(e) {
                                return "groupSelect" === e.meta
                            }), t);
                            if (-1 === n) return Promise.resolve(null);
                            var r = t[n],
                                i = r.options.map((function(e) {
                                    return e.groupId
                                }));
                            return i.length > 20 ? Promise.resolve(null) : Be(e, {
                                groupIds: i
                            }).then((function(e) {
                                return Object(b.Ab)(n, Object(g.a)({}, r, {
                                    options: r.options.map((function(t) {
                                        return Object(g.a)({}, t, {
                                            meta: {
                                                online: "online" === e[t.groupId]
                                            }
                                        })
                                    }))
                                }), t)
                            }))
                        }(o, e.properties.fields)), P.q)
                    })))
                })), Object(P.i)((function(e) {
                    return e && Object(M.L)(t, "prechat")
                })), Object(P.j)((function(e) {
                    var n = t.getLastEvent(ie.d).id;
                    return t.updateEvent(ie.d, n, {
                        properties: {
                            fields: e
                        }
                    })
                })));
                var gt = function(e) {
                        return e.forEach((function(e) {
                            switch (e.type) {
                                case "panic":
                                    return void d();
                                case "chat_activated":
                                    return void Me(e.payload);
                                case "predicted_welcome_message":
                                    var n = e.payload,
                                        r = n.agent,
                                        i = n.message,
                                        a = n.groupHasQueue;
                                    return S(r), Object(z.D)(t, r.id), k(i), void t.updateChat(ie.d, {
                                        properties: {
                                            fakeAgentMessageId: i.id,
                                            groupHasProbableQueue: a
                                        }
                                    });
                                case "show_ticket_form":
                                    return e.payload && t.updateView("Chat/ticketForm", e.payload), void Object(z.I)(t);
                                case "hide_prechat_form":
                                    return void Object(z.x)(t);
                                case "hide_ticket_form":
                                    return void(Object(M.L)(t, "ticket") && (Object(z.y)(t), t.setDefaultView("Chat", "timeline")));
                                case "show_prechat":
                                    return void Object(z.H)(t);
                                case "accept_muted_greeting":
                                    return void
                                    function() {
                                        var e = t.getLastEvent(ie.d),
                                            n = t.getChat(ie.d).properties.mutedGreeting;
                                        t.updateEvent(ie.d, e.id, {
                                            seen: !0
                                        }), st.acceptingGreeting = !0, Pe(o, n).then((function(e) {
                                            var n = e.event;
                                            t.updateChat(ie.d, {
                                                properties: {
                                                    mutedGreeting: void 0
                                                }
                                            }), Object(z.u)(t, n)
                                        }), b.V).finally((function() {
                                            st.acceptingGreeting = !1
                                        }))
                                    }();
                                default:
                                    return
                            }
                        }))
                    },
                    yt = function() {
                        var e = t.getChat(ie.d);
                        return {
                            active: e.active,
                            availability: t.getApplicationState("availability"),
                            connected: Object(M.G)(t),
                            hasFakeAgentMessage: Object(M.z)(t, ie.d),
                            startChatAgainPending: e.properties.startChatAgainPending,
                            limitReached: t.getApplicationState("limitReached"),
                            hasMutedGreeting: !!e.properties.mutedGreeting
                        }
                    };
                Object(P.y)(ue((function() {
                    return Object(P.y)(Object(D.c)(t, (function() {
                        return t.getChat(ie.d).properties.startChatAgainPending
                    })), Object(P.i)(Boolean))
                })), Object(P.E)((function() {
                    return Object(P.o)(lt(yt()))
                })), Object(P.j)((function(e) {
                    Object(z.z)(t, ie.d, {
                        chatId: t.getChat(ie.d).serverId
                    }), gt(e)
                }))), Object(P.y)(Object(P.t)(se, bt, ht), Object(P.g)(ae), Object(P.i)((function() {
                    return ft() && t.getApplicationState().eagerFetchingMode
                })), Object(P.h)((function() {
                    return Object(P.o)(lt(yt()))
                })), Object(P.G)(mt), Object(P.j)(gt)), Object(P.y)(ue((function() {
                    return Object(P.y)(se, Object(P.i)((function() {
                        return !t.getApplicationState().eagerFetchingMode
                    })))
                })), Object(P.E)((function() {
                    var e = t.getChat(ie.d).serverId;
                    return Object(P.o)(Promise.all([lt(yt()), Object(M.E)(t) && e && Ye(o, e)].filter(Boolean)))
                })), Object(P.G)(mt), Object(P.j)((function(e) {
                    var n = e[0],
                        r = e[1];
                    if (Object(z.a)(t), r) {
                        l(t.getChat(ie.d).serverId, r.iterator), $(r.hasMore);
                        var i = Object(b.s)((function(e) {
                            return e.events
                        }), r.threads).filter((function(e) {
                            return !t.hasEvent(ie.d, e.id)
                        }));
                        i.length > 0 && t.addHistoryEvents(ie.d, i), t.updateChat(ie.d, {
                            properties: {
                                lastThread: r.threads.length ? Object(b.M)(r.threads).id : null,
                                eventsSeenUpToMap: r.eventsSeenUpToMap
                            }
                        })
                    }
                    t.setApplicationState({
                        eagerFetchingMode: !0
                    }), gt(n)
                }))), Object(P.y)(Object(D.c)(t, (function(e) {
                    return e.application.page
                })), Object(P.B)(1), Object(P.G)(mt), Object(P.j)((function(e) {
                    var t = e.url,
                        n = e.title;
                    i.updateCustomerPage({
                        url: t,
                        title: n
                    })
                })))
            },
            lt = function(e) {
                return e.some(b.C)
            },
            ft = n(230),
            pt = n(128),
            mt = n(92),
            vt = n(159);

        function bt(e, t, r, i) {
            var o = t.adapterOptions,
                a = t.props,
                c = a.onError,
                u = void 0 === c ? b.V : c,
                s = Object(y.a)(a, ["onError"]),
                d = t.onBootstrap,
                l = void 0 === d ? b.V : d;
            Promise.resolve(E.a && Promise.all([n.e(1), n.e(6), n.e(5)]).then(n.bind(null, 752))).then((function(t) {
                dt(o, e, r);
                e.on("set_application_state", (function n(r) {
                    if (r.readyState !== at.a.NOT_READY) {
                        window.performance && "function" === typeof window.performance.mark && window.performance.mark("lc_sdk_ready"), e.off("set_application_state", n), e.getApplicationState("embedded") || function(e) {
                                Object(P.y)(Object(D.c)(e, (function() {
                                    return e.localize("welcome_title")
                                })), Object(P.j)((function(e) {
                                    document.title = e
                                })))
                            }(e), e.getApplicationState("embedded") && !Object(pt.b)() || Object(ft.b)(e), Object(mt.a)(e), Object(O.a)(e),
                            function(e, t) {
                                var n = Object(P.y)(Object(P.p)(), P.z);
                                if (t) {
                                    var r = Object(P.n)(t);
                                    Object(P.y)(n, Object(P.j)((function(n) {
                                        e.setApplicationState({
                                            applicationFocused: n
                                        }), t.emit("focus", n)
                                    }))), Object(P.y)(Object(P.b)(n, r), Object(P.d)(50), Object(P.s)(lt), Object(P.f)(), Object(P.j)((function(t) {
                                        e.setApplicationState({
                                            pageFocused: t
                                        })
                                    })))
                                } else Object(P.y)(n, Object(P.j)((function(t) {
                                    e.setApplicationState({
                                        pageFocused: t,
                                        applicationFocused: t
                                    })
                                })))
                            }(e, i), t && t.connect(e);
                        var o = document.getElementById("root");
                        Object(vt.b)(o, Object(g.a)({}, s, {
                            onError: function(e, t) {
                                var n = t.componentStack;
                                Object(O.c)("react_error", e, {
                                    componentStack: n
                                }), W.render(null, o), u()
                            },
                            store: e,
                            amplitude: t
                        })), window.performance && "function" === typeof window.performance.mark && window.performance.mark("lc_bootstrap_end"), l(e)
                    }
                }))
            }))
        }
        var ht = n(148),
            gt = function(e, t, n, r) {
                var i = e.getApplicationState("visibility");
                return r && "maximized" !== i.state ? {
                    state: "hidden",
                    forced: !0
                } : n ? {
                    state: "maximized"
                } : t ? {
                    state: "minimized"
                } : i
            };

        function yt(e, t) {
            var n = e.license,
                r = e.group,
                i = e.uniqueGroups,
                o = e.isIdentityProviderEnabled,
                a = Object(A.a)({
                    application: {
                        license: n,
                        group: r
                    }
                }, {
                    persistKey: Object(G.a)(e)
                }),
                c = function(e) {
                    return {
                        hide: function() {
                            Object(M.W)(e, "hidden") || e.setApplicationState({
                                visibility: {
                                    state: "hidden",
                                    forced: !0
                                }
                            })
                        },
                        hideGreeting: function() {
                            Object(z.q)(e)
                        },
                        hideEyeCatcher: function() {
                            Object(z.p)(e)
                        },
                        isFocused: function() {
                            return !!document.hasFocus && document.hasFocus()
                        },
                        maximize: function(t) {
                            var n = (void 0 === t ? {} : t).modality;
                            n && e.emit("set_host_modality", n), e.setApplicationState({
                                visibility: {
                                    state: "maximized"
                                }
                            })
                        },
                        minimize: function() {
                            e.setApplicationState({
                                visibility: {
                                    state: Object(M.Q)(e) ? "minimized" : "hidden"
                                }
                            })
                        },
                        startStateSync: function() {
                            e.startStateSync(this)
                        },
                        storeMethod: function(t) {
                            var n = t[0],
                                r = t.slice(1);
                            e[n].apply(e, r)
                        },
                        logInfo: function() {
                            O.d.apply(void 0, arguments)
                        },
                        logError: function() {
                            O.c.apply(void 0, arguments)
                        },
                        logNotice: function() {
                            O.e.apply(void 0, arguments)
                        }
                    }
                }(a);
            new k.Model(c).then((function(e) {
                return Promise.all([e, a.syncing()])
            })).then((function(e) {
                var c = e[0];
                window.performance && "function" === typeof window.performance.mark && window.performance.mark("lc_postmate_ready");
                var u = c.model,
                    s = u.clientLimitExceeded,
                    d = u.customer,
                    l = u.requestedGroup,
                    f = u.hidden,
                    p = u.integrationName,
                    m = u.isInCustomContainer,
                    v = u.page,
                    b = u.region,
                    h = u.serverConfig,
                    y = u.actingAsDirectLink,
                    O = a.getApplicationState("mobile"),
                    j = y || m,
                    _ = h.__unsafeProperties.group.language;
                Object(G.c)(_), a.updateUser(a.getSessionUserId(), d), a.setApplicationState({
                    clientLimitExceeded: !a.getApplicationState("clientLimitExceededLifted") && s,
                    actingAsDirectLink: y,
                    embedded: !0,
                    region: b,
                    isInCustomContainer: m,
                    mobileWrapper: null,
                    page: v,
                    rtl: Object(G.b)(_),
                    language: _,
                    integrationName: p,
                    requestedGroup: l,
                    visibility: gt(a, O, j, f)
                });
                var w = {
                    onAnimationEnd: function() {
                        return a.emit("animation_end")
                    },
                    onError: function() {
                        c.call("kill")
                    },
                    onMinimizedRef: function(e) {
                        c.minimizedRef = e
                    },
                    onMinimizedResize: function() {
                        return U(c, a)
                    }
                };
                bt(a, {
                    adapterOptions: Object(g.a)({
                        license: n,
                        group: r,
                        requestedGroup: l,
                        region: b,
                        uniqueGroups: i,
                        mobile: Object(B.i)()
                    }, o && {
                        identityProvider: function() {
                            return {
                                getToken: function() {
                                    return c.call("callIdentityProvider", "getToken")
                                },
                                getFreshToken: function() {
                                    return c.call("callIdentityProvider", "getFreshToken")
                                },
                                hasToken: function() {
                                    return c.call("callIdentityProvider", "hasToken")
                                },
                                invalidate: function() {
                                    return c.call("callIdentityProvider", "invalidate")
                                }
                            }
                        }
                    }),
                    props: w,
                    onBootstrap: function() {
                        if (ht.a(c, a), j) return c.call("show"), void t(a);
                        H(c, a).then((function() {
                            "hidden" !== a.getApplicationState("visibility").state && c.call("show"), t(a)
                        }))
                    }
                }, h, c)
            }))
        }
        var Ot = n(127),
            jt = function(e, t) {
                var n = e.license,
                    r = e.group,
                    i = e.requestedGroup,
                    o = t.__unsafeProperties.group.language.language,
                    a = Object(A.a)({
                        application: {
                            license: n,
                            group: r,
                            requestedGroup: i,
                            region: t.region,
                            rtl: Object(G.b)(o),
                            language: o,
                            embedded: !1,
                            mobileWrapper: Object(mt.b)(),
                            page: {
                                title: document.title,
                                url: String(document.location),
                                referrer: document.referrer
                            }
                        }
                    }, {
                        persistKey: Object(G.a)(e)
                    }),
                    c = !a.getApplicationState().clientLimitExceededLifted && t.clientLimitExceeded;
                return a.setApplicationState({
                    visibility: {
                        state: "maximized"
                    },
                    clientLimitExceeded: c
                }), a.updateUser(a.getSessionUserId(), function() {
                    var e = Object(C.i)(window.location.search),
                        t = Object(b.fb)(["name", "email"], e);
                    return e.params && (t.properties = Object(b.P)((function(e) {
                        return String(e)
                    }), Object(C.b)(e.params))), t
                }()), a
            };

        function _t(e, t) {
            window.performance && "function" === typeof window.performance.mark && window.performance.mark("lc_config_request");
            var n, r = e.license,
                i = e.group;
            (n = {
                licenseId: r,
                groupId: i,
                url: Object(Ot.a)(String(document.location)),
                channelType: "direct_link"
            }, Object(ze.a)(n).then((function(e) {
                var t = e.groupId;
                return Promise.all([e, Object(ze.d)({
                    licenseId: n.licenseId,
                    groupId: t,
                    region: e.region,
                    version: e.configVersion
                })]).then((function(e) {
                    var t = e[0],
                        n = e[1];
                    return Object(g.a)({}, t, n)
                }))
            }))).then((function(n) {
                window.performance && "function" === typeof window.performance.mark && window.performance.mark("lc_server_config");
                var o = n.groupId,
                    a = n.region;
                Object(G.c)(n.__unsafeProperties.group.language);
                var c = jt(Object(g.a)({}, e, {
                    group: o,
                    requestedGroup: i
                }), n);
                Object(ze.b)({
                    licenseId: r,
                    region: a,
                    groupId: o,
                    version: n.localizationVersion,
                    language: n.__unsafeProperties.group.language
                }).then(c.setLocalization);
                var u = {
                    adapterOptions: Object(g.a)({}, e, {
                        group: o,
                        requestedGroup: i,
                        region: a,
                        mobile: Object(B.i)()
                    }),
                    props: {},
                    onBootstrap: t
                };
                Object(mt.c)() && (u.props.onMinimizeButtonPress = function() {
                    return c.emit("mobile_wrapper_minimize_intent")
                }), bt(c, u, n)
            }))
        }
        var wt = n(229),
            xt = n(158),
            Et = "first-paint",
            Ct = function(e, t) {
                if (!e || !t) return null;
                var n = Object(b.M)(e);
                return n ? Math.max(n.startTime + n.duration, t.startTime) : t.startTime
            },
            It = function() {
                if (!Math.floor(1e3 * Math.random())) {
                    var e = Object(wt.a)(Et);
                    return {
                        getLogs: function() {
                            return Promise.all([e, Object(xt.a)(Et)]).then((function(e) {
                                var t = e[0],
                                    n = e[1];
                                return Object(b.P)((function(e) {
                                    return e && Object(b.vb)(e, 2)
                                }), {
                                    totalBlockingTime: t && Object(b.qb)(t.map((function(e) {
                                        return e.duration
                                    }))),
                                    firstContentfulPaint: null == n ? void 0 : n.startTime,
                                    timeToInteractive: Ct(t, n)
                                })
                            }))
                        }
                    }
                }
            },
            St = Object(C.i)(window.location.search),
            Tt = Object(j.c)(),
            kt = Object(j.b)(St),
            At = Object(j.e)(),
            zt = "1" === St.custom_identity_provider;
        if (!Tt) throw new Error("No license found in the URL.");
        E.a && Promise.all([n.e(1), n.e(6), n.e(5)]).then(n.bind(null, 752)).catch(b.V),
            function() {
                var e = {
                        license: Tt,
                        group: kt,
                        uniqueGroups: At,
                        isIdentityProviderEnabled: zt
                    },
                    t = It(),
                    n = function(e) {
                        e.setApplicationState({
                            readyState: at.a.BOOTSTRAPPED
                        }), zt && Object(O.d)("custom_identity_provider_enabled", {}), t && t.getLogs().then((function(e) {
                            Object(O.d)("iframe_vitals", Object(b.f)(Object(g.a)({}, e, {
                                isEmbedded: !!St.embedded
                            })))
                        }))
                    };
                St.embedded ? yt(e, n) : _t(e, n)
            }()
    }],
    [
        [722, 13, 0, 3]
    ]
]);